create function           is_display
/**
    （新版）通过用户、货号判断商品是否显示(订货会商品、上架、暂下架状态商品)
    考虑以下信息：
    1、商品显示区域
    2、站点延后显示时间
    3、区域控货
    songwangwen
    2017-07-18
   显示规则
   
   reid 2018.12.26 私有平台商品也需要展示
   如果商品不是启用状态，直接返回，不显示 zhengfangyuan 2019.02.27
    返回值：1（显示）  0：不显示
**/
(
    c_user_name   varchar2,            --用户名
    c_product_itemnumber   varchar2    --商品货号
) return varchar2
 is
     v_id number:=0;                                --商品id
     v_sell_state_date date;                        --商品最后上架时间
     v_district_templet_id number:=0;               --商品显示区域模板id
     v_user_company_address_prov number:=0;         --用户经营地 省代码
     v_user_company_address_city number:=0;         --用户经营地 市代码
     v_site_id number:=0;                           --客户站点id
     v_flag number:=1;                              --是否显示   1（显示）  0：不显示 2:订货会商品
     v_stationed_user_id number:=0;                 --入驻商id
     v_month_statement number:=2;                   --入驻商是否支持月结  1、不支持月结   2、支持月结
     v_credit_money number:=0;                       --会员月结额度
     v_count number:=0;                       --临时变量
     v_exists number:=0;                            --是否存在临时变量
     
     v_user_type number:=0;                         --用户类型 1 用户会员 2 店铺会员 3店铺查看用户 4：游客 5：私有平台用户
begin
    
    --如果不是普通商品，直接返回，不显示   songwanwgen    2018.09.06
    --如果商品不是启用状态或者无启用状态的尺码，直接返回，不显示 zhengfangyuan 2019.02.27
    select count(1) into v_count  from tbl_product_info tpi where tpi.product_type in (0,3) and tpi.itemnumber = c_product_itemnumber and tpi.start_stop_state = 1
     and exists(
        select 1
        from tbl_product_sku
        where product_itemnumber = tpi.itemnumber
        and start_stop_state = 1
        and product_group = '尺码'
    );
    if v_count =0 then
        return 0;
    end if;
    
    --查询用户城市代码和站点
    select user_company_address_province,user_company_address_city,site_id,user_type into v_user_company_address_prov,v_user_company_address_city,v_site_id,v_user_type from tbl_user_info where user_name = c_user_name;
    
    if v_user_type in (1,2,3) then 

        /***********************************************订货会相关代码****begin*****wangpeng***2017-09-26****************************************************/
        --查询用户是否为订货会用户并且商品为订货会内的商品
        select count(1) into v_count from tbl_activity_info a,tbl_activity_detail a1,tbl_activity_product c 
        where a.id = a1.activity_id and a.id = c.activity_id and a.activity_type = '2'
        and a.activity_state = '3' and a.state = '2' and c.product_itemnumber = c_product_itemnumber
        and sysdate between c.activity_start_date and c.activity_end_date 
        and case 
           when (a1.user_group_id = 0 or a1.user_group_id is null)
               then 1
           else
               case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and a1.user_group_id = aa.id and  bb.user_id = c_user_name)
               then 
                   1
               else
                   0
               end
        end  = 1
        and exists (select 1 from tbl_activity_site tas where tas.activity_id = a.id and tas.site_id = v_site_id);
        if v_count>0 then 
            return 2;
        end if;   
        /***********************************************订货会相关代码****end*******wangpeng***2017-09-26**************************************************/  
     end if;      
    select count(1) into v_count from tbl_product_info where itemnumber = c_product_itemnumber and (state = '上架' or state = '暂下架');
    if v_count<1 then 
        return 0;
    end if; 
    --查询商品id和上架时间,区域模板
    select id,sell_state_date,district_templet_id,stationed_user_id into v_id,v_sell_state_date,v_district_templet_id,v_stationed_user_id from tbl_product_info where itemnumber = c_product_itemnumber and (state = '上架' or state = '暂下架');


    --查询入驻商是否支持月结
    select month_statement into v_month_statement from tbl_stationed_user_info where id = v_stationed_user_id;

    --查询会员月结额度
    select credit_money into v_credit_money from tbl_bank_account where user_id = c_user_name;

    --有月结额度  并且  不支持 授信支付  则不显示商品
    if v_credit_money!=0 and  v_month_statement=1 then
        v_flag:=0;
    end if;

    if v_flag !=0 then
        --查询商品是否在站点显示
        select count(1) into v_flag from tbl_site_product_delay where site_id = v_site_id and product_id = v_id and v_sell_state_date+delay_days<=sysdate;
    end if;

    if v_user_type in (1,2,5) then 
        if v_flag !=0 then
            --填写了省市信息
            if v_user_company_address_prov is not null and v_user_company_address_prov != 0 and v_user_company_address_city is not null and v_user_company_address_city != 0  then 
                --查询商品是否在用户区域显示
                select count(1) into v_flag from tbl_district_templet_rel where template_id = v_district_templet_id and (region_id = v_user_company_address_prov or region_id = v_user_company_address_city);
            end if;
        end if;
    end if;

    if v_flag !=0 then
        v_flag := 1;
    end if;
    
    if v_user_type in (1,2) then 
        /**********************进行区域控货的判断*****begin***************************/
       --全部控货的过滤处理
       select count(1) into v_count
         from tbl_product_info tpi,mv_user_product_control_detail vupc
        where tpi.itemnumber = c_product_itemnumber
          and vupc.user_id = c_user_name
          and vupc.product_control_mode = '1'
          and vupc.product_control_brand = tpi.brand_id
                          ;
       --当前商品在控货范围内
       if v_count > 0 then
          v_flag := 0;
       else
         --根据货号校验被控货人是否是最小下单时间
         select count(1) into v_exists
           from (select itemnumber,order_date from mv_order_product_control where control_user_id = c_user_name and itemnumber = c_product_itemnumber) a,
                (select itemnumber,order_date from mv_order_product_control where user_id = c_user_name and itemnumber = c_product_itemnumber) b
          where a.itemnumber = b.itemnumber;
         if v_exists > 0 then
            --下单控货的过滤处理
             select count(1) into v_count
               from tbl_product_info tpi,mv_user_product_control_detail vupc,mv_user_order_product tops,
           (select case when a.order_date < b.order_date then a.itemnumber
              else '1' end itemnumber from (select itemnumber,order_date from mv_order_product_control where control_user_id = c_user_name and itemnumber = c_product_itemnumber) a,
                (select itemnumber,order_date from mv_order_product_control where user_id = c_user_name and itemnumber = c_product_itemnumber) b
                where a.itemnumber = b.itemnumber) t
              where tpi.itemnumber = c_product_itemnumber
                    and vupc.product_control_mode = '2'
                    and vupc.user_id = c_user_name
                    and vupc.product_control_brand = tpi.brand_id
                    and tops.user_id = vupc.control_user_id
                    and tops.itemnumber = tpi.itemnumber
                    --过滤被控货人可以看的商品 yejingquan 2019.05.31
                    and tpi.itemnumber != t.itemnumber;
         else
             --下单控货的过滤处理
             select count(1) into v_count
               from tbl_product_info tpi,mv_user_product_control_detail vupc,mv_user_order_product tops
              where tpi.itemnumber = c_product_itemnumber
                    and vupc.product_control_mode = '2'
                    and vupc.user_id = c_user_name
                    and vupc.product_control_brand = tpi.brand_id
                    and tops.user_id = vupc.control_user_id
                    and tops.itemnumber = tpi.itemnumber;
         end if;
         if v_count > 0 then
          v_flag := 0;
         end if;
       end if;
       /**********************进行区域控货的判断*****end***************************/
   end if;
   return v_flag;

end is_display;
/

