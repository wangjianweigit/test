create PROCEDURE           display_product
/**
     分析商品所在规格和仓库分布数据
     wangpeng
     2017-09-05
  **/
is
  
begin
  
    delete TBL_PRODUCT_DISPLAY;
    
    --规格分析
    declare cursor specs is  
       select id from TBL_PRODUCT_SPEC_GROUP;   
    begin
        for row_spec in specs loop
            DBMS_OUTPUT.put_line('-------规格--'||row_spec.id);
            insert into TBL_PRODUCT_DISPLAY(ITEMNUMBER,display_type,display_key,is_display) select itemnumber,'spec',row_spec.id,IS_DISPLAY_SPEC(itemnumber,row_spec.id) from tbl_product_info where product_type = 0;
        end loop;
    end;
    
    
    --仓库分析
    declare cursor warehouses is  
       select distinct warehouse_id id from TBL_SITE_WAREHOUSE ;
    begin
        for row_warehouse in warehouses loop
            DBMS_OUTPUT.put_line('-------仓库--'||row_warehouse.id);
            insert into TBL_PRODUCT_DISPLAY(ITEMNUMBER,display_type,display_key,is_display) select itemnumber,'warehouse',row_warehouse.id,IS_DISPLAY_WAREHOUSE(itemnumber,row_warehouse.id) from tbl_product_info where product_type = 0;
        end loop;
    end;
    
  commit;
exception
  when others then
    rollback;
end display_product;
/

