create FUNCTION           getSpecs_SalePrice
/**
   （新版） 获取商品规格-原销售价【联营设置零售价的规格批发价使用】
    shif
    2018-04-24
    2018-12-25   update  for wangpeng  支持新老商品不同费率计算
    2019-09-05   update  for wangpeng  支持新老商品不同费率计算 针对2019-09-15新费率调整
    返回值：商品价
**/
(
    c_product_itemnumber  varchar2, --商品货号,
    c_product_specs   varchar2,--商品规格 
    c_prize_type      number   --获取价格类型  0-获取最低价  1获取最高价
) return number
 is
     v_product_prize number:=0;                      --需要返回的商品价格
     v_specs_prize number:=0;                        --商品原价最小价或最高价
     
     v_member_service_rate number:=0;                --会员服务费比例-汇总
     v_member_service_rate_rzs number:=0;            --会员服务费比例-入驻商
     v_member_service_rate_qj number:=0;             --会员服务费比例-全局
     v_product_create_date date;                                             --商品创建时间                          --界线新加配置
     v_sys_line date:=to_date('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置
     v_sys_line2 date:=to_date('2019-09-15 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置  针对2019-09-15新费率调整
BEGIN

     /*************************商品新老计费费率控制*********begin**********************/
    select a.create_date into v_product_create_date from tbl_product_info a where a.ITEMNUMBER = c_product_itemnumber;
    if v_product_create_date < v_sys_line then
        --查询入驻商会员服务费比例-老费率
        select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RATE where STATIONED_USER_ID = (
            select STATIONED_USER_ID from TBL_PRODUCT_INFO where ITEMNUMBER = c_product_itemnumber
        );
    end if;
    /*************************商品新老计费费率控制*********end**********************/
    
   --查询全局会员服务费比例
   --select member_service_rate into v_member_service_rate_qj from TBL_SYS_CONFIG where id = 1;

    if v_product_create_date >= v_sys_line then
       --查询入驻商会员服务费比例-按当前费率计算
        select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_USER_INFO where id = (
            select STATIONED_USER_ID from TBL_PRODUCT_INFO where ITEMNUMBER = c_product_itemnumber
        );
    end if;
    
    /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
    if v_sys_line2 > v_product_create_date and v_product_create_date >= v_sys_line then
        --查询入驻商会员服务费比例-老费率2次调整
        select nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RAT2 where STATIONED_USER_ID = (
            select STATIONED_USER_ID from TBL_PRODUCT_INFO where ITEMNUMBER = c_product_itemnumber
        );
    end if;
    /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
   
   --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
   v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;
   
   --查询原价最低或最高价
   if c_prize_type = 1 then
      select max(nvl(f.product_prize_cost,0)) into v_specs_prize from tbl_product_sku f where PRODUCT_ITEMNUMBER = c_product_itemnumber and PRODUCT_SPECS = c_product_specs;
   else
      select min(nvl(f.product_prize_cost,0)) into v_specs_prize from tbl_product_sku f where PRODUCT_ITEMNUMBER = c_product_itemnumber and PRODUCT_SPECS = c_product_specs;
   end if;
   
   --计算应销售价（最低）=报价/（1-会员服务费比例）
   v_specs_prize:=v_specs_prize/(1-v_member_service_rate);
   
   
     if ceil(v_specs_prize)-v_specs_prize<0.5 then
      v_specs_prize := ceil(v_specs_prize);
   elsif ceil(v_specs_prize)-v_specs_prize=0 then
      v_specs_prize := v_specs_prize;
   else 
      v_specs_prize := ceil(v_specs_prize)-0.5;
   end if;
   
   --金额格式化
   v_product_prize := to_number(to_char(v_specs_prize,'fm999999990.00'));
   return v_product_prize;
 
END getSpecs_SalePrice;
/

