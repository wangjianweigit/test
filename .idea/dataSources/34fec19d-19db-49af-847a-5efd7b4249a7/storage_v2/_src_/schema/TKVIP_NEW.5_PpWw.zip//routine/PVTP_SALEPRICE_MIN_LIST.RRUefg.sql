create FUNCTION PVTP_SALEPRICE_MIN_LIST
/**
    私有站商品列表商品最低售价展示 reid 2019-09-04
    返回值：商品中所有SKU的最低销售价格
**/
(
    c_stationed_user_id     number,      --当前访问的私有平台ID（即所属私有商家的ID）
    c_user_name             varchar2,    --用户名
    c_product_itemnumber    varchar2     --商品货号    
) return varchar2
 is
     v_product_prize_str varchar2(50):='0.00';    --需要返回的商品价格
     v_id number:=0;                              --最低报价SKUID
     v_count number:=0;                           --临时参数
BEGIN
    --查询会员相关信息
    SELECT count(1) 
    INTO v_count
    FROM TBL_USER_INFO WHERE user_name = c_user_name and rownum<=1;
     ----会员查询失败或者会员所属的私有站ID不存在，则返回0
    IF v_count = 0 THEN
        return 0;
    END IF;
    /*******判断商品是私有商品还是童库商品**********/
    select count(1) into v_count
    from TBL_PVTP_PRODUCT_INFO ppi
    where ppi.itemnumber = c_product_itemnumber and ppi.stationed_user_id = c_stationed_user_id;
    IF v_count = 0 THEN 
        --查询最低报价的SKUID
        select id into v_id from (select id from tbl_product_sku where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架' order by product_prize_cost asc ) where rownum<2;
    ELSE
        --查询最低报价的SKUID
        select id into v_id from (select id from tbl_pvtp_product_sku where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架' order by product_prize_cost asc ) where rownum<2;
    END IF;
    --dbms_output.put_line('c_product_itemnumber===='||c_product_itemnumber);
    --查找SKU对应的实际销售价
    v_product_prize_str:=nvl(to_char(PVTP_GETSKU_USER_SALEPRICE(c_stationed_user_id,c_user_name,v_id),'fm999999990.00'),'0.00');

    return v_product_prize_str;
   
END PVTP_SALEPRICE_MIN_LIST;
/

