create PROCEDURE           move_into_favorite
/**
     移入收藏夹
     shifan
     2016-04-08
     20170307 新增清空指定仓库购物车商品数据处理  shif
     返回值：移入收藏夹成功或移入收藏失败消息
  **/
(
 client_user_name   IN VARCHAR2, --用户名
 client_itemnumbers IN VARCHAR2, --商品货号拼接字符串，逗号分隔
 client_warehouse_ids IN VARCHAR2, --商品货号对应仓库拼接字符串 ，逗号分隔
 output_status      OUT VARCHAR2, --返回的状态码 0-取消失败 1-取消成功
 output_msg         OUT VARCHAR2 --返回的信息
 ) IS
  temp_itemnumber_count                   INT := 0; --临时变量（货号数量）
  temp_warehouse_id_count                  INT := 0; --临时变量（货号对应仓库数量）
  temp_count                  INT := 0; --临时变量(循环)
  temp_count1                  INT := 0; --临时变量（校验是否已加入收藏夹）
  temp_itemnumber              VARCHAR2(50); --商品货号
  temp_warehouse_id            NUMBER :=0;   --仓库id
  temp_collect_product_price   VARCHAR2(50); --收藏商品价格
  temp_collect_product_name    VARCHAR2(300); --收藏商品名字
  temp_collect_product_img_url VARCHAR2(200); --收藏商品图片路径
 v_source_type varchar2(10):='1';
BEGIN
  output_status := '0';
  output_msg    := '移入收藏夹失败！';
  SELECT COUNT(*)
    INTO temp_count
    FROM tbl_user_info
   WHERE user_name = client_user_name;
  IF temp_count = 0 THEN
    output_msg := '用户信息不能为空，请检查！';
    RETURN;
  END IF;
  --获取当前移入收藏夹的货号数量及
  SELECT COUNT(1)
    INTO temp_itemnumber_count
    FROM (SELECT * FROM TABLE(SPLITSTR(client_itemnumbers, ',')));
   SELECT COUNT(1)
    INTO temp_warehouse_id_count
    FROM (SELECT * FROM TABLE(SPLITSTR(client_warehouse_ids, ',')));
  --DBMS_OUTPUT.put_line('----111temp_itemnumber_count---'||temp_itemnumber_count);
  IF temp_itemnumber_count = 0 or temp_itemnumber_count <> temp_warehouse_id_count THEN
    output_msg := '商品货号数量不符，请检查！';
    RETURN;
  END IF;
  temp_count := 1;
  while temp_count <= temp_itemnumber_count loop
    temp_itemnumber    := getstrforarrid(',' || client_itemnumbers || ',',',',temp_count);
    temp_warehouse_id := getstrforarrid(',' || client_warehouse_ids || ',',',',temp_count);
    --查询商品是否已经收藏
    SELECT COUNT(1) INTO temp_count1 FROM tbl_user_collection WHERE user_name = client_user_name AND itemnumber = temp_itemnumber; 
    ---已经收藏，则仅仅更新收藏时间
    IF temp_count1 <> 0 THEN
            --清除购物车相应的记录
           DELETE FROM tbl_user_cart t
           WHERE t.user_name = client_user_name
                 and t.warehouse_id = temp_warehouse_id
                 AND EXISTS (SELECT 1 FROM tbl_product_sku s
                    WHERE s.product_itemnumber = temp_itemnumber
                    AND s.id = t.product_sku_id);
      --reid 2019.05.16 已存在则仅更新收藏时间
      UPDATE TBL_USER_COLLECTION SET create_date = SYSDATE WHERE user_name = client_user_name and itemnumber = temp_itemnumber;
     ELSE
              --获取商品价格
              temp_collect_product_price:=getProduct_SalePrice_Min(client_user_name, temp_itemnumber);  
              --获取商品名称，主图片路径
              SELECT product_name, product_img_url INTO temp_collect_product_name, temp_collect_product_img_url FROM tbl_product_info WHERE itemnumber = temp_itemnumber;
          --插入我的收藏
          INSERT INTO TBL_USER_COLLECTION (id, user_name, product_name, product_price, product_img_url, itemnumber, create_date)
          VALUES (seq_user_collection.NEXTVAL, client_user_name, temp_collect_product_name, temp_collect_product_price, temp_collect_product_img_url, temp_itemnumber, SYSDATE);
     END IF;
     --清除购物车相应的记录
     DELETE FROM tbl_user_cart t
     WHERE t.user_name = client_user_name and t.warehouse_id = temp_warehouse_id 
     AND EXISTS (SELECT 1 FROM tbl_product_sku s WHERE s.product_itemnumber = temp_itemnumber AND s.id = t.product_sku_id);
     temp_count:= temp_count + 1;
  end loop;
  output_status := '1';
  output_msg    := '移入收藏夹成功！';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    output_msg := '移入收藏夹时出现未知错误！';
    ROLLBACK;
END move_into_favorite;
/

