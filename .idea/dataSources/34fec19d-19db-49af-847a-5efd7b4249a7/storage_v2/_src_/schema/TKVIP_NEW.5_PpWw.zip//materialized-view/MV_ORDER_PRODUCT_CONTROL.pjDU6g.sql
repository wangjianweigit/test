create materialized view MV_ORDER_PRODUCT_CONTROL
  refresh complete on demand
as
select t4.user_id,t4.control_user_id,t3.itemnumber,min(t1.order_date) as order_date
  from tbl_order_product t1,
       tbl_product_info t3,
       MV_USER_PRODUCT_CONTROL_DETAIL t4
 where exists (select 1 from tbl_order_info where order_state IN (2, 3, 4, 5) and order_number = t1.order_number)
   and t1.user_name = t4.control_user_id
   and t3.brand_id = t4.product_control_brand
   and t1.itemnumber = t3.itemnumber
   and t4.product_control_mode = '2'
   group by t4.user_id,t4.control_user_id,t3.itemnumber
/

