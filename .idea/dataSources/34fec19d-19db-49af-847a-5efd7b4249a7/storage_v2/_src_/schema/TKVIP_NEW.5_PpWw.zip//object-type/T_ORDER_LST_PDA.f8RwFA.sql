create TYPE           T_ORDER_LST_PDA                                                                                                           
AS TABLE OF T_ORDER_PDA;
/

