create FUNCTION PVTP_GETFREIGHTMONEYNEW
/**
    私有站下单时计算运费（按大仓进行运费计算）【根据新版本临时表商品数据】
    reid  2019.04.28
    返回值：运费
**/
(
    c_logistics_company_id in number,       --物流公司ID
    c_user_province_id in number,           --收货地址所在省ID
    c_warehouse_id in number,               --下单仓库id
    c_freight_payment_type number,          --运费是否到付  1.先支付运费   ；2：到付运费
    c_order_id  number                      --订单ID，临时表TMP_NEW_ORDER的主键ID
) return number
 is
 v_total_money number:=0;                   --运费
 v_det_id number:=0;                        --快递运费模板
 v_temp_first_count number:=0;              --临时变量 首件数量
 v_temp_first_money number:=0;              --临时变量 首件价格
 v_temp_continue_count number:=0;           --临时变量 续件数量
 v_temp_continue_money number:=0;           --临时变量 续件价格
 v_temp_default_id number:=999999;          --全局默认运费
 v_type char:='0';                          --物流公司类型
 v_sku_count number :=0;                    --sku数组数量
 v_sku_counts_count number :=0;             --sku数量数组的数量
 v_temp_count number :=0;                   --临时数量
 v_parent_warehouse_id number :=0;          --大仓id
BEGIN
    --只有非到付运费时，才进行运费计算，否则，直接返回0
    IF c_freight_payment_type = 1 THEN
        --获取下单仓库的父仓（大仓）id
        SELECT PARENT_ID INTO v_parent_warehouse_id FROM TBL_WAREHOUSE_INFO  WHERE ID = c_warehouse_id;
        --查询物流公司类型
        SELECT TYPE INTO v_type FROM TBL_LOGISTICS_COMPANY WHERE ID = c_logistics_company_id;
        --普通物流公司
        IF v_type = '0' THEN
        v_temp_default_id:=999999;
        END IF;
        --代发物流公司
        IF v_type = '1' THEN
        v_temp_default_id:=999998;
        END IF;
       --定义游标查询使用统一运费模板的商品数量
       DECLARE CURSOR product_skus_counts IS
       SELECT 
         c.freight_template_id,sum(d.order_count) total_count FROM TBL_PVTP_PRODUCT_INFO C,
         (
            SELECT 
            po.product_itemnumber,
            sum(ops.count) order_count
            from TMP_NEW_ORDER_PRODUCT_SKU ops
            inner join TMP_NEW_ORDER_PRODUCT po on ops.order_product_id = po.order_product_id
            inner join TMP_NEW_ORDER tno on tno.order_id = po.order_id
            WHERE tno.order_id = c_order_id
            group by po.product_itemnumber
        ) d WHERE d.product_itemnumber = c.itemnumber
        GROUP BY c.freight_template_id;
        myrec product_skus_counts%ROWTYPE;
       BEGIN
        FOR c_row IN product_skus_counts LOOP
         --DBMS_OUTPUT.PUT_LINE('-------模板ID：'||c_row.freight_template_id||'-----购买数量'||c_row.total_count);
            --获取本商品的运费模板---当查询不到模板的时候，则使用全局通用模板，模板ID固定为99999
            SELECT NVL(MIN(ID),v_temp_default_id) INTO v_det_id FROM
            (
            SELECT ID FROM TBL_FREIGHT_TEMPLATE_DETAIL
                WHERE
                 TEMPLATE_ID = c_row.freight_template_id
                AND LOGISTICS_COMPANY_ID = c_logistics_company_id
                AND (RANGE LIKE '%'||c_user_province_id||'%' OR RANGE ='0')
                AND WAREHOUSE_ID = v_parent_warehouse_id
            ORDER BY RANGE DESC
            ) WHERE ROWNUM < 2;

            --获取模板详情
            SELECT FIRST_COUNT,FIRST_MONEY,CONTINUE_COUNT,CONTINUE_MONEY INTO v_temp_first_count,v_temp_first_money,v_temp_continue_count,v_temp_continue_money FROM TBL_FREIGHT_TEMPLATE_DETAIL WHERE ID = v_det_id;
            --计算首件价格
            IF v_total_money = 0 THEN
            v_total_money := v_total_money + v_temp_first_money;
            IF c_row.total_count > v_temp_first_count THEN
                v_total_money := v_total_money+ceil((c_row.total_count-v_temp_first_count)/v_temp_continue_count) * v_temp_continue_money;
            END IF;
            ELSE --计算续件金额
            v_total_money := v_total_money + ceil(c_row.total_count/v_temp_continue_count) * v_temp_continue_money;
            END IF;
        END LOOP;
        END;
    END IF;
   --返回运费
   RETURN nvl(v_total_money,0);

END PVTP_GETFREIGHTMONEYNEW;
------------------------------------------------
/

