create FUNCTION PVTP_GETPRODUCT_QJ_SYS
/**
    （私有平台）通过用户名获取商品货号价格价格区间   （精确价格）
    reid 2019-09-12
    返回值：商品价格
**/
(
    c_stationed_user_id     number,              --当前下单私有平台ID（即所属私有商家的ID）
    c_product_itemnumber   varchar2         --商品货号    
) return varchar2
 is
    v_id_min number:=0;                              --最低报价SKUID
    v_id_max number:=0;                              --最高报价SKUID
    v_product_prize_str varchar2(50):='0.00-0.00';      --需要返回的商品价格区间
BEGIN
   --查询最低报价的SKUID
    select id into v_id_min from (select id from tbl_product_sku where product_itemnumber = c_product_itemnumber and product_group ='尺码' order by product_prize_cost asc ) where rownum<2;
    --查询最高报价的SKUID
    select id into v_id_max from (select id from tbl_product_sku where product_itemnumber = c_product_itemnumber and product_group ='尺码' order by product_prize_cost desc ) where rownum<2;
    --查找SKU对应的实际销售价
    v_product_prize_str:=nvl(to_char(PVTP_GETSKU_PRICE_SYS(c_stationed_user_id,v_id_min),'fm999999990.00'),'0.00');
    v_product_prize_str:=v_product_prize_str||'-'||nvl(to_char(PVTP_GETSKU_PRICE_SYS(c_stationed_user_id,v_id_max),'fm999999990.00'),'0.00');
    return v_product_prize_str;
END PVTP_GETPRODUCT_QJ_SYS;
/

