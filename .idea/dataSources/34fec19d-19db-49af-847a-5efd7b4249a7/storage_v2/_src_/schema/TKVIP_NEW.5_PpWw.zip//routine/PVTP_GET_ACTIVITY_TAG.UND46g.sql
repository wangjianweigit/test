create FUNCTION PVTP_GET_ACTIVITY_TAG
/**
  reid 2019.09.11 计算私有站商品参加活动信息
  activity_id:表示商品参加的活动的id
  activity_type：表示商品参加的活动的类型
        0：未参加活动
        1：【平台活动】限时折扣（数据表：tbl_sale_activity_info）;
        3:私有平台活动
   activity_state：表示商品参加的活动的状态
        waiting：活动未开始
        going：活动进行中
   返回值：activity_id + activity_type + activity_state + plan_delivery_date（仅activity_type=4时有值）+ activity_product_id
**/
(
    c_stationed_user_id     number,   --当前访问的私有平台ID（即所属私有商家的ID）
    c_user_name             varchar2,   --用户名
    c_product_itemnumber    varchar2    --商品货号
) return varchar2
 is
     v_return_tags varchar2(500):='';               --需要返回的标签
     v_site_id number:=0;                           --客户站点id
     v_activity_type number:=0;                     --活动类型
     v_activity_id number:=0;                       --活动id
     v_activity_state varchar2(50);                 --表示商品参加的活动的状态
     v_count number:=0;                             --临时变量
     v_activity_count number:=0;                    --临时变量
     v_plan_delivery_date varchar2(50):='';         --预计发货时间，仅activity_type=4时有值
     v_activity_product_id number:=0;               --活动商品id，关联表tbl_activity_product的id
begin
    ----判断商品是私有商品还是童库商品
       select nvl(min(site_id),0)
       into v_site_id
       from tbl_user_info where user_name = c_user_name;
       ----会员查询失败或者会员所属的私有站ID不存在，则返回0
       IF v_site_id = 0 THEN
            return 0;
       END IF;
    ----判断商品是私有商品还是童库商品
    /*******判断商品是私有商品还是童库商品**********/
    select count(1) into v_count
    from TBL_PVTP_PRODUCT_INFO ppi
    where ppi.itemnumber = c_product_itemnumber and ppi.stationed_user_id = c_stationed_user_id;
    IF v_count<> 0 THEN
       ---私有站商品，查询是否参加了店铺活动
       select count(1) into v_count
       from tbl_sta_sale_activity ssa where exists (
            select 1 from tbl_sta_sale_activity_product ssap where
            ssap.activity_id = ssa.id
            and ssap.is_delete = 1
            and ssap.product_itemnumber = c_product_itemnumber
       )
       and ssa.activity_state = 1
       and ssa.end_date >=sysdate
       and ssa.is_delete = 1
       and rownum <=1;
       IF v_count > 0 THEN
               select 
               ssa.id,
               3 activity_type,
               (case when ssa.begin_date > sysdate then 'waiting' when ssa.begin_date <= sysdate then 'going' end ) activity_state,
               ssap.id activity_product_id
               into v_activity_id,v_activity_type,v_activity_state,v_activity_product_id
               from tbl_sta_sale_activity ssa
               inner join tbl_sta_sale_activity_product ssap on ssap.activity_id = ssa.id
               where  ssap.is_delete = 1
               and ssap.product_itemnumber = c_product_itemnumber
               and ssa.activity_state = 1
               and ssa.end_date >=sysdate
               and ssa.is_delete = 1
               and rownum <=1;
       END IF;
    ELSE
        ---童库商品
         select count(1) into v_count  from tbl_product_info tpi 
         where  tpi.itemnumber = c_product_itemnumber and tpi.start_stop_state = 1
         and exists(
            select 1
            from tbl_product_sku
            where product_itemnumber = tpi.itemnumber
            and start_stop_state = 1
            and product_group = '尺码'
        ) 
        and tpi.is_private = 1
        and exists (
            select 1 from tbl_pvtp_product_info_ref pir where pir.platform_id = c_stationed_user_id
            and pir.product_itemnumber =  tpi.itemnumber and pir.enabled_flag = 1
        );
        if v_count =0 then
            return v_return_tags;
        end if;
        /*******************查询商品是否参加了平台**********************/
        select count(ai.id) into v_count from tbl_activity_info ai,tbl_activity_detail a1 
        where a1.activity_id = ai.id 
        and exists(
            select 1 from tbl_activity_product ap 
            where  ap.activity_end_date >sysdate
            and ap.product_itemnumber = c_product_itemnumber
            and ap.activity_id = ai.id
        )
        and ai.state = 2
        and ai.is_delete = '1'
        and ai.activity_type = '1'
        and exists (select 1 from tbl_activity_site tas where tas.activity_id = ai.id and tas.site_id = v_site_id)
        /********订货会活动需要控制可见用户组******/
        and (case when (a1.user_group_id = 0 or a1.user_group_id is null) then 1 else case when exists (
            select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' 
            and a1.user_group_id = aa.id and  bb.user_id = c_user_name and (bb.activity_id = a1.activity_id or bb.activity_id = 0)
        ) then 1 else 0 end end) = 1 
        and rownum <=1;
        /*******************参加了平台活动，获取活动相关信息******************/
        if v_count > 0 then
            select 
            ai.id,
            ai.activity_type,
            (
                select case when tap.activity_start_date > sysdate then 'waiting' when tap.activity_start_date <= sysdate then 'going' end 
                from tbl_activity_product tap
                where tap.activity_id = ai.id
                and tap.product_itemnumber = c_product_itemnumber and rownum<2
             )  as activity_state,
             (
                select to_char(tap.plan_delivery_date,'yyyy-mm-dd hh24:mi:ss')
                from tbl_activity_product tap
                where tap.activity_id = ai.id
                and tap.product_itemnumber = c_product_itemnumber and rownum<2
             )  as plan_delivery_date,
             (
                select tap.id
                from tbl_activity_product tap
                where tap.activity_id = ai.id
                and tap.product_itemnumber = c_product_itemnumber and rownum<2
             )  as activity_product_id
             into v_activity_id,v_activity_type,v_activity_state,v_plan_delivery_date,v_activity_product_id 
             from tbl_activity_info ai,tbl_activity_detail a1
             where a1.activity_id = ai.id 
             and exists(
                select 1 from tbl_activity_product ap 
                where  ap.activity_end_date >sysdate
                and ap.product_itemnumber = c_product_itemnumber
                and ap.activity_id = ai.id
            )
            and ai.state = 2
            and ai.is_delete = '1'
            and ai.activity_type = '1'
            and exists (select 1 from tbl_activity_site tas where tas.activity_id = ai.id and tas.site_id = v_site_id)
            /********订货会活动需要控制可见用户组******/
            and (case when (a1.user_group_id = 0 or a1.user_group_id is null) then 1 else case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and a1.user_group_id = aa.id and  bb.user_id = c_user_name) then 1 else 0 end end) = 1
            and rownum <=1;
        end if;
    END IF;
    if v_activity_id =0 then 
         v_return_tags := '';
    else 
         v_return_tags := v_activity_id||'#-#'||v_activity_type||'#-#'||v_activity_state||'#-#'||v_plan_delivery_date||'#-#'||v_activity_product_id;
    end if;
    return v_return_tags;
end PVTP_GET_ACTIVITY_TAG;
/

