create function           is_activity
/**
    
   
   reid 2019.03.04 根据商家查询当前商品是否参加活动
   reid 2019.04.11 优化查询效率
   reid 2019.04.12 仅计算正在进行中的活动
   reid 2019.04.18 增加一口清类型活动
   返回值：activity_type
        0：未参加活动
        1：限时折扣（数据表：tbl_sale_activity_info）;
        2：订货会（表tbl_preorder_activity_info）
        4：预售（表tbl_presell_activity_info）
        5：一口清活动（表tbl_clear_activity_info）
**/
(
    c_user_name             varchar2,   --用户名
    c_product_itemnumber    varchar2    --商品货号
) return varchar2
 is
     v_site_id number:=0;                           --客户站点id
     v_activity_type number:=0;                     --活动类型
     v_activity_id number:=0;                       --活动id
     v_count number:=0;                             --临时变量
     v_activity_count number:=0;                    --临时变量
begin
    
    --如果商品不是启用状态或者无启用状态的尺码，直接返回，不显示 zhengfangyuan 2019.02.27
    select count(1) into v_count  from tbl_product_info tpi where tpi.product_type in (0,3) and tpi.itemnumber = c_product_itemnumber and tpi.start_stop_state = 1
     and exists(
        select 1
        from tbl_product_sku
        where product_itemnumber = tpi.itemnumber
        and start_stop_state = 1
        and product_group = '尺码'
    );
    if v_count =0 then
        return 0;
    end if;
    --查询用户站点
    select site_id into v_site_id from tbl_user_info where user_name = c_user_name;
    /*******************查询商品是否参加了平台******************************************/
    select ai.id,to_number(ai.activity_type) into v_activity_id,v_activity_type from tbl_activity_info ai,tbl_activity_detail ad,tbl_activity_product ap 
    where ai.id = ad.activity_id and ai.id = ap.activity_id
    and sysdate between ap.activity_start_date and ap.activity_end_date
    and ap.product_itemnumber = c_product_itemnumber
    and ai.state = 2
    and ai.is_delete = '1'
    and exists (select 1 from tbl_activity_site tas where tas.activity_id = ai.id and tas.site_id = v_site_id)
    and (case when (ad.user_group_id = 0 or ad.user_group_id is null) then 1 else case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and ad.user_group_id = aa.id and bb.user_id = c_user_name) then 1 else 0 end end) = 1
    and rownum <=1;
    
    if v_activity_id = 0 then
        return 0;
    end if;
    
    return v_activity_type;

end is_activity;
/

