create TYPE T_NEW_ORDER                                                                                                                                                                                                                                                                                                                                                                                                                as object
(
    stationed_user_id   NUMBER,                     --商品所属平台ID；0表示童库平台
    warehouse_id        NUMBER,                     --下单仓库id,
    product_list T_NEW_ORDER_PRODUCT_LIST,          --下单商品集合
    product_money NUMBER,                           --订单商品金额
    logistics_company_code VARCHAR2(50),            --物流公司代码
    logistics_money NUMBER,                         --商品物流费用
    df_money NUMBER,                                --商品代发费用
    freight_payment_type NUMBER,                    --订单运费是否到付  1.先支付运费 ;2:到货支付运费
    order_remark varchar2(1000)                     --订单备注
);
------------------------------------------------
/

