create PROCEDURE           AUTO_USERPRODUCTSTATE_public
/**
     自动处理已登录用户，（job调用专用），建议半小时调用一次
     wangpeng
     2018-03-06 
  **/
 IS
    v_sxsj     number:=30/(24*60);         --查询30分钟内有活动的用户
BEGIN
  --定义游标查询半小时有活动的用户
   declare cursor all_users is  
       select create_user_name user_name from TBL_USER_LOG_INFO where --PAGE_TYPE !='登录' and 
       CREATE_DATE > sysdate -v_sxsj group by create_user_name;
   begin
        for c_row in all_users loop
          --处理通用用户商品状态
          iniuserproductstate_public(c_row.user_name);
        end loop;
    end;
    
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END AUTO_USERPRODUCTSTATE_public;
/

