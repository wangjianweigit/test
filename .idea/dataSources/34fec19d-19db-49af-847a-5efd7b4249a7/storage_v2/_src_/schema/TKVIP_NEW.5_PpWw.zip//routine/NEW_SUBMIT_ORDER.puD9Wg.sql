create PROCEDURE           NEW_SUBMIT_ORDER
/**
     实际处理单个订单提交任务
     Reid 2019.04.28 
     Reid 2019.06.12 代发费不存在则存储0
     zhengfy 2019.07.16 记录活动商品ID、订单取消时间
     reid 2019.11.21 下单时，在订单商品表中记录该商品是否是买断下单
     返回值：订单提交结果消息
**/
(
   client_user_name                IN     VARCHAR2,              --用户名
   client_receiving_name           IN     VARCHAR2,              --收货人姓名
   client_receiving_phone          IN     VARCHAR2,              --收货电话
   client_user_province_id         IN     NUMBER,                --收货地省ID
   client_receiving_address        IN     VARCHAR2,              --收货地址
   client_order_id                 IN     NUMBER,                --订单ID，临时表TMP_NEW_ORDER的主键ID
   client_order_remark             IN     VARCHAR2,              --订单备注
   client_logistics_company_code   IN     VARCHAR2,              --物流公司代码
   client_product_money            IN     NUMBER,                --前台传递 商品总价
   client_logistics_money          IN     NUMBER,                --前台传递 物流总价
   client_df_money                 IN     NUMBER,                --前台传递 代发费用
   client_order_source             IN     VARCHAR2,              --订单来源
   client_submode                  IN     CHAR,                  --下单模式   0:正常下单   1：代客户下单
   client_xdr_user_name            IN     VARCHAR2,              --下单人用户名
   client_xdr_type                 IN     CHAR,                  --下单人用户类型（3：业务员，4：业务经理，5：店长，6：营业员，7：自行下单）
   client_warehouse_id             IN     NUMBER,                --下单仓库id
   client_freight_payment_type     IN     NUMBER,                --运费是否到付  1.先支付运费   ；2：到付运费
   client_mbr_card                 IN     NUMBER:=1,             --是否使用会员卡金额结算  1:不使用   2：使用
   output_status                   OUT    VARCHAR2,              --返回的状态码 0-失败 1-成功
   output_msg                      OUT    VARCHAR2               --返回的信息
 )
AS
   v_temp_count               INT := 0;                            --临时变量
   v_user_manage_name         VARCHAR2 (50);                       --客户姓名
   v_logistics_company_id     NUMBER := 0;                         --物流公司ID
   v_logistics_company_name   VARCHAR2 (50);                       --物流公司名称
   v_product_money            NUMBER := 0;                         --后台计算 商品总价
   v_logistics_money          NUMBER := 0;                         --后台计算 物流总价
   v_order_product            T_ORDER_PRODUCT;                     --订单商品对象
   temp_count                 INT := 1;                            --临时变量 计数
   temp_sku_id                NUMBER := 0;                         --临时变量 SKUID
   temp_sku_count             NUMBER := 0;                         --临时变量 订购数量
   temp_ok_count_ck           NUMBER := 0;                         --仓库实际库存数
   v_order_number             VARCHAR2 (21);                       --订单号
   v_product_total_money      NUMBER := 0;                         --商品总价 系统计算得出
   v_ysyf                     NUMBER := 0;                         --应收运费 系统计算得出
   v_is_outstock              INT := 0;                            --缺货预售标记
   v_flag                     INT := 0;                            --业务员客户关系验证标志
   v_user_type                NUMBER := 0;                         --数据库中的系统用户类型
   v_state                    CHAR (1);                            --数据库中的系统用户状态
   v_order_type               VARCHAR2 (50);                       --订单类型  批发  代发
   v_issuing_grade_id         NUMBER := 1;                         --用户代发等级ID
   v_piece_cost               NUMBER := 0;                         --代发等级单价费用
   v_product_total_count      NUMBER := 0;                         --购买商品总数
   v_store_user_type          CHAR (1);                            --门店人员用户类型
   v_store_state              CHAR (1);                            --门店状态
   v_user_state               CHAR (1);                            --用户状态
   v_store_id                 NUMBER := 0;                         --门店ID
   v_ywjl_user_name           VARCHAR2 (50);                       --业务经理username
   v_ywy_user_name            VARCHAR2 (50);                       --业务员username
   v_md_id                    NUMBER := 0;                         --门店ID
   v_site_id                  NUMBER := 0;                         --用户所属站点
   v_outstock_flag            NUMBER := 0;                         --是否缺货订购订单标识,
   v_shipping_method_id          NUMBER;                           --标准配送方式ID,关联表TBL_SHIPPING_METHOD的ID字段
   v_is_delivery_home NUMBER:=2;                                   --用户是否支持送货入户 (1-支持，2-不支持)
   v_temp_activity_product_count NUMBER :=0;
BEGIN
   output_status := '0';

   --1.校验下单仓库是否有效
   SELECT COUNT (1)
     INTO v_temp_count
     FROM TBL_SITE_WAREHOUSE T
     WHERE t.warehouse_id = client_warehouse_id
          AND EXISTS (SELECT 1
                    FROM TBL_USER_INFO T1
                    WHERE t1.user_name = client_user_name and t1.site_id = t.site_id);
   IF v_temp_count = 0
   THEN
      OUTPUT_MSG := '下单仓库不存在';
      RETURN;
   END IF;
   --2.查询物流公司名称
   SELECT COUNT (*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE code = client_logistics_company_code;
   IF v_temp_count <> 0
   THEN
      SELECT id,name,shipping_method_id 
      INTO v_logistics_company_id,v_logistics_company_name,v_shipping_method_id
      FROM TBL_LOGISTICS_COMPANY WHERE code = client_logistics_company_code;
   ELSE
      output_msg := '物流公司不能为空，请检查!';
      RETURN;
   END IF;
   --3.查询客户姓名
   SELECT COUNT (*)  INTO v_temp_count FROM TBL_USER_INFO WHERE user_name = client_user_name AND user_state!=2;
   IF v_temp_count <> 0
   THEN
      SELECT user_manage_name, issuing_grade_id
      INTO v_user_manage_name, v_issuing_grade_id
      FROM TBL_USER_INFO WHERE user_name = client_user_name;
   ELSE
      output_msg := '用户不存在或已禁用，请检查!';
      RETURN;
   END IF;
   /*******************************************4.判断下单模式-start*************************************/
   IF client_submode = '1'  --如果 【代客户下单】
   THEN
      --4.1业务员代客户下单模式
      IF client_xdr_type = '3' OR client_xdr_type = '4'
      THEN
         --4.11业务员或业务经理代下单
         --验证业务员、业务经理信息
         SELECT COUNT (*)
           INTO v_temp_count
           FROM TBL_SYS_USER_INFO
          WHERE user_name = client_xdr_user_name;

         IF v_temp_count = 1
         THEN
            SELECT USER_TYPE, STATE
              INTO v_user_type, v_state
              FROM TBL_SYS_USER_INFO
             WHERE USER_NAME = client_xdr_user_name;

            IF v_state = '1'
            THEN
               output_msg :=
                  '当前用户已被禁用，无法代客户下单!';
               RETURN;
            ELSE
               IF v_user_type != 3 AND v_user_type != 4
               THEN
                  output_msg :=
                     '当前操作员不是业务员或业务经理，无法代客户下单!';
                  RETURN;
               END IF;
            END IF;
         ELSE
            output_msg := '业务员或业务经理信息异常!';
            RETURN;
         END IF;
         --4.12验证业务员与客户关系
         IF client_xdr_type = '3'
         THEN
            SELECT COUNT (1)
              INTO v_flag
              FROM TBL_USER_INFO tui
            WHERE tui.user_name = client_user_name
            AND EXISTS  (SELECT 1
                                FROM TBL_SYS_USER_INFO tsui 
                                WHERE tsui.id = tui.referee_user_id
                                AND tsui.user_name = client_xdr_user_name);
            IF v_flag <= 0
            THEN
               output_msg := '当前业务员与客户关系存疑，无法代客户下单!';
               RETURN;
            ELSE
               v_ywy_user_name := client_xdr_user_name;
            END IF;
         END IF;
         --4.13验证业务经理与客户关系
         IF client_xdr_type = '4'
         THEN
            SELECT COUNT (1)
              INTO v_flag
              FROM TBL_USER_INFO TUI
             WHERE     TUI.USER_NAME = client_user_name
                   AND EXISTS
                          (SELECT 1
                             FROM TBL_SYS_USER_INFO TSUI
                            WHERE     TSUI.ID =
                                         TUI.MARKET_SUPERVISION_USER_ID
                                  AND TSUI.USER_NAME = client_xdr_user_name);

            IF v_flag <= 0
            THEN
               output_msg :=  '当前业务经理与客户关系存疑，无法代客户下单!';
               RETURN;
            ELSE
               v_ywjl_user_name := client_xdr_user_name;
            END IF;
         END IF;
      --4.14 门店代下单 --验证门店与用户关系
      ELSIF client_xdr_type = '5' OR client_xdr_type = '6'
      THEN
         SELECT COUNT (1)
           INTO v_temp_count
           FROM TBL_SYS_USER_INFO A
          WHERE a.user_name = client_xdr_user_name
                AND (EXISTS (SELECT 1
                             FROM TBL_STORE_INFO B
                             WHERE b.shopkeeper_user_id = a.id)
                     OR EXISTS (SELECT 1
                                FROM TBL_STORE_USER_REL C1, TBL_STORE_INFO C2
                                WHERE c1.store_id = c2.id and c1.user_id = a.id));

         IF v_temp_count = 1
         THEN
            SELECT A1.USER_TYPE,
                   A1.STATE,
                   C.TYPE,
                   B1.ID,
                   B1.STATE AS STORE_STATE
              INTO v_user_type,
                   v_user_state,
                   v_store_user_type,
                   v_store_id,
                   v_store_state
              FROM TBL_SYS_USER_INFO A1,
                   TBL_STORE_INFO    B1,
                   (SELECT A.ID                 AS STORE_ID,
                           A.SHOPKEEPER_USER_ID AS USER_ID,
                           5                    AS TYPE
                      FROM TBL_STORE_INFO A
                     WHERE EXISTS
                              (SELECT 1
                                 FROM TBL_USER_INFO TUI
                                WHERE     TUI.STORE_ID = A.ID
                                      AND TUI.USER_NAME = client_user_name)
                    UNION
                    SELECT B.STORE_ID, B.USER_ID, B.TYPE
                      FROM TBL_STORE_USER_REL B) C
             WHERE     A1.ID = C.USER_ID
                   AND B1.ID = C.STORE_ID
                   AND A1.USER_NAME = client_xdr_user_name;

            IF v_store_state = '1'
            THEN
               output_msg := '当前门店已停运不能代客户下单';
               RETURN;
            END IF;

            IF v_store_user_type <> v_user_type
            THEN
               output_msg := '用户类型存疑，不能代客户下单';
               RETURN;
            END IF;

            IF v_user_state = '0'
            THEN
               output_msg := '当前用户已禁用，不能继续操作';
               RETURN;
            END IF;
         ELSE
            output_msg := '门店信息异常' || client_xdr_user_name;
            RETURN;
         END IF;

         SELECT COUNT (1)
           INTO v_flag
           FROM TBL_USER_INFO
          WHERE STORE_ID = v_store_id AND USER_NAME = client_user_name;

         IF v_flag <= 0
         THEN
            output_msg := '当前用户不属于该门店，无法代客户下单';
            RETURN;
         END IF;
      END IF;
   ELSIF client_submode != '0'
   THEN
      output_msg := '下单模式异常，请检查';
      RETURN;
   END IF;
   --4.15 查询用户所属业务经理
   SELECT (SELECT TSUI.USER_NAME
             FROM TBL_SYS_USER_INFO TSUI
            WHERE TSUI.ID = TUI.MARKET_SUPERVISION_USER_ID)
             AS MARKET_SUPERVISION_USER_NAME,
          (SELECT TSUI.USER_NAME
             FROM TBL_SYS_USER_INFO TSUI
            WHERE TSUI.ID = TUI.REFEREE_USER_ID)
             AS REFEREE_USER_NAME,
          TUI.STORE_ID,
          TUI.SITE_ID
     INTO v_ywjl_user_name,
          v_ywy_user_name,
          v_md_id,
          v_site_id
     FROM TBL_USER_INFO TUI
    WHERE USER_NAME = client_user_name;
   /*******************************************4.判断下单模式-end*************************************/
   
     /*******************************************5.如果商品参加了活动，需要更新活动的售卖数量-start*************************************/
     ---5.1 如果当前商品参加了预售活动，则更新预售数量
     MERGE INTO TBL_PRESELL_ACTIVITY_SKU t1
     USING (
            SELECT 
            po.activity_id,
            po.product_itemnumber,
            ops.sku_id product_sku,
            ops.count order_count
            from TMP_NEW_ORDER_PRODUCT_SKU ops
            inner join TMP_NEW_ORDER_PRODUCT po on ops.order_product_id = po.order_product_id
            inner join TMP_NEW_ORDER tno on tno.order_id = po.order_id
            WHERE tno.order_id = client_order_id AND po.activity_type = 4
     ) t2 on (t1.activity_id = t2.activity_id and t1.product_itemnumber = t2.product_itemnumber and t1.product_sku = t2.product_sku)
      WHEN MATCHED THEN 
      UPDATE SET t1.activity_sell_amount =  t1.activity_sell_amount + t2.order_count;
    ---5.2 如果当前商品参加了非预售活动的锁定库存的活动，则更新预售数量
     MERGE INTO TBL_SALE_ACTIVITY_SKU t1
     USING (
            SELECT 
            po.activity_id,
            po.product_itemnumber,
            ops.sku_id product_sku,
            ops.count order_count
            from TMP_NEW_ORDER_PRODUCT_SKU ops
            inner join TMP_NEW_ORDER_PRODUCT po on ops.order_product_id = po.order_product_id
            inner join TMP_NEW_ORDER tno on tno.order_id = po.order_id
            WHERE tno.order_id = client_order_id AND po.activity_type != 4
     ) t2 on (t1.activity_id = t2.activity_id and t1.product_itemnumber = t2.product_itemnumber and t1.product_sku = t2.product_sku)
      WHEN MATCHED THEN 
      UPDATE SET t1.activity_sell_amount =  t1.activity_sell_amount + t2.order_count;
     /*******************************************5.如果商品参加了活动，需要更新活动的售卖数量-end*************************************/
   -------------------------6.0计算物流价格
   v_ysyf := getFreightMoneyNew(v_logistics_company_id, client_user_province_id,client_warehouse_id,client_freight_payment_type,client_order_id);
   --校验物流费用是否被篡改
   IF v_ysyf <> client_logistics_money
   THEN
      output_msg := '运费被篡改或运费计算规则发生变化,应收运费（' ||v_ysyf|| '），请重新下单!';
      RETURN;
   END IF;
   --统计当前订单的下单商品数量 
   SELECT sum (count) into v_product_total_count FROM TMP_NEW_ORDER_PRODUCT_SKU  WHERE order_id = client_order_id;
   /**************************7.0 计算订单是否是代发订单，如果是代发订单，则需要校验代发费用-start*****************************/
   SELECT COUNT (*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE TYPE = '2' AND code = client_logistics_company_code;
   --当前订单为代发订单
   IF v_temp_count > 0
   THEN
      --查询用户代发等级ID
      IF v_issuing_grade_id = 0
      THEN
         v_issuing_grade_id := 1;
      END IF;
      --查询代发等级的单价费用
      SELECT piece_cost into v_piece_cost FROM TBL_ISSUING_GRADE WHERE ID = v_issuing_grade_id;
      --代发费 = 单个商品费用 * 商品数量
      v_piece_cost := v_product_total_count * v_piece_cost;
      IF v_piece_cost != client_df_money
      THEN output_msg := '代发费用被篡改或代发费用收取标准发生变化,应收代发费用（' || v_PIECE_COST || '），请重新下单';
         RETURN;
      END IF;
      v_order_type := '代发';
   ELSE
      IF client_df_money <> 0
      THEN output_msg := '代发费（'|| client_df_money|| '），当前订单不属于代发订单,无需收取代发费用，请重新下单!';
         RETURN;
      END IF;
      v_order_type := '批发';
   END IF;
   /**************************7.0 计算订单是否是代发订单，如果是代发订单，则需要校验代发费用-end*****************************/
   ---------------------8.判断当前下单用户是否支持送货入户
    select count(1) into v_temp_count  from TBL_MEMBER_DELIVERY_HOME where user_id=client_user_name and IS_SUPPORT=1 and effect_begin_date<=sysdate and  effect_end_date>=sysdate;
    if v_temp_count>0 then
        v_is_delivery_home:= 1;
    end if;
    --生成新的订单号
    v_order_number := getAutoNumber ('D');
    /**********************************************9 插入订单主表信息--start*************************************************/
    INSERT INTO TBL_ORDER_INFO (ID,
                       ORDER_NUMBER,
                       CREATE_DATE,
                       USER_NAME,
                       USER_MANAGE_NAME,
                       ORDER_TYPE,
                       ORDER_STATE,
                       ORDER_REMARK,
                       RECEIVING_NAME,
                       RECEIVING_ADDRESS,
                       RECEIVING_PHONE,
                       LOGISTICS_COMPANY_CODE,
                       LOGISTICS_COMPANY_NAME,
                       LOGISTICS_MONEY,
                       DF_MONEY,
                       PAYMENT_STATE,
                       ORDER_SOURCE,
                       YWJL_USER_NAME,
                       YWY_USER_NAME,
                       MD_ID,
                       XDR_USER_TYPE,
                       XDR_USER_NAME,
                       WAREHOUSE_ID,
                       OLD_LOGISTICS_MONEY,
                       OLD_DF_MONEY,
                       MBR_CARD,
                       MBR_CARD_REDUCE,
                       DELIVERY_TYPE,
                       FREIGHT_PAYMENT_TYPE,
                       IS_DELIVERY_HOME,
                       SALE_MD_ID
           )
     VALUES (
        SEQ_ORDER_INFO.NEXTVAL,
        v_order_number,
        SYSDATE,
        client_user_name,
        v_user_manage_name,
        v_order_type,
        1,
        client_order_remark,
        client_receiving_name,
        client_receiving_address,
        client_receiving_phone,
        client_logistics_company_code,
        v_logistics_company_name,
        client_logistics_money,
        NVL(client_df_money,0),
        1,
        client_order_source,
        v_ywjl_user_name,
        v_ywy_user_name,
        v_md_id,
        client_xdr_type,
        client_xdr_user_name,
        client_warehouse_id,
        client_logistics_money,
        NVL(client_df_money,0),
        nvl(client_mbr_card,1),
        0,
        v_shipping_method_id,
        client_freight_payment_type,
        v_is_delivery_home,
        v_md_id);
     /**********************************************9 插入订单主表信息--end**************************************************/
   
    /*************************************10.0 用户是否存在快递配置，存在则需要插入订单备注信息-start************************************/
    v_temp_count:=0;---临时变量置空
    --select count(1) into v_temp_count from tbl_user_logistics_config  where user_id = client_user_name and state = 2;
    select (select count(1)
           from table (splitstr (t.enable_logistics, ',')) a,
                tbl_standard_logistics b
          where a.column_value = b.logistics_code
                and b.shipping_method_id = v_shipping_method_id)
          +(select count(1)
              from table (splitstr (t.enable_logistics, ',')) a,
                   tbl_standard_logistics b
             where a.column_value = b.logistics_code
                   and b.shipping_method_id = v_shipping_method_id) 
          into v_temp_count
     from tbl_user_logistics_config t
    where t.user_id = client_user_name
      and t.state = 2;
    if v_temp_count > 0 then
        insert into tbl_order_remark
            (
                id,
                order_number,
                disabled_logistics,
                enable_logistics,
                disabled_logistics_name,
                enabled_logistics_name,
                create_user_id,
                create_user_realname,
                create_date,
                state
            ) 
            select seq_order_remark.nextVal,
                   v_order_number,
                   disabled_logistics,
                   (select to_char (wm_concat (a.column_value))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics,
                   disabled_logistics_name,
                   (select to_char (wm_concat (b.logistics_name))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics_name,
                   create_user_id,
                   '客户设置' create_user_realname,
                   sysdate,
                   state
              from tbl_user_logistics_config t
             where user_id = client_user_name
               and state = 2;
    else
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 start
        SELECT 
        count(1) into v_temp_count
        FROM 
        TBL_LOGISTICS_COMPANY tlc
        INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
        INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
        where tlc.code = client_logistics_company_code;
        --需要新增备注数据
        IF v_temp_count<>0 THEN
            Insert into TBL_ORDER_REMARK
            (ID, ORDER_NUMBER,STATE,ENABLE_LOGISTICS,ENABLED_LOGISTICS_NAME,CREATE_DATE,CREATE_USER_ID,CREATE_USER_REALNAME)
            select
            seq_order_remark.nextval,temp.*
            from 
            (
            SELECT 
            v_order_number ORDER_NUMBER,
            2 STATE,
            to_char(wm_concat(lc.LOGISTICS_CODE)) ENABLE_LOGISTICS, 
            (wm_concat(lc.LOGISTICS_NAME)) ENABLED_LOGISTICS_NAME,
        sysdate,
        0 CREATE_USER_ID,
        '系统设置' CREATE_USER_REALNAME
            FROM 
            TBL_LOGISTICS_COMPANY tlc
            INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
            INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
            where tlc.code = client_logistics_company_code
            ) temp;
        END IF;
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 end
    end if;
    /*************************************10.0 用户是否存在快递配置，存在则需要插入订单备注信息-end*************************************/
    /*************************************11.0 插入订单规格表 start*******************************************************/
    INSERT INTO TBL_ORDER_PRODUCT (ID,
                                  ORDER_NUMBER,
                                  ORDER_ITEM_NUMBER,
                                  USER_NAME,
                                  USER_MANAGE_NAME,
                                  ITEMNUMBER,
                                  PRODUCT_NAME,
                                  PRODUCT_COLOR,
                                  PRODUCT_UNIT_PRICE,
                                  PRODUCT_UNIT_PRICE_TAG,
                                  PRODUCT_OLD_UNIT_PRICE,
                                  ORDER_DATE,
                                  ORDER_TYPE,
                                  PRODUCT_SPECS,
                                  PRODUCT_LACK_COUNT,
                                  WAREHOUSE_ID,
                                  MBR_CARD_REDUCE,
                                  PRODUCT_ACTIVITY_ID,
                                  ACTIVITY_PRODUCT_ID,
                  BUY_OUT_FLAG
                                  )
      select seq_order_product.nextval,
             c.order_number,
             c.order_item_number,
             c.user_name,
             c.user_manage_name,
             c.product_itemnumber,
             c.product_name,
             c.product_color,
             c.product_unit_price,
             c.product_prize_tag,
             c.product_old_unit_price,
             c.order_date,
             c.order_type,
             c.product_specs,
             c.product_lack_count,
             c.warehouse_id,
             0,
             c.activity_id,
             c.activity_product_id,
         c.buy_out_flag
        FROM (
                     SELECT  DISTINCT
                     v_order_number      as order_number,
                     dense_rank () over (order by ps.parent_id)  as order_item_number,
                     client_user_name    AS USER_NAME,
                     v_user_manage_name  as user_manage_name,
                     ps.product_itemnumber,
                     pi.product_name, 
                     ps.product_color,
                     ops.sku_unit_price PRODUCT_UNIT_PRICE,
                     ps.product_prize_tag,
                     ops.sku_unit_price  as product_old_unit_price,
                     sysdate       as order_date,
                     v_order_type  as order_type,
                     ps.product_specs,
                     0   as product_lack_count,
                     oo.warehouse_id as warehouse_id,
                     op.activity_id,
                     op.activity_product_id,
             op.buy_out_flag
                FROM TBL_PRODUCT_SKU ps
                INNER JOIN TMP_NEW_ORDER_PRODUCT_SKU ops ON ps.id = ops.sku_id
                INNER JOIN TMP_NEW_ORDER_PRODUCT op ON ops.order_product_id = op.order_product_id
                INNER JOIN TMP_NEW_ORDER oo ON oo.order_id = op.order_id
                INNER JOIN TBL_PRODUCT_INFO pi on  pi.ITEMNUMBER = ps.PRODUCT_ITEMNUMBER
                WHERE oo.order_id = client_order_id
        ) c;
    /*************************************11.0 插入订单规格表 end*********************************************************/
   --14.0插入订单详细表
   INSERT INTO TBL_ORDER_PRODUCT_SKU (ID,
                                      ORDER_NUMBER,
                                      ORDER_ITEM_NUMBER,
                                      USER_NAME,
                                      CODENUMBER,
                                      COUNT,
                                      PRODUCT_UNIT_PRICE,
                                      PRODUCT_TOTAL_MONEY,
                                      PRODUCT_OLD_UNIT_PRICE,
                                      ORDER_DATE,
                                      PRODUCT_SKU,
                                      PRODUCT_SKU_NAME,
                                      PRODUCT_ITEMNUMBER,
                                      PRODUCT_COLOR,
                                      PRODUCT_SPECS,
                                      PRODUCT_LACK_COUNT,
                                      PRODUCT_OLDSALE_PRIZE,
                                      WAREHOUSE_ID,
                                      MBR_CARD_REDUCE,
                                      PRODUCT_PRIZE_COST,
                                      ACTIVITY_PRODUCT_PRIZE_COST
                                      )
      SELECT       
             seq_order_product_sku.nextval,
             v_order_number,
             top.order_item_number,
             client_user_name,
             ps.product_group_member codenumber,
             ops.count,
             ops.sku_unit_price  product_unit_price,
             ops.sku_unit_price * ops.count product_total_money,
             ops.sku_unit_price product_old_unit_price,
             sysdate,
             ps.id product_sku,
             ps.product_sku_name,
             ps.product_itemnumber,
             ps.product_color,
             ps.product_specs,
             0,
             getsku_oldprice(ps.id),
             oo.warehouse_id,
             --如果使用会员了会员卡，且会员卡价格是最低价格，则有优惠额
             (
                case when (client_mbr_card =2 and ops.sku_unit_price<ops.original_sku_unit_price) 
                then (ops.original_sku_unit_price - ops.sku_unit_price)
                else 0
                end
             ) mbr_card_reduce,
              ops.product_prize_cost,
              ops.activity_product_prize_cost
        FROM TBL_PRODUCT_SKU ps
                INNER JOIN TMP_NEW_ORDER_PRODUCT_SKU ops ON ps.id = ops.sku_id
                INNER JOIN TMP_NEW_ORDER_PRODUCT op ON ops.order_product_id = op.order_product_id
                INNER JOIN TMP_NEW_ORDER oo ON oo.order_id = op.order_id
                INNER JOIN TBL_PRODUCT_INFO pi on  pi.itemnumber = ps.product_itemnumber
                LEFT JOIN TBL_ORDER_PRODUCT top on top.itemnumber = ps.product_itemnumber 
                                                    and top.product_color = ps.product_color 
                                                    and top.product_specs = ps.product_specs
                                                    and top.user_name = client_user_name
                                                    and top.order_number = v_order_number
                WHERE oo.order_id = client_order_id;
   --14.11查询逻辑库存量,根据逻辑库存量与下单量比较，如果不足，则为缺货订购商品订单 --仅批发5双以上需要判断
   IF v_product_total_count >= 5
   THEN
      SELECT COUNT (1)
        INTO v_temp_count
        FROM (SELECT T1.PRODUCT_SKU,
                     T1.COUNT AS PRODUT_COUNT,
                     NVL (
                        (SELECT   NVL (PRODUCT_TOTAL_COUNT, 0)
                                - NVL (PRODUCT_ORDER_OCCUPY_COUNT, 0)
                                - NVL (PRE_ORDER_OCCUPY_COUNT, 0)
                           FROM TBL_PRODUCT_SKU_STOCK
                          WHERE     PRODUCT_SKU = T1.PRODUCT_SKU
                                AND WAREHOUSE_ID = T1.WAREHOUSE_ID),
                        0)
                        AS WAREHOUSE_PRODUCT_COUNT
                FROM TBL_ORDER_PRODUCT_SKU T1
               WHERE T1.ORDER_NUMBER = v_order_number)
       WHERE WAREHOUSE_PRODUCT_COUNT < PRODUT_COUNT;

      IF v_temp_count > 0
      THEN
         v_outstock_flag := 1;
      END IF;
   END IF;
   --15.0修改各表的统计性数据
   UPDATE TBL_ORDER_PRODUCT TOP
   SET   product_count =
             (select sum (tops.count)
                from TBL_ORDER_PRODUCT_SKU tops
               where     tops.order_number = top.order_number
                     and tops.order_item_number = top.order_item_number),
          product_total_money =
             (select sum (tops.product_total_money)
                from TBL_ORDER_PRODUCT_SKU tops
               where     tops.order_number = top.order_number
                     and tops.order_item_number = top.order_item_number),
          mbr_card_reduce =
             (select sum(tops.mbr_card_reduce * tops.count)
                from TBL_ORDER_PRODUCT_SKU tops
               where tops.order_number = top.order_number
                     and tops.order_item_number = top.order_item_number)
    where top.order_number = v_order_number;

   --处理一下,防止总价没有计算
   UPDATE TBL_ORDER_PRODUCT TOP
     SET product_total_money = round (top.product_count * top.product_unit_price, 2)
     WHERE top.order_number = v_order_number  and nvl (product_total_money, 0) = 0;

   --16.0计算商品总价
   SELECT SUM (TOP.PRODUCT_TOTAL_MONEY)
     INTO v_product_total_money
     FROM TBL_ORDER_PRODUCT TOP
    WHERE TOP.ORDER_NUMBER = v_order_number;

   --校验商品总价是否被篡改
   IF v_product_total_money <> client_product_money
   THEN
      output_msg :='商品价格被篡改或商品价格发生变化,应收货款（'|| v_product_total_money|| '），请重新下单!';
      ROLLBACK;
      RETURN;
   END IF;
   
    --校验订单中是否包含活动商品
    select count(1) into v_temp_activity_product_count
    from tbl_order_info oi
    where oi.order_number = v_order_number
    and exists(
        select 1
        from tbl_order_product op
        where oi.order_number = op.order_number
        and op.activity_product_id > 0 and op.product_activity_id > 0
    );
   /**
   更新订单主表数据
   **/
   UPDATE TBL_ORDER_INFO TOI
      SET PRODUCT_MONEY = v_product_total_money,
          PRODUCT_COUNT =
             (SELECT SUM (TOP.PRODUCT_COUNT)
                FROM TBL_ORDER_PRODUCT TOP
               WHERE TOP.ORDER_NUMBER = TOI.ORDER_NUMBER),
          IS_OUTSTOCK_ORDER = v_outstock_flag,
          MBR_CARD_REDUCE=(SELECT SUM(TOP.MBR_CARD_REDUCE) FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER = TOI.ORDER_NUMBER),
            LAST_CANCEL_DATE = (
              CASE WHEN v_temp_activity_product_count > 0 then GETORDERLASTCANCELDATE(v_order_number)
              else TOI.create_date + 1
              end
           )  
    WHERE TOI.ORDER_NUMBER = v_order_number;
   --17.0更新订单占用量
   INSERT INTO TBL_ORDER_WAREHOUSE_COUNT (ID,
                                          ORDER_NUMBER,
                                          WAREHOUSE_ID,
                                          PRODUCT_SKU,
                                          OCCUPY_COUNT,
                                          CREATE_DATE)
      SELECT SEQ_ORDER_WAREHOUSE_COUNT.NEXTVAL,
             ORDER_NUMBER,
             client_warehouse_id,
             PRODUCT_SKU,
             COUNT,
             SYSDATE
        FROM TBL_ORDER_PRODUCT_SKU
       WHERE ORDER_NUMBER = v_order_number;

   output_status := '1';
   output_msg := v_order_number;
EXCEPTION
   WHEN OTHERS
   THEN
      output_status := '0';
      output_msg :=
            '提交订单出现未知错误::'
         || SQLCODE
         || '::'
         || SQLERRM
         || '----';
END NEW_SUBMIT_ORDER;
------------------------------------------------
/

