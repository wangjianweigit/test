create PROCEDURE           payment_order_sale
/**
   订单付款--现金支付方式
    shif
    2017-05-17 增加合并付款的处理【多仓下单】
    2019-01-15 增加私有平台现金付款处理
    2019-07-10 update by wangjianwei
    根据订单下单人类型判断业务员类型
    
    返回值：付款结果消息
**/
(
    client_user_name in varchar2,               --用户名
    client_pay_trade_number in varchar2,        --付款交易号
    client_money in number,                     --现金支付金额
    client_pay_type in varchar2,                --现金支付方式(现金、POS刷卡、转账)
    client_sale_user_name varchar2,             --业务员用户名
    client_voucher_path varchar2,               --收款凭证
    output_status  out varchar2,                --返回的状态码 0-失败 1-成功
    output_msg out varchar2                     --返回的信息
) AS
    v_temp_count number:=0;                     --临时变量
    v_payment_state varchar2(50);               --付款状态
    v_order_state varchar2(50);                 --订单流程状态
    v_logistics_money number:=0;                --数据库中的物流费用
    v_product_money number:=0;                  --数据库中的商品总价
    v_user_type number:=0;                      --数据库中的系统用户类型
    v_user_id number:=0;                        --数据库中的系统用户ID
    v_credit_money number:=0;                   --数据库中的业务员授信额度
    v_credit_money_order number:=0;             --业务员订单已使用-订单
    v_credit_money_cz number:=0;                --业务员代客户充值待验款-充值
    v_credit_money_wait number:=0;              --业务员待缴款
    v_credit_money_use number:=0;               --业务员总待缴款
    v_state char(1);                            --数据库中的系统用户状态 或门店状态
    v_ORDER_TYPE varchar(50);                   --订单类型
    v_df_money number:=0;                       --代发费用
    v_md_id number:=0;                          --门店ID
    v_flag int:=0;                              --业务员客户关系验证数
BEGIN
    output_status:='0';
    output_msg:='订单现金支付失败，请检查!';
    --验证订单号码是否存在
    SELECT COUNT(*) INTO v_temp_count
      FROM TBL_ORDER_INFO  T1
     WHERE T1.USER_NAME = client_user_name
           AND EXISTS(SELECT 1 FROM TBL_ORDER_UNION_PAY_DETAIL T2 WHERE T2.PAY_TRADE_NUMBER=client_pay_trade_number AND T2.ORDER_NUMBER = T1.ORDER_NUMBER);       
    IF v_temp_count = 0 THEN
        output_msg:='订单号码有误，无法完成现金支付，请检查!';
        RETURN;
    END IF;
    SELECT xdr_user_type INTO v_user_type
      FROM TBL_ORDER_INFO  T1
     WHERE T1.USER_NAME = client_user_name
           AND EXISTS(SELECT 1 FROM TBL_ORDER_UNION_PAY_DETAIL T2 WHERE T2.PAY_TRADE_NUMBER=client_pay_trade_number AND T2.ORDER_NUMBER = T1.ORDER_NUMBER)
           and rownum = 1;       
    
    --检查业务人员用户是否正常
    IF v_user_type != 8 THEN
        SELECT COUNT(*) INTO v_temp_count FROM TBL_SYS_USER_INFO WHERE USER_NAME = client_sale_user_name;
        IF v_temp_count = 1 THEN
            SELECT ID,CREDIT_MONEY,STATE into v_user_id,v_credit_money,v_state FROM TBL_SYS_USER_INFO WHERE USER_NAME = client_sale_user_name;
            IF v_state = '1' THEN
                output_msg:='当前用户已被禁用，无法使用现金支付!';
                RETURN;
            ELSE
                IF v_user_type != 3 AND v_user_type != 5 AND v_user_type != 6 AND v_user_type != 4 THEN
                    output_msg:='当前操作员无法使用现金支付!';
                    RETURN;
                ELSE
                   IF v_user_type = 3 OR v_user_type = 4 THEN 
                       IF v_credit_money <= 0 THEN
                            output_msg:='当前业务员没有授信额度，无法使用现金支付!';
                            RETURN;
                        END IF;
                   END IF;
                   IF v_user_type = 5 OR v_user_type = 6 THEN
                       SELECT count(1) into v_temp_count FROM TBL_STORE_INFO C WHERE C.SHOPKEEPER_USER_ID = v_user_id OR EXISTS(SELECT 1 FROM TBL_STORE_USER_REL A WHERE A.STORE_ID = C.ID AND A.USER_ID = v_user_id AND A.TYPE = '6');
                       --店长或营业员
                       IF v_temp_count = 1 THEN
                            --查询门店授信额度
                            SELECT C.STATE,C.ID,C.STORE_LIMIT
                              into v_state,v_md_id,v_credit_money
                              FROM TBL_STORE_INFO C
                             WHERE C.SHOPKEEPER_USER_ID = v_user_id OR EXISTS(SELECT 1 FROM TBL_STORE_USER_REL A WHERE A.STORE_ID = C.ID AND A.USER_ID = v_user_id AND A.TYPE = '6');
                            IF  v_state = '1' THEN
                                output_msg:='当前门店已停止运营，无法使用现金支付!';
                                RETURN;
                            END IF;
                            IF v_credit_money <= 0 THEN
                                output_msg:='当前门店没有授信额度，无法使用现金支付!';
                                RETURN;
                            END IF;
                       ELSE
                            output_msg:='当前业务人员未关联门店!';
                            RETURN;
                       END IF;
                    END IF;
                END IF;
            END IF;
        END IF;
    ELSE
        v_md_id := 0; 
        SELECT COUNT(*) INTO v_temp_count FROM TBL_STATIONED_USER_INFO WHERE USER_NAME = client_sale_user_name;
        IF v_temp_count < 1 THEN
          output_msg:='业务人员信息异常!';
          RETURN;
        END IF;
    END IF;
    
    --获取用户信息
    SELECT COUNT(*) INTO v_temp_count FROM TBL_USER_INFO WHERE USER_NAME = client_user_name;
    IF v_temp_count=0 THEN
        output_msg:='用户信息错误，请检查!';
        RETURN;
    END IF;

    --验证业务员收款凭证
    IF client_voucher_path IS NULL OR client_voucher_path ='' THEN
        output_msg:='请上传客户支付凭证!';
        RETURN;
    END IF;
    --获取流程状态，支付状态
    DECLARE CURSOR to_pay_orders IS
    SELECT T.ORDER_NUMBER,T.ORDER_STATE,T.PAYMENT_STATE,T.LOGISTICS_MONEY,T.PRODUCT_MONEY,T.DF_MONEY,T.ORDER_TYPE
      FROM TBL_ORDER_INFO T
     WHERE T.USER_NAME = client_user_name
           AND EXISTS(SELECT 1 FROM TBL_ORDER_UNION_PAY_DETAIL T2  WHERE  T2.PAY_TRADE_NUMBER=client_pay_trade_number AND T2.ORDER_NUMBER = T.ORDER_NUMBER);
    BEGIN
        FOR c_row in to_pay_orders LOOP
            --验证订单状态和支付状态是否为 未支付
          IF c_row.ORDER_STATE<> 1 THEN
              IF c_row.payment_state=2 THEN
                  output_msg:= c_row.order_number||'订单已付款，无需重复付款!';
              END IF;
              IF c_row.payment_state=3 THEN
                  output_msg:=c_row.order_number||'订单已通过现金支付方式付款，等待审核中!';
              END IF;
              RETURN;
          ELSE
            IF c_row.ORDER_TYPE='批发' THEN
                v_logistics_money := v_logistics_money + c_row.logistics_money;
                v_product_money := v_product_money + c_row.product_money;
            END IF;
            IF c_row.ORDER_TYPE='代发' THEN
               v_logistics_money := v_logistics_money + c_row.logistics_money;
               v_product_money := v_product_money + c_row.product_money;
               v_df_money := v_df_money + c_row.df_money;
            END IF;
          END IF;
        END LOOP;
    END;
    --验证支付总额是否等于 现金支付金额
    IF client_money<>(v_logistics_money+v_product_money+v_df_money) THEN
       output_msg:='您支付的金额与（商品总价+物流费用+代发费用）不符，请刷新当前页面！';
       RETURN;
    END IF;

    --业务员或业务经理
    IF v_user_type ='3' OR v_user_type='4' THEN
       ---0查询业务代客户现金充值待审核使用额度
       SELECT NVL(SUM(MONEY),0) INTO v_credit_money_cz FROM TBL_USER_CHARGE_RECORD TUCR WHERE TUCR.STATE = '1' AND TUCR.AGENCY_USER_ID = v_user_id;
       ---1查询业务员订单现金支付待审核使用额度
       SELECT NVL(SUM(LOGISTICS_MONEY+PRODUCT_MONEY+DF_MONEY),0) INTO v_credit_money_order FROM TBL_ORDER_INFO WHERE PAYMENT_STATE = 3 AND SALE_USER_NAME = client_sale_user_name;
       ---2查询业务员待缴款额度
       SELECT NVL(SUM(CONTRIBUTION_MONEY),0) INTO v_credit_money_wait from TBL_CONTRIBUTION_WAIT WHERE STATE <> 3 AND SALE_USER_NAME = client_sale_user_name;
       ---3查询业务员总待缴款金额
       v_credit_money_use := v_credit_money_cz + v_credit_money_order + v_credit_money_wait;
       ---4计算业务员可用额度
       v_credit_money:=v_credit_money-v_credit_money_use;
       ---5计算业务员的授信额度是否大于支付金额
       IF v_credit_money >= client_money THEN
          --更新订单支付状态
          UPDATE TBL_ORDER_INFO T
             SET T.ORDER_STATE=2,T.PAYMENT_STATE=3,T.CHECK_STATE=0,T.PAYMENT_DATE=SYSDATE,T.PAYMENT_MONEY=(PRODUCT_MONEY+LOGISTICS_MONEY+DF_MONEY),T.PAYMENT_TYPE=client_pay_type,
                 T.SALE_USER_NAME=client_sale_user_name,T.SALE_USER_TYPE = v_user_type
           WHERE T.USER_NAME=client_user_name
                 AND EXISTS(SELECT 1 FROM TBL_ORDER_UNION_PAY_DETAIL T1  WHERE  T1.PAY_TRADE_NUMBER=client_pay_trade_number AND T1.ORDER_NUMBER = T.ORDER_NUMBER);
          --更新合并付款支付状态
          UPDATE TBL_ORDER_UNION_PAY T
             SET T.VOUCHER_PATH=client_voucher_path,T.STATE='1',T.PAY_DATE=SYSDATE,T.AUDIT_STATE = '0'
           WHERE T.PAY_TRADE_NUMBER = client_pay_trade_number;
          OUTPUT_STATUS:='1';
          OUTPUT_MSG:='订单现金支付成功，请耐心等待审核！';
          COMMIT;
       ELSE
          OUTPUT_MSG:='您的授信余额不足，无法完成现金支付！授信余额【'||v_credit_money||'】';
          RETURN;
       END IF;
     END IF;

    --门店
    IF v_user_type ='5' or v_user_type='6' THEN
        ---0查询业务代客户现金充值待审核使用额度
        SELECT NVL(SUM(MONEY),0) INTO v_credit_money_cz FROM TBL_USER_CHARGE_RECORD WHERE STATE = '1' AND (AGENCY_USER_TYPE='5' or AGENCY_USER_TYPE='6') AND MD_ID = v_md_id;
        ---1查询门店订单现金支付待审核使用额度
        SELECT NVL(SUM(LOGISTICS_MONEY+PRODUCT_MONEY+DF_MONEY),0) INTO v_credit_money_order FROM TBL_ORDER_INFO WHERE PAYMENT_STATE = 3 AND (XDR_USER_TYPE='5' or XDR_USER_TYPE='6') AND SALE_MD_ID = v_md_id;
        ---2查询门店待缴款额度
        SELECT NVL(SUM(CONTRIBUTION_MONEY),0) INTO v_credit_money_wait FROM TBL_CONTRIBUTION_WAIT WHERE STATE <> 3 AND (XDR_USER_TYPE='5' or XDR_USER_TYPE='6') AND MD_ID = v_md_id;
        ---3查询门店总待缴款金额
        v_credit_money_use:=v_credit_money_cz+v_credit_money_order+v_credit_money_wait;
        ---4计算门店可用额度
        v_credit_money:=v_credit_money-v_credit_money_use;
        ---5计算业务员的授信额度是否大于支付金额
        IF v_credit_money >= client_money THEN
            --更新订单支付状态
            UPDATE TBL_ORDER_INFO T
               SET T.ORDER_STATE = 2,T.PAYMENT_STATE = 3,T.CHECK_STATE = 0,T.PAYMENT_DATE = SYSDATE,T.PAYMENT_MONEY=(PRODUCT_MONEY+LOGISTICS_MONEY+DF_MONEY),
                   T.PAYMENT_TYPE=client_pay_type,T.SALE_MD_ID = v_md_id,T.SALE_USER_NAME=client_sale_user_name,T.SALE_USER_TYPE = v_user_type
             WHERE T.USER_NAME = CLIENT_USER_NAME
                   AND EXISTS(SELECT 1 FROM TBL_ORDER_UNION_PAY_DETAIL T1  WHERE  T1.PAY_TRADE_NUMBER=client_pay_trade_number AND T1.ORDER_NUMBER = T.ORDER_NUMBER);
             --更新合并付款支付状态
            UPDATE TBL_ORDER_UNION_PAY T
             SET T.VOUCHER_PATH=client_voucher_path,T.STATE='1',T.PAY_DATE=SYSDATE,T.AUDIT_STATE = '0'
            WHERE T.PAY_TRADE_NUMBER = client_pay_trade_number;
            output_status:='1';
            output_msg:='订单现金支付成功，请耐心等待审核！';
            COMMIT;
        ELSE
            output_msg:='您的授信余额不足，无法完成现金支付！授信余额【'||v_credit_money||'】';
            RETURN;
        END IF;
    END IF;
    
    --门店
    IF v_user_type = '8' THEN
      --更新订单支付状态
      UPDATE TBL_ORDER_INFO T
         SET T.ORDER_STATE = 2,T.PAYMENT_STATE = 3,T.CHECK_STATE = 0,T.PAYMENT_DATE = SYSDATE,T.PAYMENT_MONEY=(PRODUCT_MONEY+LOGISTICS_MONEY+DF_MONEY),
             T.PAYMENT_TYPE=client_pay_type,T.SALE_MD_ID = v_md_id,T.SALE_USER_NAME=client_sale_user_name,T.SALE_USER_TYPE = v_user_type
       WHERE T.USER_NAME = CLIENT_USER_NAME
             AND EXISTS(SELECT 1 FROM TBL_ORDER_UNION_PAY_DETAIL T1  WHERE  T1.PAY_TRADE_NUMBER=client_pay_trade_number AND T1.ORDER_NUMBER = T.ORDER_NUMBER);
       --更新合并付款支付状态
      UPDATE TBL_ORDER_UNION_PAY T
         SET T.VOUCHER_PATH=client_voucher_path,T.STATE='1',T.PAY_DATE=SYSDATE,T.AUDIT_STATE = '0'
       WHERE T.PAY_TRADE_NUMBER = client_pay_trade_number;
      output_status:='1';
      output_msg:='订单现金支付成功，请耐心等待审核！';
      COMMIT;
    END IF;
    
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='订单现金支付出现未知错误';
    ROLLBACK;
END payment_order_sale;
/

