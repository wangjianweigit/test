create FUNCTION           replaceProperties
/**
    处理聚水潭商品属性函数
**/
(p_properties_name IN VARCHAR2, p_properties IN VARCHAR2)
    RETURN varchar2
AS
    v_properties_value varchar2(1000 byte);
BEGIN

    v_properties_value := p_properties_name;
    
    for properties_value in (select * from table(SPLITSTR(p_properties,';'))) loop
        v_properties_value := replace(v_properties_value, properties_value.COLUMN_VALUE||':', '');
    end loop;

    return v_properties_value;
END replaceProperties;
/

