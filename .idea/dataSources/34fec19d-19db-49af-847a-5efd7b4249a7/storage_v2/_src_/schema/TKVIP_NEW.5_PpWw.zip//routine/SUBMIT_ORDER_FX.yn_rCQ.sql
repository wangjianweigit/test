create PROCEDURE           SUBMIT_ORDER_FX
/**
   提交订单-微信分销自动提交订单(绑定默认仓库)
    shif
    20170517
    增加记录订单是否是缺货商品订单   shif 2017-11-23
    返回值：订单提交结果消息

    songwangwen 2018.08.28 预售活动相关修改

    songwangwen 2018.11.29  发货方式调整相关修改(分销订单默认代发,不允许到付运费)
    
    liujialong  2019.1.8  订单主表增加用户是否支持送货入户
    
    yejingquan 20190311 下单用户是否存在快递配置
    
    zhengfy 20190716 记录活动id、活动商品id、商品报价、订单自动取消时间

**/
(
        client_user_name in varchar2,              --用户名
        client_receiving_name in varchar2,         --收货人姓名
        client_receiving_phone in varchar2,        --收货电话
        client_user_province_id in number,         --收货地省ID
        client_receiving_address in varchar2,      --收货地址
        client_order_remark in varchar2,           --订单备注
        client_order_sku_ids in varchar2,          --商品SKU集合  使用逗号分隔
        client_order_sku_counts in varchar2,       --商品订购数量  使用逗号分隔
        client_logistics_company_code in varchar2, --物流公司代码
        client_order_source  in varchar2,          --订单来源
        output_status  out varchar2,               --返回的状态码 0-失败 1-成功
        output_msg out varchar2                    --返回的信息
) AS
    v_user_manage_name varchar2(50);          --客户姓名
    v_logistics_company_id number:=0;         --物流公司ID
    v_logistics_company_name varchar2(50);    --物流公司名称
    v_sku_count int:=0;                       --商品SKU数组个数
    v_sku_counts_count int:=0;                --商品数量数组个数
    temp_count int:=1;                        --临时变量 计数
    temp_sku_id number:=0;                    --临时变量  SKUID
    temp_sku_count number:=0;                 --临时变量 订购数量
    temp_ok_count_ck number:=0;               --临时变量  仓库实际库存数
    v_order_number varchar2(21);              --订单号
    v_product_total_money number:=0;          --商品总价 系统计算得出
    v_ysyf number:=0;                         --应收运费 系统计算得出
    v_temp_count int:=0;                      --临时变量
    v_is_outstock int:=0;                     --缺货预售标记
    v_order_type varchar2(50);                --订单类型   批发  代发
    v_issuing_grade_id number:=1;             --用户代发等级ID
    v_piece_cost number:=0;                   --代发等级单价费用
    v_product_total_count number:=0;          --购买商品总数
    v_user_state number:=0;                   --用户状态
    v_df_money number:=0;                     --代发费用
    v_ywjl_user_name varchar2(50);            --业务经理用户名
    v_ywy_user_name varchar2(50);             --业务员用户名
    v_md_id number:=0;                        --门店ID
    v_xdr_user_type CHAR(1):='7';             --下单人用户类型    自行下单
    v_xdr_user_name VARCHAR2(50);             --下单人用户名
    v_distribution_state number:=0;           --是否开通了分销权限   0 未开通   1已开通
    v_warehouse_id number:= 2;                --分销绑定仓库
    v_site_id number:=0;                      --下单用户绑定仓库
    v_pay_trade_number varchar2(50 byte);     --付款交易号
    v_outstock_flag number:=0;                --是否缺货订购订单标识
    v_shipping_method_id NUMBER;          --标准配送方式ID,关联表TBL_SHIPPING_METHOD的ID字段
    v_freight_payment_type NUMBER:=1;         --运费是否到付  1.先支付运费   ；2：到付运费    
    v_is_delivery_home NUMBER:=2;          --用户是否支持送货入户
    v_user_logistics_count     NUMBER :=0;    --用户是否存在快递配置
    v_temp_activity_product_count NUMBER :=0;

BEGIN
    output_status:='0';
    --1.0校验下单仓库是否有效
    SELECT COUNT(1)
      INTO v_temp_count
      FROM tbl_site_warehouse t
     WHERE t.warehouse_id = v_warehouse_id
           AND EXISTS (SELECT 1
              FROM TBL_USER_INFO T1
             WHERE T1.USER_NAME = CLIENT_USER_NAME
                   AND T1.SITE_ID = T.SITE_ID);
    IF v_temp_count = 0 THEN
        output_msg:='下单仓库不存在!';
        RETURN;
    END IF;
    v_temp_count := 0;
    --2.0数据有效性校验
    v_sku_count:=length(replace(client_order_sku_ids,',',',-'))-length(client_order_sku_ids)+1;
    v_sku_counts_count:=length(replace(client_order_sku_counts,',',',-'))-length(client_order_sku_counts)+1;
    IF v_sku_count <> v_sku_counts_count THEN
        output_msg:='商品个数或数量个数不符!';
        RETURN;
    END IF;
    --校验SKU的有效性
    SELECT v_sku_count-COUNT(*) INTO v_temp_count FROM TBL_PRODUCT_SKU A,(
        SELECT substr(t,1,instr(t,',',1)-1) skuid_str  FROM (
            SELECT substr(s,instr(s,',',1,rownum)+1) AS T,ROWNUM AS d ,instr(s,',',1,ROWNUM)+1 FROM (
                SELECT ','||client_order_sku_ids||','  AS S FROM DUAL
            )CONNECT BY instr(s,',','1',ROWNUM)>1
        ) WHERE T IS NOT NULL
    ) B,TBL_PRODUCT_INFO C WHERE A.ID = B.SKUID_STR AND A.PRODUCT_ITEMNUMBER = C.ITEMNUMBER AND (c.STATE='上架' or c.STATE='暂下架' ) AND A.STATE='上架';

    IF v_temp_count<>0 THEN
        output_msg:='SKU错误或已下架请检查SKU的有效性!';
        RETURN;
    END IF;

    --3.0查询物流公司名称
    SELECT COUNT(*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE CODE = client_logistics_company_code;
    IF v_temp_count<>0 THEN
        SELECT ID,NAME,shipping_method_id
    INTO v_logistics_company_id,v_logistics_company_name,v_shipping_method_id
    FROM TBL_LOGISTICS_COMPANY WHERE CODE = client_logistics_company_code;
    ELSE
        output_msg:='物流信息不能为空，请检查!'||client_logistics_company_code||'--';
        RETURN;
    END IF;

    --4.0查询客户姓名
    SELECT COUNT(*) INTO v_temp_count FROM TBL_USER_INFO WHERE USER_NAME = client_user_name;
    IF v_temp_count<>0 THEN
        SELECT (SELECT TSUI.USER_NAME FROM TBL_SYS_USER_INFO TSUI WHERE TSUI.ID = TUI.MARKET_SUPERVISION_USER_ID ) AS MARKET_SUPERVISION_USER_NAME,
               (SELECT TSUI.USER_NAME FROM TBL_SYS_USER_INFO TSUI WHERE TSUI.ID = TUI.REFEREE_USER_ID ) AS REFEREE_USER_NAME,
               TUI.STORE_ID,
               TUI.DISTRIBUTION_STATE,
               TUI.USER_MANAGE_NAME,
               TUI.ISSUING_GRADE_ID,
               TUI.USER_STATE,
               TUI.SITE_ID
          INTO v_ywjl_user_name,v_ywy_user_name,v_md_id,v_distribution_state,v_user_manage_name,v_issuing_grade_id,v_user_state,v_site_id
          FROM TBL_USER_INFO TUI
         WHERE USER_NAME = client_user_name;
        IF v_user_state = 2 THEN
            output_msg:='当前经销商被禁用，无法生成代发订单!';
            RETURN;
        END IF;

        --检查当前用户是否开通了分销权限   0未开通   1已开通
        IF v_distribution_state = 0 THEN
            output_msg:='当前经销商没有开通分销权限，无法生成代发订单!';
            RETURN;
        END IF;
        v_xdr_user_name:=client_user_name;
    ELSE
        output_msg:='经销商信息不能为空，请检查!';
        RETURN;
    END IF;

    --5.0校验下单数量是否大于库存数
    WHILE temp_count <= v_sku_count LOOP
        temp_sku_id:=getStrforArrid(','||client_order_sku_ids||',',',',temp_count);
        temp_sku_count:=getStrforArrid(','||client_order_sku_counts||',',',',temp_count);
        --5.1判断该SKU是否为可缺货订购
        SELECT A.is_outstock INTO v_is_outstock FROM TBL_PRODUCT_SKU A WHERE A.ID = temp_sku_id;
        --5.11非缺货订单的商品，判断下单数是否大于库存可用数
        IF v_is_outstock = 0 THEN
           --查询可下单库存数
           SELECT GETPRODUCTSKU_STOCKS(temp_sku_id,v_warehouse_id,client_user_name) INTO temp_ok_count_ck FROM DUAL;
           IF temp_ok_count_ck < temp_sku_count THEN
               SELECT 'SKU('||temp_sku_id||'),货号:'||product_itemnumber||' '||product_sku_name||',可下单数：'||temp_ok_count_ck||'，您实际下单数：'||temp_sku_count INTO output_msg FROM TBL_PRODUCT_SKU WHERE ID = temp_sku_id;
               RETURN;
           END IF;
           --商品参加了预售活动，则会对预售活动的SKU表进行SKU销售数量的更新
            UPDATE TBL_SALE_ACTIVITY_SKU TSAS
                     SET ACTIVITY_SELL_AMOUNT = ACTIVITY_SELL_AMOUNT + temp_sku_count
                   WHERE EXISTS(
                         SELECT 1
                           FROM TBL_ACTIVITY_INFO TAI,TBL_ACTIVITY_DETAIL TSAI,
                           TBL_ACTIVITY_PRODUCT AP
                          WHERE TAI.ID = TSAS.ACTIVITY_ID AND TAI.ID = TSAI.ACTIVITY_ID 
                                AND TAI.ID = AP.ACTIVITY_ID
                                AND AP.PRODUCT_ITEMNUMBER = TSAS.PRODUCT_ITEMNUMBER
                                AND EXISTS (SELECT 1
                                    FROM TBL_ACTIVITY_SITE tas
                                   WHERE tas.site_id = v_site_id AND tas.ACTIVITY_ID = TAI.ID)
                                AND AP.ACTIVITY_START_DATE <= SYSDATE
                                AND AP.ACTIVITY_END_DATE >= SYSDATE
                                AND TAI.ACTIVITY_STATE = '3'
                                AND TAI.STATE = '2'
                                AND TAI.ACTIVITY_TYPE = '4'
                                AND (CASE WHEN (TSAI.USER_GROUP_ID = 0 OR TSAI.USER_GROUP_ID IS NULL) THEN 1 ELSE CASE WHEN 
                                EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB 
                                WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND TSAI.USER_GROUP_ID = AA.ID AND  BB.USER_ID = client_user_name
                                AND (bb.ACTIVITY_ID = tsai.activity_id OR bb.ACTIVITY_ID = 0)
                                ) THEN 1 ELSE 0 END END) = 1 
           )
                         AND TSAS.PRODUCT_SKU = temp_sku_id;
           --商品参加了非预售活动，则会对非预售活动的SKU表进行SKU销售数量的更新
           UPDATE TBL_SALE_ACTIVITY_SKU TSAS
                     SET ACTIVITY_SELL_AMOUNT = ACTIVITY_SELL_AMOUNT + temp_sku_count
                   WHERE EXISTS(
                         SELECT 1
                           FROM TBL_ACTIVITY_INFO TAI, 
               TBL_ACTIVITY_DETAIL TSAI,
                           TBL_ACTIVITY_PRODUCT AP
                          WHERE TAI.ID = TSAS.ACTIVITY_ID
                AND TAI.ID = AP.ACTIVITY_ID
                                AND AP.PRODUCT_ITEMNUMBER = TSAS.PRODUCT_ITEMNUMBER
                                AND TAI.ID = TSAI.ACTIVITY_ID
                                AND EXISTS (SELECT 1
                                    FROM TBL_ACTIVITY_SITE tas
                                   WHERE tas.site_id = v_site_id AND tas.ACTIVITY_ID = TAI.ID)
                                AND AP.ACTIVITY_START_DATE <= SYSDATE
                                AND AP.ACTIVITY_END_DATE >= SYSDATE
                                AND TAI.ACTIVITY_STATE = '3'
                                AND TAI.STATE = '2'
                                AND TAI.ACTIVITY_TYPE != '4'
                                AND TSAI.LOCKED_STOCK = '2'
                                AND (CASE WHEN (TSAI.USER_GROUP_ID = 0 OR TSAI.USER_GROUP_ID IS NULL) THEN 1 ELSE CASE WHEN 
                                EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB 
                                WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND TSAI.USER_GROUP_ID = AA.ID AND  BB.USER_ID = client_user_name
                                AND (bb.ACTIVITY_ID = tsai.activity_id OR bb.ACTIVITY_ID = 0)
                                ) THEN 1 ELSE 0 END END) = 1 
           )
                         AND TSAS.PRODUCT_SKU = temp_sku_id
                         AND TSAS.WAREHOUSE_ID = v_warehouse_id;
        END IF;
        temp_count:=temp_count+1;
    END LOOP;

    --6.0计算物流价格(默认不允许到付邮费)
    v_ysyf:=getFreightMoney(v_logistics_company_id,client_user_province_id,client_order_sku_ids,client_order_sku_counts,v_warehouse_id,1);

    --7.0计算购买商品总数
     SELECT SUM(substr(t,1,instr(t,',',1)-1)) INTO v_product_total_count  FROM (
            SELECT substr(s,instr(s,',',1,ROWNUM)+1) AS T,ROWNUM AS d ,instr(s,',',1,ROWNUM)+1 FROM (
                SELECT ','||client_order_sku_counts||','  AS S FROM DUAL
            )CONNECT BY instr(s,',','1',ROWNUM)>1
        ) WHERE T IS NOT NULL;

    --8.0查询用户代发等级ID
    IF v_issuing_grade_id = 0 THEN
       v_issuing_grade_id := 1;
    END IF;
    --查询代发等级的单价费用
    SELECT PIECE_COST INTO v_piece_cost FROM TBL_ISSUING_GRADE WHERE ID =v_issuing_grade_id;
    v_df_money := v_product_total_count * v_piece_cost;
    v_order_type := '代发';
    --判断当前下单用户是否支持送货入户
    select count(1) into v_temp_count  from TBL_MEMBER_DELIVERY_HOME where user_id=client_user_name and IS_SUPPORT=1 and effect_begin_date<=sysdate and  effect_end_date>=sysdate;
    if v_temp_count>0 then
        v_is_delivery_home:= 1;
    end if;
    --9.0获取订单号
    v_order_number:=getAutoNumber('D');
    --插入订单主表
    INSERT INTO TBL_ORDER_INFO(
        ID,ORDER_NUMBER, CREATE_DATE,USER_NAME,USER_MANAGE_NAME,ORDER_TYPE,
        ORDER_STATE,ORDER_REMARK,RECEIVING_NAME,RECEIVING_ADDRESS,RECEIVING_PHONE,
        LOGISTICS_COMPANY_CODE,LOGISTICS_COMPANY_NAME,LOGISTICS_MONEY,DF_MONEY,PAYMENT_STATE,
        ORDER_SOURCE,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,XDR_USER_TYPE,XDR_USER_NAME,WAREHOUSE_ID,
        OLD_LOGISTICS_MONEY,OLD_DF_MONEY,DELIVERY_TYPE,FREIGHT_PAYMENT_TYPE,IS_DELIVERY_HOME
    )
    VALUES(
        SEQ_ORDER_INFO.NEXTVAL,v_order_number,SYSDATE,client_user_name,v_user_manage_name,v_order_type,
        1,client_order_remark,client_receiving_name,client_receiving_address,client_receiving_phone,
        client_logistics_company_code,v_logistics_company_name,v_ysyf,v_df_money,
        1,client_order_source,v_ywjl_user_name,v_ywy_user_name,v_md_id,v_xdr_user_type,v_xdr_user_name,v_warehouse_id,
        v_ysyf,v_df_money,v_shipping_method_id,v_freight_payment_type,v_is_delivery_home
    );
    --用户是否存在快递配置
   --select count(1) into v_user_logistics_count
   --  from tbl_user_logistics_config
   -- where user_id = client_user_name
   --   and state = 2;
    select (select count(1)
           from table (splitstr (t.enable_logistics, ',')) a,
                tbl_standard_logistics b
          where a.column_value = b.logistics_code
                and b.shipping_method_id = v_shipping_method_id)
          +(select count(1)
              from table (splitstr (t.enable_logistics, ',')) a,
                   tbl_standard_logistics b
             where a.column_value = b.logistics_code
                   and b.shipping_method_id = v_shipping_method_id) 
          into v_user_logistics_count
     from tbl_user_logistics_config t
    where t.user_id = client_user_name
      and t.state = 2;  
    if v_user_logistics_count > 0 then
        insert into tbl_order_remark
            (
                id,
                order_number,
                disabled_logistics,
                enable_logistics,
                disabled_logistics_name,
                enabled_logistics_name,
                create_user_id,
                create_user_realname,
                create_date,
                state
            ) 
            select seq_order_remark.nextVal,
                   v_order_number,
                   disabled_logistics,
                   (select to_char (wm_concat (a.column_value))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics,
                   disabled_logistics_name,
                   (select to_char (wm_concat (b.logistics_name))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics_name,
                   create_user_id,
                   '客户设置' create_user_realname,
                   sysdate,
                   state
              from tbl_user_logistics_config t
             where user_id = client_user_name
               and state = 2;
    else
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 start
        SELECT 
        count(1) into v_temp_count
        FROM 
        TBL_LOGISTICS_COMPANY tlc
        INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
        INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
        where tlc.code = client_logistics_company_code;
        --需要新增备注数据
        IF v_temp_count<>0 THEN
            Insert into TBL_ORDER_REMARK
            (ID, ORDER_NUMBER,STATE,ENABLE_LOGISTICS,ENABLED_LOGISTICS_NAME,CREATE_DATE,CREATE_USER_ID,CREATE_USER_REALNAME)
            select
            seq_order_remark.nextval,temp.*
            from 
            (
            SELECT 
            v_order_number ORDER_NUMBER,
            2 STATE,
            to_char(wm_concat(lc.LOGISTICS_CODE)) ENABLE_LOGISTICS, 
            (wm_concat(lc.LOGISTICS_NAME)) ENABLED_LOGISTICS_NAME,
        sysdate,
        0 CREATE_USER_ID,
        '系统设置' CREATE_USER_REALNAME
            FROM 
            TBL_LOGISTICS_COMPANY tlc
            INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
            INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
            where tlc.code = client_logistics_company_code
            ) temp;
        END IF;
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 end
    end if;
    --10.0插入订单规格表
    INSERT INTO TBL_ORDER_PRODUCT(
        ID,ORDER_NUMBER,ORDER_ITEM_NUMBER,USER_NAME,USER_MANAGE_NAME,ITEMNUMBER,
        PRODUCT_NAME,PRODUCT_COLOR,
        PRODUCT_UNIT_PRICE,
        PRODUCT_UNIT_PRICE_TAG,
        PRODUCT_OLD_UNIT_PRICE,ORDER_DATE,ORDER_TYPE,PRODUCT_SPECS,
        PRODUCT_LACK_COUNT,
        WAREHOUSE_ID,
        PRODUCT_ACTIVITY_ID,
        ACTIVITY_PRODUCT_ID
    )
    SELECT SEQ_ORDER_PRODUCT.NEXTVAL,C.ORDER_NUMBER,
           C.ORDER_ITEM_NUMBER,C.USER_NAME,C.USER_MANAGE_NAME,C.PRODUCT_ITEMNUMBER,C.PRODUCT_NAME,C.PRODUCT_COLOR,
           C.PRODUCT_UNIT_PRICE,C.PRODUCT_PRIZE_TAG,C.PRODUCT_OLD_UNIT_PRICE,C.ORDER_DATE,C.ORDER_TYPE,C.PRODUCT_SPECS,
           C.PRODUCT_LACK_COUNT,C.WAREHOUSE_ID,
           (case when activity_state='going' then C.activity_id else null end) activity_id,
           (case when activity_state='going' then C.activity_product_id else null end) activity_product_id
        FROM (
        SELECT DISTINCT
            v_order_number AS ORDER_NUMBER,DENSE_RANK() OVER(ORDER BY A.PARENT_ID) AS ORDER_ITEM_NUMBER,client_user_name AS USER_NAME,
            v_user_manage_name AS USER_MANAGE_NAME, A.PRODUCT_ITEMNUMBER,
            (SELECT F.PRODUCT_NAME FROM TBL_PRODUCT_INFO F WHERE F.ITEMNUMBER = A.PRODUCT_ITEMNUMBER AND ROWNUM=1) AS PRODUCT_NAME,A.PRODUCT_COLOR,
            getSku_User_SalePrice(client_user_name,A.ID) AS PRODUCT_UNIT_PRICE,
            A.PRODUCT_PRIZE_TAG,
            getSku_User_SalePrice(client_user_name,A.ID) AS PRODUCT_OLD_UNIT_PRICE,
            SYSDATE AS ORDER_DATE,v_order_type AS ORDER_TYPE,A.PRODUCT_SPECS,0 AS PRODUCT_LACK_COUNT,v_warehouse_id as warehouse_id,
             (case when length(NVL(GET_ACTIVITY_TAG(client_user_name,product_itemnumber),''))>0 then to_number(substr(NVL(GET_ACTIVITY_TAG(client_user_name,product_itemnumber),''),0,instr(NVL(GET_ACTIVITY_TAG(client_user_name,product_itemnumber),''),'#-#',1,1)-1)) else null end) activity_id,
            (case when length(NVL(GET_ACTIVITY_TAG(client_user_name,product_itemnumber),''))>0 then substr(NVL(GET_ACTIVITY_TAG(client_user_name,product_itemnumber),''),instr(NVL(GET_ACTIVITY_TAG(client_user_name,product_itemnumber),''),'#-#',1,2)+3,5) else '' end) activity_state,
            (case when length(NVL(GET_ACTIVITY_TAG(client_user_name,product_itemnumber),''))>0 then to_number(substr(NVL(GET_ACTIVITY_TAG(client_user_name,product_itemnumber),''),instr(NVL(GET_ACTIVITY_TAG(client_user_name,product_itemnumber),''),'#-#',1,4)+3)) else null end) activity_product_id
        FROM TBL_PRODUCT_SKU A,
        (SELECT substr(t,1,instr(t,',',1)-1) skuid  FROM (
                SELECT substr(s,instr(s,',',1,ROWNUM)+1) AS T,ROWNUM AS D ,instr(s,',',1,ROWNUM)+1 FROM (
                    SELECT ','||client_order_sku_ids||','  AS S FROM DUAL
                )CONNECT BY instr(s,',','1',rownum)>1
            ) WHERE T IS NOT NULL
        ) B
        WHERE A.ID = B.SKUID
    ) C;

    --11.0插入订单详细表
    temp_count:=1;
    WHILE temp_count <= v_sku_count LOOP
        temp_sku_id:=getStrforArrid(','||client_order_sku_ids||',',',',temp_count);
        temp_sku_count:=getStrforArrid(','||client_order_sku_counts||',',',',temp_count);

        INSERT INTO TBL_ORDER_PRODUCT_SKU
        (
            ID,ORDER_NUMBER, ORDER_ITEM_NUMBER,USER_NAME,CODENUMBER,
            COUNT,PRODUCT_UNIT_PRICE,PRODUCT_TOTAL_MONEY,PRODUCT_OLD_UNIT_PRICE,ORDER_DATE,PRODUCT_SKU,
            PRODUCT_SKU_NAME,PRODUCT_ITEMNUMBER,PRODUCT_COLOR,PRODUCT_SPECS,PRODUCT_LACK_COUNT,PRODUCT_OLDSALE_PRIZE,WAREHOUSE_ID,
            ACTIVITY_PRODUCT_PRIZE_COST
        )
        SELECT
            SEQ_ORDER_PRODUCT_SKU.NEXTVAL,v_order_number,B.ORDER_ITEM_NUMBER,client_user_name,A.PRODUCT_GROUP_MEMBER,
            temp_sku_count,
            getSku_User_SalePrice(client_user_name,A.ID),
            getSku_User_SalePrice(client_user_name,A.ID) * temp_sku_count,
            getSku_User_SalePrice(client_user_name,A.ID),
            SYSDATE,A.ID,
            A.PRODUCT_SKU_NAME,A.PRODUCT_ITEMNUMBER,A.PRODUCT_COLOR,A.PRODUCT_SPECS,0,getSku_OldPrice(A.ID),v_warehouse_id as warehouse_id,
            getSku_User_QuotePrice(client_user_name, A.ID, 1, temp_sku_count, 1)
         FROM TBL_PRODUCT_SKU A,TBL_ORDER_PRODUCT B
         WHERE B.ORDER_NUMBER = v_order_number AND B.USER_NAME = client_user_name
         AND B.ITEMNUMBER = A.PRODUCT_ITEMNUMBER AND B.PRODUCT_COLOR = A.PRODUCT_COLOR
         AND B.PRODUCT_SPECS = A.PRODUCT_SPECS
         AND A.ID = temp_sku_id;

        temp_count:=temp_count+1;
    END LOOP;
    --11.11查询逻辑库存量,根据逻辑库存量与下单量比较，如果不足，则为缺货订购商品订单,5双以上
    IF v_product_total_count >=5 THEN
        SELECT COUNT(1)
          INTO v_temp_count
          FROM (SELECT T1.PRODUCT_SKU,T1.COUNT AS PRODUT_COUNT,
                        NVL((SELECT NVL(PRODUCT_TOTAL_COUNT,0) - NVL(PRODUCT_ORDER_OCCUPY_COUNT,0) - NVL(PRE_ORDER_OCCUPY_COUNT,0)
                          FROM TBL_PRODUCT_SKU_STOCK
                         WHERE PRODUCT_SKU = T1.PRODUCT_SKU AND WAREHOUSE_ID = T1.WAREHOUSE_ID),0) AS WAREHOUSE_PRODUCT_COUNT
                   FROM TBL_ORDER_PRODUCT_SKU T1
                  WHERE T1.ORDER_NUMBER = v_order_number)
         WHERE  WAREHOUSE_PRODUCT_COUNT <  PRODUT_COUNT;
        IF v_temp_count >0 THEN
           v_outstock_flag := 1;
        END IF;
    END IF;
     --12.0修改各表的统计性数据
    UPDATE TBL_ORDER_PRODUCT TOP
        SET PRODUCT_COUNT = (SELECT SUM(TOPS.COUNT)
                               FROM TBL_ORDER_PRODUCT_SKU TOPS
                              WHERE TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER AND TOPS.ORDER_ITEM_NUMBER = TOP.ORDER_ITEM_NUMBER),
            PRODUCT_TOTAL_MONEY = (SELECT SUM(TOPS.PRODUCT_TOTAL_MONEY)
                                     FROM TBL_ORDER_PRODUCT_SKU TOPS
                                    WHERE TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER AND TOPS.ORDER_ITEM_NUMBER = TOP.ORDER_ITEM_NUMBER)
        WHERE TOP.ORDER_NUMBER = v_order_number;
    --处理一下,防止总价没有计算
    UPDATE TBL_ORDER_PRODUCT TOP
       SET PRODUCT_TOTAL_MONEY = ROUND(TOP.PRODUCT_COUNT * TOP.PRODUCT_UNIT_PRICE,2)
     WHERE TOP.ORDER_NUMBER = v_order_number AND NVL(PRODUCT_TOTAL_MONEY,0) = 0;
    --13.0计算商品总价
    SELECT SUM(TOP.PRODUCT_TOTAL_MONEY) INTO v_product_total_money FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER=v_order_number;
    
    --校验订单中是否包含活动商品
    select count(1) into v_temp_activity_product_count
    from tbl_order_info oi
    where oi.order_number = v_order_number
    and exists(
        select 1
        from tbl_order_product op
        where oi.order_number = op.order_number
        and op.activity_product_id > 0 and op.product_activity_id > 0
    );
    
    UPDATE TBL_ORDER_INFO TOI
       SET PRODUCT_MONEY = v_product_total_money,
           PRODUCT_COUNT = (SELECT SUM(TOP.PRODUCT_COUNT) FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER = TOI.ORDER_NUMBER),
           IS_OUTSTOCK_ORDER = v_outstock_flag,
           LAST_CANCEL_DATE = (
              CASE WHEN v_temp_activity_product_count > 0 then GETORDERLASTCANCELDATE(v_order_number)
              else TOI.create_date + 1
              end
           )  
     WHERE TOI.ORDER_NUMBER = v_order_number;
    --14.0更新订单占用量
    INSERT INTO TBL_ORDER_WAREHOUSE_COUNT
       (ID, ORDER_NUMBER, WAREHOUSE_ID,PRODUCT_SKU, OCCUPY_COUNT, CREATE_DATE)
    SELECT SEQ_ORDER_WAREHOUSE_COUNT.NEXTVAL, ORDER_NUMBER, v_warehouse_id,PRODUCT_SKU, COUNT, SYSDATE
      FROM TBL_ORDER_PRODUCT_SKU
     WHERE ORDER_NUMBER = v_order_number;
    v_pay_trade_number:='1'||getAutoNumber('D');
    --15.0生成支付交易号处理
    INSERT INTO TBL_ORDER_UNION_PAY(ID,PAY_TRADE_NUMBER,STATE,CREATE_DATE,ORDER_SUBMOD,ORDER_XDR_TYPE,ORDER_SALE_USER_NAME)
         VALUES(SEQ_ORDER_UNION_PAY.NEXTVAL,v_pay_trade_number,0,SYSDATE,0,7,NULL);
    INSERT INTO TBL_ORDER_UNION_PAY_DETAIL(ID,PAY_TRADE_NUMBER,ORDER_NUMBER,CREATE_DATE)
         VALUES(SEQ_ORDER_UNION_PAY_DETAIL.NEXTVAL,v_pay_trade_number,v_order_number,SYSDATE);
    --16.0生成清分相关记录
    --16.1生成入驻商单个商品SKU收入
    INSERT INTO TBL_ORDER_DIVIDE_RECORD
             (ID, ORDER_NUMBER, PRODUCT_SKU, PRODUCT_ITEMNUMBER, DIVIDE_TYPE, DIVIDE_USER_ID, ORDER_MONEY, DIVIDE_MONEY, CREATE_DATE)
      SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
             ORDER_NUMBER,
             PRODUCT_SKU,
             PRODUCT_ITEMNUMBER,
             '1',
             STATIONED_USER_ID DIVIDE_USER_ID,
             PRODUCT_OLD_UNIT_PRICE ORDER_MONEY,
             GETSKU_USER_LIQUIDATIONPRICE(1, USER_NAME, PRODUCT_SKU,round(product_total_money/count,5),1) AS DIVIDE_MONEY,
             SYSDATE
        FROM (SELECT OS.ORDER_NUMBER,
                     OS.PRODUCT_SKU,
                     OS.PRODUCT_ITEMNUMBER,
                     OS.PRODUCT_OLD_UNIT_PRICE,
                     OI.USER_NAME,
                     PI.STATIONED_USER_ID,
                     os.product_total_money,
                     os.count
                FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP, TBL_ORDER_PRODUCT_SKU OS, TBL_PRODUCT_INFO PI
               WHERE OI.ORDER_NUMBER = OP.ORDER_NUMBER
                    and op.order_number = os.order_number and op.itemnumber = os.product_itemnumber and op.product_color = os.product_color and op.product_specs = os.product_specs
                     AND OS.PRODUCT_ITEMNUMBER = PI.ITEMNUMBER
                     AND OI.ORDER_NUMBER = v_order_number);
     --16.2生成平台服务单个商品SKU收入
    INSERT INTO TBL_ORDER_DIVIDE_RECORD
             (ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,ORDER_MONEY,DIVIDE_MONEY,CREATE_DATE)
      SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
             ORDER_NUMBER,
             PRODUCT_SKU,
             PRODUCT_ITEMNUMBER,
             '2',
             STATIONED_USER_ID,
             PRODUCT_OLD_UNIT_PRICE ORDER_MONEY,
             GETSKU_USER_LIQUIDATIONPRICE(2,USER_NAME,PRODUCT_SKU,round(product_total_money/count,5),1) AS DIVIDE_MONEY,
             SYSDATE
        FROM   (SELECT OS.ORDER_NUMBER,
                     OS.PRODUCT_SKU,
                     OS.PRODUCT_ITEMNUMBER,
                     OS.PRODUCT_OLD_UNIT_PRICE,
                     OI.USER_NAME,
                     PI.STATIONED_USER_ID,
                     os.product_total_money,
                     os.count
                FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP, TBL_ORDER_PRODUCT_SKU OS, TBL_PRODUCT_INFO PI
               WHERE OI.ORDER_NUMBER = OP.ORDER_NUMBER
                    and op.order_number = os.order_number and op.itemnumber = os.product_itemnumber and op.product_color = os.product_color and op.product_specs = os.product_specs
                     AND OS.PRODUCT_ITEMNUMBER = PI.ITEMNUMBER
                     AND OI.ORDER_NUMBER = v_order_number);
     --16.3生成仓储服务单个商品SKU收入
    INSERT INTO TBL_ORDER_DIVIDE_RECORD
             (ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,ORDER_MONEY,DIVIDE_MONEY,CREATE_DATE)
      SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
             ORDER_NUMBER,
             PRODUCT_SKU,
             PRODUCT_ITEMNUMBER,
             '3',
             STATIONED_USER_ID,
             PRODUCT_OLD_UNIT_PRICE ORDER_MONEY,
             GETSKU_USER_LIQUIDATIONPRICE(3,USER_NAME,PRODUCT_SKU,round(product_total_money/count,5),1) AS DIVIDE_MONEY,
             SYSDATE
        FROM   (SELECT OS.ORDER_NUMBER,
                     OS.PRODUCT_SKU,
                     OS.PRODUCT_ITEMNUMBER,
                     OS.PRODUCT_OLD_UNIT_PRICE,
                     OI.USER_NAME,
                     PI.STATIONED_USER_ID,
                     os.product_total_money,
                     os.count
                FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP, TBL_ORDER_PRODUCT_SKU OS, TBL_PRODUCT_INFO PI
               WHERE OI.ORDER_NUMBER = OP.ORDER_NUMBER
                    and op.order_number = os.order_number and op.itemnumber = os.product_itemnumber and op.product_color = os.product_color and op.product_specs = os.product_specs
                     AND OS.PRODUCT_ITEMNUMBER = PI.ITEMNUMBER
                     AND OI.ORDER_NUMBER = v_order_number);
     --16.4生成入驻商服务单个商品SKU收入
     INSERT INTO TBL_ORDER_DIVIDE_RECORD
              (ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,ORDER_MONEY,DIVIDE_MONEY,CREATE_DATE)
        SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
               ORDER_NUMBER,
               PRODUCT_SKU,
               PRODUCT_ITEMNUMBER,
               '4',
               STATIONED_USER_ID,
               PRODUCT_OLD_UNIT_PRICE ORDER_MONEY,
               GETSKU_USER_LIQUIDATIONPRICE(4,USER_NAME,PRODUCT_SKU,round(product_total_money/count,5),1) AS DIVIDE_MONEY,
               SYSDATE
          FROM (SELECT OS.ORDER_NUMBER,
                     OS.PRODUCT_SKU,
                     OS.PRODUCT_ITEMNUMBER,
                     OS.PRODUCT_OLD_UNIT_PRICE,
                     OI.USER_NAME,
                     PI.STATIONED_USER_ID,
                     os.product_total_money,
                     os.count
                FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP, TBL_ORDER_PRODUCT_SKU OS, TBL_PRODUCT_INFO PI
               WHERE OI.ORDER_NUMBER = OP.ORDER_NUMBER
                    and op.order_number = os.order_number and op.itemnumber = os.product_itemnumber and op.product_color = os.product_color and op.product_specs = os.product_specs
                     AND OS.PRODUCT_ITEMNUMBER = PI.ITEMNUMBER
                     AND OI.ORDER_NUMBER = v_order_number);
      
     --16.5生成入驻商支付服务费单个商品SKU收入
     INSERT INTO TBL_ORDER_DIVIDE_RECORD
              (ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,ORDER_MONEY,DIVIDE_MONEY,CREATE_DATE)
        SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
               ORDER_NUMBER,
               PRODUCT_SKU,
               PRODUCT_ITEMNUMBER,
               '5',
               STATIONED_USER_ID,
               PRODUCT_OLD_UNIT_PRICE ORDER_MONEY,
               GETSKU_USER_LIQUIDATIONPRICE(5,USER_NAME,PRODUCT_SKU,round(product_total_money/count,5),1) AS DIVIDE_MONEY,
               SYSDATE
          FROM (SELECT OS.ORDER_NUMBER,
                     OS.PRODUCT_SKU,
                     OS.PRODUCT_ITEMNUMBER,
                     OS.PRODUCT_OLD_UNIT_PRICE,
                     OI.USER_NAME,
                     PI.STATIONED_USER_ID,
                     os.product_total_money,
                     os.count
                FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP, TBL_ORDER_PRODUCT_SKU OS, TBL_PRODUCT_INFO PI
               WHERE OI.ORDER_NUMBER = OP.ORDER_NUMBER
                    and op.order_number = os.order_number and op.itemnumber = os.product_itemnumber and op.product_color = os.product_color and op.product_specs = os.product_specs
                     AND OS.PRODUCT_ITEMNUMBER = PI.ITEMNUMBER
                     AND OI.ORDER_NUMBER = v_order_number);
                       
     --17.0返回结果
     output_status:='1';
     output_msg:=v_order_number;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='提交订单出现未知错误::'||SQLCODE || '::'||SQLERRM||'----';
    ROLLBACK;
END SUBMIT_ORDER_FX;
------------------------------------------------
/

