create PROCEDURE           pro_readjust_order_new
/**
   订单调价【正在用】
    shif
    2017-05-02 从tkvip_new移植 [update_order_prize]
    20171024 修复预付订单产生的普通订单调价异常问题
    返回值：订单提交结果消息
**/
(
        client_order_number in varchar2,            --订单编号
        client_order_sku_ids in varchar2,           --商品SKU集合  使用逗号分隔
        client_order_old_prize in varchar2,         --商品原单价集合  使用逗号分隔
        client_order_new_prize in varchar2,         --商品折后单价集合  使用逗号分隔
        client_discount_money  in varchar2,         --商品sku优惠金额集合  使用逗号分隔
        client_logistics_company_code in varchar2,  --物流公司代码
        client_logistics_money number:=0,           --物流费用
        client_update_reason in varchar2,           --调价原因
        client_df_money in number:=0,               --代发费用
        output_status  out varchar2,                --返回的状态码 0-失败 1-成功
        output_msg out varchar2                     --返回的信息
) AS
    v_logistics_company_name varchar2(50);      --物流公司名称
    v_sku_count int:=0;                         --商品SKU数组个数
    v_sku_old_prize_count int:=0;               --商品原单价集合个数
    v_sku_new_prize_count int:=0;               --商品折后单价集合个数
    v_sku_discount_count int:=0;                --商品折后单价集合个数
    v_temp_count int:=0;                        --临时变量 计数
    temp_sku_id number:=0;                      --临时变量  SKUID
    temp_sku_new_prize number:=0;               --临时变量  原单价
    temp_sku_old_prize number:=0;               --临时变量  折后单价
    temp_sku_discount_money number:=0;          --临时变量  优惠金额
    v_order_state int:=0;                       --订单总状态
    v_payment_state int:=0;                     --订单付款状态
    v_order_type varchar2(50);                  --订单类型
    v_df_money number:=0;                       --临时变量  代发费用
BEGIN
    output_status:='0';
    --数据有效性校验
    v_sku_count:=length(replace(client_order_sku_ids,',',',-'))-length(client_order_sku_ids)+1;
    v_sku_old_prize_count:=length(replace(client_order_old_prize,',',',-'))-length(client_order_old_prize)+1;
    v_sku_new_prize_count:=length(replace(client_order_new_prize,',',',-'))-length(client_order_new_prize)+1;
    v_sku_discount_count:=length(replace(client_discount_money,',',',-'))-length(client_discount_money)+1;

    IF v_sku_count <> v_sku_old_prize_count or v_sku_count <> v_sku_new_prize_count or v_sku_count <> v_sku_discount_count then
        output_msg:='商品个数与价格组个数不符!';
        RETURN;
    END IF;

    --校验SKU的有效性
    SELECT v_sku_count - COUNT(*) INTO v_temp_count FROM TBL_PRODUCT_SKU A,(
        SELECT substr(t,1,instr(t,',',1)-1) skuid_str  FROM (
            SELECT substr(s,instr(s,',',1,ROWNUM)+1) AS t,ROWNUM AS d ,instr(s,',',1,ROWNUM)+1 FROM (
                SELECT ','||client_order_sku_ids||','  AS s FROM DUAL
            )CONNECT BY instr(s,',','1',ROWNUM)>1
        ) WHERE T IS NOT NULL
    ) B WHERE A.ID = B.SKUID_STR;
    --DBMS_OUTPUT.PUT_LINE('-------：'||v_temp_count);
    IF v_temp_count <> 0 THEN
        output_msg:='SKU错误或已下架请检查SKU的有效性!';
        RETURN;
    END IF;

    --查询物流公司名称
    SELECT COUNT(*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE CODE = client_logistics_company_code;
    IF v_temp_count<>0 THEN
        SELECT NAME INTO v_logistics_company_name FROM TBL_LOGISTICS_COMPANY WHERE CODE = client_logistics_company_code;
    ELSE
        output_msg:='物流信息不能为空，请检查!';
        RETURN;
    END IF;

    --校验订单是否存在以及订单状态
    SELECT COUNT(*) INTO v_temp_count FROM TBL_ORDER_INFO WHERE ORDER_NUMBER = client_order_number;
    IF v_temp_count <> 0 THEN
        --获取流程状态，支付状态
        SELECT ORDER_STATE,PAYMENT_STATE,ORDER_TYPE into v_order_state,v_payment_state,v_order_type FROM TBL_ORDER_INFO WHERE ORDER_NUMBER=client_order_number;
        --验证订单状态和支付状态是否为 未支付
        IF v_order_state <> 1 OR v_payment_state <> 1 THEN
            output_msg:='当前订单状态为【'||v_order_state||'】，不支持调价!';
            RETURN;
        END IF;
    ELSE
        output_msg:='订单号码有误，无法调价，请检查!';
        RETURN;
    END IF;

    v_temp_count:=1;
    --修改订单详细表的价格
    WHILE v_temp_count <= v_sku_count LOOP
        temp_sku_id:=getStrforArrid(','||client_order_sku_ids||',',',',v_temp_count);
        temp_sku_old_prize:=getStrforArrid(','||client_order_old_prize||',',',',v_temp_count);
        temp_sku_new_prize:=getStrforArrid(','||client_order_new_prize||',',',',v_temp_count);
        temp_sku_discount_money:=getStrforArrid(','||client_discount_money||',',',',v_temp_count);

         UPDATE TBL_ORDER_PRODUCT_SKU
            SET PRODUCT_UNIT_PRICE = ROUND(temp_sku_new_prize,2),
                PRODUCT_OLD_UNIT_PRICE = temp_sku_old_prize,
                PRODUCT_TOTAL_DISCOUNT_MONEY = round(temp_sku_discount_money,2),
                PRODUCT_TOTAL_MONEY = ROUND(temp_sku_old_prize * COUNT - temp_sku_discount_money,2)
        WHERE ORDER_NUMBER = client_order_number AND PRODUCT_SKU = temp_sku_id;

        v_temp_count:=v_temp_count+1;
    END LOOP;

    --修改订单规格表的单价
    UPDATE TBL_ORDER_PRODUCT ECL SET ECL.PRODUCT_UNIT_PRICE=
       (SELECT ECD.PRODUCT_UNIT_PRICE FROM TBL_ORDER_PRODUCT_SKU ECD
            WHERE ECL.USER_NAME=ECD.USER_NAME AND
                  ECL.ORDER_NUMBER=ECD.ORDER_NUMBER AND
                  ECL.ITEMNUMBER=ECD.PRODUCT_ITEMNUMBER AND ECL.PRODUCT_SPECS=ECD.PRODUCT_SPECS AND ECL.PRODUCT_COLOR=ECD.PRODUCT_COLOR AND
                  ECD.ORDER_NUMBER=ECL.ORDER_NUMBER AND ROWNUM<2)
       WHERE ECL.ORDER_NUMBER = client_order_number;

    --计算商品优惠价格和商品总价
    UPDATE TBL_ORDER_PRODUCT ECL
        SET PRODUCT_TOTAL_DISCOUNT_MONEY=(SELECT ROUND(SUM(ECD.PRODUCT_TOTAL_DISCOUNT_MONEY),2) 
                                            FROM TBL_ORDER_PRODUCT_SKU ECD 
                                           WHERE ECD.ORDER_NUMBER=ECL.ORDER_NUMBER 
                                                 AND ECD.PRODUCT_ITEMNUMBER=ECL.ITEMNUMBER
                                                 AND ECD.PRODUCT_COLOR=ECL.PRODUCT_COLOR
                                                 AND ECD.PRODUCT_SPECS=ECL.PRODUCT_SPECS),
            PRODUCT_TOTAL_MONEY=(SELECT SUM(ECD.PRODUCT_TOTAL_MONEY) 
                                   FROM TBL_ORDER_PRODUCT_SKU ECD 
                                  WHERE ECD.ORDER_NUMBER=ECL.ORDER_NUMBER 
                                        AND ECD.PRODUCT_ITEMNUMBER=ECL.ITEMNUMBER
                                        AND ECD.PRODUCT_COLOR=ECL.PRODUCT_COLOR
                                        AND ECD.PRODUCT_SPECS=ECL.PRODUCT_SPECS)
        WHERE ECL.ORDER_NUMBER=client_order_number;
     IF v_order_type='代发' THEN
        v_df_money:=client_df_money;
     ELSE
        v_df_money:=0;
     END IF;
     UPDATE TBL_ORDER_INFO ECH
        SET PRODUCT_MONEY=(SELECT SUM(ECL.PRODUCT_TOTAL_MONEY) FROM TBL_ORDER_PRODUCT ECL WHERE ECL.ORDER_NUMBER=ECH.ORDER_NUMBER),
            DISCOUNT_MONEY=(SELECT ROUND(SUM(ECL.PRODUCT_TOTAL_DISCOUNT_MONEY),2) FROM TBL_ORDER_PRODUCT ECL WHERE ECL.ORDER_NUMBER=ECH.ORDER_NUMBER),
            LOGISTICS_COMPANY_CODE = client_logistics_company_code,
            LOGISTICS_COMPANY_NAME = v_logistics_company_name,
            LOGISTICS_MONEY = client_logistics_money,
            UPDATE_REASON = client_update_reason,
            DF_MONEY=v_df_money
        WHERE ECH.ORDER_NUMBER = client_order_number;
     output_status:='1';
     output_msg:='订单调价执行成功';
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='订单调价出现未知错误';
    ROLLBACK;
END pro_readjust_order_new;
/

