create FUNCTION           getOrderSendStatus
/**
   获取发货状态
**/
(
    v_order_number   VARCHAR2,       --订单号
    order_status  number             --订单状态
) RETURN VARCHAR2
 IS
    status VARCHAR2(50);
    counts number;
    sent_count number;
    return_count number;
BEGIN
   IF order_status=3
   THEN
        select sum(count),sum(total_send_count) into counts,sent_count from TBL_ORDER_PRODUCT_SKU where ORDER_NUMBER=v_order_number;
        select nvl((select sum(tori.product_count) from tbl_order_return_info tori
            where  tori.state='2' and tori.order_number=v_order_number),0)
          into return_count  from dual;
         IF counts=sent_count+return_count
           THEN
             status :='全部发货';
             return status;
          END IF;

         IF counts<>sent_count+return_count and sent_count<>0
          THEN
            status :='部分发货';
            return status;
         END IF;

         IF sent_count=0
          THEN
            status :='发货中';
            return status;
         END IF;

   ELSE
        status :='';
        return status;
   END IF;

END getOrderSendStatus;
/

