create function GET_PRODUCT_ACTIVITY_IMG
/**
   获取商品参加活动的图片，无活动则返回商品主图
   create by reid 2019.11.06 
   返回值：图片地址
**/
(
    c_user_name             varchar2,         --用户名
    c_product_itemnumber    varchar2,         --商品货号
    c_source_type           varchar2:='PC'  --访问设备,直接英文字表示
) return varchar2
 is
     v_product_img_url varchar2(500);           --商品活动图片地址
     v_site_id number:=0;                       --客户站点id
     v_activity_id number:=0;                   --活动ID
     v_count number:=0;                         --临时变量
     v_pc_watermark_img_url varchar2(500);      --PC水印图片
     v_mobile_watermark_img_url varchar2(500);  --移动端水印图片
     v_source_type varchar2(50);                --访问设备,直接英文字表示
begin
    /*******如果c_support_flag传值错误，则赋值为默认值*********/
    v_source_type:=c_source_type;
    IF v_source_type is null OR v_source_type = '' THEN
        v_source_type:= 'PC';
    END IF;
    --如果商品不是启用状态或者无启用状态的尺码，直接返回，不显示 zhengfangyuan 2019.02.27
    select count(1)
    into v_count
    from tbl_product_info tpi where tpi.product_type in (0,3) and tpi.itemnumber = c_product_itemnumber and tpi.start_stop_state = 1
    and exists(
        select 1
        from tbl_product_sku
        where product_itemnumber = tpi.itemnumber
        and start_stop_state = 1
        and product_group = '尺码'
    );
    if v_count =0 then
        return '';
    end if;
    /*******************查询商品是否参加了平台******************************************/
    select ai.id,NVL(ap.pc_watermark_img_url,null),NVL(ap.mobile_watermark_img_url,null)
    into v_activity_id,v_pc_watermark_img_url,v_mobile_watermark_img_url 
    from tbl_activity_info ai,tbl_activity_detail ad,tbl_activity_product ap 
    where ai.id = ad.activity_id and ai.id = ap.activity_id
    and sysdate between ap.activity_start_date and ap.activity_end_date
    and ap.product_itemnumber = c_product_itemnumber
    and ai.state = 2
    and ai.is_delete = '1'
    and exists (
        select 1 from tbl_activity_site tas
        inner join tbl_user_info tui on tas.site_id = tui.site_id
        where tui.user_name = c_user_name and tas.activity_id = ai.id
    )
    and (case when (ad.user_group_id = 0 or ad.user_group_id is null) then 1 else case when 
        exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb 
        where aa.id = bb.group_id and aa.state = '2' and ad.user_group_id = aa.id and bb.user_id = c_user_name
        and (bb.activity_id = ad.activity_id or bb.activity_id = 0)
    ) then 1 else 0 end end) = 1
    and rownum <=1;
    if v_activity_id != 0 and v_source_type = 'PC' and v_pc_watermark_img_url is not null then  --PC水印图片
        v_product_img_url := v_pc_watermark_img_url;
    elsif v_activity_id != 0 and v_source_type <> 'PC' and v_mobile_watermark_img_url is not null then  --移动端水印图片
        v_product_img_url := v_mobile_watermark_img_url;
    end if;
    return v_product_img_url;
end GET_PRODUCT_ACTIVITY_IMG;
/

