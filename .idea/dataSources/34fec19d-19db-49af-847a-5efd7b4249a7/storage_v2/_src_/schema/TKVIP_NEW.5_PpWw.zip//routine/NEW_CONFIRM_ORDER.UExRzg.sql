create PROCEDURE new_confirm_order
/**
     确认订单口[多仓下单] 
     reid  2019.04.23 创建
     reid  2019.06.12 修改 清尾活动下单时，只有下单总量等于现有库存即认为买断错误修改
  **/
(
 c_user_name        IN  varchar2,             --用户名
 c_order_lst        IN  T_NEW_ORDER_LIST,     --订单数组对象
 c_confirm_type     IN  number,               --1：如果确认发送异常，不需要修正数据    2：如果确认发送异常，修正数据
 c_mbr_card         IN number:=1,             --是否使用会员卡金额结算  1:不使用   2：使用
 output_status      OUT varchar2,             --返回的状态码  0-校验失败  ；1-校验成功 ； 2-部分SKU存在异常（失效或者库存不足或者价格异常） 3-所有SKU失效
 output_msg         OUT varchar2              --返回的信息
) AS
v_order                     T_NEW_ORDER;                            --订单对象
v_order_product             T_NEW_ORDER_PRODUCT;                    --订单商品对象
v_order_product_list        T_NEW_ORDER_PRODUCT_LIST;               --订单商品对象集合
v_order_product_sku         T_NEW_ORDER_PRODUCT_SKU;                --订单商品SKU对象
v_order_product_sku_list    T_NEW_ORDER_PRODUCT_SKU_LIST;          --订单商品SKU对象集合
v_temp_count                number :=0;--临时变量
v_order_product_money       number :=0;--订单金额（页面汇总）
v_sku_product_money         number :=0;--商品SKU金额（后台汇总）
v_product_order_count       number :=0;--商品的总下单量（货号维度，汇总所有订单）
v_temp_activity_product_id  number :=0;--临时变量，活动商品ID
v_temp_ladder_price         number :=0;--临时变量，清尾活动阶梯报价
v_warehouse_buy_out_count   number :=0;--当前仓库的库存是买断计数器，有一个仓库是买断，就加一
v_total_warehouse_count   number :=0;--当前商品的总可见仓库数量  当v_warehouse_buy_out_count = v_total_warehouse_count，则表示整个货号

BEGIN
  output_status:='0';
  --循环处理订单
  IF c_order_lst.count > 0 THEN
     FOR i IN 1..c_order_lst.COUNT LOOP
        v_order:=c_order_lst(i);--获取订单对象
        /**
        1.0 判断仓库是否存在，不存在则直接返回错误，不存在包括ID错误或者ID对当前用户不可见
        **/
         select count (1) into v_temp_count
         from tbl_site_warehouse sw
         where sw.warehouse_id = v_order.warehouse_id
         and exists (select 1 from tbl_user_info ui where ui.user_name = c_user_name and sw.site_id = ui.site_id);
         IF v_temp_count = 0 THEN
            OUTPUT_MSG := '下单仓库不存在';
            RETURN;
         END IF;
        --插入订单临时表信息
        INSERT INTO TMP_NEW_ORDER 
        (
            order_id,
            warehouse_id,
            product_money,
            logistics_company_code,
            logistics_money,
            df_money,
            freight_payment_type,
            order_remark
        ) 
        VALUES (
            i,
            v_order.warehouse_id,
            v_order.product_money,
            v_order.logistics_company_code,
            v_order.logistics_money,
            v_order.df_money,
            v_order.freight_payment_type,
            v_order.order_remark
        );
        /****************************循环处理订单对象中的商品信息*********************************/
        v_order_product_list:= v_order.product_list;
          IF v_order_product_list.count > 0 THEN
                 FOR j IN 1..v_order_product_list.COUNT LOOP
                        v_order_product:=v_order_product_list(j);--获取订单商品对象ORDER_ID            NUMBER,
                        INSERT INTO TMP_NEW_ORDER_PRODUCT 
                        (order_id,order_product_id,product_itemnumber,activity_id,activity_type,activity_product_id,buy_out_flag)
                        SELECT
                        i order_id,
                        to_number(i||''||j) order_product_id,
                        v_order_product.product_itemnumber,
                        (case when activity_state='going' then temp2.activity_id else 0 end) activity_id,
                        (case when activity_state='going' then temp2.activity_type else 0 end) activity_type,
                        (case when activity_state='going' then temp2.activity_product_id else 0 end) activity_product_id,
                        1 buy_out_flag  --默认非买断
                        from
                        (
                            select 
                            (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,0,instr(activity_tag,'#-#',1,1)-1)) else 0 end) activity_id,
                            (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,instr(activity_tag,'#-#',1,1)+3,1)) else 0 end) activity_type,
                            (case when length(temp.activity_tag)>0 then substr(temp.activity_tag,instr(activity_tag,'#-#',1,2)+3,5) else '' end) activity_state,
                            (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,instr(activity_tag,'#-#',1,4)+3)) else 0 end) activity_product_id
                            from (
                                select NVL(GET_ACTIVITY_TAG(c_user_name,v_order_product.product_itemnumber),'') activity_tag from dual
                            ) temp
                        ) temp2;
                       /****************************循环处理订单对象中的商品SKU信息*********************************/
                       ---获取刚刚插入的表 TMP_NEW_ORDER_PRODUCT 的记录
                       SELECT activity_product_id into v_temp_activity_product_id FROM TMP_NEW_ORDER_PRODUCT WHERE order_id = i and order_product_id = to_number(i||''||j);
                       v_order_product_sku_list:=v_order_product.product_sku_list;
                       IF v_order_product_sku_list.count > 0 THEN
                            FOR k IN 1..v_order_product_sku_list.COUNT LOOP
                                v_order_product_sku:=v_order_product_sku_list(k);--获取订单商品SKU对象
                                INSERT INTO TMP_NEW_ORDER_PRODUCT_SKU
                                (
                                    order_id,
                                    order_product_id,
                                    sku_id,
                                    count,
                                    valid_flag,
                                    stock_count,
                                    page_sku_unit_price,
                                    is_outstock,
                                    product_prize_cost
                                )
                                SELECT    
                                    i order_id,
                                    to_number(i||''||j) order_product_id,
                                    ps.id sku_id,
                                    v_order_product_sku.count,          
                                    (case when (pi.state in ('上架','暂下架') and ps.state = '上架') then 1 else 0 end) valid_flag,
                                    getproductsku_stocks(ps.id,v_order.warehouse_id,c_user_name) stock_count,
                                    v_order_product_sku.unit_price,
                                    is_outstock_product_sku(c_user_name,ps.product_itemnumber,ps.id,v_order.warehouse_id) is_outstock,
                                    ps.product_prize_cost
                                FROM TBL_PRODUCT_SKU ps
                                INNER JOIN TBL_PRODUCT_INFO pi on ps.product_itemnumber = pi.itemnumber
                                WHERE ps.id = v_order_product_sku.sku_id;
                            END LOOP;/**end v_order_product_list**/
                       ELSE
                         output_status:='0';
                         output_msg:='订单商品SKU列表参数错误';
                         RETURN;      
                       END IF;  
                 END LOOP;/**end v_order_product_list**/
         ELSE
            output_status:='0';
            output_msg:='订单商品列表参数错误';
            RETURN;      
         END IF;
     END LOOP;/**end c_order_lst**/
    ----2 完成下单数据的记录后，进行下单库存的相关校验
    ---2.1循环所有商品，如果商品参加了【清尾活动】,且该活动设置了买断价格，则需要判断该次下单是否是买断下单，通过下单数量与总库存是否一致来判断下商品是否是【买断】
    SELECT COUNT(1) INTO v_temp_count 
    FROM TMP_NEW_ORDER_PRODUCT nop
    inner join TBL_ACTIVITY_PRODUCT_SPECPRIZE aps on nop.activity_product_id = aps.activity_product_id
    where nop.activity_type = 5
    and aps.min_count = -1 ;
    IF v_temp_count > 0 THEN
      /***********************第一层循环，循环所有的商品货号**********************************/
      BEGIN
          FOR tb IN(
            select
            op.product_itemnumber
            FROM TMP_NEW_ORDER_PRODUCT op
            WHERE op.activity_type = 5
            group by op.product_itemnumber
       ) LOOP
         --参数初始化
        v_warehouse_buy_out_count:=0;
        v_total_warehouse_count:=0;     
        /***********************第二层循环，循环所有的仓库，计算每个仓库的商品是否买断，
        只要每个仓库的库存均买断，该货号才是真正的买断**********************************/
        BEGIN
              FOR wa IN(
                             select warehouse_id from (
                                 select 
                                 t2.warehouse_id,
                                 (
                                    select NVL(sum(getproductsku_stocks(tps.id,t2.warehouse_id,c_user_name)),0)
                                    from tbl_product_sku tps where tps.product_group = '尺码'
                                    and tps.product_itemnumber = tb.product_itemnumber
                                    and tps.state = '上架'
                                 ) warehouse_count
                                 from tbl_warehouse_info t 
                                 inner join tbl_site_warehouse t2 on t.id = t2.parent_warehouse_id
                                 where exists (select 1 from tbl_user_info t1 where t1.user_name = c_user_name and t1.site_id = t2.site_id)  
                            ) where warehouse_count>0
           ) LOOP
                     v_total_warehouse_count:=v_total_warehouse_count+1;
                     select count(1) into v_temp_count from (
                            select 
                             count(id) total_num,/*SKU个数**/
                             sum(
                                case when order_count >= stock_count then 1 else 0 end --当前购买数量大于等于库存的，即算作买断
                             ) buy_out_num /*买断的SKU个数**/
                             from 
                             (
                                select
                                ps.id,
                                nvl(ops.count,0) order_count,
                                getproductsku_stocks(ps.id,wa.warehouse_id,c_user_name) stock_count
                                from
                                tbl_product_sku ps
                                left join TMP_NEW_ORDER_PRODUCT_SKU ops on ps.id = ops.sku_id
                                left join TMP_NEW_ORDER_PRODUCT op on ops.order_id = op.order_id 
                                and ops.order_product_id = op.order_product_id and op.activity_type = 5
                                left join TMP_NEW_ORDER oo on op.order_id = oo.order_id
                                where ps.product_itemnumber =  tb.product_itemnumber
                                and ps.product_group = '尺码'
                                and ps.state = '上架'
                                and oo.warehouse_id = wa.warehouse_id
                             )
                     ) temp2 where  total_num = buy_out_num;
                     /***
                     不存在 下单数量与可售库存不等的商品，则表示当前仓库买断，买断仓库
                     **/
                     if v_temp_count <> 0 then
                        --当前仓库是买断，则数量加一
                        v_warehouse_buy_out_count:=v_warehouse_buy_out_count+1;
                     end if; 
           END LOOP;
        END;
        /***当前所有仓库均买断时，讲买断标志位更新为买断***/
        IF v_warehouse_buy_out_count = v_total_warehouse_count THEN
            update TMP_NEW_ORDER_PRODUCT set BUY_OUT_FLAG = 2 WHERE product_itemnumber = tb.product_itemnumber; 
        ELSE
            update TMP_NEW_ORDER_PRODUCT set BUY_OUT_FLAG =1 WHERE product_itemnumber = tb.product_itemnumber;
        END IF;
       END LOOP;
      END;
    END IF;
    ---2.2 循环表TMP_NEW_ORDER_PRODUCT_SKU，查看是否存在失效的SKU，如果存在，则直接删除，返回值状态修改为 2 
    SELECT count(1) into v_temp_count FROM TMP_NEW_ORDER_PRODUCT_SKU  WHERE  VALID_FLAG = 0;
    IF v_temp_count > 0 THEN
        output_status := '2';
        output_msg := '部分商品已失效！';
        ---需要修正数据，删除无效的数据
        IF c_confirm_type = 2 THEN 
            delete from TMP_NEW_ORDER_PRODUCT_SKU where  valid_flag = 0;
            --删除已经不存在SKU的商品 
            delete from TMP_NEW_ORDER_PRODUCT op 
            where not exists (select 1 from TMP_NEW_ORDER_PRODUCT_SKU ops where op.order_id = ops.order_id and op.order_product_id = ops.order_product_id);
            --删除已经不存在任何商品的订单
            delete from TMP_NEW_ORDER oo 
            where not exists (select 1 from TMP_NEW_ORDER_PRODUCT op where op.order_id = oo.order_id);
        END IF;
    END IF;
    ---2.3 循环表TMP_NEW_ORDER_PRODUCT_SKU，查看SKU库存是否充足(可缺货订购，则默认库存充足)
    SELECT count(1) into v_temp_count FROM TMP_NEW_ORDER_PRODUCT_SKU  WHERE  COUNT > STOCK_COUNT AND IS_OUTSTOCK=0;
    IF v_temp_count > 0 THEN
        output_status := '2';
        output_msg := '部分商品SKU库存不足！';
        ---需要修正数据，删除无效的数据
        IF c_confirm_type = 2 THEN 
            --删除无库存商品
            delete from TMP_NEW_ORDER_PRODUCT_SKU where stock_count = 0;
           ---删除已经不存在SKU的商品
            delete from TMP_NEW_ORDER_PRODUCT op 
            where not exists (select 1 from TMP_NEW_ORDER_PRODUCT_SKU ops where op.order_id = ops.order_id and op.order_product_id = ops.order_product_id);
           --删除已经不存在任何商品的订单 
            delete from TMP_NEW_ORDER oo 
            where not exists (select 1 from TMP_NEW_ORDER_PRODUCT op where op.order_id = oo.order_id);
            --将下单数量更新为库存数量
            update TMP_NEW_ORDER_PRODUCT_SKU  set count =  stock_count where count > stock_count;
        END IF;
    END IF;
    ---2.5 循环商品SKU表，将计算出商品SKU的售价信息，用于校验商品的金额
    BEGIN
      FOR t2 IN(
                   SELECT             
                   ops.order_id,
                   ops.order_product_id,
                   op.activity_type,
                   op.activity_id,
                   op.activity_product_id,
                   ops.sku_id,
                   ps.product_specs,
                   op.buy_out_flag,
                   get_ByOut_SaleProductCount(ops.sku_id,ops.count) order_total_count,
                   get_ByOut_SalePrice(c_user_name,op.activity_id,ops.sku_id,op.buy_out_flag,get_ByOut_SaleProductCount(ops.sku_id,ops.count)) original_sku_unit_price,
                   (case when c_mbr_card = 2 then
                    least(getSku_User_VipPrice(c_user_name,ops.sku_id),get_ByOut_SalePrice(c_user_name,op.activity_id,ops.sku_id,op.buy_out_flag,get_ByOut_SaleProductCount(ops.sku_id,ops.count)))
                   else 
                      get_ByOut_SalePrice(c_user_name,op.activity_id,ops.sku_id,op.buy_out_flag,get_ByOut_SaleProductCount(ops.sku_id,ops.count)) 
                   end) sku_unit_price
                   FROM TMP_NEW_ORDER_PRODUCT_SKU ops 
                   INNER JOIN TMP_NEW_ORDER_PRODUCT op ON ops.order_product_id = op.order_product_id
                   INNER JOIN TBL_PRODUCT_SKU ps on ps.id = ops.sku_id
     ) LOOP
         /****修改售价信息****/
         UPDATE TMP_NEW_ORDER_PRODUCT_SKU t1 
         set t1.sku_unit_price = t2.sku_unit_price,
         t1.original_sku_unit_price = t2.original_sku_unit_price
         WHERE t1.order_id = t2.order_id and t1.order_product_id = t2.order_product_id and t1.sku_id = t2.sku_id;
         /**************更新商品SKU的【活动后报价】**********/
         UPDATE TMP_NEW_ORDER_PRODUCT_SKU t3 
         set t3.ACTIVITY_PRODUCT_PRIZE_COST = getSku_User_QuotePrice(c_user_name,t2.sku_id,t2.buy_out_flag,t2.order_total_count,c_mbr_card)
         WHERE t3.order_id = t2.order_id and t3.order_product_id = t2.order_product_id and t3.sku_id = t2.sku_id;
     END LOOP;
     END;
    ---2.6 循环表TMP_NEW_ORDER_PRODUCT_SKU，查看SKU单价是否异常（即页面单价与数据库计算的单价是否一致）
    SELECT count(1) into v_temp_count FROM TMP_NEW_ORDER_PRODUCT_SKU  WHERE  PAGE_SKU_UNIT_PRICE <> SKU_UNIT_PRICE;
    --需要修正数据，则直接将PAGE_SKU_UNIT_PRICE赋值为SKU_UNIT_PRICE
    IF c_confirm_type = 2 THEN 
        IF v_temp_count > 0 THEN
           update TMP_NEW_ORDER_PRODUCT_SKU set page_sku_unit_price = SKU_UNIT_PRICE;
        END IF;
    ELSE
        IF v_temp_count > 0 THEN
            output_status := '2';
            output_msg := '部分商品SKU单价异常！';
        END IF;
    END IF;
    
     ---2.4 如果所有的SKU都失效，则校验失败
    SELECT count(1) into v_temp_count FROM TMP_NEW_ORDER_PRODUCT_SKU WHERE (STOCK_COUNT>0 OR IS_OUTSTOCK = 1) AND VALID_FLAG = 1;
    IF v_temp_count = 0 THEN
        output_status := '3';
        output_msg := '所有SKU均已失效!';
    END IF;
    ----3 库存校验完成，校验商品价格信息，如果之前有发送SKU库存变更等情况，则直接将下单表中的下单金额修改为实际金额；否则需要校验总价是否正确
    IF output_status = '1' THEN
        select sum(product_money) into v_order_product_money from TMP_NEW_ORDER;
        select sum(ops.count*NVL(ops.sku_unit_price,0)) into v_sku_product_money from TMP_NEW_ORDER_PRODUCT_SKU ops;
        IF v_order_product_money<>v_sku_product_money THEN
             output_status:='0';
             output_msg := '商品价格被篡改或商品价格发生变化,应收货款（'|| v_sku_product_money|| '）!';
            RETURN;
        END IF;
    ELSE
          BEGIN
          FOR t2 IN(
                    --将SKU中的价格赋值该order表
                    select 
                    ops.order_id,sum(ops.count*ops.sku_unit_price) product_money
                    from TMP_NEW_ORDER_PRODUCT_SKU ops
                    inner join TMP_NEW_ORDER_PRODUCT op on ops.order_id = op.order_id and ops.order_product_id = op.order_product_id
                    inner join TMP_NEW_ORDER oo on op.order_id = oo.order_id
                    group by ops.order_id
         ) LOOP
             UPDATE TMP_NEW_ORDER t1 set t1.product_money = t2.product_money WHERE t1.order_id = t2.order_id;
         END LOOP;
         END;
    END IF;
  ELSE
         output_status:='0';
         output_msg:='订单信息校验失败,参数错误';
         RETURN;
  END IF;
  IF  output_status='0' THEN
      output_status:='1';
      output_msg := '订单信息校验成功';
  END IF;
EXCEPTION
   when others then  
        output_msg := 'errorCode=' || SQLCODE || ',errorMsg=' || SUBSTR(SQLERRM, 1, 200);  
  --WHEN OTHERS THEN
    ROLLBACK;
  --output_msg := '订单信息校验失败';  
END new_confirm_order;
------------------------------------------------
/

