create view V_BUSS_SETTLEMENT_B20191009 as
  SELECT stationed_user_id,
          settlement_user_id,
          settlement_number,
          settlement_state,
          settlement_type,
          settlement_group,
          remark,
          CASE
             WHEN settlement_amount > settled_amount
             THEN
                settlement_amount - settled_amount
             ELSE
                0
          END
             settlement_amount,
          pay_number,
          order_number,
          create_date,
          bank_account_type,
          bank_account,
          CASE
             WHEN product_num > settled_quantity
             THEN
                product_num - settled_quantity
             ELSE
                0
          END
             product_num,
          settlement_date,
          liquidation_date,
          settlement_item
     FROM tbl_buss_settlement_info
    WHERE settlement_state <> '2'
   UNION ALL
   SELECT stationed_user_id,
          settlement_user_id,
          settlement_number,
          settlement_state,
          settlement_type,
          settlement_group,
          remark,
          settlement_amount,
          pay_number,
          order_number,
          create_date,
          bank_account_type,
          bank_account,
          product_num,
          settlement_date,
          liquidation_date,
          settlement_item
     FROM tbl_buss_settlement_info
    WHERE     settlement_state = '2'
          AND settled_quantity = 0
          AND settled_amount = 0
   UNION ALL
   SELECT settlement_user_id stationed_user_id,
          settlement_user_id,
          settlement_number,
          settlement_state,
          '1' settlement_type,
          TO_CHAR (settlement_type) settlement_group,
          '入驻商货款' remark,
          settlement_amount,
          pay_number,
          order_number,
          create_date,
          '1' bank_account_type,
          bank_account,
          product_num,
          pre_settelment_date settlement_date,
          settlement_date liquidation_date,
          settlement_item
     FROM tbl_buss_settlement_shipments a
    WHERE     settlement_state = '2'
          AND NOT EXISTS
                     (SELECT 1
                        FROM tbl_buss_settlement_info b
                       WHERE     b.bank_account_type = 1
                             AND b.settlement_state = '2'
                             AND b.settled_quantity = 0
                             AND a.order_number = b.order_number
                             AND a.settlement_user_id = b.stationed_user_id)
   UNION ALL
   SELECT stationed_user_id,
          settlement_user_id,
          settlement_number,
          settlement_state,
          TO_CHAR (settlement_type) settlement_type,
          TO_CHAR (settlement_type) settlement_group,
          remark,
          settlement_amount,
          pay_number,
          order_number,
          create_date,
          '' bank_account_type,
          bank_account,
          product_num,
          pre_settelment_date settlement_date,
          settlement_date liquidation_date,
          settlement_item
     FROM tbl_fee_settlement_shipments a
    WHERE     a.settlement_state = '2'
          AND NOT EXISTS
                     (SELECT 1
                        FROM tbl_buss_settlement_info b
                       WHERE     b.bank_account_type <> 1
                             AND b.settlement_state = '2'
                             AND b.settled_quantity = 0
                             AND b.settled_amount = 0
                             AND a.order_number = b.order_number
                             AND a.stationed_user_id = b.stationed_user_id
                             AND a.settlement_item = b.settlement_item)
/

