create PROCEDURE           CALC_RM_STOCK
/**
     定时计算商品起码率大于0.5，并且总库存大于100的商品信息
     wangpeng
     2019-03-01
  **/
is
  temp_count                   INT := 0; --临时变量
begin
    
    update tbl_product_info set stock_qml = 0  where PRODUCT_TYPE in (0,3) and STATE in ('上架','暂上架');

    MERGE INTO  tbl_product_info T1
    USING (
        select product_itemnumber,sum(sku_stock) product_stock
        ,count(1) sku_count,sum(case when sku_stock >0 then 1 else 0 end ) stock_ok_count
         from (
              SELECT PRODUCT_ITEMNUMBER, product_sku, SUM (PRODUCT_TOTAL_COUNT-PRODUCT_ORDER_OCCUPY_COUNT-PRE_ORDER_OCCUPY_COUNT) sku_stock
                FROM TBL_PRODUCT_SKU_STOCK a, tbl_product_sku b,tbl_product_info c
               WHERE a.product_sku = b.id AND PRODUCT_GROUP = '尺码' and b.PRODUCT_ITEMNUMBER = c.itemnumber and c.START_STOP_STATE = 1 and c.PRODUCT_TYPE in (0,3) and c.STATE in ('上架','暂上架')
            GROUP BY PRODUCT_ITEMNUMBER, product_sku
         ) group by product_itemnumber 
         having 
            sum(sku_stock)>=100 
            and sum(case when sku_stock >0 then 1 else 0 end )/count(1) >=0.5
            --order by sum(sku_stock) desc

    ) T2 on (T1.itemnumber=T2.PRODUCT_ITEMNUMBER)
    WHEN MATCHED THEN UPDATE SET T1.stock_qml=T2.product_stock; 
  
  commit;
exception
  when others then
    rollback;
end CALC_RM_STOCK;
/

