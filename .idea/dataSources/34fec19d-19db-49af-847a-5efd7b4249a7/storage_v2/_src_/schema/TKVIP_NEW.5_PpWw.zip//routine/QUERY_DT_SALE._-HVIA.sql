create PROCEDURE           query_dt_sale
/**
    手动查询地推销售数据，
    wangpeng
    2018-10-17
  **/
(
    begin_date        in varchar2,               --统计开始时间
    end_date_in         in varchar2                 --统计结束时间
 ) IS
  end_date              varchar2(50);          --转账金额
  
  
BEGIN
    --移除之前的导出记录
    delete tbl_dt_sale;
    end_date := end_date_in || '23:59:59';
    commit;
    insert into tbl_dt_sale(业务员ID,业务员姓名,新客户数,新客户成交金额,沉睡用户数,沉睡用户成交金额,老用户数,老用户成交金额,查询时间段,数据生成时间)
    select 业务员ID,业务员姓名,sum(新客户数) 新客户数,sum(新客户成交金额) 新客户成交金额,sum(沉睡用户数) 沉睡用户数,sum(沉睡用户成交金额) 沉睡用户成交金额,sum(老用户数) 老用户数,sum(老用户成交金额) 老用户成交金额,
     begin_date||' 至 '||end_date_in,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')
     from (
        /*******新用户数*******/
        select REFEREE_USER_ID 业务员ID,REFEREE_USER_REALNAME 业务员姓名,count(*) 新客户数,0 新客户成交金额,0 沉睡用户数,0 沉睡用户成交金额,0 老用户数,0 老用户成交金额  from tbl_user_info where  
            --特定程超业务经理
            MARKET_SUPERVISION_USER_ID = 1000050 
            --规定时间范围内注册
            and CREATE_DATE >= to_date(begin_date,'yyyy-mm-dd') and CREATE_DATE < to_date(end_date,'yyyy-mm-dd hh24:mi:ss') 
            group by REFEREE_USER_ID,REFEREE_USER_REALNAME
        union all 
        /*******新用户成交金额*******/
        select b.id 业务员ID,b.USER_REALNAME 业务员姓名,0 新客户数,sum(PAYMENT_MONEY) 新客户成交金额,0 沉睡用户数,0 沉睡用户成交金额,0 老用户数,0 老用户成交金额 from tbl_order_info a ,tbl_sys_user_info b where a.YWY_USER_NAME = b.user_name 
            --特定程超业务经理
            and a.YWJL_USER_NAME = 'dtcc' 
            --规定时间范围内成交
            and a.PAYMENT_STATE = '2' and a.PAYMENT_DATE >= to_date(begin_date,'yyyy-mm-dd') and a.PAYMENT_DATE < to_date(end_date,'yyyy-mm-dd hh24:mi:ss') 
            group by b.id,b.USER_REALNAME
        union all 
        /*******沉睡用户数及支付金额*******/
        select REFEREE_USER_ID 业务员ID,REFEREE_USER_REALNAME 业务员姓名,0 新客户数,0 新客户成交金额,count(*) 沉睡用户数,sum(total_PAYMENT_MONEY) 沉睡用户成交金额,0 老用户数,0 老用户成交金额 from (
            select REFEREE_USER_ID,REFEREE_USER_REALNAME,a.user_name,sum(PAYMENT_MONEY) total_PAYMENT_MONEY from tbl_user_info a,tbl_order_info b where a.USER_NAME = b.USER_NAME
                --特定程超业务经理
                and b.YWJL_USER_NAME = 'dtcc' 
                --规定时间范围内成交
                and b.PAYMENT_STATE = '2' and b.PAYMENT_DATE >= to_date(begin_date,'yyyy-mm-dd') and b.PAYMENT_DATE < to_date(end_date,'yyyy-mm-dd hh24:mi:ss')
                --沉睡用户
                and b.user_name in 
                (
                    select c.user_name from tbl_user_info c,tbl_order_info d where c.USER_NAME = d.USER_NAME and MARKET_SUPERVISION_USER_ID = 1000050
                    --规定时间范围内成交
                    and d.PAYMENT_STATE = '2' and d.PAYMENT_DATE >= to_date(begin_date,'yyyy-mm-dd') and d.PAYMENT_DATE < to_date(end_date,'yyyy-mm-dd hh24:mi:ss')
                    
                    and exists( 
                        select 1 from tbl_order_info f where f.PAYMENT_DATE < to_date(begin_date,'yyyy-mm-dd') and d.user_name = f.user_name 
                        group by f.user_name
                        having 
                        case when max(f.PAYMENT_DATE) is not null then 
                            --最近一笔成交距离现在大于3个月
                            add_months(max(f.PAYMENT_DATE),3) - d.PAYMENT_DATE
                        else
                            --成交时间距注册时间大于3个月
                           add_months(c.create_date,3) -  d.PAYMENT_DATE
                        end  <0
                    )
                )
                --排除新用户
                and a.user_name not in (
                    select user_name from tbl_user_info where CREATE_DATE >= to_date(begin_date,'yyyy-mm-dd') and CREATE_DATE < to_date(end_date,'yyyy-mm-dd hh24:mi:ss') 
                )
                group by REFEREE_USER_ID,REFEREE_USER_REALNAME,a.user_name,a.USER_MANAGE_NAME
        ) group by  REFEREE_USER_ID,REFEREE_USER_REALNAME
        union all 
        /*******老用户数及支付金额*******/
        select REFEREE_USER_ID 业务员ID,REFEREE_USER_REALNAME 业务员姓名,0 新客户数,0 新客户成交金额,0 沉睡用户数,0 沉睡用户成交金额,count(*) 老用户数,sum(total_PAYMENT_MONEY) 老用户成交金额 from (
        select REFEREE_USER_ID,REFEREE_USER_REALNAME,a.user_name,sum(PAYMENT_MONEY) total_PAYMENT_MONEY from tbl_user_info a,tbl_order_info b where a.USER_NAME = b.USER_NAME
            --特定程超业务经理
            and b.YWJL_USER_NAME = 'dtcc' 
            --规定时间范围内成交
            and b.PAYMENT_STATE = '2' and b.PAYMENT_DATE >= to_date(begin_date,'yyyy-mm-dd') and b.PAYMENT_DATE < to_date(end_date,'yyyy-mm-dd hh24:mi:ss')
            --老用户(排除沉睡用户)
            and b.user_name not in
            (
                select c.user_name from tbl_user_info c,tbl_order_info d where c.USER_NAME = d.USER_NAME and MARKET_SUPERVISION_USER_ID = 1000050
                --规定时间范围内成交
                and d.PAYMENT_STATE = '2' and d.PAYMENT_DATE >= to_date(begin_date,'yyyy-mm-dd') and d.PAYMENT_DATE < to_date(end_date,'yyyy-mm-dd hh24:mi:ss')
                
                and exists( 
                    select 1 from tbl_order_info f where f.PAYMENT_DATE < to_date(begin_date,'yyyy-mm-dd') and d.user_name = f.user_name 
                    group by f.user_name
                    having 
                    case when max(f.PAYMENT_DATE) is not null then 
                        --最近一笔成交距离现在大于3个月
                        add_months(max(f.PAYMENT_DATE),3) - d.PAYMENT_DATE
                    else
                        --成交时间距注册时间大于3个月
                       add_months(c.create_date,3) -  d.PAYMENT_DATE
                    end  <0
                )
            )
            --排除新用户
            and a.user_name not in (
                select user_name from tbl_user_info where CREATE_DATE >= to_date(begin_date,'yyyy-mm-dd') and CREATE_DATE < to_date(end_date,'yyyy-mm-dd hh24:mi:ss') 
            )
            group by REFEREE_USER_ID,REFEREE_USER_REALNAME,a.user_name,a.USER_MANAGE_NAME
        ) group by  REFEREE_USER_ID,REFEREE_USER_REALNAME 
    ) group by 业务员ID,业务员姓名;
    commit;
END query_dt_sale;
/

