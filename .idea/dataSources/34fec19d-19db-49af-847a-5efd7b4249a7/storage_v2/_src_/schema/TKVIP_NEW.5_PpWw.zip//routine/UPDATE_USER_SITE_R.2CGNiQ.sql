create PROCEDURE           update_user_site_r
/**
     自动用户站点回撤     
     wangpeng
     2017-12-29
  **/
is
  temp_count                   INT := 0; --临时变量
begin

    update TBL_USER_INFO set site_id = 2 where id in (select id from TBL_USER_INFO_BAK20171227);

  commit;
exception
  when others then
    rollback;
end update_user_site_r;
/

