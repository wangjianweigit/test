create trigger TRI_FREIGHT_TEMPLATE
  before insert or update
  on TBL_FREIGHT_TEMPLATE
  for each row
DECLARE
      V_TEMP VARCHAR2(50);
    BEGIN
      IF UPDATING('LAST_UPDATE_TIME') THEN
        V_TEMP := '1';
      ELSE
        :NEW.LAST_UPDATE_TIME := SYSDATE + (10 / (24 * 60 * 60));
      END IF;
    END;
/

