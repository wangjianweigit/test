create FUNCTION           getStrforArrid 
/**
    字符串拆分 传入格式    ,111,222,333,    
    从tkvip_new移植过来
    20170502
**/
(
str   varchar2,   --待分拆的字符串
flag   char,      --分隔符
numberid   int    --第几个     
) return number
 is
 returnstr number;
BEGIN
   returnstr:=substr(str,instr(str,flag,1,numberid)+1,instr(str,flag,1,numberid+1)-instr(str,flag,1,numberid)-1);
   return returnstr;
END getStrforArrid;
/

