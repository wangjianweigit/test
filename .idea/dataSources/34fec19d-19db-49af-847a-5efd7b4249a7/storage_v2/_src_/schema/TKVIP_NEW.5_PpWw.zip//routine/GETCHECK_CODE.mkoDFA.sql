create FUNCTION getCheck_Code
/**
    获取校验码
    wangpeng
    2016-03-24
**/
(
    c_user_name   varchar2,       --用户名
    c_money  number,              --金额
    c_user_key   varchar2         --解密的KEY
) return varchar2
 is
 PRAGMA AUTONOMOUS_TRANSACTION;
     return_check_code varchar2(32);       --需要返回的校验码
     temp_str varchar2(500);         --需要md5的字符串
BEGIN

   temp_str:=c_user_name||to_char(c_money)||c_user_key;
   return_check_code:=Utl_Raw.Cast_To_Raw(sys.dbms_obfuscation_toolkit.md5(input_string => temp_str));

   return return_check_code;
END getCheck_Code;
/

