create PROCEDURE           CONFIRM_RETAIL_ORDER
/**
    新版本新零售 确认订单存储过程，该存储过程的作用如下
    1、判断库存是否充足
    2、将下单库存按照仓库进行拆分
    
    2019.07.11 reid 创建
    
    返回值 
        output_status 0-失败 1-成功
        output_msg   提示信息
     
**/
(
        client_user_name in varchar2,              --下单人user_name
        client_logistics_company_code in varchar2, --物流公司代码
        product_sku_list IN  T_ORDER_PRODUCT_LST,  --订单中包含的SKU信息集合
        output_status  out varchar2,               --返回的状态码 0-失败 1-成功
        output_msg out varchar2                    --返回的信息
) AS
    v_product_sku   T_ORDER_PRODUCT;                            --订单商品SKU对象
    v_temp_count    number :=0;                                 --临时变量

BEGIN
    output_status:='0';
    --1.查询物流公司信息是否存在
    SELECT COUNT(*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE code = client_logistics_company_code;
    IF v_temp_count =0 THEN
          output_msg:='物流信息不能为空，请检查!';
          RETURN;
    END IF;
    --2.循环订单SKU信息，将订单的SKU数据插入到临时表中
    IF product_sku_list.count > 0 THEN
           ---2.1 插入前端传值的SKU数据
           FOR i IN 1..product_sku_list.COUNT LOOP
                v_product_sku:=product_sku_list(i);--获取订单对象
                    insert into TMP_RETAIL_SKU(product_sku,count)
                    values (v_product_sku.product_sku,v_product_sku.count);
           END LOOP;/**end product_sku_list**/
           ---2.2 判断是否存在无效的SKU 所有下单的SKU必须是 上架状态
           SELECT    
                 (count(rs.product_sku) - sum((case when (pi.state in ('上架','暂下架') and ps.state = '上架') then 1 else 0 end)))
                 into
                 v_temp_count
           FROM
           TMP_RETAIL_SKU rs
           LEFT JOIN TBL_PRODUCT_SKU ps on rs.product_sku = ps.id and ps.product_group = '尺码' and  ps.state = '上架'
           LEFT JOIN TBL_PRODUCT_INFO pi on ps.product_itemnumber = pi.itemnumber and pi.state in ('上架','暂下架') and pi.start_stop_state = 0;
           IF v_temp_count<>0 THEN
                output_msg:='部分下单SKU已失效，请检查!';
                RETURN;
           END IF;
    ELSE
        output_msg:='参数异常，缺少下单商品SKU信息';
        RETURN;
    END IF;
    output_status:='1';
    output_msg:='订单确认校验成功，允许下单';
  EXCEPTION
    WHEN OTHERS THEN
        output_status := '0';
        output_msg:='提交订单出现未知错误::'||SQLCODE || '::'||SQLERRM||'----';
END CONFIRM_RETAIL_ORDER;
------------------------------------------------
/

