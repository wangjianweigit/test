create procedure           UPDATE_PRODUCT_TAG
/**
     更新商品档案的新品、热卖标签
     zhengfangyuan
     2019-01-02
  **/
is
  t_period_new number:=0;
  t_period_hot number:=0;
  t_count_hot number:=0;
begin
    ---- 获取新品规则------
    select period into t_period_new
    from tbl_product_tag_rule_info
    where is_delete = 0 and type = 1;

    ---- 获取热卖规则------
    select period, count into t_period_hot, t_count_hot
    from tbl_product_tag_rule_info
    where is_delete = 0 and type = 2;

    ------更新新品标签 
    if t_period_new > 0 then 
        update tbl_product_info set is_new = 0;

        update tbl_product_info 
        set is_new = 1
        where ceil(sysdate - to_date(first_sell_state_date)) <=t_period_new ;  

    end if;

    ------更新热卖标签 
    if t_count_hot > 0 then 
        update tbl_product_info set is_hot = 0;

        if t_period_hot = 7 then 
            update tbl_product_info set is_hot = 1  where  product_count7 > t_count_hot;
        elsif t_period_hot = 15 then 
            update tbl_product_info set is_hot = 1  where  product_count15 > t_count_hot;
        elsif t_period_hot = 30 then 
            update tbl_product_info set is_hot = 1  where  product_count30 > t_count_hot;
        elsif t_period_hot = 7 then 
            update tbl_product_info set is_hot = 1  where product_count90 > t_count_hot;
        else
            update tbl_product_info set is_hot = 1  where product_count > t_count_hot;

        end if;
    end if;
    commit;
exception
    when others then
    rollback;
end update_product_tag;
/

