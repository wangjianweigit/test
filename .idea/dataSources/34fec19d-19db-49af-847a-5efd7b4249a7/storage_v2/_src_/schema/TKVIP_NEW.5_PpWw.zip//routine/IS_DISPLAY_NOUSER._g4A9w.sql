create function           is_display_nouser
/**
    （新版）通过站点id、货号判断商品是否显示
    wangpeng
    2017-05-12
   显示规则
   
   reid 2018.12.26 私有平台商品也需要展示
    返回值：1（显示）  0：不显示
**/
(
    c_site_id              number,     --站点id
    c_product_itemnumber   varchar2    --商品货号    
) return varchar2
 is
     v_id number:=0;                                --商品id
     v_sell_state_date date;                        --商品最后上架时间
     v_flag number:=1;                              --是否显示   1（显示）  0：不显示
     v_count number:=0;                       --临时变量
begin
    
    --如果不是普通商品，直接返回，不显示   songwanwgen    2018.09.06
    select count(1) into v_count  from tbl_product_info tpi where tpi.product_type not in (0,3) and tpi.itemnumber = c_product_itemnumber;
    if v_count >0 then
        return 0;
    end if;

    /***********************************************订货会相关代码****begin*****wangpeng***2017-09-26****************************************************/
    --查询用户是否为订货会用户并且商品为订货会内的商品,此处忽略活动时间以及用户
    select count(1) into v_count from tbl_activity_info a,tbl_activity_detail b,tbl_activity_product c 
        where  a.id = b.activity_id and a.id = c.activity_id and a.activity_type = '2'
        and a.activity_state = '3' and a.state = '2' and c.product_itemnumber = c_product_itemnumber
        and exists (select 1 from tbl_activity_site tas where tas.activity_id = a.id and tas.site_id = c_site_id);
    if v_count>0 then 
        return v_flag;
    end if;   
    /***********************************************订货会相关代码****end*******wangpeng***2017-09-26**************************************************/    
   

    --查询商品id和上架时间
    select id,sell_state_date into v_id,v_sell_state_date from tbl_product_info where itemnumber = c_product_itemnumber and state = '上架';

    if v_flag !=0 then 
        --查询商品是否在站点显示
        select count(1) into v_flag from tbl_site_product_delay where site_id = c_site_id and product_id = v_id and v_sell_state_date+delay_days<=sysdate;
    end if;
    
   
    if v_flag !=0 then 
        v_flag := 1;
    end if;

    return v_flag;
   
end is_display_nouser;
/

