create PROCEDURE PVTP_COLLECT_PRODUCT
/**
     私有平台收藏商品
     reid 2019-09-16
     返回值：收藏成功或收藏失败消息
  **/
(
 client_stationed_user_id  IN number,     --当前下单私有平台ID（即所属私有商家的ID）
 client_user_name  IN VARCHAR2, --用户名
 client_itemnumber IN VARCHAR2, --商品货号
 output_status     OUT VARCHAR2, --返回的状态码 0-取消失败 1-取消成功
 output_msg        OUT VARCHAR2 --返回的信息
 ) IS
      temp_count                   INT := 0; --临时变量
BEGIN
   
     output_status := '0';
      SELECT COUNT(*) INTO temp_count FROM tbl_user_info WHERE user_name = client_user_name;
      IF temp_count = 0 THEN
        output_msg := '用户信息不能为空，请检查！';
        RETURN;
      END IF;
     select count(1) into temp_count
     from TBL_PVTP_PRODUCT_INFO ppi
     where ppi.itemnumber = client_itemnumber and ppi.stationed_user_id = client_stationed_user_id;
     IF temp_count<> 0 THEN
              SELECT COUNT(1) INTO temp_count
              FROM tbl_user_collection
              WHERE user_name = client_user_name
                     AND itemnumber = client_itemnumber
                     AND platform_id = client_stationed_user_id;
              IF temp_count <> 0 THEN
                 output_msg := '该商品已收藏！';
                 RETURN;
              END IF;
              ---插入收藏数据
              INSERT INTO tbl_user_collection 
              (
                  id, 
                  user_name,
                  product_name,
                  product_price,
                  product_img_url,
                  itemnumber,
                  create_date,
                  platform_id
              )
              SELECT 
               seq_user_collection.NEXTVAL,
               client_user_name,
               pi.product_name, 
               PVTP_GETPRODUCT_SALEPRICE_MIN(client_stationed_user_id,client_user_name, client_itemnumber),
               pi.product_img_url,
               pi.itemnumber,
               sysdate,
               client_stationed_user_id
              FROM TBL_PVTP_PRODUCT_INFO pi
              WHERE itemnumber = client_itemnumber;
     ELSE
              SELECT COUNT(1) INTO temp_count FROM tbl_product_info pi WHERE pi.itemnumber = client_itemnumber
              and exists (select 1 from TBL_PVTP_PRODUCT_INFO_REF ppir where ppir.product_itemnumber = pi.itemnumber and ppir.enabled_flag = 1)
              and pi.is_private = 1;
              IF temp_count = 0 THEN
                output_msg := '商品信息不存在，请检查！';
                RETURN;
              END IF;
              SELECT COUNT(1) INTO temp_count
              FROM tbl_user_collection
              WHERE user_name = client_user_name
                     AND itemnumber = client_itemnumber
                     AND platform_id = client_stationed_user_id;
              IF temp_count <> 0 THEN
                 output_msg := '该商品已收藏！';
                 RETURN;
              END IF;
              ---插入收藏数据
              INSERT INTO tbl_user_collection 
              (
                  id, 
                  user_name,
                  product_name,
                  product_price,
                  product_img_url,
                  itemnumber,
                  create_date,
                  platform_id
              )
              SELECT 
               seq_user_collection.nextval,
               client_user_name,
               pi.product_name, 
               pvtp_getproduct_saleprice_min(client_stationed_user_id,client_user_name, client_itemnumber),
               pi.product_img_url,
               pi.itemnumber,
               sysdate,
               client_stationed_user_id
              FROM tbl_product_info pi
              WHERE itemnumber = client_itemnumber;
     END IF;
     output_status := '1';
     output_msg    := '收藏成功！';
     COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    output_msg := '收藏商品时出现未知错误！';
    ROLLBACK;
END PVTP_COLLECT_PRODUCT;
/

