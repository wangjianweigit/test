create FUNCTION           getSku_User_SalePrice_stop
/**
    （新版、暂废）通过用户名获取SKU商品的             实际销售价格(精确)  （详情、购物车、订单提交专用）
    wangpeng
    2017-05-12
    价格计算规则：活动价（取所有活动中最低的折扣）、 站点价(按照用户站点折扣计算) 、  会员价（按照会员折扣计算）、特殊价格  取最低
    返回值：商品实际销售价格
**/
(
    c_user_name   varchar2,         --用户名
    c_product_sku_id   number       --商品SKUID 
) return number
 is
     v_product_prize number:=0;             --需要返回的商品价格
     v_product_hd_prize number:=0;          --活动应销售价
     v_product_pt_prize number:=0;          --普通应销售价
     v_user_id number:=0;                   --用户ID
     v_product_itemnumber   varchar2(50);   --商品货号
     v_product_prize_cost number:=0;        --报价
     v_product_sale_prize number:=0;        --应销售价格
     v_hd_flag number:=-1;                  --是否参加了活动
     v_hd_discount number:=1;               --活动折扣
     v_hy_discount number:=1;               --会员等级折扣
     v_site_discount number:=1;             --站点折扣
     v_ts_discount number:=1;               --特殊价折扣
     v_hyfwf_discount number :=1 ;          --最终会员服务费折扣率
     v_member_service_rate number:=0;       --全局会员服务费比例
     v_site_id number:=0;                   --会员站点
     v_hdhy_discount number:=1;             --活动会员折扣
BEGIN
   --查询全局会员服务费比例
   select member_service_rate into v_member_service_rate from TBL_SYS_CONFIG where id = 1;
   
   --查询品牌会员服务费比例
   select nvl(member_service_rate,0)+v_member_service_rate into v_member_service_rate from TBL_DIC_PRODUCT_BRAND where id = (
        select brand_id from tbl_product_info where ITEMNUMBER=(select PRODUCT_ITEMNUMBER from tbl_product_sku where id = c_product_sku_id)
   );

    --查询入驻商会员服务费比例
    select nvl(member_service_rate,0)+v_member_service_rate into v_member_service_rate from TBL_STATIONED_USER_INFO where id = (
        select STATIONED_USER_ID from tbl_product_sku where id = c_product_sku_id
    );

   --查询SKU基本信息
   select product_itemnumber,product_prize_cost into v_product_itemnumber,v_product_prize_cost from tbl_product_sku where product_group = '尺码' and id = c_product_sku_id ;

   --计算应销售价
   v_product_sale_prize:=v_product_prize_cost/(1-v_member_service_rate);

   --查询会员站点
   select nvl(min(site_id),0),nvl(min(id),0),nvl(min(discount),1) into v_site_id,v_user_id,v_hy_discount from tbl_user_info where user_name = c_user_name;
   
   --查询站点折扣
   select nvl(min(discount),1) into v_site_discount from tbl_site_info  where id = v_site_id;
   
   --初始销售价
   v_product_hd_prize:=v_product_sale_prize;
   v_product_pt_prize:=v_product_sale_prize;
   
   --如果没有查询到用户信息，则返回原价
   if v_user_id=0 then
        v_product_prize:=v_product_sale_prize;
   else
       /***********************************************订货会相关代码****begin*****wangpeng***2017-09-27****************************************************/
          --查询参加的活动----订货会
           select nvl(min(c.ACTIVITY_DISCOUNT),0),nvl(min(c.id),-1),nvl(min(a1.ACTIVITY_SERVICE_DISCOUNT),1) into v_hd_discount,v_hd_flag,v_hdhy_discount from TBL_ACTIVITY_INFO a ,TBL_PREORDER_ACTIVITY_INFO a1,TBL_ACTIVITY_PRODUCT c 
           where a.ACTIVITY_STATE = '3' and a.STATE = '2'  and a.ACTIVITY_TYPE='2' 
           and sysdate between a.BEGIN_DATE and a.END_DATE 
           and sysdate between c.activity_start_DATE and c.activity_END_DATE 
           and a.id = a1.ACTIVITY_ID
           and c.ACTIVITY_ID = a.id 
           and c.product_itemnumber =v_product_itemnumber
            and  
            case 
               when a1.user_group_id = 0 
                   then 1
               else
                   case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and a1.user_group_id = aa.id and  bb.user_id = c_user_name)
                   then 
                       1
                   else
                       0
                   end
            end  = 1
           and exists (select 1 from TBL_ACTIVITY_SITE tas where tas.ACTIVITY_ID = a.id and tas.site_id = v_site_id);
       /***********************************************订货会相关代码****end*****wangpeng***2017-09-27****************************************************/
           
       if v_hd_flag=-1 then 
           --查询参加的活动----限时折扣
           select nvl(min(c.ACTIVITY_DISCOUNT),0),nvl(min(c.id),-1),nvl(min(b.ACTIVITY_SERVICE_DISCOUNT),1) into v_hd_discount,v_hd_flag,v_hdhy_discount from TBL_ACTIVITY_INFO a ,TBL_SALE_ACTIVITY_INFO b,TBL_ACTIVITY_PRODUCT c 
           where a.ACTIVITY_STATE = '3' and a.STATE = '2'  and a.ACTIVITY_TYPE='1' 
           and sysdate between a.BEGIN_DATE and a.END_DATE 
           and sysdate between c.activity_start_DATE and c.activity_END_DATE 
           and a.id = b.ACTIVITY_ID
           and c.ACTIVITY_ID = a.id 
           and c.product_itemnumber =v_product_itemnumber
           and exists (select 1 from TBL_ACTIVITY_SITE aa where aa.ACTIVITY_ID = a.id and aa.site_id = v_site_id);
       end if;
       
       --没有参加活动
       if v_hd_flag=-1 then  
            v_product_prize:=v_product_sale_prize;
       --参加了活动
       else  
            --按照活动计算  销售价=报价*活动折扣+((报价/(1-服务费费率))-报价)*(活动折扣 or 会员服务费折扣 中最小的)
            if v_hd_discount < v_hdhy_discount then
                v_product_hd_prize := v_product_prize_cost*v_hd_discount+(v_product_sale_prize-v_product_prize_cost)*v_hd_discount;
            else
                v_product_hd_prize := v_product_prize_cost*v_hd_discount+(v_product_sale_prize-v_product_prize_cost)*v_hdhy_discount;
            end if;

       end if; 
       
       --查询特殊价格折扣
       select nvl(min(discount),1) into v_ts_discount from 
       (
        select a.* from TBL_USER_DISCOUNT_PRODUCT a,tbl_product_sku b ,TBL_USER_DISCOUNT c
        where a.user_name = c_user_name 
          and B.PRODUCT_COLOR = A.PRODUCT_COLOR 
          and B.PRODUCT_SPECS = A.PRODUCT_SPECS
          and B.PRODUCT_ITEMNUMBER = A.PRODUCT_ITEMNUMBER
         and c.state = '3' 
         and C.APPLY_NUMBER = a.APPLY_NUMBER
         AND SYSDATE BETWEEN A.BEGIN_TIME AND a.END_TIME
         AND B.PRODUCT_GROUP = '尺码'
         and B.ID = c_product_sku_id
         order by a.id desc
        ) 
       where rownum <2;
       
       --获取 会员折扣 或  站点折扣 或  特殊折扣 中最低的
       v_hyfwf_discount:= least(v_hy_discount,v_site_discount,v_ts_discount);

       --按照会员折扣计算  销售价=报价+((报价/(1-服务费费率))-报价)*（会员折扣<站点折扣?会员折扣:站点折扣）
       v_product_pt_prize := v_product_prize_cost+(v_product_sale_prize-v_product_prize_cost)*v_hyfwf_discount;
        
   end if;

   --获取  活动价 或 普通价（ 会员折扣 或 站点折扣 或 特殊折扣 中最低的）   中最低的
   v_product_prize := least(v_product_pt_prize,v_product_hd_prize);
   
   if ceil(v_product_prize)-v_product_prize<0.5 then
      v_product_prize := ceil(v_product_prize);
   elsif ceil(v_product_prize)-v_product_prize=0 then
      v_product_prize := v_product_prize;
   else 
      v_product_prize := ceil(v_product_prize)-0.5;
   end if;
   
   return v_product_prize;
   
END getSku_User_SalePrice_stop;
/

