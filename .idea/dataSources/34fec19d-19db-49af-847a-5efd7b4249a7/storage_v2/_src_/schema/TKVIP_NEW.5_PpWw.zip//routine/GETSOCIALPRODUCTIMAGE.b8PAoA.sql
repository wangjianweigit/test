create FUNCTION           GETSOCIALPRODUCTIMAGE
/**
    根据标志位获取商品图片信息- 社交首页
    zhenghui
    2018.11.27
    
    2018.01.18 reid 修改获取第几张图片的方式
    2019.04.25 zhengfy 增加商品图片类型参数
**/
(
    C_PRODUCT_ITEMNUMBER    VARCHAR2,                --商品货号
    C_INDEX                 NUMBER,                   --标志位  0.主图 
    C_TYPE                  NUMBER:=1                    -- 商品图片类型 类型：1、图片；2、视频
) RETURN VARCHAR2
 IS
    V_IMAGE_URL           VARCHAR2(200);           --图片URL
BEGIN
   /***************获取商品第几张图********************/
   IF C_INDEX = 0 THEN
        SELECT PRODUCT_IMG_URL INTO V_IMAGE_URL FROM TBL_PRODUCT_INFO WHERE ITEMNUMBER = C_PRODUCT_ITEMNUMBER;
   ELSE
        SELECT IMAGE_URL INTO V_IMAGE_URL FROM (SELECT A.*, ROWNUM num FROM (
            select
            pim.image_url
            from tbl_product_images pim
            where pim.product_itemnumber = C_PRODUCT_ITEMNUMBER and pim.type = nvl(C_TYPE,1)
            order by pim.type desc, pim.is_primary desc, pim.sortid desc
        ) A) temp where temp.num = C_INDEX;
   END IF;
   RETURN V_IMAGE_URL;
END GETSOCIALPRODUCTIMAGE;
/

