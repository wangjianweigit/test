create FUNCTION GETORDERLASTCANCELDATE
/**
    获取订单最终取消时间
    zhengfy
    2019-07-17
    reid 2019.09.26 如果时间不存在，则直接使用下单时间+24小时
    返回值：取消时间
**/
(
    c_order_number in varchar2,       --订单号
    c_type in number:=1                --1、普通订单 2、预付订单
) return date
 is
    v_return_date date;                   --返回值
BEGIN
    if c_type = 1 then

        select min(
            case when ai.pay_end_flag = 1 then least(sysdate+ai.cancel_time/1440, ai.END_DATE)
            else sysdate+ai.cancel_time/1440
            end
        ) into v_return_date
        from tbl_order_product op
        left join tbl_activity_info ai on op.product_activity_id = ai.id
        where op.order_number = c_order_number;
        
    else 
        select min(
            case when ai.pay_end_flag = 1 then least(sysdate+ai.cancel_time/1440, ai.END_DATE)
            else sysdate+ai.cancel_time/1440
            end
        ) into v_return_date
        from tbl_pre_order_detail op
        left join tbl_activity_product ap on op.activity_product_id = ap.id 
        left join tbl_activity_info ai on ap.activity_id = ai.id
        where op.order_number = c_order_number;
    end if;
    if v_return_date is null then
        v_return_date := sysdate +1;
    end if;
    return v_return_date;
END GETORDERLASTCANCELDATE;
-------------活动自动取消订单内容优化---------------
/

