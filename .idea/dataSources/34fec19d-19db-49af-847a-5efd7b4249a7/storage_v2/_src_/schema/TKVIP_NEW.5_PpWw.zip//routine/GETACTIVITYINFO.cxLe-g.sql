create FUNCTION           getActivityInfo
/**
    根据商品货号获取商品参加的活动信息
    songwangwen
    2018.08.30
**/
(
    c_product_itemnumber    varchar2,                 --货号
    c_type                  number                  --获取的数据类型   1.活动开始时间  2.活动结束时间
) return varchar2
 is
  v_activity_end_date           DATE:=NULL; --活动结束时间
  v_activity_start_date         DATE:=NULL; --活动开始时间
  v_count                       NUMBER := 0; --临时变量
BEGIN
   /***************校验商品是否参加了【店铺活动】********************/
   SELECT ssa.BEGIN_DATE,ssa.END_DATE into v_activity_start_date,v_activity_end_date FROM TBL_STA_SALE_ACTIVITY_PRODUCT ssap
   inner join TBL_STA_SALE_ACTIVITY ssa on ssa.id = ssap.activity_id
   WHERE ssap.product_itemnumber = c_product_itemnumber
   and ssa.end_date >sysdate
   and rownum<=1;
   /***************如果没有参加店铺活动，再校验是否参加了【平台活动】********************/
   IF v_activity_end_date IS NULL AND v_activity_start_date IS NULL THEN
    SELECT ACTIVITY_END_DATE,ACTIVITY_START_DATE INTO v_activity_start_date,v_activity_end_date FROM TBL_ACTIVITY_PRODUCT WHERE product_itemnumber = c_product_itemnumber;
   END IF;
   IF c_type=1 THEN
        return to_char(v_activity_start_date,'yyyy-mm-dd hh24:mi:ss');
   ELSE
        return to_char(v_activity_end_date,'yyyy-mm-dd hh24:mi:ss');
   END IF;
END getActivityInfo;
/

