create FUNCTION           getFreightMoney
/**
    计算运费（按大仓进行运费计算）
    shif
    2017-05-16

    songwangwen 2018.11.29  发货方式调整相关修改
    返回值：运费
**/
(
    c_logistics_company_id in number,       --物流公司ID
    c_user_PROVINCE_ID in number,           --收货地址所在省ID
    c_order_sku_ids in varchar2,            --商品SKU集合  使用逗号分隔
    c_order_sku_counts in varchar2,         --商品订购数量  使用逗号分隔
    c_warehouse_id in number,               --下单仓库id
    c_freight_payment_type number        --运费是否到付  1.先支付运费   ；2：到付运费
) return number
 is
 v_total_money number:=0;                   --运费
 v_det_id number:=0;                        --快递运费模板
 v_temp_first_count number:=0;              --临时变量 首件数量
 v_temp_first_money number:=0;              --临时变量 首件价格
 v_temp_continue_count number:=0;           --临时变量 续件数量
 v_temp_continue_money number:=0;           --临时变量 续件价格
 v_temp_default_id number:=999999;          --全局默认运费
 v_type char:='0';                          --物流公司类型
 v_sku_count number :=0;                    --sku数组数量
 v_sku_counts_count number :=0;             --sku数量数组的数量
 v_temp_count number :=0;                   --临时数量
 v_parent_warehouse_id number :=0;          --大仓id
BEGIN
    --只有非到付运费时，才进行运费计算，否则，直接返回0
    IF c_freight_payment_type = 1 THEN
        --获取下单仓库的父仓（大仓）id
        SELECT PARENT_ID INTO v_parent_warehouse_id FROM TBL_WAREHOUSE_INFO  WHERE ID = c_warehouse_id;
        --查询物流公司类型
        SELECT TYPE INTO v_type FROM TBL_LOGISTICS_COMPANY WHERE ID = c_logistics_company_id;
        --普通物流公司
        IF v_type = '0' THEN
        v_temp_default_id:=999999;
        END IF;
        --代发物流公司
        IF v_type = '1' THEN
        v_temp_default_id:=999998;
        END IF;
        --校验计算运费的商品数量
        v_sku_count:=length(replace(c_order_sku_ids,',',',-'))-length(c_order_sku_ids)+1;
        v_sku_counts_count:=length(replace(c_order_sku_counts,',',',-'))-length(c_order_sku_counts)+1;
       --定义游标查询使用统一运费模板的商品数量
       DECLARE CURSOR product_skus_counts IS
         SELECT C.FREIGHT_TEMPLATE_ID,SUM(D.A_COUNT) TOTAL_COUNT FROM TBL_PRODUCT_INFO C,
         (
             SELECT A.PRODUCT_ITEMNUMBER,SUM(B.COUNT_STR) A_COUNT FROM TBL_PRODUCT_SKU A,
             (
                SELECT substr(t1,1,instr(t1,',',1)-1) AS sku_str,substr(t2,1,instr(t2,',',1)-1) AS COUNT_STR  FROM
                (
                SELECT substr(s1,instr(s1,',',1,ROWNUM)+1) AS t1,substr(s2,instr(s2,',',1,ROWNUM)+1) AS T2,ROWNUM AS d ,instr(s1,',',1,ROWNUM)+1 FROM (
                    SELECT ','||c_order_sku_ids||',' AS s1,','||c_order_sku_counts||','  AS S2 FROM DUAL
                )CONNECT BY INSTR(s1,',','1',ROWNUM)>1
                ) CC WHERE T1 IS NOT NULL
            ) B
            WHERE A.ID =B.SKU_STR GROUP BY A.PRODUCT_ITEMNUMBER
        ) D WHERE D.PRODUCT_ITEMNUMBER = C.ITEMNUMBER
        GROUP BY C.FREIGHT_TEMPLATE_ID;
        myrec product_skus_counts%ROWTYPE;
       BEGIN
        FOR c_row IN product_skus_counts LOOP
         --DBMS_OUTPUT.PUT_LINE('-------模板ID：'||c_row.freight_template_id||'-----购买数量'||c_row.total_count);
            --获取本商品的运费模板---当查询不到模板的时候，则使用全局通用模板，模板ID固定为99999
            SELECT NVL(MIN(ID),v_temp_default_id) INTO v_det_id FROM
            (
            SELECT ID FROM TBL_FREIGHT_TEMPLATE_DETAIL
                WHERE
                 TEMPLATE_ID = c_row.freight_template_id
                AND LOGISTICS_COMPANY_ID = c_logistics_company_id
                AND (RANGE LIKE '%'||c_user_province_id||'%' OR RANGE ='0')
                AND WAREHOUSE_ID = v_parent_warehouse_id
            ORDER BY RANGE DESC
            ) WHERE ROWNUM < 2;

            --获取模板详情
            SELECT FIRST_COUNT,FIRST_MONEY,CONTINUE_COUNT,CONTINUE_MONEY INTO v_temp_first_count,v_temp_first_money,v_temp_continue_count,v_temp_continue_money FROM TBL_FREIGHT_TEMPLATE_DETAIL WHERE ID = v_det_id;
            --计算首件价格
            IF v_total_money = 0 THEN
            v_total_money := v_total_money + v_temp_first_money;
            IF c_row.total_count > v_temp_first_count THEN
                v_total_money := v_total_money+ceil((c_row.total_count-v_temp_first_count)/v_temp_continue_count) * v_temp_continue_money;
            END IF;
            ELSE --计算续件金额
            v_total_money := v_total_money + ceil(c_row.total_count/v_temp_continue_count) * v_temp_continue_money;
            END IF;
        END LOOP;
        END;
    END IF;
    
   --返回运费
   RETURN nvl(v_total_money,0);

END getFreightMoney;
------------------------------------------------
/

