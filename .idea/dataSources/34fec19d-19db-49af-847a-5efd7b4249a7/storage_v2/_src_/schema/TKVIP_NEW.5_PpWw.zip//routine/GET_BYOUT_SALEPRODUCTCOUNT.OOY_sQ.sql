create FUNCTION           get_ByOut_SaleProductCount
/**
    reid 2019.04.25 汇总商品购买总数量，主要用于清尾活动的订单确认。下单步奏
    返回值：当次下单中，该SKU所属的商品的购买总量
**/
(
     c_product_sku_id   number,       --商品SKUID
     c_product_sku_count   number     --商品SKU下单量
) return number
 is
     v_temp_count            number :=0;        --临时变量
     v_product_itemnumber    varchar2(50);      --商品货号
     v_product_count         number:=0;         --商品购买量
BEGIN    
   --查询货号
   select product_itemnumber into v_product_itemnumber from tbl_product_sku where id = c_product_sku_id;
   ---查询当前商品是否参加了【清尾活动】
   select count(1) into v_temp_count from TMP_NEW_ORDER_PRODUCT 
   where product_itemnumber = v_product_itemnumber
   AND activity_type = 5;
   IF v_temp_count > 0 THEN
         --查询购买总数，如果是【清尾活动】，则返回商品购买总数；如果不是，则仅仅返回当前SKU的购买量
          select 
          sum(count) INTO v_product_count
          from TMP_NEW_ORDER_PRODUCT_SKU tops
          inner join TMP_NEW_ORDER_PRODUCT top on tops.order_product_id = top.order_product_id
          where top.product_itemnumber = v_product_itemnumber
          group by top.product_itemnumber;
   ELSE
        v_product_count:=c_product_sku_count;
   END IF;
   return v_product_count;
END get_ByOut_SaleProductCount;
/

