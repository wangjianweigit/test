create PROCEDURE UPDATE_PVTP_ACCOUNT_BALANCE
/**
    更新私有平台入驻商的余额，可以增加也可以减少
    2019-09-25 wjw
**/ 
(
        c_user_id in number,                  --平台会员或者入住商的用户ID
        money  in number,                   --变更的账号金额，正数表示余额增加，负数表示余额减少
        output_status  out varchar2,        --返回的状态码 0-失败 1-成功 2-充值成功，但无法完成订单支付
        output_msg out varchar2             --返回的信息
        
) AS
    v_user_name varchar2(50);                       --平台会员或者入住商的用户名
    v_user_key varchar2(32);                        --用户KEY
    v_account_balance_checkcode varchar2(32);       --当前的余额校验码
    v_account_balance_begin number:=0;              --前的帐户余额变
    v_create_code varchar2(32);                     --通过当前余额计算得到的校验码，用于校验余额是否被篡改
    v_user_count number:=0;                            --用户帐户信息是否存在
    v_credit_checkcode varchar2(32);                --新授信余额校验码
    v_deposit_checkcode varchar2(32);        --保证金余额校验码
BEGIN
    output_status:='0';
    -------------------------------------根据用户id以及类型获取用户名-start--------------------------------------------------------------------------------------
    SELECT id INTO v_user_name FROM TBL_STATIONED_USER_INFO WHERE ID = c_user_id;
    dbms_output.put_line('v_user_name==='||v_user_name);
    -------------------------------------根据用户id以及类型获取用户名-end----------------------------------------------------------------------------------------
    select count(1) into v_user_count 
    FROM TBL_PVTP_BANK_ACCOUNT 
    WHERE USER_ID = c_user_id;
    /*获取当前的用户余额,授信余额*/
    SELECT ACCOUNT_BALANCE,ACCOUNT_BALANCE_CHECKCODE INTO v_account_balance_begin,v_account_balance_checkcode
    FROM TBL_PVTP_BANK_ACCOUNT 
    WHERE USER_ID = c_user_id AND rownum=1;

    -------------------------------------验证余额是否被篡改-start------------------------------------------------------------------------------------------------
    --获取用户KEY
    select getUserKey(v_user_name,'old','8') into v_user_key from dual;
    dbms_output.put_line('v_user_key==='||v_user_key);

    --获取余额校验码并判断是否被篡改
    v_create_code:=getCheck_Code(v_user_name,v_account_balance_begin,v_user_key);
    IF v_account_balance_checkcode is null or v_account_balance_checkcode<>v_create_code then
        output_msg:='余额发生篡改，无法完成当前操作!';
        return;
    END IF;
    -------------------------------------验证余额是否被篡改-end---------------------------------------------------------------------------------------------------
    --如果是支出，则需要校验余额是否足够
    IF (v_account_balance_begin+money)<0 then
        output_msg:='余额不足，无法完成当前操作!';
        return;
    END IF;
    ------更新账户余额----
    update TBL_PVTP_BANK_ACCOUNT set 
    account_balance=(account_balance + money)
    where user_id = c_user_id;

   --更新用户账户校验码
   --创建新的账户KEY
    select getUserKey(v_user_name,'new','8') into v_user_key from dual;
    --产生新的余额校验码
    select getcheck_code(v_user_name,account_balance,v_user_key),getcheck_code(v_user_name,deposit_money_balance,v_user_key)
    into 
    v_account_balance_checkcode,v_deposit_checkcode
    from TBL_PVTP_BANK_ACCOUNT 
    WHERE USER_ID = c_user_id;   
    --更新余额校验码、授信校验码
     update TBL_PVTP_BANK_ACCOUNT set account_balance_checkcode=v_account_balance_checkcode,deposit_checkcode=v_deposit_checkcode
     WHERE USER_ID = c_user_id;
    --更新用户账户KEY
    update TBL_STATIONED_CACHE_KEY set cache_key = v_user_key,create_time=sysdate where user_name = v_user_name;
    output_status := '1';
    output_msg    := '修改余额成功！';
    EXCEPTION
  WHEN OTHERS THEN
    output_msg := '修改余额时出现未知错误，操作失败！';
    DBMS_OUTPUT.put_line('修改余额时出现未知错误:'||SQLCODE || ':'||SQLERRM||'');
    ROLLBACK;
END UPDATE_PVTP_ACCOUNT_BALANCE;
/

