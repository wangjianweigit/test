create FUNCTION pvtp_get_SalePrice_Min_List
/**
    （新版）通过用户名获取商品货号最低价格             (列表专用) 速度做过优化
    wangpeng
    2017-05-12
    价格计算规则：取最低报价SKU ---->>>>>>  获取SKU对应实际销售价调用函数getSku_User_SalePrice
    返回值：商品最低销售价格    （未考虑特殊价格）
    
    -reid 2019-09-28
**/
(
    c_stationed_user_id     number,                                --当前访问的私有平台ID（即平台所属私有商家的ID）    
    c_user_name   varchar2,            --用户名
    c_product_itemnumber   varchar2    --商品货号    
) return varchar2
 is
     v_product_prize_str varchar2(50):='0.00';    --需要返回的商品价格
     v_id number:=0;                              --最低报价SKUID
     v_count number:=0;                               --临时变量
BEGIN
    --判断商品是私有商品还是童库分享的商品
    select count(1) into v_count from TBL_PVTP_PRODUCT_INFO ppi where ppi.stationed_user_id = c_stationed_user_id
    and ppi.itemnumber = c_product_itemnumber;
    IF v_count <> 0 THEN
        --查询最低报价的SKUID
        select id into v_id from (select id from tbl_pvtp_product_sku where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架' order by product_prize_cost asc ) where rownum<2;
    else
         --查询最低报价的SKUID
        select id into v_id from (
                select id from tbl_product_sku ps 
                where ps.product_itemnumber = c_product_itemnumber 
                and ps.product_group ='尺码' 
                and ps.state='上架' 
                and exists (
                    SELECT 1 from TBL_PRODUCT_INFO pi 
                    INNER JOIN TBL_PVTP_PRODUCT_INFO_REF ppir on ppir.product_id = pi.id
                    where ppir.platform_id = c_stationed_user_id
                    and pi.is_private = 1
                    and ppir.enabled_flag = 1
                    and ps.product_itemnumber = pi.itemnumber 
                )
                order by product_prize_cost asc 
        ) where rownum<2;
    end if;
    --查找SKU对应的实际销售价
    v_product_prize_str:=nvl(to_char(pvtp_getSku_User_SalePrice(c_stationed_user_id,c_user_name,v_id),'fm999999990.00'),'0.00');

    return v_product_prize_str;
   
END pvtp_get_SalePrice_Min_List;
/

