create FUNCTION           GETSKU_USER_SALEPRICE_pre
/**
    获取订货会商品最终销售价格
    wanghai
    2017-09-27
    返回值：价格
**/
(
    c_user_name   varchar2,   --用户名
    c_product_sku   number     --规格
) return varchar2
 is
    v_prize number:=0;
    v_tiered_prize number:=0;
    v_product_prize_str varchar2(50):='0.00';   --需要返回的商品规格价格
    v_product_itemnumber varchar2(50);  --货号
    v_product_color varchar2(50);   --颜色
    v_product_specs   varchar2(50);      --商品规格
    t_result_count number:=0;
BEGIN

        --通过sku获取价格
        select product_itemnumber,product_color,product_specs,getSku_User_SalePrice(c_user_name,id) into v_product_itemnumber,v_product_color,v_product_specs,v_prize 
        from tbl_product_sku where id = c_product_sku and product_group ='尺码';
        
        --获取阶梯价格
        select count(1) into t_result_count from TMP_TIERED_PRICE where product_itemnumber = v_product_itemnumber and product_color = v_product_color and product_specs = v_product_specs;
        if t_result_count > 0 then
            select price into v_tiered_prize from TMP_TIERED_PRICE where product_itemnumber = v_product_itemnumber and product_color = v_product_color and product_specs = v_product_specs;
        end if;
        
        if v_tiered_prize > 0 and v_tiered_prize < v_prize then
            v_prize := v_tiered_prize;
        end if;

        v_product_prize_str := to_char(nvl(v_prize,0),'fm999999990.00');

   return v_product_prize_str;
   
END GETSKU_USER_SALEPRICE_pre;
/

