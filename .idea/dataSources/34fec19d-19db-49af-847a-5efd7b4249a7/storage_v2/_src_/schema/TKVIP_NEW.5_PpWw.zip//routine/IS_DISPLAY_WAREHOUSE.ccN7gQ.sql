create FUNCTION           IS_DISPLAY_WAREHOUSE
/**
      判断商品是否在传入仓显示
      wangpeng
      2017-08-30
      返回值：0不显示   1显示
      
      reid 2019.02.27 商家可以设置缺货订购仓库，相关改造
      去除商品表中预售字段          zhenghui 2019.04.10
  **/
(c_product_itemnumber  VARCHAR2, --商品货号
 c_warehouse_id NUMBER --仓库
 ) RETURN NUMBER IS
  v_is_outstock          number :=0;--是否缺货订购   是否支持缺货订购（0：不支持，1：支持）
  v_return_display       number :=0;--是否展示       0不展示    1展示
  v_count                NUMBER := 0; --临时变量
BEGIN
    
   --查询是否缺货订购,需要商品以及仓库同时支持
    select 
           (case when sui.default_outstock_warehouse = c_warehouse_id and pi.is_outstock =1 then 1 else 0 end) is_outstock 
           into v_is_outstock
           from tbl_product_info pi, 
           tbl_stationed_user_info sui 
           where sui.id = pi.stationed_user_id
           and pi.itemnumber = c_product_itemnumber;
   
   /**
    1、如果当前商品是预售商品且是华东仓，则直接返回1
    2、如果当前商品在当前仓库可以缺货订购，也直接返回1
   **/
   if (v_is_outstock =1 ) then
        v_return_display := 1;
   else
        --按仓查询是否有库存
        SELECT COUNT(1) INTO v_count FROM TBL_PRODUCT_SKU_STOCK WHERE WAREHOUSE_ID = c_warehouse_id 
            and PRODUCT_TOTAL_COUNT>PRODUCT_ORDER_OCCUPY_COUNT
            and PRODUCT_SKU in (select id from tbl_product_sku where PRODUCT_ITEMNUMBER = c_product_itemnumber and PRODUCT_GROUP = '尺码' and STATE = '上架')
            ;
        --有库存可售
        if v_count > 0 then   
            v_return_display := 1;
        end if;
            
   end if;

  --返回值
  RETURN v_return_display;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END IS_DISPLAY_WAREHOUSE;
/

