create TYPE           T_ORDER                                                                                                                                                                                                                                                                                                                              as object
(
     order_remark VARCHAR2 (1000 Byte),    --订单备注
    order_sku_ids varchar2 (4000 Byte),    --订单商品sku集合
    order_sku_counts  varchar2 (4000 Byte),   --订单商品sku数量集合
    logistics_company_code VARCHAR2(50 Byte),  --物流公司代码
    product_money NUMBER,  --订单商品金额
    logistics_money NUMBER,  --订单物流费用
    df_money NUMBER,   --订单代发费用
    warehouse_id NUMBER,   --下单仓库id,
    out_order_number VARCHAR2 (100 Byte), --外部订单号（淘宝）
    freight_payment_type NUMBER --运费是否到付  1.先支付运费   ；2：到付运费
);
------------------------------------------------
/

