create FUNCTION getAutoNumberShort/**
                                                       生成单编号-- 短
                                                       wangpeng
                                                       2016-03-15
                                                   **/
(v_seq_id IN VARCHAR2                                                   --序列ID
                     )
   RETURN VARCHAR2
IS
   PRAGMA AUTONOMOUS_TRANSACTION;
   returnstr       VARCHAR2 (50);                                       --返回单号
   v_seq_count     NUMBER;                                              --序列数量
   v_seq_size      NUMBER;                                              --序列长度
   v_random_size   NUMBER;                                             --随机数长度
   v_random        VARCHAR2 (100);                                       --随机数
   v_seq_num       NUMBER;                                               --序列值
   v_seq_date      VARCHAR (6);                                         --序列日期
   v_order_type    VARCHAR (2);                                         --单号类型
BEGIN
   --判断当前单号类型是否存在序列中
   SELECT COUNT (1)
     INTO v_seq_count
     FROM TBL_ORDER_SEQ
    WHERE id = v_seq_id;

   IF v_seq_count = 0
   THEN
      raise_application_error (
         -20000,
         '传入序列ID错误，未找到相应序列记录');    --3、抛出自定义异常
   END IF;

   --查询单号配置信息
   SELECT order_type,
          seq_size,
          random_size,
          NVL (seq_date, TO_CHAR (SYSDATE, 'yyMMdd')),
          NVL (seq_num, 0) + 1
     INTO v_order_type,
          v_seq_size,
          v_random_size,
          v_seq_date,
          v_seq_num
     FROM TBL_ORDER_SEQ
    WHERE id = v_seq_id
   FOR UPDATE;

   --获取单号
   IF v_seq_date != TO_CHAR (SYSDATE, 'yyMMdd')
   THEN
      v_seq_date := TO_CHAR (SYSDATE, 'yyMMdd');
      v_seq_num := 1;
   END IF;

   UPDATE TBL_ORDER_SEQ
      SET seq_num = v_seq_num, seq_date = v_seq_date, update_date = SYSDATE
    WHERE id = v_seq_id;

   --查询随机数
   SELECT SUBSTR (CAST (DBMS_RANDOM.VALUE AS VARCHAR2 (38)),
                  3,
                  v_random_size)
     INTO v_random
     FROM DUAL;

   --拼上随机数
   returnstr :=
         v_order_type
      || v_seq_date
      || LPAD (v_seq_num, v_seq_size, 0)
      || v_random;
   COMMIT;
   RETURN returnstr;
END getAutoNumberShort;
/

