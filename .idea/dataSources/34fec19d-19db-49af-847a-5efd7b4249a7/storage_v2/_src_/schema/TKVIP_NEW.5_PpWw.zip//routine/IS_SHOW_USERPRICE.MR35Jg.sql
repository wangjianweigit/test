create FUNCTION IS_SHOW_USERPRICE
/**
    通过用户名查询用户是否有权限查询价格
    zhenghui
    2019-10-09               
    返回值：是否可见价格 1.可见 0.不可见
    
**/
(
     C_USER_NAME        VARCHAR2     --用户名
) RETURN NUMBER
 IS
     V_SHOW_USERPRICE NUMBER:= 0;   --需要返回标志位
     V_USER_STATE NUMBER:= 0;       --用户状态
     V_PRE_APRV_ALLOWED_DATE DATE;  --预审用户最后允许登陆时间
BEGIN
   --游客用户直接返回不可见
    IF C_USER_NAME != '6666666' THEN
    
       --查询会员状态及预审用户最后允许登陆时间
       SELECT USER_STATE,PRE_APRV_ALLOWED_DATE INTO V_USER_STATE,V_PRE_APRV_ALLOWED_DATE FROM TBL_USER_INFO WHERE USER_NAME = C_USER_NAME;
       
       --用户状态为已审核直接返回可见
        IF V_USER_STATE = 1 THEN
            V_SHOW_USERPRICE := 1;
        END IF;
        
        --用户状态为预审通过并且预审最后时间大于当前时间则返回可见
        IF V_USER_STATE = 4 THEN
            IF V_PRE_APRV_ALLOWED_DATE > SYSDATE THEN
                V_SHOW_USERPRICE := 1;
            END IF;
        END IF;
    END IF;

    RETURN V_SHOW_USERPRICE;
   
END IS_SHOW_USERPRICE;
/

