create FUNCTION           getPaySeq
/**
    生成支付序号
    wanghai
    2017-01-18
**/
(
    v_order_number in varchar2  --订单号
)
return varchar2
is
PRAGMA AUTONOMOUS_TRANSACTION;
returnstr varchar2(10);     --返回支付序号
BEGIN
   select case when max(pay_seq) > 999 then lpad(to_number(substr(to_char(nvl(max(pay_seq),0)),2))+1,3,0) else lpad(nvl(max(pay_seq),0)+1,3,0) end into returnstr from TBL_ORDER_PAYMENT where ORDER_NUMBER = v_order_number;
   return returnstr;
END getPaySeq;
/

