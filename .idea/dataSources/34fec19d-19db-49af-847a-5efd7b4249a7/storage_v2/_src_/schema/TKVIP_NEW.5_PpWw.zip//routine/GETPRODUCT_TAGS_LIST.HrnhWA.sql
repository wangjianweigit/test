create function           getproduct_tags_list
/**
    （新版）通过用户名获取商品标签----列表页专用
    wangpeng
    2017-05-12
    返回值：需要返回的优惠标签
    
    reid 2018.10.25 预售活动相关修改
**/
(
    c_user_name   varchar2,             --用户名
    c_product_itemnumber   varchar2     --商品货号    
) return varchar2
 is
     v_user_id number:=0;                   --用户id
     v_hd_flag number:=-1;                  --是否参加了活动
     v_site_id number:=0;                   --会员站点
     v_tag_color varchar2(20);              --活动标签颜色
     v_tag_name varchar2(100);              --活动标签名称
     v_tag_img_wx varchar2(500);            --移动端标签图片
     v_tag_img_pc varchar2(500);            --pc端标签图片
     v_tag_level number:=2;                   --列表页标签等级
     v_return_tags varchar2(500);            --需要返回的标签
begin

   --查询会员站点
   select nvl(min(site_id),0),nvl(min(id),0) into v_site_id,v_user_id from tbl_user_info where user_name = c_user_name;
   --如果没有查询到用户信息，则返回原价
   if v_user_id!=0 then
   
        --查询参加的活动----订货会、限时折扣、预售活动、清尾活动
        select nvl(min(c.id),-1),nvl(min(a1.tag_color),'1'),nvl(min(a1.tag_name),'1'),nvl(min(a1.tag_img_wx),'1'),nvl(min(a1.tag_img_pc),'1'),nvl(min(a1.tag_level),2) 
        into v_hd_flag,v_tag_color,v_tag_name,v_tag_img_wx,v_tag_img_pc,v_tag_level 
        from tbl_activity_info a ,tbl_activity_detail a1,tbl_activity_product c 
        where a.activity_state = '3' and a.state = '2' 
        and sysdate between a.begin_date and a.end_date 
        and sysdate between c.activity_start_date and c.activity_end_date 
        and a.id = a1.activity_id
        and c.activity_id = a.id 
        and c.product_itemnumber =c_product_itemnumber
        and(case when (a1.user_group_id = 0 or a1.user_group_id is null) then 1 else case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and a1.user_group_id = aa.id and bb.user_id = c_user_name)then 1 else 0 end end) = 1
        and exists (select 1 from tbl_activity_site tas where tas.activity_id = a.id and tas.site_id = v_site_id);
       --参加了活动
       if v_hd_flag!=-1 then
            if v_tag_level = 1 then
                --附加活动标签
                v_return_tags := v_tag_level||'#-#'||v_tag_img_wx||'#-#'||v_tag_img_pc;
            else
                --附加活动标签
                v_return_tags := v_tag_level||'#-#'||v_tag_name||'#-#'||v_tag_color;
            end if;
       end if; 
        
   end if;

   return v_return_tags;
end getproduct_tags_list;
/

