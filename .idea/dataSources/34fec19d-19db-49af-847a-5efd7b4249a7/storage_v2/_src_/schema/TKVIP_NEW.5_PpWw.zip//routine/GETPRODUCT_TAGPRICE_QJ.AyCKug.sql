create FUNCTION           getProduct_TagPrice_Qj
/**
    （新版）通过用户名获取商品吊牌价格区间 
    wangpeng
    2017-05-13
    返回值：商品价格
**/
(
    c_product_itemnumber   varchar2     --商品货号    
) return varchar2
 is
    v_product_prize_str varchar2(50):='0.00-0.00';   --需要返回的商品价格
BEGIN

   --通过sku获取最低价
   select nvl(to_char(min(product_prize_tag),'fm999999990.00'),'0.00')||'-'||nvl(to_char(max(product_prize_tag),'fm999999990.00'),'0.00') into v_product_prize_str  from tbl_product_sku 
   where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架';
   return v_product_prize_str;
   
END getProduct_TagPrice_Qj;
/

