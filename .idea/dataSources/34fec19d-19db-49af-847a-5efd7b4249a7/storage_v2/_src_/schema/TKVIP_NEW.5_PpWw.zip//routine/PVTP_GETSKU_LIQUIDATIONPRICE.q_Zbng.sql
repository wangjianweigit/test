create FUNCTION           pvtp_getsku_liquidationprice
/**
    通过用户名获取SKU商品的最终清分价格
    wanghai
    创建：2019-09-06 create by wanghai 私有平台清分规则计算
    
    返回值：商品清分价格
**/
(
    c_type  number,                     --清分类型  1、私有商家收入；2、平台服务费；3、仓储服务费；4、私有商家服务费；5、支付服务费
    c_user_name   varchar2,             --用户名
    c_product_sku_id   number,          --商品SKUID
    c_product_price    number,          --商品单价
    c_vip   number,                     --会员价标识
    c_original_cost number,             --原报价
    c_new_cost  number,                 --折扣后报价
    c_activity_id   number              --活动ID
) return number
 is
     v_service_pay_charges  number:=0;           --私有商家支付服务费率
     v_service_charges      number:=0;           --私有商家服务费率
     v_storage_charges      number:=0;           --仓储服务费
     v_product_itemnumber   varchar2(50);        --商品货号
     v_product_prize_cost   number:=0;           --商品报价
     v_product_specs_id     number :=0;          --商品规格ID                   --私有平台特殊价格新加配置
     v_product_specs        varchar2(500);       --商品规格名称                 --私有平台特殊价格新加配置
     v_product_type_id      number := 0;         --商品类型ID
     v_product_type_type    char := '1';         --商品类型类别
     v_discount             number := 1;         --折扣
     v_now_prize_cost       number;              --当前清分报价
     v_liquidation_prize    number;              --清分金额
     
     v_product_create_date date;                 --商品创建时间  
BEGIN
    
    v_now_prize_cost := c_new_cost;

    --查询私有商家支付服务费比例,私有商家服务费比例
    select nvl(pay_service_rate,0), nvl(service_charges,0) into v_service_pay_charges,v_service_charges  from TBL_PVTP_CONFIG where stationed_user_id = (
        select stationed_user_id from TBL_PVTP_PRODUCT_SKU where id = c_product_sku_id
    );

    --查询SKU基本信息
    select a.create_date,a.product_type_id,b.product_itemnumber,b.product_prize_cost,b.parent_id,b.product_specs into v_product_create_date,v_product_type_id,v_product_itemnumber,v_product_prize_cost,v_product_specs_id,v_product_specs from TBL_PVTP_PRODUCT_INFO a,TBL_PVTP_PRODUCT_SKU b where a.itemnumber = b.product_itemnumber and b.product_group = '尺码' and b.id = c_product_sku_id and rownum < 2;
       
    --获取商品类型的类别
    select type into v_product_type_type from TBL_DIC_PRODUCT_TYPE where id = v_product_type_id;
       
    --查询SKU仓储费
    if v_product_type_type = '1' then
       select nvl(max(storage_charges),0) into v_storage_charges from TBL_PVTP_STAT_STORAGE_CHARGES ssc,TBL_PVTP_PRODUCT_SKU ps 
       where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size(+) = ps.product_group_member and ps.id = c_product_sku_id and type = v_product_type_type;
    else
       select nvl(max(storage_charges),0) into v_storage_charges from TBL_PVTP_STAT_STORAGE_CHARGES ssc,TBL_PVTP_PRODUCT_SKU ps 
       where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size = v_product_type_id and ps.id = c_product_sku_id and type = v_product_type_type;
    end if;
    
    --报价大于售价，按照售价计算私有商家货款
    if v_now_prize_cost > c_product_price then
        v_now_prize_cost := c_product_price;
    end if;
    
    --如果报价小于仓储费，则不收取仓储费
    if v_now_prize_cost <= v_storage_charges then
        v_storage_charges := 0;
    end if;
    
    --计算清分规则
    if c_type = 1 then
        --私有商家收入 报价*折扣-报价*活动折扣*私有商家服务费-仓储费
        v_liquidation_prize := trunc(v_now_prize_cost,2) - trunc(v_now_prize_cost*v_service_charges,2) - trunc(v_now_prize_cost*v_service_pay_charges,2) - v_storage_charges;
    elsif c_type = 2 then
        --会员服务费 活动价-报价*活动折扣
        v_liquidation_prize := c_product_price - trunc(v_now_prize_cost,2);
    elsif c_type = 3 then
        v_liquidation_prize := v_storage_charges;
    elsif c_type = 4 then
        v_liquidation_prize := trunc(v_now_prize_cost*v_service_charges,2);
    elsif c_type = 5 then
        --私有商家支付服务费
        v_liquidation_prize := trunc(v_now_prize_cost*v_service_pay_charges,2);
    end if;
   
    return v_liquidation_prize;
   
END pvtp_getsku_liquidationprice;
/

