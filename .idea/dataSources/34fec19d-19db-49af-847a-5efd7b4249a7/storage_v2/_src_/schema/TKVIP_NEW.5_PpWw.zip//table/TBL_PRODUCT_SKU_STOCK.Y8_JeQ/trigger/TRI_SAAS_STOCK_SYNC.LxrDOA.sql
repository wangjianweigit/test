create trigger TRI_SAAS_STOCK_SYNC
  after insert or update
  on TBL_PRODUCT_SKU_STOCK
  for each row
declare
temp_count number := 0;

begin

    --判断逻辑库存是否有变化
    if :old.PRODUCT_TOTAL_COUNT - :old.PRODUCT_ORDER_OCCUPY_COUNT - :old.PRE_ORDER_OCCUPY_COUNT <> :new.PRODUCT_TOTAL_COUNT - :new.PRODUCT_ORDER_OCCUPY_COUNT - :new.PRE_ORDER_OCCUPY_COUNT then
        
        declare cursor csr_saas_company is select id from TBL_SAAS_COMPANY where state = '1';
        
        begin
            for company in csr_saas_company loop
                -- 获取sku当前未同步数量
                select count(1) into temp_count from TBL_SAAS_STOCK_SYNC where state in ('0','1') and sku_id = :new.PRODUCT_SKU and saas_company = company.id;
                -- 判断是否存在未同步数据
                if temp_count = 0 then
                    insert into TBL_SAAS_STOCK_SYNC(
                        id,
                        sku_id,
                        saas_company
                    )
                    values (
                        SEQ_saas_stock_sync.nextval,
                        :new.PRODUCT_SKU,
                        company.id
                    );
                end if;
            end loop;
        end;
    end if;
end;
/

