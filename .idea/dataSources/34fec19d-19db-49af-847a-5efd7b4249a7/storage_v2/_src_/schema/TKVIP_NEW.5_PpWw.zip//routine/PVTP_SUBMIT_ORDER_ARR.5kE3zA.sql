create PROCEDURE PVTP_SUBMIT_ORDER_ARR
/**
     reid 2019.04.29  新版批量下单处理存储过程
  **/
(
 c_stationed_user_id  IN  number,               --当前下单私有平台ID（即所属私有商家的ID）
 client_user_name in varchar2,             --用户名
 client_receiving_name in varchar2,        --收货人姓名
 client_receiving_phone in varchar2,       --收货电话
 client_user_province_id in number,        --收货地省ID
 client_receiving_address in varchar2,     --收货地址
 client_order_list IN  T_NEW_ORDER_LIST,    --订单数组对象
 client_order_source  in varchar2,         --订单来源
 client_submode char,                      --下单模式   0:正常下单   1：代客户下单
 client_xdr_user_name  in varchar2,        --下单人用户名
 client_xdr_type in char,                  --下单人用户类型（3：业务员，4：业务经理，5：店长，6：营业员，7：自行下单）
 output_status  out varchar2,              --返回的状态码 0-失败 1-成功
 output_msg out varchar2                   --返回的信息
) AS
v_order T_ORDER_INFO;--订单对象
v_order_product T_ORDER_PRODUCT;--订单商品对象
v_pay_trade_number varchar2(50 byte);   --付款交易号
v_order_product_count  number  :=0;--订单商品数
v_product_total_count number  :=0;--下单商品总数
v_temp_count number :=0;--临时变量
v_df_flag number:=0;--是否代发订单0默认批发 1代发订单
BEGIN
  output_status:='0';
  --先调出校验存储过程；进行订单校验；创建临时表数据,默认不进行数据修正
  PVTP_CONFIRM_ORDER(c_stationed_user_id,client_user_name,client_order_list,1,output_status,output_msg);
  --校验未能通过，直接返回
  IF output_status<>'1' THEN
    RETURN;
  END IF;
  ---创建合并支付表数据
      v_pay_trade_number:='1'||getAutoNumber('D');
      INSERT INTO TBL_ORDER_UNION_PAY(ID,PAY_TRADE_NUMBER,STATE,CREATE_DATE,ORDER_SUBMOD,ORDER_XDR_TYPE,ORDER_SALE_USER_NAME)
      VALUES(SEQ_ORDER_UNION_PAY.NEXTVAL,v_pay_trade_number,0,sysdate,client_submode,client_xdr_type,client_xdr_user_name);
      --判断订单是否代发，不是代发必须下单数量在 5 件以上
      select count(1) into v_temp_count 
      from TMP_NEW_ORDER tno 
      INNER JOIN TBL_LOGISTICS_COMPANY lc on lc.code = tno.logistics_company_code
      WHERE lc.type='2';
     IF v_temp_count > 0 THEN
          v_df_flag := 1;       --当前下单是代发
     END IF;
     ---查询当前下单总量（所有订单的总数，如果小于5件，则必须选择代发）
     select sum(count) into v_product_total_count from TMP_NEW_ORDER_PRODUCT_SKU;
     IF v_df_flag = 0 and v_product_total_count < 5 THEN
           output_status:='0';
           output_msg:='当前订购商品总数为（'||v_product_total_count||'）双，不满足批发要求5双及以上，请重新下单或选择代发下单';
           RETURN;
     END IF;
     /**
     循环订单临时表，进行下单操作
     **/
     BEGIN
      FOR v_order IN(
           select order_id,warehouse_id,product_money,logistics_company_code,logistics_money,df_money,freight_payment_type,order_remark,stationed_user_id from TMP_NEW_ORDER
      ) LOOP
      ---stationed_user_id=0，表示童库商品
      IF v_order.stationed_user_id = 0 THEN
          PVTP_SUBMIT_ORDER_TK(
              c_stationed_user_id,
              client_user_name,
              client_receiving_name,
              client_receiving_phone,
              client_user_province_id,
              client_receiving_address,
              v_order.order_id,
              v_order.order_remark,
              v_order.logistics_company_code,
              v_order.product_money,
              v_order.logistics_money,
              v_order.df_money,
              client_order_source,
              client_submode,
              client_xdr_user_name,
              client_xdr_type,
              v_order.warehouse_id,
              v_order.freight_payment_type,
              output_status,
              output_msg);
      ELSE
          PVTP_SUBMIT_ORDER(
              c_stationed_user_id,
              client_user_name,
              client_receiving_name,
              client_receiving_phone,
              client_user_province_id,
              client_receiving_address,
              v_order.order_id,
              v_order.order_remark,
              v_order.logistics_company_code,
              v_order.product_money,
              v_order.logistics_money,
              v_order.df_money,
              client_order_source,
              client_submode,
              client_xdr_user_name,
              client_xdr_type,
              v_order.warehouse_id,
              v_order.freight_payment_type,
              output_status,
              output_msg);
      END IF;
      IF output_status <>'1' THEN
         ROLLBACK;
         RETURN;
      END IF;
      INSERT INTO TBL_ORDER_UNION_PAY_DETAIL(ID,PAY_TRADE_NUMBER,ORDER_NUMBER,CREATE_DATE) VALUES(SEQ_ORDER_UNION_PAY_DETAIL.NEXTVAL,V_PAY_TRADE_NUMBER,OUTPUT_MSG,SYSDATE);
     END LOOP;
     END;
  output_status:='1';
  output_msg := v_pay_trade_number;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END PVTP_SUBMIT_ORDER_ARR;
------------------------------------------------
/

