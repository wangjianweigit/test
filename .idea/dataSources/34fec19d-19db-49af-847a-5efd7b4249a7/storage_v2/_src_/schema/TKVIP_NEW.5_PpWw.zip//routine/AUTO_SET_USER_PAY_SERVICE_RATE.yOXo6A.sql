create PROCEDURE           AUTO_SET_USER_PAY_SERVICE_RATE
/**
     设置用户支付服务费，（job调用专用），一次性调用
     wangpeng
     2018-03-06 
  **/
 IS
    v_sxsj     number:=1;         
BEGIN
  update TBL_STATIONED_USER_INFO set PAY_SERVICE_RATE = 0.006 ;
  commit;
    
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END AUTO_SET_USER_PAY_SERVICE_RATE;
/

