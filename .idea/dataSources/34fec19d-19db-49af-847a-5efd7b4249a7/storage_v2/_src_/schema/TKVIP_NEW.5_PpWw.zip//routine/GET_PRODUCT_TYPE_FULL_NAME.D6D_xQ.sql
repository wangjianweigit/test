create FUNCTION           GET_PRODUCT_TYPE_FULL_NAME
/**
    根据商品分类的ID获取完整的分类路径
    参数：子节点ID
    返回值：祖父节点名称>父节点名>子节点名称
    songwangwen
    2017-04-28
**/
(
    v_product_type_id   NUMBER   --分类ID 
) return varchar2
 is
 v_product_type_name varchar2(200);   --拼接后的分类名称
BEGIN

    for tb in(
        --循环条件
        select wi.TYPE_NAME
        from TBL_DIC_PRODUCT_TYPE wi
        start with wi.id = v_product_type_id
        connect by nocycle prior wi.parent_id = wi.id
        order by wi.id asc
) loop
    --循环体
    IF v_product_type_name is not null
    THEN
          v_product_type_name:= v_product_type_name||' > '||tb.TYPE_NAME;
    END IF;
    IF v_product_type_name is null
    THEN
          v_product_type_name:= tb.TYPE_NAME;
    END IF;

end loop;
   return v_product_type_name;
END GET_PRODUCT_TYPE_FULL_NAME;
/

