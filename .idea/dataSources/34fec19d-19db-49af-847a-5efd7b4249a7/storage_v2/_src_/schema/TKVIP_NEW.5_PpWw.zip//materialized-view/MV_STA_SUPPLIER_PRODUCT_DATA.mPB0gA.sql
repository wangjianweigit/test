create materialized view MV_STA_SUPPLIER_PRODUCT_DATA
  refresh force on demand
as
select distinct pi.stationed_user_id, po.supplier_id, 
    pi.product_type,
    (case when pi.product_type = 1 
    then (select ORIGINAL_PRODUCT_ITEMNUMBER from TBL_CUSTOM_PRODUCT_REL where CUSTOM_PRODUCT_ITEMNUMBER = pi.itemnumber)
    else pi.itemnumber
    end
    )product_itemnumber,
    pi.year,
    pi.SEASON_ID,
    pi.BRAND_ID,
    (nvl(instorage.instorage_count,0))instorage_count,
    (nvl(sale.sale_count,0))sale_count,
    (nvl(fqc.fqc_count,0))fqc_count,
    (nvl(sale_return.sale_return_num,0))sale_return_num,
    (nvl(deliver.deliver_day,0))deliver_day
from tbl_product_info pi
inner join tkerp.TBL_PURCHASE_DETAIL pd on pd.product_itemnumber = pi.itemnumber
inner join tkerp.tbl_purchase_order po on pd.PURCHASE_NUMBER = po.PURCHASE_NUMBER
left join (
    SELECT isd.supplier_id, isd.product_itemnumber,COUNT (isd.PRODUCT_UNIQUE_CODE) instorage_count
    FROM tkerp.tbl_in_storage_detail isd
    WHERE exists(
        select 1
        from tkerp.tbl_in_storage_order iso
        where iso.state = '2'
        and isd.in_storage_number = iso.in_storage_number
    )
    GROUP BY isd.supplier_id,isd.product_itemnumber
)instorage on pi.itemnumber = instorage.product_itemnumber and po.supplier_id = instorage.supplier_id
left join (
    select po.SUPPLIER_ID, pd.product_itemnumber, count(bd.product_unique_code) sale_count
    from tkerp.TBL_ENCASEMENT_INFO ei
    inner join tkerp.tbl_box_detail bd on ei.box_number = bd.box_number
    inner join tkerp.tbl_barcode_collect bc on bd.product_unique_code = bc.product_unique_code
    inner join tkerp.tbl_purchase_detail pd on bc.PURCHASE_NUMBER = pd.purchase_number and bc.product_sku = pd.product_sku
    inner join tkerp.tbl_purchase_order po on pd.PURCHASE_NUMBER = po.PURCHASE_NUMBER
    where ei.is_out = 1
    group by po.SUPPLIER_ID, pd.product_itemnumber
) sale on pi.itemnumber = sale.product_itemnumber and po.supplier_id = sale.SUPPLIER_ID
left join (
    select po.SUPPLIER_ID, pd.product_itemnumber , count(tod.product_unique_code) fqc_count
    from tkerp.TBL_TEMPORARY_OUT_DETAIL tod
    inner join tkerp.tbl_barcode_collect bc on tod.product_unique_code = bc.product_unique_code
    inner join tkerp.TBL_PURCHASE_DETAIL pd ON bc.PURCHASE_NUMBER = pd.purchase_number and bc.product_sku = pd.product_sku
    inner join tkerp.tbl_purchase_order po on pd.PURCHASE_NUMBER = po.PURCHASE_NUMBER
    where exists(
        select 1
        from tkerp.tbl_temporary_out_order too
        where tod.temporary_out_number = too.temporary_out_number
        and too.state = 2
    )
    group by po.SUPPLIER_ID, pd.product_itemnumber
)fqc on pi.itemnumber= fqc.product_itemnumber and po.SUPPLIER_ID = fqc.SUPPLIER_ID
left join (
    select po.SUPPLIER_ID,pd.product_itemnumber, count(1) sale_return_num
    from tkerp.tbl_new_return_detail_code nrdc
    inner join tkerp.tbl_barcode_collect bc on nrdc.product_unique_code = bc.product_unique_code
    inner join tkerp.TBL_PURCHASE_DETAIL pd ON bc.PURCHASE_NUMBER = pd.purchase_number and bc.product_sku = pd.product_sku
    inner join tkerp.tbl_purchase_order po on pd.PURCHASE_NUMBER = po.PURCHASE_NUMBER
    where nrdc.qualified_flag = '2'
    group by po.SUPPLIER_ID,pd.product_itemnumber
) sale_return on pi.itemnumber= sale_return.product_itemnumber  and po.SUPPLIER_ID = sale_return.SUPPLIER_ID
left join (
    select supplier_id, product_itemnumber, TRUNC(sum(TOTAL_COUNT * delivery_date) / 30,1) deliver_day
    from (
        select t.supplier_id,t.product_itemnumber, t.purchase_number, sum(t.PRODUCT_COUNT) TOTAL_COUNT,
            SUM((t.APPROVAL_DATE - t.REVIEWERS_DATE) * t.PRODUCT_COUNT) /30 delivery_date
        from (
            select
                po.supplier_id,
                isd.product_itemnumber,
                po.purchase_number,
                min(po.REVIEWERS_DATE) REVIEWERS_DATE,
                iso.in_storage_number,
                count(isd.product_unique_code) product_count,
                min(iso.APPROVAL_DATE) APPROVAL_DATE
            from tkerp.tbl_purchase_order po
            inner join tkerp.tbl_in_storage_detail isd on isd.purchase_number = po.purchase_number
            inner join tkerp.tbl_in_storage_order iso on isd.in_storage_number = iso.in_storage_number
            where po.state= 3
            group by po.supplier_id,isd.product_itemnumber, po.purchase_number, iso.in_storage_number
        ) t
        group by t.supplier_id,t.product_itemnumber, t.purchase_number
    )
    group by supplier_id,product_itemnumber
)deliver on pi.itemnumber = deliver.product_itemnumber and po.SUPPLIER_ID = deliver.SUPPLIER_ID
where pi.product_type in (0,1)
/

