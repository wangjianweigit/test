create FUNCTION           IS_DISPLAY_SPEC
/**
      判断商品是否属于某个规格
      wangpeng
      2017-08-30
      返回值：0不显示   1显示
  **/
(c_product_itemnumber  VARCHAR2, --商品货号
 c_spec_id NUMBER                --规格ID
 ) RETURN NUMBER IS
  v_is_outstock          number :=0;--是否缺货订购   是否支持缺货订购（0：不支持，1：支持）
  v_is_presale           number :=0;--是否预售       是否为商品预售（0：不是，1：是预售）
  v_return_display       number :=0;--是否展示       0不展示    1展示
  v_count                NUMBER := 0; --临时变量
BEGIN
    
   select count(1) into v_count from tbl_product_sku where PRODUCT_ITEMNUMBER = c_product_itemnumber and PRODUCT_GROUP = '尺码' and STATE = '上架'
       and PRODUCT_GROUP_MEMBER in (
            select PRODUCT_SIZE from tbl_product_spec_size where spec_id = c_spec_id
       );
   if v_count > 0 then
        v_return_display := 1;
   end if;

  --返回值
  RETURN v_return_display;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END IS_DISPLAY_SPEC;
/

