create FUNCTION IS_USER_CATR_SKU_EFFECT
/**
    reid 2019.05.16 判断普通购物车则的商品SKU是否有效
    以下情况商品会失效
    1、SKU已下架 或者商品下架
    2、商品参加特殊活动【订货会】【清尾活动】
    3、商品库存为0,且不可缺货订购
    2019.09.17 reid 购物车在，存在已经不可见的仓库，则返回失效
    返回值：0 失效  1：有效
**/
(
    c_user_name             varchar2,               --用户名
    c_product_sku           number,                 --商品SKU ID
    c_warehouse_id          number                  --仓库ID（小仓ID,为0表示不限制仓库）
) return varchar2
 is
     v_count number:=0;                                    --临时变量
     v_activity_type number:=0;                            --商品参加活动的类型 
     v_product_itemnumber varchar2(50);                    --商品货号
     v_productsku_stocks number:=0;                        --库存数量
     v_is_outstock number:=0;                              --是否支持缺货订购 1：支持 0：不支持
BEGIN
    /*****查询仓库对当前用户是否可见*******/
    select  count(1) into v_count
    from 
    tbl_site_warehouse t2
    where exists (select 1 from tbl_user_info t1 where t1.user_name = c_user_name and t1.site_id = t2.site_id)
    and t2.warehouse_id = c_warehouse_id;
    ---仓库不可见，直接标记为失效
    IF v_count = 0 THEN
        return 0;
    END IF;
    ---1、SKU已下架 或者商品下架
    SELECT count(1) into v_count FROM TBL_PRODUCT_SKU ps WHERE ps.id = c_product_sku AND ps.state = '上架'
    AND exists (select 1 from TBL_PRODUCT_INFO pi where pi.itemnumber = ps.product_itemnumber and pi.state in ('上架','暂下架'));
    IF v_count=0 THEN
        RETURN 0;
    END IF;
    
    SELECT ps.product_itemnumber into v_product_itemnumber FROM TBL_PRODUCT_SKU PS WHERE ps.id = c_product_sku;
    select IS_ACTIVITY(c_user_name,v_product_itemnumber) into v_activity_type from dual;
    --2、商品参加特殊活动【订货会】【清尾活动】
    IF v_activity_type = 2 OR v_activity_type = 5 THEN
        RETURN 0;
    END IF;
    --查询库存信息
   select GETPRODUCTSKU_STOCKS(c_product_sku,c_warehouse_id,c_user_name) into v_productsku_stocks from dual;
   select IS_OUTSTOCK_PRODUCT_SKU(c_user_name,v_product_itemnumber,c_product_sku,c_warehouse_id) into v_is_outstock from dual;
   IF v_productsku_stocks = 0 and v_is_outstock=0 THEN
        RETURN 0;
   ELSE
        RETURN 1;
   END IF;
END IS_USER_CATR_SKU_EFFECT;
/

