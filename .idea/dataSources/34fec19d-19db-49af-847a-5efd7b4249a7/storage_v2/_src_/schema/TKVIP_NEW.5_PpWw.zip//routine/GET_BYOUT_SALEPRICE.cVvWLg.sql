create function get_byout_saleprice
/**
    reid 2019.04.23 计算商品售价，计算规则与函数getsku_user_saleprice相同，
    修改：2019-09-05   update  for wangpeng  支持新老商品不同费率计算 针对2019-09-15新费率调整
    修改：2019-11-01   update  for reid   没有设置买断价格进行买断时，确认订单报错错误修改

    该方法仅用于计算【清尾活动】的商品价格
   
    商品价格规则：
    0. 报价  =  阶梯价格 
        if(买断){报价  =  买断价格}
    1、商品应销售价 = 报价 / (1-入驻商服务费比例 - 入驻商会员区域服务费比例)
    2、会员区域服务费 = 商品应该销售价 * 会员区域服务费比例
    3、入驻商会员服务费 = 商品应销售价 * 会员服务费比例
    4、童库平台特殊价格 = 商档报价 + (入驻商会员服务费 + 会员区域服务费) * 特殊折扣
    5、普通销售价 = 商档报价 + 入驻商会员服务费 + (会员区域服务费 * least(会员折扣，站点折扣))
   
    返回值：商品实际销售价格--清尾阶梯价计算和普通计算取最低价
**/
(
     c_user_name        varchar2,     --用户名
     c_activity_id      number,       --活动id
     c_product_sku_id   number,       --商品skuid
     c_buy_out_flag     number,       --是否买断该商品  1：非买断   2：买断
     c_product_count    number       --商品购买量，一次下单中，当前货号的总购买量
) return number
 is
     v_temp_count            number :=0;     --临时变量
     v_product_itemnumber    varchar2(50);   --商品货号
     v_product_specs varchar2(50);          --商品规格名称                                                         
     v_hy_discount number:=1;                --会员等级折扣
     v_site_discount number:=1;             --站点折扣
     v_hyfwf_discount number :=1 ;          --会员服务费折扣率,站点或会员等级折扣
     v_site_id number:=0;                   --会员站点
     v_hdhy_discount number:=1;             --活动会员折扣
     v_hd_discount   number:=1;             --活动商品折扣
     v_member_service_rate number:=0;                --会员服务费比例-汇总
     v_member_service_rate_rzs number:=0;            --会员服务费比例-入驻商
     v_member_service_rate_qj number:=0;             --会员服务费比例-全局
     
     v_product_create_date date;                                             --商品创建时间                          --界线新加配置
     v_sys_line date:=to_date('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置
     v_sys_line2 date:=to_date('2019-09-13 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置  针对2019-09-13新费率调整
     v_sys_default_hy_dis number := 0.7;                                     --新注册会员老商品采用默认费率折扣      --界线新加配置
     
     v_product_prize_cost number:=0;                                --商品原报价，直接取sku表中的报价
     v_tiered_pricing number:=0;                                    --商品阶梯报价 或者买断价格
     v_tp_sale_prize number:=0;                                     --商品阶梯应售价
     v_tp_member_service_money_rzs number:=0;                       --阶梯报价-会员服务费-入驻商
     v_tp_member_service_money_qj number:=0;                        --阶梯报价-会员服务费-全局
     v_tp_product_prize number:=0;                                  --阶梯报价-最终售价
     v_product_prize number:=0;                                     --非阶梯情况下的-最终售价
     v_activity_type number:=0;                                     --商品参加的活动类型 0：未参加活动  5：清尾活动
     v_buy_out_flag number:=1;                                      --是否买断该商品  1：非买断   2：买断   
begin   
    v_buy_out_flag:=c_buy_out_flag;
    if c_activity_id<>0 then
          select activity_type into v_activity_type from tbl_activity_info where id = c_activity_id;
          /***如果当前是清尾活动****/
          if v_activity_type = 5 then
                /*************************商品新老计费费率控制*********begin**********************/
                select a.create_date into v_product_create_date from tbl_product_info a,tbl_product_sku b where b.id = c_product_sku_id  and a.itemnumber = b.product_itemnumber and rownum<2;
                if v_product_create_date < v_sys_line then
                    --查询入驻商会员服务费比例-老费率
                    select nvl(member_service_rate,0),nvl(area_service_rate,0) into v_member_service_rate_rzs,v_member_service_rate_qj from tbl_stationed_old_service_rate where stationed_user_id = (
                        select stationed_user_id from tbl_product_sku where id = c_product_sku_id and rownum<2
                    );
                end if;
                /*************************商品新老计费费率控制*********end**********************/
                
                if v_product_create_date >= v_sys_line then
                   --查询入驻商会员服务费比例-按当前费率计算
                    select nvl(member_service_rate,0),nvl(area_service_rate,0) into v_member_service_rate_rzs,v_member_service_rate_qj from tbl_stationed_user_info where id = (
                        select stationed_user_id from tbl_product_sku where id = c_product_sku_id
                    );
               end if;
               
                /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
                if v_sys_line2 > v_product_create_date and v_product_create_date >= v_sys_line then
                    --查询入驻商会员服务费比例-老费率2次调整
                    select nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RAT2 where STATIONED_USER_ID = (
                         select stationed_user_id from tbl_product_sku where id = c_product_sku_id and rownum<2
                    );
                end if;
                /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/

               --查询sku基本信息
               select product_itemnumber,product_specs,product_prize_cost into v_product_itemnumber,v_product_specs,v_product_prize_cost
               from tbl_product_sku where product_group = '尺码' and id = c_product_sku_id ;
               
               --查询会员站点、特殊价格模板（私有站）
               select nvl(min(site_id),0),nvl(min(discount),1) into v_site_id,v_hy_discount from tbl_user_info where user_name = c_user_name;  

                --查询【清尾活动】的会员服务费折扣
                select nvl(min(b.activity_service_discount),1), nvl(min(c.activity_discount),1) into v_hdhy_discount,v_hd_discount 
                from tbl_activity_info a ,tbl_activity_detail b,tbl_activity_product c 
                where a.activity_state = '3' and a.state = '2'  and a.activity_type='5'
                and sysdate between a.begin_date and a.end_date 
                and sysdate between c.activity_start_date and c.activity_end_date 
                and a.id = b.activity_id
                and c.activity_id = a.id 
                and c.product_itemnumber =v_product_itemnumber
                and a.id = c_activity_id
                and exists (select 1 from tbl_activity_site aa where aa.activity_id = a.id and aa.site_id = v_site_id)
                and (case when (b.user_group_id = 0 or b.user_group_id is null) then 1 else case when 
                    exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb 
                    where aa.id = bb.group_id and aa.state = '2' and b.user_group_id = aa.id AND (bb.ACTIVITY_ID = a.id OR bb.ACTIVITY_ID = 0)
                    and  bb.user_id = c_user_name) then 1 else 0 end end
                ) = 1;
                --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
                v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;
               /****************
               获取商品的基础报价信息
               1、查询商品是否设置了阶梯价格，如果未设置，则仍然使用sku中的报价
               2、查询商品的买断价格
               **********************/
               /****
               如果当前用户购买了全部商品，还需要计算是否设置了买断价
               如果设置了买断价，则按照买断价下单
               没有设置买断价，则还是按照截图价格下单
               **/
               if v_buy_out_flag = 2 then
                   ---查询是否设置了阶梯价格
                   select count(1) into v_temp_count from 
                   tbl_activity_product_specprize  aps
                   where 
                   exists (
                        select 1 from tbl_activity_product ap 
                        where 
                        aps.activity_product_id = ap.id
                        and ap.activity_start_date<=sysdate
                        and ap.activity_end_date >sysdate
                        and ap.product_itemnumber = v_product_itemnumber
                   )
                   and exists (
                        select 1 from tbl_activity_info ai
                        where 
                        aps.activity_id = ai.id
                        and ai.begin_date<=sysdate 
                        and ai.end_date > sysdate
                        and ai.activity_type = '5'
                   )
                   and activity_id = c_activity_id
                   and min_count  = -1;
                   --已设置阶梯价，则需要按照阶梯价进行计算价格
                   if v_temp_count > 0 then
                        --查询当前买断价格
                         select min(prize)  into v_tiered_pricing from 
                         tbl_activity_product_specprize aps 
                         where 
                         exists (
                                select 1 from tbl_activity_product ap 
                                where 
                                aps.activity_product_id = ap.id
                                and ap.activity_start_date<=sysdate
                                and ap.activity_end_date >sysdate
                         )
                         and activity_id = c_activity_id
                         and product_itemnumber = v_product_itemnumber
                         and product_spec = v_product_specs
                         and min_count =-1;
                         --以买断价格就按各个报价
                   else
                        ---没有设置买断价格，还是认为是未买断
                        v_buy_out_flag := 1;
                   end if;
               end if;
               ---如果非买断，查询是否设置了阶梯价格
               if v_buy_out_flag=1 then
                   select count(1) into v_temp_count from 
                   tbl_activity_product_specprize  aps
                   where 
                   exists (
                           select 1 
                            from tbl_activity_info ai 
                            inner join tbl_activity_product ap on ap.activity_id = ai.id
                            where  
                            ap.activity_start_date <= sysdate
                            and ap.activity_end_date > sysdate
                            and ap.product_itemnumber = v_product_itemnumber
                            and ai.state = 2
                            and ai.is_delete = '1'
                            and exists (select 1 from tbl_activity_site tas where tas.activity_id = ai.id and tas.site_id = v_site_id)
                            and aps.activity_id = ai.id
                   )
                   and exists (
                        select * from tbl_activity_product ap 
                        where 
                        aps.activity_product_id = ap.id
                        and ap.activity_start_date<=sysdate
                        and ap.activity_end_date >sysdate
                   )
                   and activity_id = c_activity_id
                   and product_itemnumber = v_product_itemnumber
                   and product_spec = v_product_specs
                   and min_count >0
                   and min_count <= c_product_count;
                   --已设置阶梯价，则需要按照阶梯价进行计算价格
                   if v_temp_count > 0 then
                           --查询当前阶梯的报价信息
                           select prize into v_tiered_pricing
                           from tbl_activity_product_specprize aps
                           where 
                           exists (
                                select 1 from tbl_activity_product ap 
                                where 
                                aps.activity_product_id = ap.id
                                and ap.activity_start_date<=sysdate
                                and ap.activity_end_date >sysdate
                           )
                           and activity_id = c_activity_id
                           and product_itemnumber = v_product_itemnumber
                           and product_spec = v_product_specs
                           and min_count = (
                                 select max(min_count) from 
                                 tbl_activity_product_specprize taps
                                 where 
                                 activity_id = c_activity_id
                                 and product_itemnumber = v_product_itemnumber
                                 and product_spec = v_product_specs
                                 and exists (
                                        select 1 from tbl_activity_product ap 
                                        where 
                                        taps.activity_product_id = ap.id
                                        and ap.activity_start_date<=sysdate
                                        and ap.activity_end_date >sysdate
                                 )
                                 and min_count >0
                                 and min_count <= c_product_count
                           );
                   end if;
               end if;
               --查询站点折扣
               select nvl(min(discount),1) into v_site_discount from tbl_site_info  where id = v_site_id;
                --将活动的会员服务费折扣与 （阶梯价/原报价）的比值进行比较，取较小值
               v_hd_discount:= least(v_hd_discount,(v_tiered_pricing/v_product_prize_cost));
               v_hdhy_discount:= least(v_hdhy_discount,v_hd_discount);
               --获取 会员折扣 或  站点折扣  中最低的
               v_hyfwf_discount:= least(v_hy_discount,v_site_discount,v_hdhy_discount);
               ---按照公式计算出阶梯价售价
               --1、商品阶梯应销售价 = 商品阶梯报价 / (1-入驻商服务费比例 - 入驻商会员区域服务费比例)
               v_tp_sale_prize:= v_product_prize_cost / (1-v_member_service_rate);
               --2、（商品阶梯）计算入驻商会员服务费 = 应销售价*入驻商会员服务费比例
               v_tp_member_service_money_rzs := v_tp_sale_prize * v_member_service_rate_rzs;
               --3、（商品阶梯）计算全局会员服务费 = 应销售价*全局会员服务费比例
               v_tp_member_service_money_qj := v_tp_sale_prize * v_member_service_rate_qj;
               --4、（商品阶梯）销售价格 = 商档报价 + 入驻商会员服务费*活动折扣 + (会员区域服务费 * least(会员折扣,站点折扣,活动会员服务费折扣,阶梯价与原价的比值))
               v_tp_product_prize := v_tiered_pricing + (v_tp_member_service_money_rzs*v_hd_discount ) + (v_tp_member_service_money_qj*v_hyfwf_discount);
               /*
               dbms_output.put_line('========================清尾计算-开始======================================');
               dbms_output.put_line('清尾--区域服务费===='||v_tp_member_service_money_qj);
               dbms_output.put_line('清尾--入驻商会员服务费===='||v_tp_member_service_money_rzs);
               dbms_output.put_line('清尾--报价===='||v_tiered_pricing);
               dbms_output.put_line('清尾------应售价---'||v_tp_sale_prize);
               dbms_output.put_line('清尾--清尾价：'||v_tp_product_prize);
               dbms_output.put_line('清尾--活动折扣：'||v_hdhy_discount);
               dbms_output.put_line('清尾--服务费折扣：'||v_hyfwf_discount);
               dbms_output.put_line('清尾--服务费率-区域：'||v_member_service_rate_qj);
               dbms_output.put_line('清尾--服务费率-会员：'||v_member_service_rate_rzs);
               dbms_output.put_line('========================清尾计算-结束======================================');
                */
               if ceil(v_tp_product_prize)-v_tp_product_prize<0.5 then
                  v_tp_product_prize := ceil(v_tp_product_prize);
               elsif ceil(v_tp_product_prize)-v_tp_product_prize=0 then
                  v_tp_product_prize := v_tp_product_prize;
               else 
                  v_tp_product_prize := ceil(v_tp_product_prize)-0.5;
               end if;
          end if;
    end if;
   /***
   * 通过函数再次计算非阶梯的价格，两个价格进行比较，取较低的值作为最终售价
   ***/
   v_product_prize:=getsku_user_saleprice(c_user_name,c_product_sku_id);
   --如果计算的阶梯价格为空，表示无阶梯价格，仍然使用原价
   if v_tp_product_prize=0 then
        v_tp_product_prize:=v_product_prize;
   else
        v_tp_product_prize:= least(v_product_prize,v_tp_product_prize);
   end if;
   return v_tp_product_prize;
end get_byout_saleprice;
/

