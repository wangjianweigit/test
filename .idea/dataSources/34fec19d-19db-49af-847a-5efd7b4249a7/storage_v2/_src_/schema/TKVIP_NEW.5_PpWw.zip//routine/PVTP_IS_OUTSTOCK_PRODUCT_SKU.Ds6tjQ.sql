create FUNCTION PVTP_IS_OUTSTOCK_PRODUCT_SKU
/**
    判断私有站商品是否可以缺货订购
    reid 2019.09.19 
    返回值：0非缺货订购商品 ；1:是缺货订购商品
**/
(
    c_stationed_user_id     number,                 --当前访问的私有平台ID（即平台所属私有商家的ID）
    c_user_name             varchar2,               --用户名
    c_product_itemnumber    varchar2,               --商品货号
    c_product_sku           number,                 --商品SKU ID
    c_warehouse_id          number:=0               --仓库ID（小仓ID,为0表示不限制仓库）
) return varchar2
 is
     v_temp_count number:=0;                               --临时变量
     v_site_id number:=0;                                  --客户站点ID
     v_is_outstock number:=0;                              --商品类型  0非缺货订购商品 ；1:是缺货订购商品
     v_activity_type number:=0;                            --活动类型 1.限时折扣;3:私有平台活动
BEGIN
    --获取会员信息
   select nvl(min(site_id),0)
   into v_site_id
   from tbl_user_info where user_name = c_user_name;
   ---会员不存在，直接返回空
   IF v_site_id=0 THEN 
        RETURN 0;
   END IF;
   ----判断商品是私有商品还是童库分享得商品
   select count(1) into v_temp_count from TBL_PVTP_PRODUCT_INFO ppi where ppi.stationed_user_id = c_stationed_user_id
   and exists (select 1 from TBL_PVTP_PRODUCT_SKU pps where pps.product_id = ppi.id and pps.id = c_product_sku);
   IF v_temp_count<>0 THEN
        SELECT 
            (case when sum(
                case when (
                    select default_outstock_warehouse 
                    from TBL_STATIONED_USER_INFO sui
                    INNER JOIN  TBL_PVTP_PRODUCT_INFO pi on pi.stationed_user_id = sui.id
                    WHERE pi.itemnumber =  c_product_itemnumber
                    and pi.stationed_user_id = c_stationed_user_id
                ) = decode(c_warehouse_id,0,sw.warehouse_id,c_warehouse_id) 
                and (select is_outstock from TBL_PVTP_PRODUCT_SKU where id = c_product_sku)=1 then
                1 else 0 end
            )>0 then 1 else 0 end) is_outstock into v_is_outstock
     FROM TBL_SITE_WAREHOUSE sw
     WHERE sw.site_id = v_site_id;
   ELSE
      -----------------------童库商品
      /**************
    查询当前用户对于该商品是否存在可以缺货订购的仓
    只有满足一下条件，才允许缺货订购
    1、当前商品在当前仓库可以缺货订购
    2、当前SKU支持缺货订购
    *******************/
    SELECT 
            (case when sum(
                case when (
                    select default_outstock_warehouse 
                    from TBL_STATIONED_USER_INFO sui
                    INNER JOIN  TBL_PRODUCT_INFO pi on pi.stationed_user_id = sui.id
                    INNER JOIN TBL_PVTP_PRODUCT_INFO_REF pir on pi.id = pir.product_id
                    WHERE
                    pi.is_private = 1
                    and pir.enabled_flag = 1
                    and pi.itemnumber =  c_product_itemnumber
                    and pir.platform_id = c_stationed_user_id
                ) = decode(c_warehouse_id,0,sw.warehouse_id,c_warehouse_id) 
                and (select is_outstock from tbl_product_sku where id = c_product_sku)=1 then
                1 else 0 end
            )>0 then 1 else 0 end) is_outstock into v_is_outstock
     FROM TBL_SITE_WAREHOUSE sw
     WHERE sw.site_id = v_site_id;
   END IF;
   return v_is_outstock;
END PVTP_IS_OUTSTOCK_PRODUCT_SKU;
/

