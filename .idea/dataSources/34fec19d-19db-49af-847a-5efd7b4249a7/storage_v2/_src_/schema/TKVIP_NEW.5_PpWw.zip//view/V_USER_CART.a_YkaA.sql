create view V_USER_CART as
select id,user_name,product_sku_id,count,create_date,warehouse_id,activity_id,cart_type from (
select id,user_name,PRODUCT_SKU_ID,COUNT,CREATE_DATE,WAREHOUSE_ID,0 ACTIVITY_ID,1 cart_type from TBL_USER_CART
union all
select id,to_char(user_id) user_name,PRODUCT_SKU PRODUCT_SKU_ID,COUNT,CREATE_DATE,2 WAREHOUSE_ID,ACTIVITY_ID,2 cart_type from TBL_PRE_USER_CART)
/

