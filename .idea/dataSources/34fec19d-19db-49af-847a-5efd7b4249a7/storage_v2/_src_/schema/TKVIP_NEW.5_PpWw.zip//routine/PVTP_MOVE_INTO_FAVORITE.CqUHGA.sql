create PROCEDURE pvtp_move_into_favorite
/**
     私有平台-移入收藏夹
     20190911 yejingquan
     20170307 新增清空指定仓库购物车商品数据处理  shif

     返回值：移入收藏夹成功或移入收藏失败消息
  **/
(
 client_user_name   IN VARCHAR2, --用户名
 client_stationed_user_id IN  NUMBER,  --入驻商ID
 client_itemnumber IN VARCHAR2, --商品货号拼接字符串，逗号分隔
 client_warehouse_id IN NUMBER, --商品货号对应仓库
 output_status      OUT VARCHAR2, --返回的状态码 0-取消失败 1-取消成功
 output_msg         OUT VARCHAR2 --返回的信息
 ) IS
  temp_itemnumber_count                   INT := 0; --临时变量（货号数量）
  temp_count                  INT := 0; --临时变量（校验是否已加入收藏夹）
  temp_collect_product_price   VARCHAR2(50); --收藏商品价格
  temp_collect_product_name    VARCHAR2(300); --收藏商品名字
  temp_collect_product_img_url VARCHAR2(200); --收藏商品图片路径
 v_source_type varchar2(10):='1';
BEGIN
  output_status := '0';
  output_msg    := '移入收藏夹失败！';
  SELECT COUNT(*)
    INTO temp_count
    FROM tbl_user_info
   WHERE user_name = client_user_name;
  IF temp_count = 0 THEN
    output_msg := '用户信息不能为空，请检查！';
    RETURN;
  END IF;
  
  SELECT COUNT(*)
    INTO temp_itemnumber_count
    FROM (
    SELECT a.itemnumber
      FROM tbl_product_info a inner join tbl_pvtp_product_info_ref b on a.id = b.product_id
     WHERE b.platform_id = client_stationed_user_id
       and a.itemnumber = client_itemnumber
       and a.is_private = 1
       and b.enabled_flag = 1
    UNION ALL
    SELECT itemnumber
      FROM tbl_pvtp_product_info 
     WHERE stationed_user_id = client_stationed_user_id
       AND itemnumber = client_itemnumber);

  IF temp_itemnumber_count = 0 THEN
    output_msg := '商品信息不存在，请检查！';
    RETURN;
  END IF;
  
  --查询商品是否已经收藏
  SELECT COUNT(1) INTO temp_count FROM tbl_user_collection WHERE user_name = client_user_name AND itemnumber = client_itemnumber; 
  ---已经收藏，则仅仅更新收藏时间
  IF temp_count <> 0 THEN
       --清除购物车相应的记录
       DELETE FROM tbl_user_cart t
       WHERE t.user_name = client_user_name
             and t.warehouse_id = client_warehouse_id
             AND EXISTS (SELECT 1 FROM tbl_product_sku s
                WHERE s.product_itemnumber = client_itemnumber
                AND s.id = t.product_sku_id);
    --reid 2019.05.16 已存在则仅更新收藏时间
    UPDATE TBL_USER_COLLECTION SET create_date = SYSDATE WHERE user_name = client_user_name and itemnumber = client_itemnumber;
  ELSE
          --获取商品价格
          temp_collect_product_price:=pvtp_getProduct_SalePrice_Min(client_stationed_user_id, client_user_name, client_itemnumber);  
          ----判断商品是私有商品还是童库分享得商品
          select count(1) into temp_itemnumber_count from tbl_pvtp_product_info ppi where ppi.stationed_user_id = client_stationed_user_id and ppi.itemnumber = client_itemnumber;
          IF temp_itemnumber_count <> 0 THEN
            --获取商品名称，主图片路径
            SELECT product_name, product_img_url INTO temp_collect_product_name, temp_collect_product_img_url 
              FROM tbl_pvtp_product_info 
             WHERE stationed_user_id = client_stationed_user_id
               AND itemnumber = client_itemnumber;
          ELSE
            --获取商品名称，主图片路径
            SELECT b.product_name, a.product_img_url INTO temp_collect_product_name, temp_collect_product_img_url 
              FROM tbl_product_info a inner join tbl_pvtp_product_info_ref b on a.id = b.product_id
             WHERE b.platform_id = client_stationed_user_id
               and a.itemnumber = client_itemnumber
               and a.is_private = 1
               and b.enabled_flag = 1;
          END IF;
      --插入我的收藏
      INSERT INTO TBL_USER_COLLECTION (id, user_name, product_name, product_price, product_img_url, itemnumber, create_date, platform_id)
      VALUES (seq_user_collection.NEXTVAL, client_user_name, temp_collect_product_name, temp_collect_product_price, temp_collect_product_img_url, client_itemnumber, SYSDATE, client_stationed_user_id);
  END IF;
  --清除购物车相应的记录
  DELETE FROM tbl_user_cart t
    WHERE t.user_name = client_user_name and t.warehouse_id = client_warehouse_id 
      AND EXISTS (SELECT 1 FROM tbl_product_sku s WHERE s.product_itemnumber = client_itemnumber AND s.id = t.product_sku_id);

  output_status := '1';
  output_msg    := '移入收藏夹成功！';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    output_msg := '移入收藏夹时出现未知错误！';
    ROLLBACK;
END pvtp_move_into_favorite;
----2.2 添加浏览商品记录
/

