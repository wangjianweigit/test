create PROCEDURE           pro_readjust_order_arr_private
/**
    私有平台订单调价【支持批量】
    wanghai 2018-12-25 包含清分规则更新
    zhengfy 2019-09-23 私有平台对接，表调整
    返回值：订单提交结果消息
**/
(
        client_order_number in varchar2,            --订单编号
        client_order_product_sku_list in     T_ORDER_PRODUCT_SKU_LST,   --订单sku列表
        client_logistics_company_code in varchar2,  --物流公司代码
        client_logistics_money number:=0,           --物流费用
        client_update_reason in varchar2,           --调价原因
        client_df_money in number:=0,               --代发费用
        output_status  out varchar2,                --返回的状态码 0-失败 1-成功
        output_msg out varchar2                     --返回的信息
) AS
    v_logistics_company_name varchar2(50);      --物流公司名称
    v_order_product_sku       T_ORDER_PRODUCT_SKU;   --订单商品sku对象
    v_temp_count int:=0;                        --临时变量 计数
    v_order_state int:=0;                       --订单总状态
    v_payment_state int:=0;                     --订单付款状态
    v_order_type varchar2(50);                  --订单类型
    v_df_money number:=0;                       --临时变量  代发费用
    v_platform_money number:=0;                 --会员服务费
    v_sku_discount_money number:=0;             --单个SKU调的价格
    v_service_pay_charges number:=0;            --支付服务费比例
    v_service_charges number:=0;                --入驻商服务费比例
    v_stationed_money number:=0;                --入驻商货款
    v_product_type_id number := 0;              --商品类型ID
    v_product_type_type char := '1';            --商品类型类别
    v_storage_charges number:=0;                --仓储服务费
    v_new_product_unit_price number := 0;   --调价后单价
BEGIN
    output_status:='0';

    --校验订单是否存在以及订单状态
    SELECT COUNT(*) INTO v_temp_count FROM TBL_ORDER_INFO WHERE ORDER_NUMBER = client_order_number;
    IF v_temp_count <> 0 THEN
        --获取流程状态，支付状态
        SELECT ORDER_STATE,PAYMENT_STATE,ORDER_TYPE into v_order_state,v_payment_state,v_order_type FROM TBL_ORDER_INFO WHERE ORDER_NUMBER=client_order_number;
        --验证订单状态和支付状态是否为 未支付
        IF v_order_state <> 1 OR v_payment_state <> 1 THEN
            output_msg:='当前订单状态为【'||v_order_state||'】，不支持调价!';
            RETURN;
        END IF;
    ELSE
        output_msg:='订单号码有误，无法调价，请检查!';
        RETURN;
    END IF;

    --查询物流公司名称
    SELECT COUNT(*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE CODE = client_logistics_company_code;
    IF v_temp_count<>0 THEN
        SELECT NAME INTO v_logistics_company_name FROM TBL_LOGISTICS_COMPANY WHERE CODE = client_logistics_company_code;
    ELSE
        output_msg:='物流信息不能为空，请检查!';
        RETURN;
    END IF;

    --数据有效性校验
    IF client_order_product_sku_list.COUNT > 0 THEN
        FOR i IN 1 .. client_order_product_sku_list.COUNT LOOP
            v_order_product_sku :=client_order_product_sku_list(i);
            --校验SKU的有效性
            SELECT COUNT(1) INTO v_temp_count FROM TBL_PVTP_PRODUCT_SKU WHERE id = v_order_product_sku.sku_id;
            IF v_temp_count = 0 THEN
                output_msg:='SKU错误或已下架请检查SKU的有效性!';
                RETURN;
            END IF;

            UPDATE TBL_ORDER_PRODUCT_SKU
            SET PRODUCT_UNIT_PRICE = ROUND(v_order_product_sku.order_new_prize,2),
                PRODUCT_OLD_UNIT_PRICE = v_order_product_sku.order_old_prize,
                PRODUCT_TOTAL_DISCOUNT_MONEY = round(v_order_product_sku.order_discount_money,2),
                PRODUCT_TOTAL_MONEY = ROUND(v_order_product_sku.order_old_prize * COUNT - v_order_product_sku.order_discount_money,2)
        WHERE ORDER_NUMBER = client_order_number AND PRODUCT_SKU = v_order_product_sku.sku_id;
        END LOOP;
    ELSE
      output_msg := '订单商品参数为空，请检查';
      RETURN;
    END IF;

    --修改订单规格表的单价
    UPDATE TBL_ORDER_PRODUCT ECL SET ECL.PRODUCT_UNIT_PRICE=
       (SELECT ECD.PRODUCT_UNIT_PRICE FROM TBL_ORDER_PRODUCT_SKU ECD
            WHERE ECL.USER_NAME=ECD.USER_NAME AND
                  ECL.ORDER_NUMBER=ECD.ORDER_NUMBER AND
                  ECL.ITEMNUMBER=ECD.PRODUCT_ITEMNUMBER AND ECL.PRODUCT_SPECS=ECD.PRODUCT_SPECS AND ECL.PRODUCT_COLOR=ECD.PRODUCT_COLOR AND
                  ECD.ORDER_NUMBER=ECL.ORDER_NUMBER AND ROWNUM<2)
       WHERE ECL.ORDER_NUMBER = client_order_number;

    --计算商品优惠价格和商品总价
    UPDATE TBL_ORDER_PRODUCT ECL
        SET PRODUCT_TOTAL_DISCOUNT_MONEY=(SELECT ROUND(SUM(ECD.PRODUCT_TOTAL_DISCOUNT_MONEY),2) 
                                            FROM TBL_ORDER_PRODUCT_SKU ECD 
                                           WHERE ECD.ORDER_NUMBER=ECL.ORDER_NUMBER 
                                                 AND ECD.PRODUCT_ITEMNUMBER=ECL.ITEMNUMBER
                                                 AND ECD.PRODUCT_COLOR=ECL.PRODUCT_COLOR
                                                 AND ECD.PRODUCT_SPECS=ECL.PRODUCT_SPECS),
            PRODUCT_TOTAL_MONEY=(SELECT SUM(ECD.PRODUCT_TOTAL_MONEY) 
                                   FROM TBL_ORDER_PRODUCT_SKU ECD 
                                  WHERE ECD.ORDER_NUMBER=ECL.ORDER_NUMBER 
                                        AND ECD.PRODUCT_ITEMNUMBER=ECL.ITEMNUMBER
                                        AND ECD.PRODUCT_COLOR=ECL.PRODUCT_COLOR
                                        AND ECD.PRODUCT_SPECS=ECL.PRODUCT_SPECS)
        WHERE ECL.ORDER_NUMBER=client_order_number;
     IF v_order_type='代发' THEN
        v_df_money:=client_df_money;
     ELSE
        v_df_money:=0;
     END IF;
     UPDATE TBL_ORDER_INFO ECH
        SET PRODUCT_MONEY=(SELECT SUM(ECL.PRODUCT_TOTAL_MONEY) FROM TBL_ORDER_PRODUCT ECL WHERE ECL.ORDER_NUMBER=ECH.ORDER_NUMBER),
            DISCOUNT_MONEY=(SELECT ROUND(SUM(ECL.PRODUCT_TOTAL_DISCOUNT_MONEY),2) FROM TBL_ORDER_PRODUCT ECL WHERE ECL.ORDER_NUMBER=ECH.ORDER_NUMBER),
            LOGISTICS_COMPANY_CODE = client_logistics_company_code,
            LOGISTICS_COMPANY_NAME = v_logistics_company_name,
            LOGISTICS_MONEY = client_logistics_money,
            UPDATE_REASON = client_update_reason,
            DF_MONEY=v_df_money
        WHERE ECH.ORDER_NUMBER = client_order_number;
        
     --查询待修改商品数量
     select count(*) into v_temp_count
        from tbl_order_product_sku where PRODUCT_UNIT_PRICE <> PRODUCT_OLD_UNIT_PRICE 
        and order_number = client_order_number;
     
    IF v_temp_count > 0 THEN
        --更新清分规则
        --查询订单商品列表
        declare cursor order_sku is 
        select order_number,product_sku,PRODUCT_UNIT_PRICE,PRODUCT_TOTAL_MONEY,PRODUCT_OLD_UNIT_PRICE,COUNT 
        from tbl_order_product_sku where PRODUCT_UNIT_PRICE <> PRODUCT_OLD_UNIT_PRICE 
        and order_number = client_order_number;
        
        --循环处理调价商品的清分规则
        begin
            for c_row in order_sku
            loop 
            
                --调价后单价
                v_new_product_unit_price := round(c_row.PRODUCT_TOTAL_MONEY / c_row.COUNT, 5);
                --调价单价
                v_sku_discount_money := c_row.PRODUCT_OLD_UNIT_PRICE - v_new_product_unit_price;
                --获取会员服务费
                SELECT divide_money INTO v_platform_money FROM TBL_ORDER_DIVIDE_RECORD WHERE divide_type = 2 and order_number = c_row.order_number and product_sku = c_row.product_sku;
                
                --获取商品类型ID
                select PRODUCT_TYPE_ID into v_product_type_id from tbl_pvtp_product_info where ITEMNUMBER = (select PRODUCT_ITEMNUMBER from tbl_pvtp_product_sku where id = c_row.product_sku);
                   
                --获取商品类型的类别
                select type into v_product_type_type from TBL_DIC_PRODUCT_TYPE where id = v_product_type_id;
                   
                --查询SKU仓储费
                if v_product_type_type = '1' then
                   select nvl(max(storage_charges),0) into v_storage_charges from tbl_pvtp_stat_storage_charges ssc,tbl_pvtp_product_sku ps 
                   where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size(+) = ps.product_group_member and ps.id = c_row.product_sku and type = v_product_type_type;
                else
                   select nvl(max(storage_charges),0) into v_storage_charges from tbl_pvtp_stat_storage_charges ssc,tbl_pvtp_product_sku ps 
                   where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size = v_product_type_id and ps.id = c_row.product_sku and type = v_product_type_type;
                end if;
                
                --查询支付服务费比例,入驻商服务费比例
                select nvl(pay_service_rate,0),nvl(service_charges,0) into v_service_pay_charges,v_service_charges from TBL_STATIONED_USER_INFO where id = (
                    select STATIONED_USER_ID from tbl_pvtp_product_sku where id = c_row.product_sku
                );
                
                if v_sku_discount_money < 0 then
                    v_stationed_money := v_new_product_unit_price - v_platform_money;
                elsif v_sku_discount_money >= v_platform_money then
                    v_stationed_money := v_new_product_unit_price;
                    v_platform_money := 0;
                else
                    v_stationed_money := v_new_product_unit_price - (v_platform_money - v_sku_discount_money);
                    v_platform_money := v_platform_money - v_sku_discount_money;
                end if;
                
                if v_storage_charges >= v_stationed_money then
                    v_storage_charges := 0;
                end if;
                
                --更新入驻商货款
                update TBL_ORDER_DIVIDE_RECORD set divide_money = v_stationed_money - trunc(v_stationed_money*v_service_charges,2) - trunc(v_stationed_money*v_service_pay_charges,2) - v_storage_charges WHERE divide_type = 1 and order_number = c_row.order_number and product_sku = c_row.product_sku;
                --更新会员服务费
                update TBL_ORDER_DIVIDE_RECORD set divide_money = v_platform_money WHERE divide_type = 2 and order_number = c_row.order_number and product_sku = c_row.product_sku;
                --更新仓储费
                update TBL_ORDER_DIVIDE_RECORD set divide_money = v_storage_charges WHERE divide_type = 3 and order_number = c_row.order_number and product_sku = c_row.product_sku;
                --更新入驻商服务费
                update TBL_ORDER_DIVIDE_RECORD set divide_money = trunc(v_stationed_money*v_service_charges,2) WHERE divide_type = 4 and order_number = c_row.order_number and product_sku = c_row.product_sku;
                --更新支付服务费
                update TBL_ORDER_DIVIDE_RECORD set divide_money = trunc(v_stationed_money*v_service_pay_charges,2) WHERE divide_type = 5 and order_number = c_row.order_number and product_sku = c_row.product_sku;
            
            end loop;
        end;
     end if;
      
     output_status:='1';
     output_msg:='订单调价执行成功';
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='订单调价出现未知错误';
    ROLLBACK;
END pro_readjust_order_arr_private;
/

