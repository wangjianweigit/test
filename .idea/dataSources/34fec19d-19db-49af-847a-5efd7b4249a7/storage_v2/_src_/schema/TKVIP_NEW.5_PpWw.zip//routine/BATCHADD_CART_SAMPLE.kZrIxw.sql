create PROCEDURE           batchadd_cart_sample
/**
     批量加入购物车，购物车已添加过时，不做添加
     yejingquan 20180404【样品】
      返回值：加入购物车结果消息
  **/
(client_user_name        in varchar2, --用户名
 client_order_sku_ids    in varchar2, --商品SKU集合  使用逗号分隔
 client_order_sku_counts in varchar2, --商品SKU数量  使用逗号分隔
 client_sku_warehouse_ids in varchar2, --商品SKU所在仓库  使用逗号分隔
 client_order_colors     in varchar2,--商品颜色 使用逗号分隔
 output_status           out varchar2, --返回的状态码 0-失败 1-成功
 output_msg              out varchar2 --返回的信息
 ) IS
  
  v_count            int := 0; --临时变量
  v_sku_count        int := 0; --商品SKU数组个数
  v_sku_counts_count int := 0; --商品SKU数量数组个数
  v_sku_warehouse_count int := 0; --商品SKU数组 仓库个数
  v_color_count      int :=0; --商品颜色数组个数
  v_temp_count       int := 0; --临时变量，校验SKU合法性用
  temp_count         int := 1; --临时变量 循环计数用
  temp_sku_id        number := 0; --临时变量  待添加商品SKUID
  temp_sku_count     number := 0; --临时变量 待添加商品SKU数量
  temp_sku_warehouse_id        number := 0; --临时变量  待添加商品SKU仓库id
  temp_color         varchar2(20);
  
BEGIN
  output_status:='0';
  --商品SKU数量有效性校验
  v_sku_count        := length(replace(client_order_sku_ids, ',', ',-')) - length(client_order_sku_ids) + 1;
  v_sku_counts_count := length(replace(client_order_sku_counts, ',', ',-')) -length(client_order_sku_counts) + 1;
  v_sku_warehouse_count := length(replace(client_sku_warehouse_ids, ',', ',-')) -length(client_sku_warehouse_ids) + 1;
  v_color_count := length(replace(client_order_colors, ',', ',-')) - length(client_order_colors) + 1;
  if v_sku_count <> v_sku_counts_count or v_sku_count <> v_sku_warehouse_count or v_sku_count <> v_color_count then
    output_msg := '商品个数或数量个数不符!';
    return;
  end if;
  --商品SKU有效性校验
  select v_sku_count - count(*)
    into v_temp_count
    from tbl_product_sku a,
         (select substr(t, 1, instr(t, ',', 1) - 1) skuid_str
            from (select substr(s, instr(s, ',', 1, rownum) + 1) as t,
                         rownum as d,
                         instr(s, ',', 1, rownum) + 1
                    from (select ',' || client_order_sku_ids || ',' as s from dual)
                  connect by instr(s, ',', '1', rownum) > 1)
           where t is not null) b
   where a.id = b.skuid_str;
  if v_temp_count <> 0 then
    output_msg := 'SKU错误或已下架请检查SKU的有效性!';
    return;
  end if;
  --循环插入购物车表
  temp_count := 1;
  while temp_count <= v_sku_count loop
    temp_sku_id    := getstrforarrid(',' || client_order_sku_ids || ',',
                                     ',',
                                     temp_count);
    temp_sku_count := getstrforarrid(',' || client_order_sku_counts || ',',
                                     ',',
                                     temp_count);
    temp_sku_warehouse_id := getstrforarrid(',' || client_sku_warehouse_ids || ',',
                                     ',',
                                     temp_count);
    temp_color := getStrforArrid_str(',' || client_order_colors || ',',
                                     ',',
                                     temp_count);
    --
    if temp_sku_count > 1 then
        output_msg :='加入购物车商品数量超出限额！';
        return;
    end if;
    --在添加购物车前判断购物车中是否已添加相应商品，如有，则跳过
    select count(1)
      into v_count
      from tbl_sample_user_cart
     where user_id = client_user_name
       and product_sku_id in (select id from tbl_product_sku where product_itemnumber = (select product_itemnumber from tbl_product_sku where id =temp_sku_id) and product_color = temp_color)
       and warehouse_id = temp_sku_warehouse_id
       and product_color = temp_color;
    if (v_count = 0) then
        insert into tbl_sample_user_cart
          (id, user_id, product_sku_id, count,CREATE_DATE,warehouse_id,product_color)
        values
          (seq_sample_user_cart.nextval,
           client_user_name,
           temp_sku_id,
           temp_sku_count,
           sysdate,
           temp_sku_warehouse_id,
           temp_color);
    else
         output_msg := '同商品一种颜色只能添加一次尺码，请重新选择！';
         return;
    end if;
    temp_count       := temp_count + 1;
    v_count := 0;
  end loop;
  output_status:='1';
  output_msg := '加入购物车成功';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    output_msg := '加入购物车出现未知错误';
    ROLLBACK;
END batchadd_cart_sample;
/

