create TYPE           T_CUSTOM_PRODUCT                                                                                                                                                        as object
(
    brand_name VARCHAR2 (100 Byte),  --品牌名称
    brand_logo VARCHAR2 (200 Byte),  --品牌LOGO图片地址
    insole_flag NUMBER,              --鞋垫LOGO是否自定义； 1:默认    2:自定义
    tongue_flag NUMBER,              --鞋舌标LOGO是否自定义； 1:默认    2:自定义
    tongue_logo VARCHAR2 (200 Byte), --鞋舌标LOGO图片地址
    insole_logo VARCHAR2 (200 Byte), --鞋垫LOGO图片地址
    box_supply_flag NUMBER,          --鞋盒是否自行提供 ； 1:默认    2:自行提供
    box_supply_contact_name VARCHAR2 (50 Byte), --鞋盒供应联系人名称
    box_supply_contact_phonenumber VARCHAR2 (50 Byte), --鞋盒供应联系人电话
    bag_supply_flag NUMBER,                 --手提袋是否自行提供 ； 1:默认    2:自行提供
    bag_supply_contact_name VARCHAR2 (50 Byte), --手提袋供应联系人名称
    bag_supply_contact_phonenumber VARCHAR2 (50 Byte), --手提袋供应联系人电话
    tag_supply_flag NUMBER,                --吊牌是否自行提供 ； 1:默认    2:自行提供
    tag_supply_contact_name VARCHAR2 (50 Byte), --吊牌供应联系人名称
    tag_supply_contact_phonenumber VARCHAR2 (50 Byte), --吊牌供应联系人电话
    certificate VARCHAR2 (200 Byte), --授权证书图片地址
    registration VARCHAR2 (200 Byte) --注册证图片地址
)
/

