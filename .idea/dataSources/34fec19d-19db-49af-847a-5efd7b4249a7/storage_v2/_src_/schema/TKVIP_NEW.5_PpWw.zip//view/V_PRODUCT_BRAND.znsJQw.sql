create view V_PRODUCT_BRAND as
  SELECT ID,
          BRAND_NAME,
          LOGO,
          INSOLE_LOGO
     FROM TBL_DIC_PRODUCT_BRAND
    WHERE state = '2'
   UNION
   SELECT ID,
          BRAND_NAME,
          LOGO,
          INSOLE_LOGO
     FROM TBL_CUSTOM_PRODUCT_BRAND
   ORDER BY id DESC
/

