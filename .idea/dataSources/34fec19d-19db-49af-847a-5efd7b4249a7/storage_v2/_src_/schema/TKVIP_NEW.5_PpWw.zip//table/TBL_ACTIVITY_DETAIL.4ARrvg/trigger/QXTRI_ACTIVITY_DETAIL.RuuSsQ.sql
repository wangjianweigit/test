create trigger QXTRI_ACTIVITY_DETAIL
  before update
  on TBL_ACTIVITY_DETAIL
  for each row
BEGIN

   IF UPDATING ('TAG_NAME') THEN  
        IF :old.tag_name <> :new.tag_name 
        THEN
            INSERT INTO QXTMP_PRODUCT(ID,LOG_ID,OPERATION_TYPE,CREATE_DATE) 
            select QXSEQ_PRODUCT.NEXTVAL,b.id,2,sysdate 
            from TBL_ACTIVITY_PRODUCT a,TBL_PRODUCT_INFO b where a.PRODUCT_ITEMNUMBER = b.ITEMNUMBER and a.activity_id = :old.ACTIVITY_ID and b.PRODUCT_TYPE in (0,3);
        END IF;
   END IF;
END;
/

