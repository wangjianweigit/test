create PROCEDURE           aaa
/**
    asdffasdfasdfasdafsd
  **/
 is
  temp_count   INT := 0;            --临时变量
  v_order_state INT := 0;           --订单总状态
  v_payment_state INT := 0;         --订单付款状态
  temp_user_realname varchar2(50);  --订单用户姓名
begin

  
   declare cursor return_orders is 
     select return_number from tkerp.TBL_NEW_RETURN_ORDER b where  b.REFUND_DATE >= to_date('20170601','yyyymmdd') and b.STATE = '8';
      begin
            for a_row in return_orders loop
  
  
  insert into temp_temp(return_number,user_id,bank_account,user_name,return_user_id,
            return_bank_account,
            return_user_name,return_amount,remark) 
  select 
            return_number,
            user_id,
            bank_account,
            user_name,
            return_user_id,
            return_bank_account,
            return_user_name,
            return_amount,
            remark
            --operation_type,
            --'2'
        from (
        SELECT
             return_number,
             MIN (user_id) user_id,
             min(bank_account) bank_account,
             min(user_name) user_name,
             return_user_id,
             min(return_bank_account) return_bank_account,
             min(return_user_name) return_user_name,
             round(sum(return_amount),2) return_amount,
             min(remark) remark,
             min(operation_type) operation_type
        FROM (SELECT t.return_number,u.id user_id,b.bank_account,u.user_manage_name user_name,
                     CASE r.divide_type WHEN '1' THEN r.divide_user_id
                        WHEN '2' THEN (SELECT to_number(value) FROM TBL_SYS_PARAM_CONFIG WHERE key = 'platform_user_id')
                        WHEN '3' THEN (SELECT to_number(value) FROM TBL_SYS_PARAM_CONFIG WHERE key = 'storage_user_id')
                        WHEN '4' THEN (SELECT to_number(value) FROM TBL_SYS_PARAM_CONFIG WHERE key = 'platform_user_id')
                        ELSE (SELECT ps.stationed_user_id FROM TBL_PRODUCT_SKU ps WHERE ps.id = t.product_sku)
                     END return_user_id,
                     CASE r.divide_type
                         WHEN '1' THEN (select a.bank_account from tbl_bank_account a where a.user_id = r.divide_user_id and a.user_type = '2')
                        WHEN '2' THEN (SELECT value FROM TBL_SYS_PARAM_CONFIG WHERE key = 'platform_bank_account')
                        WHEN '3' THEN (SELECT value FROM TBL_SYS_PARAM_CONFIG WHERE key = 'storage_bank_account')
                        WHEN '4' THEN (SELECT value FROM TBL_SYS_PARAM_CONFIG WHERE key = 'platform_bank_account')
                        ELSE (select a.bank_account from tbl_bank_account a where a.user_id = (SELECT ps.stationed_user_id FROM TBL_PRODUCT_SKU ps WHERE ps.id = t.product_sku) and a.user_type = '2')
                     END return_bank_account,
                     CASE r.divide_type
                         WHEN '1' THEN (select a.company_name from TBL_STATIONED_USER_INFO a where a.id = r.divide_user_id)
                        WHEN '2' THEN '童库平台服务'
                        WHEN '3' THEN '童库仓储服务'
                        WHEN '4' THEN '童库平台服务'
                        ELSE (select a.company_name from TBL_STATIONED_USER_INFO a where a.id = (SELECT ps.stationed_user_id FROM TBL_PRODUCT_SKU ps WHERE ps.id = t.product_sku))
                     END return_user_name,
                     case when r.divide_type = '2' then t.product_count * (r.divide_money-s.product_total_discount_money/s.count)
                         when r.divide_type = '1' or r.divide_type = '3' or r.divide_type = '4' then t.product_count * r.divide_money
                          else s.product_unit_price * t.product_count end return_amount,
                     CASE r.divide_type
                        WHEN '1' THEN '退货单【'||t.return_number||'】售后退货，入驻商账户退款'
                        WHEN '2' THEN '退货单【'||t.return_number||'】售后退货，平台服务账户退款'
                        WHEN '3' THEN '退货单【'||t.return_number||'】售后退货，仓储服务账户退款'
                        WHEN '4' THEN '退货单【'||t.return_number||'】售后退货，平台服务账户退款'
                        ELSE '退货单【'||t.return_number||'】老订单售后退货，入驻商账户退货款'
                     END remark,
                     '1' operation_type
                FROM (
                
                    
                SELECT npc.return_number,
                         rc.ORDER_NUMBER_PLATFORM order_number,
                         npc.product_sku,
                         COUNT (npc.product_unique_code) product_count
                    FROM tkerp.TBL_NEW_RETURN_DETAIL_CODE rc,
                         tkerp.TBL_NEW_RETURN_CONFIRM npc,
                         tkerp.TBL_NEW_RETURN_ORDER b
                   WHERE     rc.return_NUMBER = npc.return_NUMBER
                         AND rc.PRODUCT_UNIQUE_CODE = npc.product_unique_code
                         AND npc.RETURN_FLAG = '1'
                         AND NPC.RETURN_NUMBER = B.RETURN_NUMBER
                         AND b.STATE = '8'
                         AND b.return_number = a_row.return_number
                GROUP BY npc.return_number, rc.ORDER_NUMBER_PLATFORM, NPC.PRODUCT_SKU
                
                
                
                
                ) t,
                     TBL_ORDER_DIVIDE_RECORD r,
                     tbl_order_info o,
                     tbl_order_product_sku s,
                     tbl_user_info u,
                     tbl_bank_account b
               WHERE     t.order_number = r.order_number(+)
                     AND t.product_sku = r.product_sku(+)
                     AND t.order_number = o.order_number
                     and t.order_number = s.order_number
                     and t.product_sku = s.product_sku
                     AND o.user_name = u.user_name
                     AND u.id = b.user_id)
        GROUP BY return_user_id,return_user_name,return_number);
  
    end loop;
  end;
  
  
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END aaa;
/

