create FUNCTION           GETDISTANCE_song
/**
    计算两个地图坐标的直线距离
    songwangwen 2017.07.07                                          
**/
(lat1 number,                       --起点经度值
lng1 number,                        --起点维度值
lat2 number,                        --终点经度值
lng2 number                         --终点维度值
) RETURN NUMBER is     ---返回值，两个坐标点的距离（单位米）
  earth_padius number := 6371;--地球赤道半径 6378.137
  radLat1      number := rad(lat1);
  radLat2      number := rad(lat2);
  a            number := radLat1 - radLat2;
  b            number := rad(lng1) - rad(lng2);
  s            number := 0;
begin
  s := 2 *
       Asin(Sqrt(power(sin(a / 2), 2) +
                 cos(radLat1) * cos(radLat2) * power(sin(b / 2), 2)));
  s := s * earth_padius;
  s := Round(s * 10000) / 10;
  return s;
end;
/

