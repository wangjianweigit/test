create PROCEDURE pro_adjust_credit_money
/**
   用户授信额度调整
     shifan
    返回值：调整成功或调整失败消息
  **/
(client_credit_user_name        IN VARCHAR2, --待调整授信额度用户名
 client_new_credit_money_number IN NUMBER, --新的授信金额
 output_status                  OUT VARCHAR2, --返回的状态码 0-失败 1-成功
 output_msg                     OUT VARCHAR2 --返回的信息
 ) IS
  temp_account_balance           NUMBER := 0; --账号余额
  temp_credit_money_balance      NUMBER := 0; --授信剩余额度
  temp_credit_money_use          NUMBER := 0; --授信已使用额度
  temp_account_balance_checkcode VARCHAR2(500); --余额校验码
  temp_credit_checkcode          VARCHAR2(500); --授信校验码
  temp_user_id                   NUMBER := 0; --用户id
  temp_count                     NUMBER := 0; --临时变量
  temp_create_code               VARCHAR2(32); --计算的校验码
  temp_user_key                  VARCHAR2(32); --用户key
  new_credit_money_balance       NUMBER := 0; --授信剩余额度
BEGIN
  output_status := '0';
  --1.验证需要调整授信额度的相关用户、账号信息
  output_msg := '授信额度调整失败！';
  --1.1获取充值加盟商用户信息
  IF client_new_credit_money_number IS NULL OR client_new_credit_money_number < 0 THEN
    output_msg := '参数错误！';
    RETURN;
  END IF;
  SELECT COUNT(*)
    INTO temp_count
    FROM tbl_user_info
   WHERE user_name = client_credit_user_name;
  IF temp_count <> 0 THEN
    SELECT id
      INTO temp_user_id
      FROM tbl_user_info
     WHERE user_name = client_credit_user_name;
  ELSE
    output_msg := '用户信息不能为空，请检查！';
    RETURN;
  END IF;
  --1.2获取账户信息
  SELECT COUNT(*)
    INTO temp_count
    FROM tbl_bank_account
   WHERE user_id = temp_user_id;
  IF temp_count <> 0 THEN
    SELECT nvl(account_balance, 0), nvl(credit_money_balance, 0), nvl(credit_money_use, 0), account_balance_checkcode, credit_checkcode
      INTO temp_account_balance, temp_credit_money_balance, temp_credit_money_use, temp_account_balance_checkcode, temp_credit_checkcode
      FROM tbl_bank_account
     WHERE user_id = temp_user_id;
  ELSE
    output_msg := '用户账户信息不能为空，请检查！';
    RETURN;
  END IF;
  --1.3验证余额是否被篡改-----------------------------------------------------------------------------------------------------------------------
  --获取用户key
  SELECT getuserkey(client_credit_user_name, 'old','1')
    INTO temp_user_key
    FROM dual;
  --1.4获取余额校验码并判断是否被篡改
  temp_create_code := getcheck_code(client_credit_user_name, temp_account_balance, temp_user_key);
  --dbms_output.put_line('比对余额校验码=========' || temp_account_balance_checkcode || '-------' || temp_create_code);
  IF temp_account_balance_checkcode IS NULL OR
     temp_account_balance_checkcode <> temp_create_code THEN
    output_msg := '余额发生篡改，无法完成当前操作！';
    RETURN;
  END IF;
  --1.5验证授信是否被篡改-----------------------------------------------------------------------------------------------------------------------
  --获取授信校验码并判断是否被篡改
  temp_create_code := getcheck_code(client_credit_user_name, temp_credit_money_balance, temp_user_key);
  --dbms_output.put_line('比对授信校验码=========' || temp_credit_checkcode ||'-------' || temp_create_code);
  IF temp_credit_checkcode IS NULL OR
     temp_credit_checkcode <> temp_create_code THEN
    output_msg := '授信余额发生篡改，无法完成当前操作！';
    RETURN;
  END IF;
  --2.调整授信额度
  new_credit_money_balance := client_new_credit_money_number -temp_credit_money_use;
  --2.1更新用户帐户表
  UPDATE tbl_bank_account
     SET credit_money_balance = new_credit_money_balance, credit_money = client_new_credit_money_number
   WHERE user_id = temp_user_id;
  --2.2更新用户账户校验码
  PRO_UPDATE_USER_ACCOUNT_CODE(client_credit_user_name);

  output_status := '1';
  output_msg    := '授信额度调整成功！';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    output_msg := '授信额度调整出现未知错误！';
    ROLLBACK;
    RETURN;
END pro_adjust_credit_money;
/

