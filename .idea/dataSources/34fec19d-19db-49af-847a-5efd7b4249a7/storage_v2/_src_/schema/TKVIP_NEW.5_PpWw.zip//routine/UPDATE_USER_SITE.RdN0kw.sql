create PROCEDURE           update_user_site
/**
     自动变更用户站点     
     wangpeng
     2017-11-15
  **/
is
  temp_count                   INT := 0; --临时变量
begin

    --ALTER TRIGGER TRI_USER_INFO DISABLE; --禁用某个触发器
    
    --批发站  小于等于7级会员 归属刘小丽   调整至   华中站
    update TBL_USER_INFO set site_id = 10000000 
    where site_id = 3 and id in (select user_id from TBL_BANK_ACCOUNT b where score <=7000 and user_type = 1) and MARKET_SUPERVISION_USER_ID = 118;
    
    --批发站  小于等于7级会员 非归属刘小丽   调整至   华东站
    update TBL_USER_INFO set site_id = 1 
    where site_id = 3 and id in (select user_id from TBL_BANK_ACCOUNT b where score <=7000 and user_type = 1) and MARKET_SUPERVISION_USER_ID <> 118;

    
    --温州站   移至    华东站     等级等于7级
    /*
    update TBL_USER_INFO set site_id = 1 
    where site_id = 2 and id in (select user_id from TBL_BANK_ACCOUNT b where score >=6001 and score <=7000 and user_type = 1) ;
    */
    --温州站           移至   华东站          小于7级并且在温州站
    /*
    update TBL_USER_INFO set site_id = 1 
    where site_id = 2 and id in (select user_id from TBL_BANK_ACCOUNT b where score <=7000 and user_type = 1) ;
    */
    
    --华东站、华中站   移至  温州站          大于7级并且在华东站或华中站
    /*
    update TBL_USER_INFO set site_id = 2 
    where site_id in(1,10000000) and id in (select user_id from TBL_BANK_ACCOUNT b where score >7000 and user_type = 1);
    */
    
    --commit;
    --ALTER TRIGGER TRI_USER_INFO ENABLE;  --启用某个触发器

  commit;
exception
  when others then
    rollback;
end update_user_site;
/

