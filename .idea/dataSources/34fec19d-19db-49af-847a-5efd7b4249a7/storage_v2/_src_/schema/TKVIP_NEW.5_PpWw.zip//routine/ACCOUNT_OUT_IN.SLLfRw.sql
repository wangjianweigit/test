create PROCEDURE           account_out_in
/**
    处理会员间转账   王朋  手动执行，
      wangpeng
      2017-11-02
  **/
(c_out_user_id        in number,               --转出用户ID
 c_in_user_id         in number               --转入用户ID

 ) IS
  c_out_money              number:=0;          --转账金额
  v_out_user_name                 varchar2(100); --转出用户名
  v_in_user_name                  varchar2(100); --转入用户名
  v_out_user_manage_name        varchar2(100); --转出用户姓名
  v_in_user_manage_name        varchar2(100); --转入用户姓名
  v_out_user_account_balance          number:=0;           --转出用户余额
  v_in_user_account_balance          number:=0;           --转入用户余额
  v_credit_money_balance number:=0; --账户授信余额
  
BEGIN
    
    --查询转出用户名
    select USER_MANAGE_NAME,login_name into v_out_user_manage_name,v_out_user_name from tbl_user_info where id = c_out_user_id;
    
    --查询转入用户名
    select USER_MANAGE_NAME,login_name into v_in_user_manage_name,v_in_user_name from tbl_user_info where id = c_in_user_id;
    
    --查询转出用户当前余额
    select ACCOUNT_BALANCE into v_out_user_account_balance from TBL_BANK_ACCOUNT where user_id = c_out_user_id;
    
    --转账金额为转出用户的全部余额
    c_out_money:=v_out_user_account_balance;
    
    --查询转入用户当前余额
    select ACCOUNT_BALANCE into v_in_user_account_balance from TBL_BANK_ACCOUNT where user_id = c_in_user_id;
    
    --查询转入用户当前余额
    select CREDIT_MONEY_BALANCE into v_credit_money_balance from TBL_BANK_ACCOUNT where user_id = c_in_user_id;
    
    --插入转出用户收支记录
     Insert into TBL_USER_ACCOUNT_RECORD
   (ID, RECORD_NUMBER, RECORD_ITEM_NUMBER, RECORD_CHANNEL, RECORD_TYPE,
    REMARK, CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME, ACCOUNTANTS_SUBJECT_ID,
     PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME, MONEY,
    SURPLUS_MONEY, STATE, USER_NAME,
     YWJL_USER_NAME, MD_ID, CREDIT_BALANCE)
 Values
   (SEQ_USER_ACCOUNT_RECORD.nextval, getautonumber('CZ'), 1, '现金', '付款',
    '系统 余额转至'||v_out_user_manage_name||'['||v_in_user_name||']账户,后续手工充值做月结还款'
    , sysdate, c_out_user_id, v_out_user_manage_name, '2121TK',
     '2121', '现金',c_out_money,v_out_user_account_balance-c_out_money,'已审核', c_out_user_id,  'yxjzm', 1, v_credit_money_balance);

    
    --插入转入用户收支记录
Insert into TBL_USER_ACCOUNT_RECORD
   (ID, RECORD_NUMBER, RECORD_ITEM_NUMBER, RECORD_CHANNEL, RECORD_TYPE,
    REMARK, CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME, ACCOUNTANTS_SUBJECT_ID,
     PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME, MONEY,
    SURPLUS_MONEY, STATE, USER_NAME,
     YWJL_USER_NAME, MD_ID, CREDIT_BALANCE)
 Values
   (SEQ_USER_ACCOUNT_RECORD.nextval, getautonumber('CZ'), 1, '现金', '收款',
    '充值 将会员 '||v_out_user_manage_name||'['||v_out_user_name||'] 余额转至本账户，后续手工充值做月结还款'
    , sysdate, c_in_user_id, v_in_user_manage_name, '1001CZ',
     '1001', '现金',c_out_money,c_out_money+v_in_user_account_balance,'已审核', c_in_user_id,  'yxjzm', 1, v_credit_money_balance);
    
    
    
--------金荣荣余额增加
          update TBL_BANK_ACCOUNT set ACCOUNT_BALANCE = ACCOUNT_BALANCE+c_out_money where user_id = c_in_user_id;
      PRO_UPDATE_USER_ACCOUNT_CODE(c_in_user_id);

---------会员余额减少   
 update TBL_BANK_ACCOUNT set ACCOUNT_BALANCE = ACCOUNT_BALANCE-c_out_money,FROZEN_BALANCE =0 where user_id = c_out_user_id;
     PRO_UPDATE_USER_ACCOUNT_CODE(c_out_user_id);

DBMS_OUTPUT.put_line('成功：'||v_out_user_manage_name||'['||v_out_user_name||']转至'||v_in_user_manage_name||'['||v_in_user_name||']'||'，转账金额为：'||c_out_money);

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
  
DBMS_OUTPUT.put_line('错误：'||v_out_user_manage_name||'['||v_out_user_name||']转至'||v_in_user_manage_name||'['||v_in_user_name||']'||'，转账金额为：'||c_out_money);

    ROLLBACK;
END account_out_in;
/

