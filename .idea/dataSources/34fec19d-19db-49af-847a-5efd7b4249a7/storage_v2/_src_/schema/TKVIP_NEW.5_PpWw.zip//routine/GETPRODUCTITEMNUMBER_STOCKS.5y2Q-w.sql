create FUNCTION           getProductItemnumber_stocks
/**
      根据货号活动商品逻辑库存，仅统计表TBL_PRODUCT_SKU_STOCK数据
      2017-07-04
      增加预占用的扣减  shif 20171008
      返回值：商品可用逻辑库存
  **/
(c_product_itemnumber  VARCHAR2:='' --商品货号
 ) RETURN NUMBER IS
  v_product_itemnumber_stock    NUMBER := 0; --需要返回的商品库存数据
  v_product_itemnumber_exist    NUMBER := 0; --货号是否存在
BEGIN
    IF c_product_itemnumber is not null  THEN
            SELECT COUNT(1) INTO v_product_itemnumber_exist from TBL_PRODUCT_SKU WHERE product_itemnumber = c_product_itemnumber;
            IF  v_product_itemnumber_exist=0 then
              RETURN v_product_itemnumber_stock;
            END IF;
            select NVL(sum((case when (NVL(pss.PRODUCT_TOTAL_COUNT,0) - NVL(pss.PRODUCT_ORDER_OCCUPY_COUNT,0) -NVL(pss.PRE_ORDER_OCCUPY_COUNT,0))<0
            then 0
            else
            (NVL(pss.PRODUCT_TOTAL_COUNT,0) - NVL(pss.PRODUCT_ORDER_OCCUPY_COUNT,0)- NVL(pss.PRE_ORDER_OCCUPY_COUNT,0))
            end)),0) cun into v_product_itemnumber_stock
             from TBL_PRODUCT_SKU_STOCK pss where exists(
                select 1 from tbl_product_sku ps where ps.product_itemnumber = c_product_itemnumber and ps.id = pss.product_sku
            );
    ELSE
    select sum((case when (NVL(pss.PRODUCT_TOTAL_COUNT,0) - NVL(pss.PRODUCT_ORDER_OCCUPY_COUNT,0)- NVL(pss.PRE_ORDER_OCCUPY_COUNT,0))<0
            then 0
            else
            (NVL(pss.PRODUCT_TOTAL_COUNT,0) - NVL(pss.PRODUCT_ORDER_OCCUPY_COUNT,0) - NVL(pss.PRE_ORDER_OCCUPY_COUNT,0))
            end)) cun into v_product_itemnumber_stock
             from TBL_PRODUCT_SKU_STOCK pss;
    END IF;
  --返回值
  RETURN v_product_itemnumber_stock;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END getProductItemnumber_stocks;
/

