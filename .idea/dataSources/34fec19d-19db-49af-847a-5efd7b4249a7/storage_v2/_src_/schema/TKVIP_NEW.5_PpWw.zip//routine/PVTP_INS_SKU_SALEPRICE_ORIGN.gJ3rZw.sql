create procedure  pvtp_ins_sku_saleprice_orign
/**
*   私有平台的童库商品订单的商品价格由来
*
**/
(
    c_stationed_user_id   in number,     --私有商家id
    c_order_number     in varchar2,     --订单编号
    c_user_name        in varchar2     --用户名
)
is
    v_sys_line date:=to_date('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间      --界线新加配置
    v_sys_line2 date:=to_date('2019-09-13 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间     --界线新加配置  针对2019-09-13新费率调整
    v_sys_default_hy_dis number := 0.7;                                     --新注册会员老商品采用默认费率折扣

    v_product_prize number:=0;             --实际销售价
    v_user_id number:=0;                   --用户id
    v_product_create_date date;             --商品创建时间
    v_product_type number:=0;              --商品类型（0：普通商品，1：定制商品，2：菜鸟商品，3：私有平台商品）   --私有平台特殊价格新加配置
    v_product_type_id number:=0;                     --商品分类 
    v_product_specs_id number :=0;                   --商品规格id                  

    v_sys_default_hy_price number:=0;                           --v7售价
    v_product_prize_cost number:=0;                 --商品报价
    v_product_sale_prize number:=0;                 --应售价
    v_member_service_rate number:=0;                --会员服务费比例-汇总
    v_member_service_rate_rzs number:=0;            --会员服务费比例-入驻商
    v_member_service_rate_qj number:=0;             --会员服务费比例-全局
    v_member_service_money_rzs number:=0;           --会员服务费-入驻商
    v_member_service_money_qj number:=0;            --会员服务费-全局

    v_site_id number:=0;                   --会员站点 
    v_site_discount number:=1;             --站点折扣
    v_activity_id number;                  --活动id
    v_activity_name  varchar2(200);                      -- 活动名称
    v_hd_flag number:=-1;                  --是否参加了活动
    v_hd_discount number:=1;               --活动折扣
    v_hdhy_discount number:=1;             --活动会员服务费折扣
    v_hy_discount number:=1;               --会员折扣

    v_hyfwf_discount number :=1 ;          --会员服务费折扣率,站点或会员等级折扣

    v_stationed_user_id number;             --商品入驻商ID
    v_remark varchar2(2000);                --记录说明
    v_num number;                           --计数

begin

    --查询会员站点、特殊价格模板（私有站）
    select nvl(min(site_id),0),nvl(min(id),0),nvl(min(discount),1)
    into v_site_id,v_user_id,v_hy_discount
    from tbl_user_info where user_name = c_user_name;

    --查询站点折扣
    select nvl(min(discount),1) into v_site_discount from tbl_site_info  where id = v_site_id;

    declare cursor to_orders is
        select product_itemnumber,product_color,product_specs
        from tbl_order_product_sku
        where order_number = c_order_number and user_name = c_user_name
        group by product_itemnumber, product_color, product_specs;
    begin
        for c_row in to_orders loop
            v_remark := ''; v_num := 1;

            select a.create_date,a.product_type,a.product_type_id, stationed_user_id
            into v_product_create_date,v_product_type, v_product_type_id, v_stationed_user_id 
            from tbl_product_info a
            where a.itemnumber =c_row.product_itemnumber and rownum<2;

            /*************************商品新老计费费率控制*********begin**********************/
            if v_product_create_date < v_sys_line then
                --查询入驻商会员服务费比例-老费率
                select nvl(member_service_rate,0),nvl(area_service_rate,0) into v_member_service_rate_rzs,v_member_service_rate_qj 
                from tbl_stationed_old_service_rate where stationed_user_id = v_stationed_user_id;
                v_remark := v_num || '、商品档案创建时间<2019-01-30，入驻商区域服务费率、入驻商会员服务费率取旧值';
                v_num := v_num + 1;
            end if;
            /*************************商品新老计费费率控制*********end**********************/

            /*************************商品新老计费费率控制****针对2019-09-13新费率调整*****begin**********************/
            if v_sys_line2 > v_product_create_date and v_product_create_date >= v_sys_line then
                --查询入驻商会员服务费比例-老费率2次调整
                select nvl(area_service_rate,0) into v_member_service_rate_qj from tbl_stationed_old_service_rat2 
                where stationed_user_id = v_stationed_user_id;
                select nvl(member_service_rate,0) into v_member_service_rate_rzs
                from tbl_stationed_user_info where id = v_stationed_user_id;
                v_remark := v_num || '、2019-01-30<=商品档案创建时间<2019-09-13，入驻商区域服务费率调整，入驻商会员服务费率';
                v_num := v_num + 1;
            end if;
            /*************************商品新老计费费率控制****针对2019-09-13新费率调整*****begin**********************/

            if v_product_create_date >= v_sys_line2 then
                --查询入驻商会员服务费比例-按当前费率计算
                select nvl(member_service_rate,0),nvl(area_service_rate,0) into v_member_service_rate_rzs,v_member_service_rate_qj 
                from tbl_stationed_user_info where id = v_stationed_user_id;
                v_remark := v_num || '、商品档案创建时间>=2019-09-13，入驻商区域服务费率调整';
                v_num := v_num + 1;
            end if;

            --使用默认会员等级计算       
            select nvl(max(user_discount),1) into v_hy_discount from tbl_pvtp_config where stationed_user_id = c_stationed_user_id;

            --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
            v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;

             --查询规格基本信息
            select product_prize_cost,parent_id
            into v_product_prize_cost,v_product_specs_id
            from tbl_product_sku where product_itemnumber = c_row.product_itemnumber
            and product_color = c_row.product_color and product_specs = c_row.product_specs and rownum < 2;
            --计算应销售价
            v_product_sale_prize:=v_product_prize_cost/(1-v_member_service_rate);
            v_remark := v_remark ||' '||v_num || '、应售价=报价/(1-入驻商会员服务费率-入驻商区域服务费率)';
            v_num := v_num + 1;

            --计算入驻商会员服务费 = 应销售价*入驻商会员服务费比例
            v_member_service_money_rzs := v_product_sale_prize * v_member_service_rate_rzs;
            v_remark := v_remark ||' '||v_num || '、入驻商会员服务费=应售价*入驻商会员服务费率';
            v_num := v_num + 1;

            --计算全局会员服务费 = 应销售价*全局会员服务费比例
            v_member_service_money_qj := v_product_sale_prize * v_member_service_rate_qj;
            v_remark := v_remark ||' '||v_num || '、入驻商区域服务费=应售价*入驻商区域服务费率';
            v_num := v_num + 1;

            --如果没有查询到用户信息，则返回原价
            if v_user_id=0 then
                v_product_prize:=v_product_sale_prize;
                v_remark := v_num || '、没有查询到用户信息，则返回应售价';
                v_num := v_num + 1;
            else
                IF v_product_type=0 THEN
                    --商品是童库活动，则需要校验商品是否参加了平台活动，其中，仅考虑限时折扣
                    select nvl(min(c.activity_discount),0),nvl(min(c.id),-1),nvl(min(a1.activity_service_discount),1) 
                    into v_hd_discount,v_hd_flag,v_hdhy_discount 
                    from tbl_activity_info a ,tbl_activity_detail a1,tbl_activity_product c 
                        where a.activity_state = '3' and a.state = '2'
                        and a.activity_type = '1'
                        and sysdate between a.begin_date and a.end_date 
                        and sysdate between c.activity_start_date and c.activity_end_date 
                        and a.id = a1.activity_id
                        and c.activity_id = a.id 
                        and c.product_itemnumber =c_row.product_itemnumber
                        and  
                            case 
                               when (a1.user_group_id = 0 or a1.user_group_id is null)
                                   then 1
                               else
                                   case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and a1.user_group_id = aa.id and  bb.user_id = c_user_name)
                                   then 
                                       1
                                   else
                                       0
                                   end
                            end  = 1
                        and exists (select 1 from tbl_activity_site tas where tas.activity_id = a.id and tas.site_id = v_site_id);
                END IF;
                --获取 会员折扣 或  站点折扣  中最低的
                v_hyfwf_discount:= least(v_hy_discount,v_site_discount);
                --没有参加活动
                if v_hd_flag=-1 then  
                    --计算售价
                    v_product_prize := v_product_prize_cost+v_member_service_money_rzs+(v_member_service_money_qj*v_hyfwf_discount);
                    v_remark := v_remark ||' '|| v_num ||'、当前商品未参加平台活动，实际销售价=报价+入驻商会员服务费+入驻商区域服务费*min(会员等级折扣，站点折扣)';
                    v_num := v_num + 1;
                --参加了活动
                else  
                    --获取最低折扣   会员折扣与活动会员折扣与活动折扣中最低
                    v_hyfwf_discount := least(v_hyfwf_discount,v_hdhy_discount,v_hd_discount);

                    --按照活动计算  报价*活动折扣 + 入驻商会员服务费*活动折扣 + 全局会员服务费*会员折扣与活动会员折扣与活动折扣中最低
                    v_product_prize := (v_product_prize_cost*v_hd_discount) + (v_member_service_money_rzs*v_hd_discount) + (v_member_service_money_qj*v_hyfwf_discount);
                    v_remark := v_remark ||' '|| v_num ||'、当前商品参加平台活动，实际销售价=报价*活动折扣+入驻商会员服务费*活动折扣+入驻商区域服务费*min(会员等级折扣，站点折扣，平台会员服务费折扣，活动折扣)';
                    v_num := v_num + 1;
                end if; 
            end if;

            if ceil(v_product_prize)-v_product_prize<0.5 then
                v_product_prize := ceil(v_product_prize);
                v_remark := v_remark ||' '|| v_num ||'、小数位大于0.5，进位到1';
                v_num := v_num + 1;
            elsif ceil(v_product_prize)-v_product_prize=0 then
                v_product_prize := v_product_prize;
                v_remark := v_remark ||' '|| v_num ||'、小数位等于0不处理';
                v_num := v_num + 1;
            else 
                v_product_prize := ceil(v_product_prize)-0.5;
                v_remark := v_remark ||' '|| v_num ||'、小数位大于0小于0.5，进位到0.5';
                v_num := v_num + 1;
            end if;


            v_sys_default_hy_price := v_product_prize_cost + v_member_service_money_rzs + (v_member_service_money_qj * v_sys_default_hy_dis);

            insert into tbl_order_specs_price(
                id,
                order_number,
                user_name,
                product_itemnumber,
                product_color,
                product_specs,
                stationed_user_id,
                activity_id,
                activity_name,
                activity_discount,
                product_price_cost,
                product_sale_price,
                product_default_price,
                product_price,
                user_discount,
                process_remark
            ) values(
                seq_order_specs_price.nextval,
                c_order_number,
                c_user_name,
                c_row.product_itemnumber,
                c_row.product_color,
                c_row.product_specs,
                v_stationed_user_id,
                v_activity_id,
                v_activity_name,
                v_hd_discount,
                v_product_prize_cost,
                v_product_sale_prize,
                v_sys_default_hy_price,
                v_product_prize,
                v_hy_discount,
                v_remark
            );

        end loop;
    end;
    commit;
end pvtp_ins_sku_saleprice_orign;
/

