create FUNCTION           getStrforArrid_str 
/**
    字符串拆分 传入格式    ,111,222,333,    返回类型为字符串型  
    shif
    20170503  从tkvip_new移植过来
**/
(
str   varchar2,   --待分拆的字符串
flag   char,      --分隔符
numberid   int    --获取第几个     
) return varchar2
 is
 returnstr varchar2(200);
BEGIN
   returnstr:=substr(str,instr(str,flag,1,numberid)+1,instr(str,flag,1,numberid+1)-instr(str,flag,1,numberid)-1);
   return returnstr;
END getStrforArrid_str;
/

