create TYPE           "T_ORDER_PRODUCT" FORCE  as object
(
    product_sku int,  --订单商品sku
    count int,  --订单sku数量
    product_gbcode VARCHAR2 (500 Byte) --sku国标码
);
/

