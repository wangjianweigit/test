create FUNCTION getProductItemNumber_new
    /**
    * 生成商品货号 songwangwen 2017.05.31
    *  update by reid 2019.11.13    私有商品与童库商品货号不允许重复
    *
    **/
  (
   brand_id  IN NUMBER, --商品品牌ID
   year      IN NUMBER, --年份
   season_id IN NUMBER --季节ID
  ) RETURN VARCHAR2 IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  returnstr     VARCHAR2(50); --返回货号
  v_count       NUMBER; --临时变量
  v_temp_count  NUMBER; --临时变量
  v_brand_code  VARCHAR2(10); --商品品牌code
  v_year_code   VARCHAR2(10); --商品年份code
  v_season_code VARCHAR2(10); --商品季节code
  v_year_length number;--年份的长度
  v_seq_number  number;--货号生成序号
  v_itemnumber  VARCHAR2(50); --货号
BEGIN
  --初始化货号为空
  returnstr := '';
  --参数校验
  SELECT CODE INTO v_brand_code FROM TBL_DIC_PRODUCT_BRAND WHERE ID = brand_id;
  if v_brand_code is null or v_brand_code ='' then
     return returnstr;
  end if;

  SELECT CODE INTO v_season_code FROM TBL_DIC_PRODUCT_SEASON WHERE ID = season_id;
  if v_season_code is null or v_season_code ='' then
     return returnstr;
  end if;

  select nvl(length(to_char(year)),0 ) into v_year_length from dual;
  if v_year_length <> 4 then
     return returnstr;
  end if;
  SELECT TO_NUMBER(SUBSTR(TO_CHAR(year),LENGTH(TO_CHAR(year)),1)) INTO v_year_code FROM DUAL;
  select count(1) into v_count from TBL_PRODUCT_ITEMNUMBER_NEW where  brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
  if v_count = 1 then
     --获取上次货号生成
     select seq_number into v_seq_number from TBL_PRODUCT_ITEMNUMBER_NEW where brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
     if v_seq_number = 999 then
        --启用备用季节code
        SELECT CODE_BAK INTO v_season_code FROM TBL_DIC_PRODUCT_SEASON WHERE ID = season_id;
        if v_season_code is null or v_season_code ='' then
           return returnstr;
        end if;
        --验证备用季节是否已有生成货号记录
        select count(1) into v_count from TBL_PRODUCT_ITEMNUMBER_NEW where  brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
        if v_count = 1 then
           select seq_number into v_seq_number from TBL_PRODUCT_ITEMNUMBER_NEW where brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
           if v_seq_number = 999 then
              return returnstr;
           end if;
           select  v_brand_code||v_year_code||v_season_code||REPLACE(lpad(v_seq_number,3,'0'), '4', '5') into v_itemnumber from dual;    
           returnstr:=v_itemnumber;      
        else
           select  v_brand_code||v_year_code||v_season_code||'001' into returnstr from dual;
           insert into TBL_PRODUCT_ITEMNUMBER_NEW (BRAND_CODE,YEAR_CODE,SEASON_CODE,SEQ_NUMBER) values(v_brand_code,v_year_code,v_season_code,1);
        end if;
     else
        --替换数字4
        select  v_brand_code||v_year_code||v_season_code||REPLACE(lpad(v_seq_number,3,'0'), '4', '5') into v_itemnumber from dual;
        --判断上次生成的货号是否已被使用,则直接更新序列信息
        select 
            (SELECT COUNT(1) FROM TBL_PRODUCT_INFO_APPLY WHERE ITEMNUMBER = v_itemnumber)
            +
            (SELECT COUNT(1)  FROM TBL_PVTP_PRODUCT_INFO_APPLY WHERE ITEMNUMBER = v_itemnumber)
            INTO v_count
        from dual;
        IF v_count>0 THEN
                 v_seq_number:=v_seq_number+1;
                 update TBL_PRODUCT_ITEMNUMBER_NEW set seq_number = to_number(REPLACE(lpad(v_seq_number,3,'0'), '4', '5')) where brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;         
        ELSE
                returnstr:=v_itemnumber;      
        END IF;
     end if;
  else
     --第一次生成货号
     select  v_brand_code||v_year_code||v_season_code||'001' into returnstr from dual;
     insert into TBL_PRODUCT_ITEMNUMBER_NEW (BRAND_CODE,YEAR_CODE,SEASON_CODE,SEQ_NUMBER) values(v_brand_code,v_year_code,v_season_code,1);
  end if;
  COMMIT;
  RETURN returnstr;
EXCEPTION
 WHEN OTHERS THEN
  rollback;
  return '';
END getProductItemNumber_new;
/

