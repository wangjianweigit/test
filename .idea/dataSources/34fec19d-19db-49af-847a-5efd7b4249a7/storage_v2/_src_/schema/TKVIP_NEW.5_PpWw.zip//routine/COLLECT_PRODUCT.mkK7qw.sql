create PROCEDURE collect_product
/**
     收藏商品 shifan 2016-04-05
     2019.09-16 兼容私有站相关改造，增加条件platform_id = 0
     返回值：收藏成功或收藏失败消息
  **/
(
 client_user_name  IN VARCHAR2, --用户名
 client_itemnumber IN VARCHAR2, --商品货号
 output_status     OUT VARCHAR2, --返回的状态码 0-取消失败 1-取消成功
 output_msg        OUT VARCHAR2 --返回的信息
 ) IS
      temp_count                   INT := 0; --临时变量
      temp_collect_product_price   VARCHAR2(50); --收藏商品价格
      temp_collect_product_name    VARCHAR2(300); --收藏商品名字
      temp_collect_product_img_url VARCHAR2(200); --收藏商品图片路径
BEGIN
   
     output_status := '0';
      SELECT COUNT(*) INTO temp_count FROM tbl_user_info WHERE user_name = client_user_name;
      IF temp_count = 0 THEN
        output_msg := '用户信息不能为空，请检查！';
        RETURN;
      END IF;
      
      SELECT COUNT(*)
        INTO temp_count
        FROM tbl_product_info
       WHERE itemnumber = client_itemnumber;
      IF temp_count = 0 THEN
        output_msg := '商品信息不存在，请检查！';
        RETURN;
      END IF;
      
      
      SELECT COUNT(*)
        INTO temp_count
        FROM tbl_user_collection
       WHERE user_name = client_user_name
             AND itemnumber = client_itemnumber
             AND platform_id = 0;
      IF temp_count <> 0 THEN
        output_msg := '该商品已收藏！';
        RETURN;
      END IF;
      
      temp_collect_product_price:=getProduct_SalePrice_Min(client_user_name, client_itemnumber);  
      
      --获取商品名称，主图片路径
      SELECT product_name, product_img_url
        INTO temp_collect_product_name, temp_collect_product_img_url
        FROM tbl_product_info
       WHERE itemnumber = client_itemnumber;
      INSERT INTO tbl_user_collection
        (id, user_name, product_name, product_price, product_img_url, itemnumber, create_date)
      VALUES
        (seq_user_collection.NEXTVAL, client_user_name, temp_collect_product_name, temp_collect_product_price, temp_collect_product_img_url, client_itemnumber, SYSDATE);
      output_status := '1';
      output_msg    := '收藏成功！';
      COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    output_msg := '收藏商品时出现未知错误！';
    ROLLBACK;
END collect_product;
/

