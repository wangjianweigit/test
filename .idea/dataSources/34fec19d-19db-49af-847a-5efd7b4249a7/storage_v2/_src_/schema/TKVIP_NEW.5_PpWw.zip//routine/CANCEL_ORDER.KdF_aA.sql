create PROCEDURE           CANCEL_ORDER
/**
     取消订单【未付款超过24小时自动取消】
     shifan
     2017-05-29
     预付订单付尾款产生的普通订单，存在手工占用，取消订单时占用处理（未付款） shif 2017-10-08
     返回值：取消成功或取消失败消息
     
     songwangwen 20180727 增加会员卡相关修改
     
    songwangwen 2018.10.16 预售活动相关修改
    
    wangjianwei 20190410 增加取消商品自动上架
  **/
(
 client_user_name     in varchar2,  --用户名
 client_order_number  in varchar2,  --订单号
 client_cancel_reason in varchar2,  --取消订单原因
 output_status        out varchar2, --返回的状态码 0-取消失败 1-取消成功
 output_msg           out varchar2  --返回的信息
 ) is
    temp_count   INT := 0;            --临时变量
    v_order_state INT := 0;           --订单总状态
    v_payment_state INT := 0;         --订单付款状态
    temp_user_realname varchar2(50);  --订单用户姓名
    c_user_type                VARCHAR2(50):='7';   --表示是平台用户获取会员卡额度校验码的key值
    v_user_name                VARCHAR2(50);        --平台会员user_name
    v_mbr_card number := 0;                         --订单是否使用会员卡  1-.没有使用 2-有使用
    v_product_money number := 0;                    --订单商品金额
    v_card_id number := 0;                          --会员卡ID
    v_expiration_date DATE;                         --会员卡过期时间
    v_user_key                 VARCHAR2 (32);       --用户KEY
    v_create_code              VARCHAR2 (32);       --通过当前余额计算得到的校验码，用于校验余额是否被篡改
    v_card_balance_checkcode   VARCHAR2 (50);       --临时变量，会员卡余额校验码
    v_card_balance             NUMBER;              --临时变量，会员卡余额
begin
  output_status := '0';
  output_msg    := '取消失败';
  v_user_name   :=client_user_name;
  --定制订单产生的普通订单不能自动取消
  select count(*) into temp_count from TBL_PRE_ORDER_RELATE tror where order_number=client_order_number
    and exists (select 1 from TBL_PRE_ORDER_INFO tpoi where tpoi.order_number=tror.pre_order_number and tpoi.pre_order_type=2);
    IF temp_count > 0 Then
    output_msg := '定制订单产生的普通订单不能取消！';
    RETURN;
  END IF;
  
  SELECT COUNT(*) INTO temp_count FROM tbl_user_info WHERE user_name = client_user_name;
  IF temp_count = 0 Then
    output_msg := '用户信息不能为空，请检查！';
    RETURN;
  END IF;
  SELECT USER_MANAGE_NAME INTO temp_user_realname FROM TBL_USER_INFO WHERE USER_NAME = client_user_name;
  --订单信息
  SELECT ORDER_STATE ,PAYMENT_STATE,MBR_CARD,PRODUCT_MONEY INTO v_order_state, v_payment_state,v_mbr_card, v_product_money
  FROM TBL_ORDER_INFO WHERE ORDER_NUMBER = client_order_number AND USER_NAME = client_user_name;
  
  IF v_order_state = 1 AND v_payment_state= 1 THEN --当订单总状态为待付款，付款状态为待付款时的取消订单，最终订单总状态更新为交易关闭
  
    ------------------------------------会员卡额度返还相关-start-------------------------------------------------
    --会员卡余额回退 1.未使用会员卡 2.使用会员卡
    IF v_mbr_card = 2 THEN
       --会员卡信息
       SELECT ID,CARD_BALANCE,EXPIRATION_DATE INTO v_card_id,v_card_balance,v_expiration_date FROM TBL_USER_MBR_CARD WHERE USER_ID = client_user_name;
       IF v_expiration_date > SYSDATE THEN
         -------------------------------------验证余额是否被篡改-start--------------------------------------------------
         --获取用户KEY
         SELECT getUserKey (v_user_name, 'old', c_user_type) INTO v_user_key FROM DUAL;
         --查询得到数据库中当前的校验码
         SELECT card_balance_checkcode,card_balance INTO v_card_balance_checkcode,v_card_balance FROM TBL_USER_MBR_CARD WHERE user_id = client_user_name;
         --获取余额校验码并判断是否被篡改
         v_create_code := getCheck_Code (v_user_name, v_card_balance, v_user_key);

         IF  v_card_balance_checkcode IS NULL OR v_card_balance_checkcode <> v_create_code
         THEN
            output_msg := '会员卡余额被篡改，取消订单失败!';
            RETURN;
         END IF;
        --创建新的账户KEY
        select getUserKey(v_user_name,'new',c_user_type) into v_user_key from dual;
        --产生新的余额校验码（过期会员卡，余额直接修改为0）
        select getcheck_code(v_user_name,v_card_balance+v_product_money,v_user_key) into v_card_balance_checkcode from dual;
        ---更新会员卡余额,校验码
        UPDATE TBL_USER_MBR_CARD
           SET card_balance = v_card_balance+v_product_money,
               card_balance_checkcode = v_card_balance_checkcode,
               update_date = SYSDATE
         WHERE user_id = client_user_name;
         --更新用户账户KEY
         update TBL_USER_MBR_CARD_CACHE_KEY set cache_key = v_user_key,create_time=sysdate where user_name = v_user_name;
      ---增加会员卡使用记录
          INSERT INTO TBL_USER_MBR_CARD_USE_RECORD (
             ID, MBR_CARD_ID, ORDER_NUMBER, TYPE, USED_AMOUNT, REMARK, CREATE_DATE
          ) VALUES (
              SEQ_USER_MBR_CARD_USE_RECORD.NEXTVAL, v_card_id, client_order_number, 4, v_product_money, '普通订单付款超时，会员卡额度返还。订单号：' || client_order_number, SYSDATE
          );
       END IF;
    END IF;
    ------------------------------------会员卡额度返还相关-end---------------------------------------------------
    
    --更新订单主表状态
    UPDATE TBL_ORDER_INFO
       SET CANCEL_REASON = client_cancel_reason, CANCEL_DATE = sysdate, ORDER_STATE = 6, CANCEL_USER_NAME = client_user_name,CANCEL_USER_REALNAME = temp_user_realname
     WHERE ORDER_NUMBER = client_order_number AND USER_NAME = client_user_name;
    --删除订单占用量
    DELETE  FROM TBL_ORDER_WAREHOUSE_COUNT WHERE ORDER_NUMBER= client_order_number;
    --当前订单为预付订单付尾款产生订单，取消时，占用回溯处理。
    INSERT INTO TBL_PRE_ORDER_WAREHOUSE_COUNT (ID,PRE_ORDER_NUMBER,USER_NAME,WAREHOUSE_ID,PRODUCT_SKU,OCCUPY_COUNT,CREATE_DATE)
        SELECT SEQ_PRE_ORDER_WAREHOUSE_COUNT.NEXTVAL,
                 PRE_ORDER_NUMBER,
                 USER_NAME,
                 WAREHOUSE_ID,
                 PRODUCT_SKU,
                 COUNT,
                 SYSDATE
         FROM (SELECT TOPS.USER_NAME,
                  TOPS.PRODUCT_SKU,
                  TOPS.COUNT,
                 (SELECT TPOR.PRE_ORDER_NUMBER
                    FROM TBL_PRE_ORDER_RELATE TPOR
                   WHERE TPOR.ORDER_NUMBER = TOPS.ORDER_NUMBER
                         AND EXISTS(SELECT 1
                                      FROM TBL_PRE_ORDER_INFO TPOI
                                     WHERE TPOI.ORDER_NUMBER = TPOR.PRE_ORDER_NUMBER
                                           AND TPOI.WAREHOUSE_STATE = '2')) AS PRE_ORDER_NUMBER,
                  (SELECT TPOI.WAREHOUSE_ID
                          FROM TBL_PRE_ORDER_RELATE TPOR,TBL_PRE_ORDER_INFO TPOI
                         WHERE TPOR.ORDER_NUMBER = TOPS.ORDER_NUMBER
                               AND TPOR.PRE_ORDER_NUMBER = TPOI.ORDER_NUMBER(+)
                               AND ROWNUM <=1) AS WAREHOUSE_ID
            FROM TBL_ORDER_PRODUCT_SKU TOPS
               WHERE TOPS.ORDER_NUMBER = client_order_number) T1
    WHERE T1.PRE_ORDER_NUMBER IS NOT NULL; 
    /*********************如果当前商品参加了预售活动，则在订单取消时，需要将已销售的预售数量恢复***********************************/
   UPDATE TBL_PRESELL_ACTIVITY_SKU pas 
   SET pas.ACTIVITY_SELL_AMOUNT = pas.ACTIVITY_SELL_AMOUNT - NVL((SELECT TOPS.COUNT
                                                                     FROM TBL_ORDER_PRODUCT_SKU TOPS
                                                                     WHERE TOPS.ORDER_NUMBER = client_order_number
                                                                            AND TOPS.PRODUCT_SKU = pas.PRODUCT_SKU),0)
   WHERE EXISTS (
                SELECT 1
                    FROM TBL_ACTIVITY_INFO tai,TBL_ACTIVITY_DETAIL A1,
                    TBL_ACTIVITY_PRODUCT AP,
                    TBL_ORDER_PRODUCT_SKU TOPS
                WHERE TOPS.ORDER_NUMBER = client_order_number
                     AND TAI.ID = AP.ACTIVITY_ID AND TAI.ID = A1.ACTIVITY_ID
                     AND AP.PRODUCT_ITEMNUMBER = TOPS.PRODUCT_ITEMNUMBER
                     AND TOPS.PRODUCT_SKU = pas.PRODUCT_SKU
                     AND TAI.ID = pas.ACTIVITY_ID
                     AND AP.ACTIVITY_START_DATE <= TOPS.ORDER_DATE
                     AND AP.ACTIVITY_END_DATE >= TOPS.ORDER_DATE
                     AND TAI.ACTIVITY_STATE = '3'
                     AND TAI.STATE = '2'
                     AND TAI.ACTIVITY_TYPE = '4'
                     AND EXISTS (SELECT 1
                                    FROM TBL_ACTIVITY_SITE tas,tbl_user_info tui
                                   WHERE tas.site_id = tui.site_id
                                   AND tas.ACTIVITY_ID = TAI.ID
                                   and tops.user_name = tui.user_name
                                   )
					AND (CASE WHEN (A1.USER_GROUP_ID = 0 OR A1.USER_GROUP_ID IS NULL) THEN 1 ELSE CASE WHEN EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND A1.USER_GROUP_ID = AA.ID AND  BB.USER_ID = client_user_name) THEN 1 ELSE 0 END END) = 1 
   );
     /*********************如果当前商品参加了非预售活动，而且是锁定库存的活动，需要将已销售的预售数量进行变更***********************************/
    UPDATE TBL_SALE_ACTIVITY_SKU TSAS
        SET TSAS.ACTIVITY_SELL_AMOUNT = TSAS.ACTIVITY_SELL_AMOUNT - NVL((SELECT TOPS.COUNT
                                                                     FROM TBL_ORDER_PRODUCT_SKU TOPS
                                                                     WHERE TOPS.ORDER_NUMBER = client_order_number
                                                                            AND TOPS.PRODUCT_SKU = TSAS.PRODUCT_SKU
                                                                            AND TOPS.WAREHOUSE_ID = TSAS.WAREHOUSE_ID),0)
        WHERE EXISTS (SELECT 1
                    FROM TBL_ACTIVITY_INFO TAI, 
            TBL_ACTIVITY_DETAIL TSAI, 
            TBL_ACTIVITY_PRODUCT ap,
            TBL_ORDER_PRODUCT_SKU TOPS
                   WHERE TOPS.ORDER_NUMBER = client_order_number
             AND TAI.ID = AP.ACTIVITY_ID
                     AND AP.PRODUCT_ITEMNUMBER = TOPS.PRODUCT_ITEMNUMBER
                     AND TOPS.PRODUCT_SKU = TSAS.PRODUCT_SKU
                     AND TOPS.WAREHOUSE_ID = TSAS.WAREHOUSE_ID
                     AND TAI.ID = TSAS.ACTIVITY_ID
                     AND TSAI.ACTIVITY_ID = TSAS.ACTIVITY_ID
                     AND AP.ACTIVITY_START_DATE <= TOPS.ORDER_DATE
                     AND AP.ACTIVITY_END_DATE >= TOPS.ORDER_DATE
                     AND TAI.ACTIVITY_STATE = '3'
                     AND TAI.STATE = '2'
					 AND TAI.ACTIVITY_TYPE != '4'
					 AND TSAI.LOCKED_STOCK = '2'
                     AND EXISTS (SELECT 1
                                    FROM TBL_ACTIVITY_SITE tas,tbl_user_info tui
                                   WHERE tas.site_id = tui.site_id
                                   AND tas.ACTIVITY_ID = TAI.ID
                                   and tops.user_name = tui.user_name
                                   )
					AND (CASE WHEN (TSAI.USER_GROUP_ID = 0 OR TSAI.USER_GROUP_ID IS NULL) THEN 1 ELSE CASE WHEN EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND TSAI.USER_GROUP_ID = AA.ID AND  BB.USER_ID = client_user_name) THEN 1 ELSE 0 END END) = 1 
                );
         /*********************订单自动取消后，更新商品sku上架状态***********************************/
        INSERT INTO tmp_common_id
           SELECT id
             FROM TBL_PRODUCT_SKU ps
            WHERE     EXISTS
                         (SELECT 1
                            FROM TBL_ORDER_PRODUCT_SKU t
                           WHERE     t.product_sku = ps.id
                                 AND ORDER_NUMBER = client_order_number)
                  AND EXISTS
                         (SELECT 1
                            FROM tbl_product_sku a
                           WHERE     product_group = '尺码'
                                 AND a.state = '下架'
                                 AND a.start_stop_state = 1
                                 AND a.id = ps.id
                                 AND EXISTS
                                        (SELECT 1
                                           FROM (SELECT product_total_count,
                                                        (  c.product_order_occupy_count
                                                         - t.product_count)
                                                           product_order_occupy_count,
                                                        c.PRODUCT_SKU
                                                   FROM tbl_product_sku_stock c,
                                                        (  SELECT COUNT (1)
                                                                     product_count,
                                                                  t.product_sku
                                                             FROM TBL_ORDER_PRODUCT_SKU t
                                                            WHERE ORDER_NUMBER =
                                                                     client_order_number
                                                         GROUP BY product_sku) t
                                                  WHERE c.product_sku = t.product_sku)
                                          WHERE     product_sku = a.id
                                                AND product_total_count >
                                                       product_order_occupy_count
                                                AND EXISTS
                                                       (SELECT 1
                                                          FROM tbl_product_info tpi
                                                         WHERE     tpi.itemnumber =
                                                                      a.product_itemnumber
                                                               AND tpi.product_type IN
                                                                      (0, 3)
                                                               AND tpi.start_stop_state =
                                                                      1)))
                  AND NOT EXISTS
                             (SELECT 1
                                FROM tbl_activity_info a, tbl_activity_product c
                               WHERE     a.id = c.activity_id
                                     AND a.activity_type IN ('2', '4')
                                     AND a.activity_state = '3'
                                     AND a.state = '2'
                                     AND ps.product_itemnumber = c.product_itemnumber
                                     AND SYSDATE BETWEEN c.activity_start_date
                                                     AND c.activity_end_date
                                     AND EXISTS
                                            (SELECT 1
                                               FROM tbl_product_info dd
                                              WHERE     dd.itemnumber =
                                                           c.product_itemnumber
                                                    AND dd.start_stop_state = 1));
        UPDATE TBL_PRODUCT_SKU ps
           SET STATE = '上架'
         WHERE ps.id IN (    SELECT id
                               FROM tbl_product_sku
                              WHERE state = '下架'
                         START WITH id IN (SELECT id FROM tmp_common_id)
                         CONNECT BY id = PRIOR parent_id);
                         
         UPDATE TBL_PRODUCT_INFO p
           SET STATE = '上架'
         WHERE p.itemnumber IN (SELECT product_itemnumber FROM tbl_product_sku WHERE id IN (SELECT id FROM tmp_common_id));
         
    output_status := '1';
    output_msg    := '取消成功';
  ELSE
    output_msg := '暂时不支持其它状态取消订单!';
    RETURN;
  END IF;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    output_msg := '取消订单出现未知错误';
    ROLLBACK;
END CANCEL_ORDER;
/

