create FUNCTION getOrderReturnStatus/**
                                                           获取订单退货状态【是否可申请退货或退款】
                                                         **/
(v_order_number VARCHAR2,                                                --订单号
                         order_status NUMBER                            --订单状态
                                            )
   RETURN VARCHAR2
IS
   status    VARCHAR2 (50);
   V_Count   NUMBER;
BEGIN
   status := '0';

   IF order_status = 3 THEN
      SELECT COUNT (1)
        INTO V_Count
        FROM (SELECT T1.*,
                     T1.COUNT - T1.TOTAL_SEND_COUNT - NVL (T3.COUNT, 0) AS CAN_RETURN_COUNT
                FROM TBL_ORDER_PRODUCT_SKU T1,
                     (  SELECT T2.ORDER_NUMBER,
                               T2.PRODUCT_SKU,
                               SUM (T2.COUNT) COUNT
                          FROM TBL_ORDER_RETURN_PRODUCT T2
                         WHERE EXISTS
                                  (SELECT 1
                                     FROM TBL_ORDER_RETURN_INFO T4
                                    WHERE     T4.STATE IN ('1', '2')
                                          AND T4.ORDER_NUMBER = v_order_number
                                          AND T4.RETURN_NUMBER = T2.RETURN_NUMBER)
                      GROUP BY T2.ORDER_NUMBER, T2.PRODUCT_SKU) T3
               WHERE     T1.ORDER_NUMBER = T3.ORDER_NUMBER(+)
                     AND T1.PRODUCT_SKU = T3.PRODUCT_SKU(+)
                     AND T1.ORDER_NUMBER = v_order_number) A
       WHERE A.CAN_RETURN_COUNT > 0;

      IF V_Count > 0 THEN
         status := '1';
      END IF;
   END IF;
   RETURN status;
END getOrderReturnStatus;
/

