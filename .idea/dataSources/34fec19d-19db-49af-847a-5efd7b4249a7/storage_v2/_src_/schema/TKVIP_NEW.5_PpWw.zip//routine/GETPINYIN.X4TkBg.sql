create FUNCTION           GETPINYIN (
    P_STR           VARCHAR2,
    P_FLAG          NUMBER:= 0
) RETURN VARCHAR2        
AS        
    V_COMPARE       VARCHAR2 (4);        
    V_RETURN        VARCHAR2 (4000);        
    V_LENGTH        NUMBER := 0;        
    V_SUBSTR        VARCHAR2 (4); 
    FUNCTION FN_NLSSORT (
        P_WORD IN VARCHAR2
    ) RETURN VARCHAR2        
    AS        
    BEGIN        
       RETURN SUBSTR (NLSSORT (P_WORD, 'nls_sort=schinese_pinyin_m'), 1, 4);        
    END FN_NLSSORT;        
BEGIN        
    IF P_STR IS NULL        
    THEN        
       RETURN '';        
    END IF;        
    V_LENGTH := LENGTH (P_STR);
            
    CASE P_FLAG 
        WHEN 1 THEN 
            FOR I IN 1 .. V_LENGTH LOOP        
                V_SUBSTR := SUBSTR (P_STR, I, 1);        
                V_COMPARE := FN_NLSSORT (V_SUBSTR);
                CASE        
                WHEN V_COMPARE BETWEEN '3B29' AND '3B30'        
                THEN        
                     V_RETURN := V_RETURN || 'a';        
                WHEN V_COMPARE = '3B31'        
                THEN        
                     V_RETURN := V_RETURN || 'aes';        
                WHEN V_COMPARE BETWEEN '3B32' AND '3B9E'        
                THEN        
                     V_RETURN := V_RETURN || 'ai';        
                WHEN V_COMPARE BETWEEN '3BA0' AND '3BFE'        
                THEN        
                     V_RETURN := V_RETURN || 'an';        
                WHEN V_COMPARE BETWEEN '3C01' AND '3C14'        
                THEN        
                     V_RETURN := V_RETURN || 'ang';        
                WHEN V_COMPARE BETWEEN '3C15' AND '3C82'        
                THEN        
                     V_RETURN := V_RETURN || 'ao';        
                WHEN V_COMPARE BETWEEN '3C84' AND '3CE9'        
                THEN        
                     V_RETURN := V_RETURN || 'ba';        
                WHEN V_COMPARE BETWEEN '3CED' AND '3D1D'        
                THEN        
                     V_RETURN := V_RETURN || 'bai';        
                WHEN V_COMPARE BETWEEN '3D20' AND '3D64'        
                THEN        
                     V_RETURN := V_RETURN || 'ban';        
                WHEN V_COMPARE BETWEEN '3D66' AND '3DA2'        
                THEN        
                     V_RETURN := V_RETURN || 'bang';        
                WHEN V_COMPARE BETWEEN '3DA4' AND '3E10'        
                THEN        
                     V_RETURN := V_RETURN || 'bao';        
                WHEN V_COMPARE = '3E11'        
                THEN        
                     V_RETURN := V_RETURN || 'be';        
                WHEN V_COMPARE BETWEEN '3E12' AND '3E7A'        
                THEN        
                     V_RETURN := V_RETURN || 'bei';        
                WHEN V_COMPARE BETWEEN '3E7C' AND '3EA0'        
                THEN        
                     V_RETURN := V_RETURN || 'ben';        
                WHEN V_COMPARE BETWEEN '3EA1' AND '3ED5'        
                THEN        
                     V_RETURN := V_RETURN || 'beng';        
                WHEN V_COMPARE BETWEEN '3ED8' AND '3FE9'        
                THEN        
                     V_RETURN := V_RETURN || 'bi';        
                WHEN V_COMPARE BETWEEN '3FEA' AND '4055'        
                THEN        
                     V_RETURN := V_RETURN || 'bian';        
                WHEN V_COMPARE BETWEEN '4058' AND '40AE'        
                THEN        
                     V_RETURN := V_RETURN || 'biao';        
                WHEN V_COMPARE = '4060'        
                THEN        
                     V_RETURN := V_RETURN || 'bia';        
                WHEN V_COMPARE BETWEEN '40B4' AND '40D4'        
                THEN        
                     V_RETURN := V_RETURN || 'bie';        
                WHEN V_COMPARE BETWEEN '40D6' AND '4116'        
                THEN        
                     V_RETURN := V_RETURN || 'bin';        
                WHEN V_COMPARE BETWEEN '4118' AND '4160'        
                THEN        
                     V_RETURN := V_RETURN || 'bing';        
                WHEN V_COMPARE BETWEEN '4161' AND '4224'        
                THEN        
                     V_RETURN := V_RETURN || 'bo';        
                WHEN V_COMPARE BETWEEN '4225' AND '427C'        
                THEN        
                     V_RETURN := V_RETURN || 'bu';        
                WHEN V_COMPARE BETWEEN '427D' AND '4289'        
                THEN        
                     V_RETURN := V_RETURN || 'ca';        
                WHEN V_COMPARE BETWEEN '428C' AND '42B5'        
                THEN        
                     V_RETURN := V_RETURN || 'cai';        
                WHEN V_COMPARE BETWEEN '42B9' AND '430C'        
                THEN        
                     V_RETURN := V_RETURN || 'can';        
                WHEN V_COMPARE BETWEEN '430D' AND '4334'        
                THEN        
                     V_RETURN := V_RETURN || 'cang';        
                WHEN V_COMPARE BETWEEN '4335' AND '435C'        
                THEN        
                     V_RETURN := V_RETURN || 'cao';        
                WHEN V_COMPARE BETWEEN '435D' AND '438C'        
                THEN        
                     V_RETURN := V_RETURN || 'ce';        
                WHEN V_COMPARE BETWEEN '4390' AND '4398'        
                THEN        
                     V_RETURN := V_RETURN || 'cen';        
                WHEN V_COMPARE BETWEEN '439D' AND '43AA'        
                THEN        
                     V_RETURN := V_RETURN || 'ceng';        
                WHEN V_COMPARE = '43AC'        
                THEN        
                     V_RETURN := V_RETURN || 'ceok';        
                WHEN V_COMPARE = '43AE'        
                THEN        
                     V_RETURN := V_RETURN || 'ceom';        
                WHEN V_COMPARE = '43B0'        
                THEN        
                     V_RETURN := V_RETURN || 'ceon';        
                WHEN V_COMPARE = '43B1'        
                THEN        
                     V_RETURN := V_RETURN || 'ceor';        
                WHEN V_COMPARE BETWEEN '43B2' AND '440A'        
                THEN        
                     V_RETURN := V_RETURN || 'cha';        
                WHEN V_COMPARE BETWEEN '440E' AND '442D'        
                THEN        
                     V_RETURN := V_RETURN || 'chai';        
                WHEN V_COMPARE BETWEEN '4431' AND '44E1'        
                THEN        
                     V_RETURN := V_RETURN || 'chan';        
                WHEN V_COMPARE BETWEEN '44E4' AND '4552'        
                THEN        
                     V_RETURN := V_RETURN || 'chang';        
                WHEN V_COMPARE BETWEEN '4554' AND '458E'        
                THEN        
                     V_RETURN := V_RETURN || 'chao';        
                WHEN V_COMPARE BETWEEN '4590' AND '45C8'        
                THEN        
                     V_RETURN := V_RETURN || 'che';        
                WHEN V_COMPARE BETWEEN '45C9' AND '463D'        
                THEN        
                     V_RETURN := V_RETURN || 'chen';        
                WHEN V_COMPARE BETWEEN '463E' AND '46CD'        
                THEN        
                     V_RETURN := V_RETURN || 'cheng';        
                WHEN V_COMPARE BETWEEN '46CE' AND '47A6'        
                THEN        
                     V_RETURN := V_RETURN || 'chi';        
                WHEN V_COMPARE BETWEEN '47A8' AND '47EC'        
                THEN        
                     V_RETURN := V_RETURN || 'chong';        
                WHEN V_COMPARE BETWEEN '47ED' AND '484C'        
                THEN        
                     V_RETURN := V_RETURN || 'chou';        
                WHEN V_COMPARE BETWEEN '484D' AND '48E2'        
                THEN        
                     V_RETURN := V_RETURN || 'chu';        
                WHEN V_COMPARE BETWEEN '48E9' AND '48F4'        
                THEN        
                     V_RETURN := V_RETURN || 'chuai';        
                WHEN V_COMPARE BETWEEN '48F6' AND '4924'        
                THEN        
                     V_RETURN := V_RETURN || 'chuan';        
                WHEN V_COMPARE BETWEEN '4925' AND '4951'        
                THEN        
                     V_RETURN := V_RETURN || 'chuang';        
                WHEN V_COMPARE BETWEEN '4954' AND '496E'        
                THEN        
                     V_RETURN := V_RETURN || 'chui';        
                WHEN V_COMPARE BETWEEN '4971' AND '49C6'        
                THEN        
                     V_RETURN := V_RETURN || 'chun';        
                WHEN V_COMPARE BETWEEN '49C8' AND '49EA'        
                THEN        
                     V_RETURN := V_RETURN || 'chuo';        
                WHEN V_COMPARE BETWEEN '49EC' AND '4A4A'        
                THEN        
                     V_RETURN := V_RETURN || 'ci';        
                WHEN V_COMPARE = '4A50'        
                THEN        
                     V_RETURN := V_RETURN || 'cis';        
                WHEN V_COMPARE BETWEEN '4A51' AND '4AB2'        
                THEN        
                     V_RETURN := V_RETURN || 'cong';        
                WHEN V_COMPARE BETWEEN '4AB4' AND '4ABA'        
                THEN        
                     V_RETURN := V_RETURN || 'cou';        
                WHEN V_COMPARE BETWEEN '4ABC' AND '4AEA'        
                THEN        
                     V_RETURN := V_RETURN || 'cu';        
                WHEN V_COMPARE BETWEEN '4AEE' AND '4B0C'        
                THEN        
                     V_RETURN := V_RETURN || 'cuan';        
                WHEN V_COMPARE BETWEEN '4B0D' AND '4B56'        
                THEN        
                     V_RETURN := V_RETURN || 'cui';        
                WHEN V_COMPARE BETWEEN '4B59' AND '4B6C'        
                THEN        
                     V_RETURN := V_RETURN || 'cun';        
                WHEN V_COMPARE BETWEEN '4B70' AND '4BA9'        
                THEN        
                     V_RETURN := V_RETURN || 'cuo';        
                WHEN V_COMPARE BETWEEN '4BAD' AND '4BFE'        
                THEN        
                     V_RETURN := V_RETURN || 'da';        
                WHEN V_COMPARE BETWEEN '4C00' AND '4C4E'        
                THEN        
                     V_RETURN := V_RETURN || 'dai';        
                WHEN V_COMPARE BETWEEN '4C50' AND '4CDC'        
                THEN        
                     V_RETURN := V_RETURN || 'dan';        
                WHEN V_COMPARE BETWEEN '4CDE' AND '4D26'        
                THEN        
                     V_RETURN := V_RETURN || 'dang';        
                WHEN V_COMPARE BETWEEN '4D28' AND '4D76'        
                THEN        
                     V_RETURN := V_RETURN || 'dao';        
                WHEN V_COMPARE BETWEEN '4D7E' AND '4D8D'        
                THEN        
                     V_RETURN := V_RETURN || 'de';        
                WHEN V_COMPARE = '4D8E'        
                THEN        
                     V_RETURN := V_RETURN || 'dem';        
                WHEN V_COMPARE BETWEEN '4D90' AND '4D91'        
                THEN        
                     V_RETURN := V_RETURN || 'den';        
                WHEN V_COMPARE BETWEEN '4D94' AND '4DC0'        
                THEN        
                     V_RETURN := V_RETURN || 'deng';        
                WHEN V_COMPARE BETWEEN '4DC4' AND '4E8A'        
                THEN        
                     V_RETURN := V_RETURN || 'di';        
                WHEN V_COMPARE = '4E8C'        
                THEN        
                     V_RETURN := V_RETURN || 'dia';        
                WHEN V_COMPARE BETWEEN '4E8D' AND '4EE8'        
                THEN        
                     V_RETURN := V_RETURN || 'dian';        
                WHEN V_COMPARE BETWEEN '4EE9' AND '4F38'        
                THEN        
                     V_RETURN := V_RETURN || 'diao';        
                WHEN V_COMPARE BETWEEN '4F39' AND '4F90'        
                THEN        
                     V_RETURN := V_RETURN || 'die';        
                WHEN V_COMPARE = '4F8D'        
                THEN        
                     V_RETURN := V_RETURN || 'dei';        
                WHEN V_COMPARE = '4F91'        
                THEN        
                     V_RETURN := V_RETURN || 'dim';        
                WHEN V_COMPARE BETWEEN '4F92' AND '4FCD'        
                THEN        
                     V_RETURN := V_RETURN || 'ding';        
                WHEN V_COMPARE BETWEEN '4FCD' AND '4FD4'        
                THEN        
                     V_RETURN := V_RETURN || 'diu';        
                WHEN V_COMPARE BETWEEN '4FD5' AND '5032'        
                THEN        
                     V_RETURN := V_RETURN || 'dong';        
                WHEN V_COMPARE BETWEEN '5034' AND '507C'        
                THEN        
                     V_RETURN := V_RETURN || 'dou';        
                WHEN V_COMPARE = '5044'        
                THEN        
                     V_RETURN := V_RETURN || 'dul';        
                WHEN V_COMPARE BETWEEN '507E' AND '50E9'        
                THEN        
                     V_RETURN := V_RETURN || 'du';        
                WHEN V_COMPARE BETWEEN '50EA' AND '5110'        
                THEN        
                     V_RETURN := V_RETURN || 'duan';        
                WHEN V_COMPARE BETWEEN '5114' AND '514E'        
                THEN        
                     V_RETURN := V_RETURN || 'dui';        
                WHEN V_COMPARE BETWEEN '5152' AND '518D'        
                THEN        
                     V_RETURN := V_RETURN || 'dun';        
                WHEN V_COMPARE = '5160'        
                THEN        
                     V_RETURN := V_RETURN || 'ton';        
                WHEN V_COMPARE BETWEEN '518E' AND '5200'        
                THEN        
                     V_RETURN := V_RETURN || 'duo';        
                WHEN V_COMPARE BETWEEN '5205' AND '52C2'        
                THEN        
                     V_RETURN := V_RETURN || 'e';        
                WHEN V_COMPARE BETWEEN '52C4' AND '52CD'        
                THEN        
                     V_RETURN := V_RETURN || 'en';        
                WHEN V_COMPARE = '52D4'        
                THEN        
                     V_RETURN := V_RETURN || 'eng';        
                WHEN V_COMPARE = '52D5'        
                THEN        
                     V_RETURN := V_RETURN || 'eo';        
                WHEN V_COMPARE = '52D6'        
                THEN        
                     V_RETURN := V_RETURN || 'eol';        
                WHEN V_COMPARE = '52D8'        
                THEN        
                     V_RETURN := V_RETURN || 'eos';        
                WHEN V_COMPARE BETWEEN '52D9' AND '5332'        
                THEN        
                     V_RETURN := V_RETURN || 'er';        
                WHEN V_COMPARE BETWEEN '5334' AND '5366'        
                THEN        
                     V_RETURN := V_RETURN || 'fa';        
                WHEN V_COMPARE BETWEEN '536A' AND '53FA'        
                THEN        
                     V_RETURN := V_RETURN || 'fan';        
                WHEN V_COMPARE BETWEEN '53FD' AND '5438'        
                THEN        
                     V_RETURN := V_RETURN || 'fang';        
                WHEN V_COMPARE BETWEEN '5439' AND '54B2'        
                THEN        
                     V_RETURN := V_RETURN || 'fei';        
                WHEN V_COMPARE BETWEEN '54B4' AND '5528'        
                THEN        
                     V_RETURN := V_RETURN || 'fen';        
                WHEN V_COMPARE BETWEEN '5529' AND '55A9'        
                THEN        
                     V_RETURN := V_RETURN || 'feng';        
                WHEN V_COMPARE BETWEEN '55AA' AND '55AE'        
                THEN        
                     V_RETURN := V_RETURN || 'fo';        
                WHEN V_COMPARE BETWEEN '55B1' AND '55BC'        
                THEN        
                     V_RETURN := V_RETURN || 'fou';        
                WHEN V_COMPARE BETWEEN '55BD' AND '5739'        
                THEN        
                     V_RETURN := V_RETURN || 'fu';        
                WHEN V_COMPARE = '569D'        
                THEN        
                     V_RETURN := V_RETURN || 'm';        
                WHEN V_COMPARE BETWEEN '573C' AND '574C'        
                THEN        
                     V_RETURN := V_RETURN || 'ga';        
                WHEN V_COMPARE BETWEEN '574D' AND '578C'        
                THEN        
                     V_RETURN := V_RETURN || 'gai';        
                WHEN V_COMPARE BETWEEN '578D' AND '57F0'        
                THEN        
                     V_RETURN := V_RETURN || 'gan';        
                WHEN V_COMPARE BETWEEN '57F1' AND '582C'        
                THEN        
                     V_RETURN := V_RETURN || 'gang';        
                WHEN V_COMPARE BETWEEN '582E' AND '5884'        
                THEN        
                     V_RETURN := V_RETURN || 'gao';        
                WHEN V_COMPARE BETWEEN '5885' AND '5905'        
                THEN        
                     V_RETURN := V_RETURN || 'ge';        
                WHEN V_COMPARE = '5906'        
                THEN        
                     V_RETURN := V_RETURN || 'gei';        
                WHEN V_COMPARE BETWEEN '5909' AND '5915'        
                THEN        
                     V_RETURN := V_RETURN || 'gen';        
                WHEN V_COMPARE BETWEEN '5918' AND '594E'        
                THEN        
                     V_RETURN := V_RETURN || 'geng';        
                WHEN V_COMPARE = '5956'        
                THEN        
                     V_RETURN := V_RETURN || 'gib';        
                WHEN V_COMPARE = '5958'        
                THEN        
                     V_RETURN := V_RETURN || 'go';        
                WHEN V_COMPARE BETWEEN '5959' AND '59BA'        
                THEN        
                     V_RETURN := V_RETURN || 'gong';        
                WHEN V_COMPARE BETWEEN '59BD' AND '5A0E'        
                THEN        
                     V_RETURN := V_RETURN || 'gou';        
                WHEN V_COMPARE BETWEEN '5A10' AND '5AB2'        
                THEN        
                     V_RETURN := V_RETURN || 'gu';        
                WHEN V_COMPARE BETWEEN '5AB4' AND '5AE8'        
                THEN        
                     V_RETURN := V_RETURN || 'gua';        
                WHEN V_COMPARE BETWEEN '5AE9' AND '5AF8'        
                THEN        
                     V_RETURN := V_RETURN || 'guai';        
                WHEN V_COMPARE BETWEEN '5AFD' AND '5B5E'        
                THEN        
                     V_RETURN := V_RETURN || 'guan';        
                WHEN V_COMPARE BETWEEN '5B60' AND '5B8C'        
                THEN        
                     V_RETURN := V_RETURN || 'guang';        
                WHEN V_COMPARE BETWEEN '5B8D' AND '5C2E'        
                THEN        
                     V_RETURN := V_RETURN || 'gui';        
                WHEN V_COMPARE = '5BC8'        
                THEN        
                     V_RETURN := V_RETURN || 'kwi';        
                WHEN V_COMPARE BETWEEN '5C30' AND '5C58'        
                THEN        
                     V_RETURN := V_RETURN || 'gun';        
                WHEN V_COMPARE BETWEEN '5C51' AND '5CB6'        
                THEN        
                     V_RETURN := V_RETURN || 'guo';        
                WHEN V_COMPARE BETWEEN '5CB8' AND '5CBD'        
                THEN        
                     V_RETURN := V_RETURN || 'ha';        
                WHEN V_COMPARE BETWEEN '5CC6' AND '5CEC'        
                THEN        
                     V_RETURN := V_RETURN || 'hai';        
                WHEN V_COMPARE = '5CED'        
                THEN        
                     V_RETURN := V_RETURN || 'hal';        
                WHEN V_COMPARE BETWEEN '5CEE' AND '5D99'        
                THEN        
                     V_RETURN := V_RETURN || 'han';        
                WHEN V_COMPARE BETWEEN '5D9D' AND '5DBC'        
                THEN        
                     V_RETURN := V_RETURN || 'hang';        
                WHEN V_COMPARE BETWEEN '5DBE' AND '5E20'        
                THEN        
                     V_RETURN := V_RETURN || 'hao';        
                WHEN V_COMPARE = '5E02'        
                THEN        
                     V_RETURN := V_RETURN || 'ho';        
                WHEN V_COMPARE BETWEEN '5E22' AND '5EC5'        
                THEN        
                     V_RETURN := V_RETURN || 'he';        
                WHEN V_COMPARE BETWEEN '5EC6' AND '5ECE'        
                THEN        
                     V_RETURN := V_RETURN || 'hei';        
                WHEN V_COMPARE BETWEEN '5ED0' AND '5EDC'        
                THEN        
                     V_RETURN := V_RETURN || 'hen';        
                WHEN V_COMPARE BETWEEN '5EDD' AND '5EDC'        
                THEN        
                     V_RETURN := V_RETURN || 'heng';        
                WHEN V_COMPARE = '5F04'        
                THEN        
                     V_RETURN := V_RETURN || 'hol';        
                WHEN V_COMPARE BETWEEN '5F05' AND '5F8D'        
                THEN        
                     V_RETURN := V_RETURN || 'hong';        
                WHEN V_COMPARE BETWEEN '5F8E' AND '5FD2'        
                THEN        
                     V_RETURN := V_RETURN || 'hou';        
                WHEN V_COMPARE BETWEEN '5FD4' AND '60B1'        
                THEN        
                     V_RETURN := V_RETURN || 'hu';        
                WHEN V_COMPARE BETWEEN '60B2' AND '6111'        
                THEN        
                     V_RETURN := V_RETURN || 'hua';        
                WHEN V_COMPARE BETWEEN '6112' AND '612D'        
                THEN        
                     V_RETURN := V_RETURN || 'huai';        
                WHEN V_COMPARE BETWEEN '612E' AND '61C6'        
                THEN        
                     V_RETURN := V_RETURN || 'huan';        
                WHEN V_COMPARE BETWEEN '61CA' AND '624A'        
                THEN        
                     V_RETURN := V_RETURN || 'huang';        
                WHEN V_COMPARE BETWEEN '624C' AND '6344'        
                THEN        
                     V_RETURN := V_RETURN || 'hui';        
                WHEN V_COMPARE BETWEEN '6346' AND '6388'        
                THEN        
                     V_RETURN := V_RETURN || 'hun';        
                WHEN V_COMPARE BETWEEN '638C' AND '63FA'        
                THEN        
                     V_RETURN := V_RETURN || 'huo';        
                WHEN V_COMPARE = '63FD'        
                THEN        
                     V_RETURN := V_RETURN || 'hwa';        
                WHEN V_COMPARE BETWEEN '63FE' AND '6601'        
                THEN        
                     V_RETURN := V_RETURN || 'ji';        
                WHEN V_COMPARE BETWEEN '6604' AND '6691'        
                THEN        
                     V_RETURN := V_RETURN || 'jia';        
                WHEN V_COMPARE BETWEEN '6692' AND '67F8'        
                THEN        
                     V_RETURN := V_RETURN || 'jian';        
                WHEN V_COMPARE BETWEEN '67F9' AND '6860'        
                THEN        
                     V_RETURN := V_RETURN || 'jiang';        
                WHEN V_COMPARE BETWEEN '6862' AND '6930'        
                THEN        
                     V_RETURN := V_RETURN || 'jiao';        
                WHEN V_COMPARE BETWEEN '6931' AND '6A18'        
                THEN        
                     V_RETURN := V_RETURN || 'jie';        
                WHEN V_COMPARE BETWEEN '6A1A' AND '6AC9'        
                THEN        
                     V_RETURN := V_RETURN || 'jin';        
                WHEN V_COMPARE BETWEEN '6ACA' AND '6B65'        
                THEN        
                     V_RETURN := V_RETURN || 'jing';        
                WHEN V_COMPARE BETWEEN '6B66' AND '6B9A'        
                THEN        
                     V_RETURN := V_RETURN || 'jiong';        
                WHEN V_COMPARE BETWEEN '6B9C' AND '6C0C'        
                THEN        
                     V_RETURN := V_RETURN || 'jiu';        
                WHEN V_COMPARE = '6C0D'        
                THEN        
                     V_RETURN := V_RETURN || 'jou';        
                WHEN V_COMPARE BETWEEN '6C0E' AND '6D2A'        
                THEN        
                     V_RETURN := V_RETURN || 'ju';        
                WHEN V_COMPARE BETWEEN '6D2D' AND '6D80'        
                THEN        
                     V_RETURN := V_RETURN || 'juan';        
                WHEN V_COMPARE BETWEEN '6D82' AND '6E28'        
                THEN        
                     V_RETURN := V_RETURN || 'jue';        
                WHEN V_COMPARE BETWEEN '6E2A' AND '6E85'        
                THEN        
                     V_RETURN := V_RETURN || 'jun';        
                WHEN V_COMPARE BETWEEN '6E86' AND '6E92'        
                THEN        
                     V_RETURN := V_RETURN || 'ka';        
                WHEN V_COMPARE BETWEEN '6E94' AND '6EC9'        
                THEN        
                     V_RETURN := V_RETURN || 'kai';        
                WHEN V_COMPARE = '6ECC'        
                THEN        
                     V_RETURN := V_RETURN || 'kal';        
                WHEN V_COMPARE BETWEEN '6ECD' AND '6F00'        
                THEN        
                     V_RETURN := V_RETURN || 'kan';        
                WHEN V_COMPARE BETWEEN '6F02' AND '6F30'        
                THEN        
                     V_RETURN := V_RETURN || 'kang';        
                WHEN V_COMPARE BETWEEN '6F31' AND '6F4D'        
                THEN        
                     V_RETURN := V_RETURN || 'kao';        
                WHEN V_COMPARE BETWEEN '6F50' AND '6FC8'        
                THEN        
                     V_RETURN := V_RETURN || 'ke';        
                WHEN V_COMPARE BETWEEN '6FC9' AND '6FDA'        
                THEN        
                     V_RETURN := V_RETURN || 'ken';        
                WHEN V_COMPARE BETWEEN '6FDC' AND '6FF5'        
                THEN        
                     V_RETURN := V_RETURN || 'keng';        
                WHEN V_COMPARE = '6FFC'        
                THEN        
                     V_RETURN := V_RETURN || 'ki';        
                WHEN V_COMPARE BETWEEN '6FFD' AND '7016'        
                THEN        
                     V_RETURN := V_RETURN || 'kong';        
                WHEN V_COMPARE = '7018'        
                THEN        
                     V_RETURN := V_RETURN || 'kos';        
                WHEN V_COMPARE BETWEEN '7019' AND '703E'        
                THEN        
                     V_RETURN := V_RETURN || 'kou';        
                WHEN V_COMPARE BETWEEN '7041' AND '707A'        
                THEN        
                     V_RETURN := V_RETURN || 'ku';        
                WHEN V_COMPARE BETWEEN '707C' AND '7095'        
                THEN        
                     V_RETURN := V_RETURN || 'kua';        
                WHEN V_COMPARE BETWEEN '709A' AND '70C1'        
                THEN        
                     V_RETURN := V_RETURN || 'kuai';        
                WHEN V_COMPARE BETWEEN '70C2' AND '70D4'        
                THEN        
                     V_RETURN := V_RETURN || 'kuan';        
                WHEN V_COMPARE BETWEEN '70D8' AND '7128'        
                THEN        
                     V_RETURN := V_RETURN || 'kuang';        
                WHEN V_COMPARE BETWEEN '7129' AND '71B1'        
                THEN        
                     V_RETURN := V_RETURN || 'kui';        
                WHEN V_COMPARE BETWEEN '71B2' AND '71FE'        
                THEN        
                     V_RETURN := V_RETURN || 'kun';        
                WHEN V_COMPARE BETWEEN '7200' AND '7226'        
                THEN        
                     V_RETURN := V_RETURN || 'kuo';        
                WHEN V_COMPARE = '7228'        
                THEN        
                     V_RETURN := V_RETURN || 'kweok';        
                WHEN V_COMPARE BETWEEN '722C' AND '726A'        
                THEN        
                     V_RETURN := V_RETURN || 'la';        
                WHEN V_COMPARE BETWEEN '726C' AND '72B5'        
                THEN        
                     V_RETURN := V_RETURN || 'lai';        
                WHEN V_COMPARE BETWEEN '72B9' AND '733C'        
                THEN        
                     V_RETURN := V_RETURN || 'lan';        
                WHEN V_COMPARE BETWEEN '733D' AND '7388'        
                THEN        
                     V_RETURN := V_RETURN || 'lang';        
                WHEN V_COMPARE BETWEEN '7389' AND '73E5'        
                THEN        
                     V_RETURN := V_RETURN || 'lao';        
                WHEN V_COMPARE BETWEEN '73E8' AND '7402'        
                THEN        
                     V_RETURN := V_RETURN || 'le';        
                WHEN V_COMPARE BETWEEN '7404' AND '7485'        
                THEN        
                     V_RETURN := V_RETURN || 'lei';        
                WHEN V_COMPARE BETWEEN '7488' AND '7499'        
                THEN        
                     V_RETURN := V_RETURN || 'leng';        
                WHEN V_COMPARE BETWEEN '749C' AND '7642'        
                THEN        
                     V_RETURN := V_RETURN || 'li';        
                WHEN V_COMPARE BETWEEN '7644' AND '7645'        
                THEN        
                     V_RETURN := V_RETURN || 'lia';        
                WHEN V_COMPARE BETWEEN '7646' AND '76EC'        
                THEN        
                     V_RETURN := V_RETURN || 'lian';        
                WHEN V_COMPARE BETWEEN '76ED' AND '7731'        
                THEN        
                     V_RETURN := V_RETURN || 'liang';        
                WHEN V_COMPARE BETWEEN '7732' AND '7794'        
                THEN        
                     V_RETURN := V_RETURN || 'liao';        
                WHEN V_COMPARE BETWEEN '7795' AND '77E2'        
                THEN        
                     V_RETURN := V_RETURN || 'lie';        
                WHEN V_COMPARE BETWEEN '77E4' AND '785D'        
                THEN        
                     V_RETURN := V_RETURN || 'lin';        
                WHEN V_COMPARE = '77EA'        
                THEN        
                     V_RETURN := V_RETURN || 'len';        
                WHEN V_COMPARE BETWEEN '7860' AND '7904'        
                THEN        
                     V_RETURN := V_RETURN || 'ling';        
                WHEN V_COMPARE BETWEEN '7905' AND '7986'        
                THEN        
                     V_RETURN := V_RETURN || 'liu';        
                WHEN V_COMPARE BETWEEN '7988' AND '7989'        
                THEN        
                     V_RETURN := V_RETURN || 'lo';        
                WHEN V_COMPARE BETWEEN '798A' AND '79FD'        
                THEN        
                     V_RETURN := V_RETURN || 'long';        
                WHEN V_COMPARE BETWEEN '79FE' AND '7A49'        
                THEN        
                     V_RETURN := V_RETURN || 'lou';        
                WHEN V_COMPARE BETWEEN '7A4C' AND '7B4D'        
                THEN        
                     V_RETURN := V_RETURN || 'lu';        
                WHEN V_COMPARE BETWEEN '7B4E' AND '7B80'        
                THEN        
                     V_RETURN := V_RETURN || 'luan';        
                WHEN V_COMPARE BETWEEN '7B81' AND '7BB2'        
                THEN        
                     V_RETURN := V_RETURN || 'lun';        
                WHEN V_COMPARE BETWEEN '7BB5' AND '7C25'        
                THEN        
                     V_RETURN := V_RETURN || 'luo';        
                WHEN V_COMPARE BETWEEN '7C26' AND '7C82'        
                THEN        
                     V_RETURN := V_RETURN || 'lv';        
                WHEN V_COMPARE BETWEEN '7C84' AND '7C98'        
                THEN        
                     V_RETURN := V_RETURN || 'lue';        
                WHEN V_COMPARE BETWEEN '7C9C' AND '7CE4'        
                THEN        
                     V_RETURN := V_RETURN || 'ma';        
                WHEN V_COMPARE BETWEEN '7CE5' AND '7DOC'        
                THEN        
                     V_RETURN := V_RETURN || 'mai';        
                WHEN V_COMPARE BETWEEN '7D11' AND '7D6E'        
                THEN        
                     V_RETURN := V_RETURN || 'man';        
                WHEN V_COMPARE BETWEEN '7D70' AND '7DA9'        
                THEN        
                     V_RETURN := V_RETURN || 'mang';        
                WHEN V_COMPARE BETWEEN '7DAC' AND '7E15'        
                THEN        
                     V_RETURN := V_RETURN || 'mao';        
                WHEN V_COMPARE = '7E0C'        
                THEN        
                     V_RETURN := V_RETURN || 'q';        
                WHEN V_COMPARE BETWEEN '7E18' AND '7E1E'        
                THEN        
                     V_RETURN := V_RETURN || 'me';        
                WHEN V_COMPARE BETWEEN '7E20' AND '7E9A'        
                THEN        
                     V_RETURN := V_RETURN || 'mei';        
                WHEN V_COMPARE BETWEEN '7E9D' AND '7EC1'        
                THEN        
                     V_RETURN := V_RETURN || 'men';        
                WHEN V_COMPARE BETWEEN '7EC2' AND '7F36'        
                THEN        
                     V_RETURN := V_RETURN || 'meng';        
                WHEN V_COMPARE = '7F38'        
                THEN        
                     V_RETURN := V_RETURN || 'meo';        
                WHEN V_COMPARE BETWEEN '7F39' AND '7FE4'        
                THEN        
                     V_RETURN := V_RETURN || 'mi';        
                WHEN V_COMPARE BETWEEN '7FE6' AND '8034'        
                THEN        
                     V_RETURN := V_RETURN || 'mian';        
                WHEN V_COMPARE BETWEEN '8035' AND '805A'        
                THEN        
                     V_RETURN := V_RETURN || 'miao';        
                WHEN V_COMPARE BETWEEN '805C' AND '8081'        
                THEN        
                     V_RETURN := V_RETURN || 'mie';        
                WHEN V_COMPARE BETWEEN '8084' AND '80E4'        
                THEN        
                     V_RETURN := V_RETURN || 'min';        
                WHEN V_COMPARE = '8096'        
                THEN        
                     V_RETURN := V_RETURN || 'lem';        
                WHEN V_COMPARE BETWEEN '80E5' AND '8116'        
                THEN        
                     V_RETURN := V_RETURN || 'ming';        
                WHEN V_COMPARE BETWEEN '8119' AND '811D'        
                THEN        
                     V_RETURN := V_RETURN || 'miu';        
                WHEN V_COMPARE BETWEEN '811E' AND '81A9'        
                THEN        
                     V_RETURN := V_RETURN || 'mo';        
                WHEN V_COMPARE BETWEEN '81AC' AND '81CC'        
                THEN        
                     V_RETURN := V_RETURN || 'mou';        
                WHEN V_COMPARE BETWEEN '81CD' AND '821E'        
                THEN        
                     V_RETURN := V_RETURN || 'mu';        
                WHEN V_COMPARE = '8220'        
                THEN        
                     V_RETURN := V_RETURN || 'myeo';        
                WHEN V_COMPARE = '8221'        
                THEN        
                     V_RETURN := V_RETURN || 'myeon';        
                WHEN V_COMPARE = '8222'        
                THEN        
                     V_RETURN := V_RETURN || 'myeong';        
                WHEN V_COMPARE BETWEEN '8224' AND '8258'        
                THEN        
                     V_RETURN := V_RETURN || 'na';        
                WHEN V_COMPARE BETWEEN '825D' AND '8285'        
                THEN        
                     V_RETURN := V_RETURN || 'nai';        
                WHEN V_COMPARE BETWEEN '8289' AND '82B5'        
                THEN        
                     V_RETURN := V_RETURN || 'nan';        
                WHEN V_COMPARE BETWEEN '82B9' AND '82D0'        
                THEN        
                     V_RETURN := V_RETURN || 'nang';        
                WHEN V_COMPARE BETWEEN '82D1' AND '8311'        
                THEN        
                     V_RETURN := V_RETURN || 'nao';        
                WHEN V_COMPARE BETWEEN '8312' AND '8320'        
                THEN        
                     V_RETURN := V_RETURN || 'ne';        
                WHEN V_COMPARE BETWEEN '8322' AND '8331'        
                THEN        
                     V_RETURN := V_RETURN || 'nei';        
                WHEN V_COMPARE = '8334'        
                THEN        
                     V_RETURN := V_RETURN || 'nem';        
                WHEN V_COMPARE = '8336'        
                THEN        
                     V_RETURN := V_RETURN || 'nen';        
                WHEN V_COMPARE = '8339'        
                THEN        
                     V_RETURN := V_RETURN || 'neng';        
                WHEN V_COMPARE = '833E'        
                THEN        
                     V_RETURN := V_RETURN || 'neus';        
                WHEN V_COMPARE = '8342'        
                THEN        
                     V_RETURN := V_RETURN || 'ngag';        
                WHEN V_COMPARE = '8344'        
                THEN        
                     V_RETURN := V_RETURN || 'ngai';        
                WHEN V_COMPARE = '8345'        
                THEN        
                     V_RETURN := V_RETURN || 'ngam';        
                WHEN V_COMPARE BETWEEN '8346' AND '83B9'        
                THEN        
                     V_RETURN := V_RETURN || 'ni';        
                WHEN V_COMPARE BETWEEN '83BC' AND '83ED'        
                THEN        
                     V_RETURN := V_RETURN || 'nian';        
                WHEN V_COMPARE BETWEEN '83EE' AND '83F5'        
                THEN        
                     V_RETURN := V_RETURN || 'niang';        
                WHEN V_COMPARE BETWEEN '83F8' AND '8414'        
                THEN        
                     V_RETURN := V_RETURN || 'niao';        
                WHEN V_COMPARE BETWEEN '8415' AND '8478'        
                THEN        
                     V_RETURN := V_RETURN || 'nie';        
                WHEN V_COMPARE BETWEEN '8479' AND '8480'        
                THEN        
                     V_RETURN := V_RETURN || 'nin';        
                WHEN V_COMPARE BETWEEN '8481' AND '84B4'        
                THEN        
                     V_RETURN := V_RETURN || 'ning';        
                WHEN V_COMPARE BETWEEN '84B5' AND '84D1'        
                THEN        
                     V_RETURN := V_RETURN || 'niu';        
                WHEN V_COMPARE BETWEEN '84D4' AND '84FA'        
                THEN        
                     V_RETURN := V_RETURN || 'nong';        
                WHEN V_COMPARE = '84E8'        
                THEN        
                     V_RETURN := V_RETURN || 'nung';        
                WHEN V_COMPARE BETWEEN '84FD' AND '850E'        
                THEN        
                     V_RETURN := V_RETURN || 'nou';        
                WHEN V_COMPARE BETWEEN '8511' AND '8522'        
                THEN        
                     V_RETURN := V_RETURN || 'nu';        
                WHEN V_COMPARE BETWEEN '8524' AND '852C'        
                THEN        
                     V_RETURN := V_RETURN || 'nuan';        
                WHEN V_COMPARE = '852D'        
                THEN        
                     V_RETURN := V_RETURN || 'nun';        
                WHEN V_COMPARE BETWEEN '8530' AND '8559'        
                THEN        
                     V_RETURN := V_RETURN || 'nuo';        
                WHEN V_COMPARE BETWEEN '855A' AND '8566'        
                THEN        
                     V_RETURN := V_RETURN || 'nv';        
                WHEN V_COMPARE BETWEEN '856D' AND '8574'        
                THEN        
                     V_RETURN := V_RETURN || 'nue';        
                WHEN V_COMPARE = '8575'        
                THEN        
                     V_RETURN := V_RETURN || 'o';        
                WHEN V_COMPARE = '8579'        
                THEN        
                     V_RETURN := V_RETURN || 'oes';        
                WHEN V_COMPARE = '857A'        
                THEN        
                     V_RETURN := V_RETURN || 'ol';        
                WHEN V_COMPARE = '857C'        
                THEN        
                     V_RETURN := V_RETURN || 'on';        
                WHEN V_COMPARE BETWEEN '857D' AND '85AE'        
                THEN        
                     V_RETURN := V_RETURN || 'ou';        
                WHEN V_COMPARE BETWEEN '85B1' AND '85C9'        
                THEN        
                     V_RETURN := V_RETURN || 'pa';        
                WHEN V_COMPARE BETWEEN '85CA' AND '85E4'        
                THEN        
                     V_RETURN := V_RETURN || 'pai';        
                WHEN V_COMPARE = '85E5'        
                THEN        
                     V_RETURN := V_RETURN || 'pak';        
                WHEN V_COMPARE BETWEEN '85E8' AND '8625'        
                THEN        
                     V_RETURN := V_RETURN || 'pan';        
                WHEN V_COMPARE BETWEEN '8626' AND '8658'        
                THEN        
                     V_RETURN := V_RETURN || 'pang';        
                WHEN V_COMPARE BETWEEN '8659' AND '8688'        
                THEN        
                     V_RETURN := V_RETURN || 'pao';        
                WHEN V_COMPARE BETWEEN '868A' AND '86C5'        
                THEN        
                     V_RETURN := V_RETURN || 'pei';        
                WHEN V_COMPARE BETWEEN '86C8' AND '86D6'        
                THEN        
                     V_RETURN := V_RETURN || 'pen';        
                WHEN V_COMPARE BETWEEN '86D8' AND '8740'        
                THEN        
                     V_RETURN := V_RETURN || 'peng';        
                WHEN V_COMPARE = '8741'        
                THEN        
                     V_RETURN := V_RETURN || 'peol';        
                WHEN V_COMPARE = '8742'        
                THEN        
                     V_RETURN := V_RETURN || 'phas';        
                WHEN V_COMPARE = '8744'        
                THEN        
                     V_RETURN := V_RETURN || 'phdeng';        
                WHEN V_COMPARE = '8745'        
                THEN        
                     V_RETURN := V_RETURN || 'phoi';        
                WHEN V_COMPARE = '8746'        
                THEN        
                     V_RETURN := V_RETURN || 'phos';        
                WHEN V_COMPARE BETWEEN '8748' AND '880D'        
                THEN        
                     V_RETURN := V_RETURN || 'pi';        
                WHEN V_COMPARE BETWEEN '880E' AND '883A'        
                THEN        
                     V_RETURN := V_RETURN || 'pian';        
                WHEN V_COMPARE BETWEEN '883C' AND '8869'        
                THEN        
                     V_RETURN := V_RETURN || 'piao';        
                WHEN V_COMPARE BETWEEN '886D' AND '8879'        
                THEN        
                     V_RETURN := V_RETURN || 'pie';        
                WHEN V_COMPARE BETWEEN '887A' AND '88A0'        
                THEN        
                     V_RETURN := V_RETURN || 'pin';        
                WHEN V_COMPARE BETWEEN '88A1' AND '88EC'        
                THEN        
                     V_RETURN := V_RETURN || 'ping';        
                WHEN V_COMPARE BETWEEN '88F0' AND '8938'        
                THEN        
                     V_RETURN := V_RETURN || 'po';        
                WHEN V_COMPARE BETWEEN '893E' AND '8958'        
                THEN        
                     V_RETURN := V_RETURN || 'pou';        
                WHEN V_COMPARE BETWEEN '895A' AND '895C'        
                THEN        
                     V_RETURN := V_RETURN || 'ppun';        
                WHEN V_COMPARE BETWEEN '895D' AND '89C4'        
                THEN        
                     V_RETURN := V_RETURN || 'pu';        
                WHEN V_COMPARE BETWEEN '89C5' AND '8B3E'        
                THEN        
                     V_RETURN := V_RETURN || 'qi';        
                WHEN V_COMPARE BETWEEN '8B41' AND '8B61'        
                THEN        
                     V_RETURN := V_RETURN || 'qia';        
                WHEN V_COMPARE BETWEEN '8B62' AND '8C54'        
                THEN        
                     V_RETURN := V_RETURN || 'qian';        
                WHEN V_COMPARE BETWEEN '8C5A' AND '8CB4'        
                THEN        
                     V_RETURN := V_RETURN || 'qiang';        
                WHEN V_COMPARE BETWEEN '8CB8' AND '8D3D'        
                THEN        
                     V_RETURN := V_RETURN || 'qiao';        
                WHEN V_COMPARE BETWEEN '8D40' AND '8D7E'        
                THEN        
                     V_RETURN := V_RETURN || 'qie';        
                WHEN V_COMPARE BETWEEN '8D81' AND '8DFA'        
                THEN        
                     V_RETURN := V_RETURN || 'qin';        
                WHEN V_COMPARE BETWEEN '8DFC' AND '8E5D'        
                THEN        
                     V_RETURN := V_RETURN || 'qing';        
                WHEN V_COMPARE BETWEEN '8E5E' AND '8E98'        
                THEN        
                     V_RETURN := V_RETURN || 'qiong';        
                WHEN V_COMPARE BETWEEN '8E9A' AND '8F2A'        
                THEN        
                     V_RETURN := V_RETURN || 'qiu';        
                WHEN V_COMPARE BETWEEN '8F2E' AND '8FE9'        
                THEN        
                     V_RETURN := V_RETURN || 'qu';        
                WHEN V_COMPARE BETWEEN '8FEA' AND '905D'        
                THEN        
                     V_RETURN := V_RETURN || 'quan';        
                WHEN V_COMPARE BETWEEN '905E' AND '9099'        
                THEN        
                     V_RETURN := V_RETURN || 'que';        
                WHEN V_COMPARE BETWEEN '909A' AND '90AA'        
                THEN        
                     V_RETURN := V_RETURN || 'qun';        
                WHEN V_COMPARE BETWEEN '90B0' AND '90B1'        
                THEN        
                     V_RETURN := V_RETURN || 'ra';        
                WHEN V_COMPARE = '90B2'        
                THEN        
                     V_RETURN := V_RETURN || 'ram';        
                WHEN V_COMPARE BETWEEN '90B4' AND '90E5'        
                THEN        
                     V_RETURN := V_RETURN || 'ran';        
                WHEN V_COMPARE BETWEEN '90E6' AND '9104'        
                THEN        
                     V_RETURN := V_RETURN || 'rang';        
                WHEN V_COMPARE BETWEEN '9105' AND '911C'        
                THEN        
                     V_RETURN := V_RETURN || 'rao';        
                WHEN V_COMPARE BETWEEN '911D' AND '9120'        
                THEN        
                     V_RETURN := V_RETURN || 're';        
                WHEN V_COMPARE BETWEEN '9121' AND '9180'        
                THEN        
                     V_RETURN := V_RETURN || 'ren';        
                WHEN V_COMPARE BETWEEN '9181' AND '918D'        
                THEN        
                     V_RETURN := V_RETURN || 'reng';        
                WHEN V_COMPARE BETWEEN '918E' AND '9196'        
                THEN        
                     V_RETURN := V_RETURN || 'ri';        
                WHEN V_COMPARE BETWEEN '9189' AND '91F1'        
                THEN        
                     V_RETURN := V_RETURN || 'rong';        
                WHEN V_COMPARE BETWEEN '91F2' AND '9218'        
                THEN        
                     V_RETURN := V_RETURN || 'rou';        
                WHEN V_COMPARE BETWEEN '9219' AND '9269'        
                THEN        
                     V_RETURN := V_RETURN || 'ru';        
                WHEN V_COMPARE BETWEEN '926C' AND '9292'        
                THEN        
                     V_RETURN := V_RETURN || 'ruan';        
                WHEN V_COMPARE BETWEEN '9294' AND '92BD'        
                THEN        
                     V_RETURN := V_RETURN || 'rui';        
                WHEN V_COMPARE BETWEEN '92BE' AND '92C9'        
                THEN        
                     V_RETURN := V_RETURN || 'run';        
                WHEN V_COMPARE = '92CA'        
                THEN        
                     V_RETURN := V_RETURN || 'rua';        
                WHEN V_COMPARE BETWEEN '92CA' AND '92E4'        
                THEN        
                     V_RETURN := V_RETURN || 'ruo';        
                WHEN V_COMPARE BETWEEN '92E5' AND '9309'        
                THEN        
                     V_RETURN := V_RETURN || 'sa';        
                WHEN V_COMPARE = '930A'        
                THEN        
                     V_RETURN := V_RETURN || 'saeng';        
                WHEN V_COMPARE BETWEEN '930C' AND '9325'        
                THEN        
                     V_RETURN := V_RETURN || 'sai';        
                WHEN V_COMPARE = '9328'        
                THEN        
                     V_RETURN := V_RETURN || 'sal';        
                WHEN V_COMPARE BETWEEN '9329' AND '9355'        
                THEN        
                     V_RETURN := V_RETURN || 'san';        
                WHEN V_COMPARE BETWEEN '9358' AND '936A'        
                THEN        
                     V_RETURN := V_RETURN || 'sang';        
                WHEN V_COMPARE BETWEEN '936C' AND '9391'        
                THEN        
                     V_RETURN := V_RETURN || 'sao';        
                WHEN V_COMPARE BETWEEN '9392' AND '93C5'        
                THEN        
                     V_RETURN := V_RETURN || 'se';        
                WHEN V_COMPARE = '93C6'        
                THEN        
                     V_RETURN := V_RETURN || 'sed';        
                WHEN V_COMPARE BETWEEN '93C8' AND '93CC'        
                THEN        
                     V_RETURN := V_RETURN || 'sen';        
                WHEN V_COMPARE BETWEEN '93CD' AND '93D0'        
                THEN        
                     V_RETURN := V_RETURN || 'seng';        
                WHEN V_COMPARE = '93D1'        
                THEN        
                     V_RETURN := V_RETURN || 'seo';        
                WHEN V_COMPARE = '93D2'        
                THEN        
                     V_RETURN := V_RETURN || 'seon';        
                WHEN V_COMPARE BETWEEN '93D4' AND '941A'        
                THEN        
                     V_RETURN := V_RETURN || 'sha';        
                WHEN V_COMPARE BETWEEN '941D' AND '9428'        
                THEN        
                     V_RETURN := V_RETURN || 'shai';        
                WHEN V_COMPARE BETWEEN '9429' AND '94C1'        
                THEN        
                     V_RETURN := V_RETURN || 'shan';        
                WHEN V_COMPARE BETWEEN '94C2' AND '94EE'        
                THEN        
                     V_RETURN := V_RETURN || 'shang';        
                WHEN V_COMPARE BETWEEN '94F1' AND '952D'        
                THEN        
                     V_RETURN := V_RETURN || 'shao';        
                WHEN V_COMPARE BETWEEN '952E' AND '9571'        
                THEN        
                     V_RETURN := V_RETURN || 'she';        
                WHEN V_COMPARE BETWEEN '9574' AND '9602'        
                THEN        
                     V_RETURN := V_RETURN || 'shen';        
                WHEN V_COMPARE BETWEEN '9604' AND '965C'        
                THEN        
                     V_RETURN := V_RETURN || 'sheng';        
                WHEN V_COMPARE BETWEEN '965E' AND '9786'        
                THEN        
                     V_RETURN := V_RETURN || 'shi';        
                WHEN V_COMPARE BETWEEN '9788' AND '97AE'        
                THEN        
                     V_RETURN := V_RETURN || 'shou';        
                WHEN V_COMPARE BETWEEN '97B0' AND '9878'        
                THEN        
                     V_RETURN := V_RETURN || 'shu';        
                WHEN V_COMPARE BETWEEN '987A' AND '987E'        
                THEN        
                     V_RETURN := V_RETURN || 'shua';        
                WHEN V_COMPARE BETWEEN '9880' AND '988A'        
                THEN        
                     V_RETURN := V_RETURN || 'shuai';        
                WHEN V_COMPARE BETWEEN '988C' AND '9894'        
                THEN        
                     V_RETURN := V_RETURN || 'shuan';        
                WHEN V_COMPARE BETWEEN '9895' AND '98BE'        
                THEN        
                     V_RETURN := V_RETURN || 'shuang';        
                WHEN V_COMPARE BETWEEN '98C0' AND '98D6'        
                THEN        
                     V_RETURN := V_RETURN || 'shui';        
                WHEN V_COMPARE BETWEEN '98DC' AND '98EE'        
                THEN        
                     V_RETURN := V_RETURN || 'shun';        
                WHEN V_COMPARE BETWEEN '98F1' AND '9911'        
                THEN        
                     V_RETURN := V_RETURN || 'shuo';        
                WHEN V_COMPARE BETWEEN '9912' AND '99AD'        
                THEN        
                     V_RETURN := V_RETURN || 'si';        
                WHEN V_COMPARE = '99AE'        
                THEN        
                     V_RETURN := V_RETURN || 'so';        
                WHEN V_COMPARE = '99B0'        
                THEN        
                     V_RETURN := V_RETURN || 'sol';        
                WHEN V_COMPARE BETWEEN '99B1' AND '99F6'        
                THEN        
                     V_RETURN := V_RETURN || 'song';        
                WHEN V_COMPARE BETWEEN '99F8' AND '9A36'        
                THEN        
                     V_RETURN := V_RETURN || 'sou';        
                WHEN V_COMPARE BETWEEN '9A38' AND '9AB6'        
                THEN        
                     V_RETURN := V_RETURN || 'su';        
                WHEN V_COMPARE BETWEEN '9AB8' AND '9AC4'        
                THEN        
                     V_RETURN := V_RETURN || 'suan';        
                WHEN V_COMPARE BETWEEN '9AC5' AND '9B3A'        
                THEN        
                     V_RETURN := V_RETURN || 'sui';        
                WHEN V_COMPARE = '9AF0'        
                THEN        
                     V_RETURN := V_RETURN || 'wie';        
                WHEN V_COMPARE BETWEEN '9B3C' AND '9B62'        
                THEN        
                     V_RETURN := V_RETURN || 'sun';        
                WHEN V_COMPARE BETWEEN '9B65' AND '9BA9'        
                THEN        
                     V_RETURN := V_RETURN || 'suo';        
                WHEN V_COMPARE BETWEEN '9BAA' AND '9C10'        
                THEN        
                     V_RETURN := V_RETURN || 'ta';        
                WHEN V_COMPARE = '9C11'        
                THEN        
                     V_RETURN := V_RETURN || 'tae';        
                WHEN V_COMPARE BETWEEN '9C12' AND '9C59'        
                THEN        
                     V_RETURN := V_RETURN || 'tai';        
                WHEN V_COMPARE BETWEEN '9C5A' AND '9CE0'        
                THEN        
                     V_RETURN := V_RETURN || 'tan';        
                WHEN V_COMPARE BETWEEN '9CE2' AND '9D55'        
                THEN        
                     V_RETURN := V_RETURN || 'tang';        
                WHEN V_COMPARE BETWEEN '9D56' AND '9DB4'        
                THEN        
                     V_RETURN := V_RETURN || 'tao';        
                WHEN V_COMPARE = '9DB6'        
                THEN        
                     V_RETURN := V_RETURN || 'tap';        
                WHEN V_COMPARE BETWEEN '9DB8' AND '9DC6'        
                THEN        
                     V_RETURN := V_RETURN || 'te';        
                WHEN V_COMPARE BETWEEN '9DC8' AND '9DED'        
                THEN        
                     V_RETURN := V_RETURN || 'teng';        
                WHEN V_COMPARE = '9DEE'        
                THEN        
                     V_RETURN := V_RETURN || 'teo';        
                WHEN V_COMPARE = '9DF0'        
                THEN        
                     V_RETURN := V_RETURN || 'teul';        
                WHEN V_COMPARE BETWEEN '9DF1' AND '9E82'        
                THEN        
                     V_RETURN := V_RETURN || 'ti';        
                WHEN V_COMPARE BETWEEN '9E85' AND '9EED'        
                THEN        
                     V_RETURN := V_RETURN || 'tian';        
                WHEN V_COMPARE BETWEEN '9EEE' AND '9F38'        
                THEN        
                     V_RETURN := V_RETURN || 'tiao';        
                WHEN V_COMPARE BETWEEN '9F39' AND '9F56'        
                THEN        
                     V_RETURN := V_RETURN || 'tie';        
                WHEN V_COMPARE BETWEEN '9F59' AND '9FAE'        
                THEN        
                     V_RETURN := V_RETURN || 'ting';        
                WHEN V_COMPARE = '9FB0'        
                THEN        
                     V_RETURN := V_RETURN || 'tol';        
                WHEN V_COMPARE BETWEEN '9FB1' AND 'A015'        
                THEN        
                     V_RETURN := V_RETURN || 'tong';        
                WHEN V_COMPARE BETWEEN 'A016' AND 'A03A'        
                THEN        
                     V_RETURN := V_RETURN || 'tou';        
                WHEN V_COMPARE BETWEEN 'A040' AND 'A0A9'        
                THEN        
                     V_RETURN := V_RETURN || 'tu';        
                WHEN V_COMPARE BETWEEN 'A0AA' AND 'A0D5'        
                THEN        
                     V_RETURN := V_RETURN || 'tuan';        
                WHEN V_COMPARE BETWEEN 'A0D6' AND 'A106'        
                THEN        
                     V_RETURN := V_RETURN || 'tui';        
                WHEN V_COMPARE BETWEEN 'A108' AND 'A131'        
                THEN        
                     V_RETURN := V_RETURN || 'tun';        
                WHEN V_COMPARE BETWEEN 'A134' AND 'A1AE'        
                THEN        
                     V_RETURN := V_RETURN || 'tuo';        
                WHEN V_COMPARE BETWEEN 'A1B0' AND 'A1E8'        
                THEN        
                     V_RETURN := V_RETURN || 'wa';        
                WHEN V_COMPARE BETWEEN 'A1E9' AND 'A1F5'        
                THEN        
                     V_RETURN := V_RETURN || 'wai';        
                WHEN V_COMPARE BETWEEN 'A1F8' AND 'A279'        
                THEN        
                     V_RETURN := V_RETURN || 'wan';        
                WHEN V_COMPARE BETWEEN 'A27A' AND 'A2B9'        
                THEN        
                     V_RETURN := V_RETURN || 'wang';        
                WHEN V_COMPARE BETWEEN 'A2BC' AND 'A408'        
                THEN        
                     V_RETURN := V_RETURN || 'wei';        
                WHEN V_COMPARE BETWEEN 'A40D' AND 'A47C'        
                THEN        
                     V_RETURN := V_RETURN || 'wen';        
                WHEN V_COMPARE BETWEEN 'A47D' AND 'A4A2'        
                THEN        
                     V_RETURN := V_RETURN || 'weng';        
                WHEN V_COMPARE BETWEEN 'A4A4' AND 'A4EA'        
                THEN        
                     V_RETURN := V_RETURN || 'wo';        
                WHEN V_COMPARE BETWEEN 'A4EC' AND 'A5D4'        
                THEN        
                     V_RETURN := V_RETURN || 'wu';        
                WHEN V_COMPARE BETWEEN 'A5D6' AND 'A784'        
                THEN        
                     V_RETURN := V_RETURN || 'xi';        
                WHEN V_COMPARE BETWEEN 'A785' AND 'A7FA'        
                THEN        
                     V_RETURN := V_RETURN || 'xia';        
                WHEN V_COMPARE BETWEEN 'A7FD' AND 'A951'        
                THEN        
                     V_RETURN := V_RETURN || 'xian';        
                WHEN V_COMPARE BETWEEN 'A954' AND 'A9CE'        
                THEN        
                     V_RETURN := V_RETURN || 'xiang';        
                WHEN V_COMPARE BETWEEN 'A9D0' AND 'AA8A'        
                THEN        
                     V_RETURN := V_RETURN || 'xiao';        
                WHEN V_COMPARE BETWEEN 'AA8D' AND 'AB7E'        
                THEN        
                     V_RETURN := V_RETURN || 'xie';        
                WHEN V_COMPARE BETWEEN 'AB80' AND 'ABEE'        
                THEN        
                     V_RETURN := V_RETURN || 'xin';        
                WHEN V_COMPARE BETWEEN 'ABF0' AND 'AC41'        
                THEN        
                     V_RETURN := V_RETURN || 'xing';        
                WHEN V_COMPARE BETWEEN 'AC42' AND 'AC64'        
                THEN        
                     V_RETURN := V_RETURN || 'xiong';        
                WHEN V_COMPARE BETWEEN 'AC65' AND 'ACBA'        
                THEN        
                     V_RETURN := V_RETURN || 'xiu';        
                WHEN V_COMPARE BETWEEN 'ACBC' AND 'AD90'        
                THEN        
                     V_RETURN := V_RETURN || 'xu';        
                WHEN V_COMPARE = 'ACD9'        
                THEN        
                     V_RETURN := V_RETURN || 'chua';        
                WHEN V_COMPARE BETWEEN 'AD91' AND 'AE32'        
                THEN        
                     V_RETURN := V_RETURN || 'xuan';        
                WHEN V_COMPARE BETWEEN 'AE34' AND 'AE89'        
                THEN        
                     V_RETURN := V_RETURN || 'xue';        
                WHEN V_COMPARE BETWEEN 'AE8C' AND 'AF1E'        
                THEN        
                     V_RETURN := V_RETURN || 'xun';        
                WHEN V_COMPARE BETWEEN 'AF20' AND 'AF96'        
                THEN        
                     V_RETURN := V_RETURN || 'ya';        
                WHEN V_COMPARE BETWEEN 'AF98' AND 'B118'        
                THEN        
                     V_RETURN := V_RETURN || 'yan';        
                WHEN V_COMPARE = 'B030'        
                THEN        
                     V_RETURN := V_RETURN || 'eom';        
                WHEN V_COMPARE BETWEEN 'B11A' AND 'B1A8'        
                THEN        
                     V_RETURN := V_RETURN || 'yang';        
                WHEN V_COMPARE BETWEEN 'B1AD' AND 'B275'        
                THEN        
                     V_RETURN := V_RETURN || 'yao';        
                WHEN V_COMPARE BETWEEN 'B276' AND 'B30A'        
                THEN        
                     V_RETURN := V_RETURN || 'ye';        
                WHEN V_COMPARE BETWEEN 'B30D' AND 'B30E'        
                THEN        
                     V_RETURN := V_RETURN || 'yen';        
                WHEN V_COMPARE BETWEEN 'B310' AND 'B594'        
                THEN        
                     V_RETURN := V_RETURN || 'yi';        
                WHEN V_COMPARE = 'B359'        
                THEN        
                     V_RETURN := V_RETURN || 'i';        
                WHEN V_COMPARE BETWEEN 'B596' AND 'B684'        
                THEN        
                     V_RETURN := V_RETURN || 'yin';        
                WHEN V_COMPARE BETWEEN 'B685' AND 'B768'        
                THEN        
                     V_RETURN := V_RETURN || 'ying';        
                WHEN V_COMPARE BETWEEN 'B76C' AND 'B76E'        
                THEN        
                     V_RETURN := V_RETURN || 'yo';        
                WHEN V_COMPARE BETWEEN 'B770' AND 'B7EA'        
                THEN        
                     V_RETURN := V_RETURN || 'yong';        
                WHEN V_COMPARE BETWEEN 'B7EC' AND 'B8B2'        
                THEN        
                     V_RETURN := V_RETURN || 'you';        
                WHEN V_COMPARE BETWEEN 'B8B5' AND 'BA98'        
                THEN        
                     V_RETURN := V_RETURN || 'yu';        
                WHEN V_COMPARE BETWEEN 'BA99' AND 'BB58'        
                THEN        
                     V_RETURN := V_RETURN || 'yuan';        
                WHEN V_COMPARE BETWEEN 'BB59' AND 'BBBE'        
                THEN        
                     V_RETURN := V_RETURN || 'yue';        
                WHEN V_COMPARE BETWEEN 'BBC1' AND 'BC58'        
                THEN        
                     V_RETURN := V_RETURN || 'yun';        
                WHEN V_COMPARE BETWEEN 'BC59' AND 'BC7E'        
                THEN        
                     V_RETURN := V_RETURN || 'za';        
                WHEN V_COMPARE BETWEEN 'BC81' AND 'BCA8'        
                THEN        
                     V_RETURN := V_RETURN || 'zai';        
                WHEN V_COMPARE BETWEEN 'BCAA' AND 'BCEA'        
                THEN        
                     V_RETURN := V_RETURN || 'zan';        
                WHEN V_COMPARE BETWEEN 'BCEE' AND 'BD0A'        
                THEN        
                     V_RETURN := V_RETURN || 'zang';        
                WHEN V_COMPARE BETWEEN 'BD0C' AND 'BD46'        
                THEN        
                     V_RETURN := V_RETURN || 'zao';        
                WHEN V_COMPARE BETWEEN 'BD48' AND 'BD99'        
                THEN        
                     V_RETURN := V_RETURN || 'ze';        
                WHEN V_COMPARE BETWEEN 'BD9A' AND 'BDA2'        
                THEN        
                     V_RETURN := V_RETURN || 'zei';        
                WHEN V_COMPARE BETWEEN 'BDA5' AND 'BDAC'        
                THEN        
                     V_RETURN := V_RETURN || 'zen';        
                WHEN V_COMPARE BETWEEN 'BDAD' AND 'BDCC'        
                THEN        
                     V_RETURN := V_RETURN || 'zeng';        
                WHEN V_COMPARE BETWEEN 'BDCE' AND 'BE40'        
                THEN        
                     V_RETURN := V_RETURN || 'zha';        
                WHEN V_COMPARE = 'BDF8'        
                THEN        
                     V_RETURN := V_RETURN || 'gad';        
                WHEN V_COMPARE BETWEEN 'BE41' AND 'BE62'        
                THEN        
                     V_RETURN := V_RETURN || 'zhai';        
                WHEN V_COMPARE BETWEEN 'BE65' AND 'BEF4'        
                THEN        
                     V_RETURN := V_RETURN || 'zhan';        
                WHEN V_COMPARE BETWEEN 'BEF6' AND 'BF3E'        
                THEN        
                     V_RETURN := V_RETURN || 'zhang';        
                WHEN V_COMPARE BETWEEN 'BF40' AND 'BF8C'        
                THEN        
                     V_RETURN := V_RETURN || 'zhao';        
                WHEN V_COMPARE BETWEEN 'BF8E' AND 'BFF8'        
                THEN        
                     V_RETURN := V_RETURN || 'zhe';        
                WHEN V_COMPARE BETWEEN 'BFF9' AND 'C0B2'        
                THEN        
                     V_RETURN := V_RETURN || 'zhen';        
                WHEN V_COMPARE BETWEEN 'C0B4' AND 'C11E'        
                THEN        
                     V_RETURN := V_RETURN || 'zheng';        
                WHEN V_COMPARE BETWEEN 'C122' AND 'C2C4'        
                THEN        
                     V_RETURN := V_RETURN || 'zhi';        
                WHEN V_COMPARE BETWEEN 'C2C5' AND 'C31A'        
                THEN        
                     V_RETURN := V_RETURN || 'zhong';        
                WHEN V_COMPARE BETWEEN 'C31D' AND 'C39A'        
                THEN        
                     V_RETURN := V_RETURN || 'zhou';        
                WHEN V_COMPARE BETWEEN 'C39C' AND 'C47C'        
                THEN        
                     V_RETURN := V_RETURN || 'zhu';        
                WHEN V_COMPARE BETWEEN 'C47D' AND 'C484'        
                THEN        
                     V_RETURN := V_RETURN || 'zhua';        
                WHEN V_COMPARE BETWEEN 'C485' AND 'C486'        
                THEN        
                     V_RETURN := V_RETURN || 'zhuai';        
                WHEN V_COMPARE BETWEEN 'C488' AND 'C4C0'        
                THEN        
                     V_RETURN := V_RETURN || 'zhuan';        
                WHEN V_COMPARE BETWEEN 'C4C2' AND 'C4E5'        
                THEN        
                     V_RETURN := V_RETURN || 'zhuang';        
                WHEN V_COMPARE BETWEEN 'C4E6' AND 'C51C'        
                THEN        
                     V_RETURN := V_RETURN || 'zhui';        
                WHEN V_COMPARE BETWEEN 'C51D' AND 'C530'        
                THEN        
                     V_RETURN := V_RETURN || 'zhun';        
                WHEN V_COMPARE BETWEEN 'C534' AND 'C5A5'        
                THEN        
                     V_RETURN := V_RETURN || 'zhuo';        
                WHEN V_COMPARE BETWEEN 'C5A8' AND 'C648'        
                THEN        
                     V_RETURN := V_RETURN || 'zi';        
                WHEN V_COMPARE = 'C64A'        
                THEN        
                     V_RETURN := V_RETURN || 'zo';        
                WHEN V_COMPARE BETWEEN 'C64C' AND 'C6B5'        
                THEN        
                     V_RETURN := V_RETURN || 'zong';        
                WHEN V_COMPARE BETWEEN 'C6B6' AND 'C6D6'        
                THEN        
                     V_RETURN := V_RETURN || 'zou';        
                WHEN V_COMPARE BETWEEN 'C6E1' AND 'C714'        
                THEN        
                     V_RETURN := V_RETURN || 'zu';        
                WHEN V_COMPARE BETWEEN 'C715' AND 'C72D'        
                THEN        
                     V_RETURN := V_RETURN || 'zuan';        
                WHEN V_COMPARE BETWEEN 'C72E' AND 'C75E'        
                THEN        
                     V_RETURN := V_RETURN || 'zui';        
                WHEN V_COMPARE BETWEEN 'C760' AND 'C776'        
                THEN        
                     V_RETURN := V_RETURN || 'zun';        
                WHEN V_COMPARE BETWEEN 'C77A' AND 'C7B4'        
                THEN        
                     V_RETURN := V_RETURN || 'zuo';        
                ELSE        
                    V_RETURN := V_RETURN || V_SUBSTR;        
                END CASE;        
            END LOOP;
        ELSE
            FOR I IN 1 .. V_LENGTH LOOP        
                V_SUBSTR := SUBSTR (P_STR, I, 1);        
                V_COMPARE := FN_NLSSORT (V_SUBSTR);        
                CASE        
                       WHEN V_COMPARE BETWEEN '3B29' AND '3C82'        
                       THEN        
                             V_RETURN := V_RETURN || 'a';        
                       WHEN V_COMPARE BETWEEN '3C84' AND '427C'        
                       THEN        
                             V_RETURN := V_RETURN || 'b';        
                       WHEN V_COMPARE BETWEEN '427D' AND '4BA9'        
                       THEN        
                             V_RETURN := V_RETURN || 'c';        
                       WHEN V_COMPARE BETWEEN '4BAD' AND '5200'        
                       THEN        
                             V_RETURN := V_RETURN || 'd';        
                       WHEN V_COMPARE BETWEEN '5205' AND '5332'        
                       THEN        
                             V_RETURN := V_RETURN || 'e';        
                       WHEN V_COMPARE BETWEEN '5334' AND '5739'        
                       THEN        
                             V_RETURN := V_RETURN || 'f';        
                       WHEN V_COMPARE BETWEEN '573C' AND '5CB6'        
                       THEN        
                             V_RETURN := V_RETURN || 'g';        
                       WHEN V_COMPARE BETWEEN '5CB8' AND '63FA'        
                       THEN        
                             V_RETURN := V_RETURN || 'h';        
                       WHEN V_COMPARE = 'B359'        
                       THEN        
                             V_RETURN := V_RETURN || 'i';        
                       WHEN V_COMPARE BETWEEN '63FE' AND '6E85'        
                       THEN        
                             V_RETURN := V_RETURN || 'j';        
                       WHEN V_COMPARE BETWEEN '5BC8' AND '7226'        
                       THEN        
                             V_RETURN := V_RETURN || 'k';        
                       WHEN V_COMPARE BETWEEN '722C' AND '7C98'        
                       THEN        
                             V_RETURN := V_RETURN || 'l';        
                       WHEN V_COMPARE BETWEEN '569D' AND '821E'        
                       THEN        
                             V_RETURN := V_RETURN || 'm';        
                       WHEN V_COMPARE BETWEEN '8224' AND '8574'        
                       THEN        
                             V_RETURN := V_RETURN || 'n';        
                       WHEN V_COMPARE BETWEEN '8575' AND '85AE'        
                       THEN        
                             V_RETURN := V_RETURN || 'o';        
                       WHEN V_COMPARE BETWEEN '85B1' AND '89C4'        
                       THEN        
                             V_RETURN := V_RETURN || 'p';        
                       WHEN V_COMPARE BETWEEN '7E0C' AND '90AA'        
                       THEN        
                             V_RETURN := V_RETURN || 'q';        
                       WHEN V_COMPARE BETWEEN '90B0' AND '92E4'        
                       THEN        
                             V_RETURN := V_RETURN || 'r';        
                       WHEN V_COMPARE BETWEEN '92E5' AND '9BA9'        
                       THEN        
                             V_RETURN := V_RETURN || 's';        
                       WHEN V_COMPARE BETWEEN '5160' AND 'A1AE'        
                       THEN        
                             V_RETURN := V_RETURN || 't';        
                       WHEN V_COMPARE BETWEEN '9AF0' AND 'A5D4'        
                       THEN        
                             V_RETURN := V_RETURN || 'w';        
                       WHEN V_COMPARE BETWEEN 'A5D6' AND 'AF1E'        
                       THEN        
                             V_RETURN := V_RETURN || 'x';        
                       WHEN V_COMPARE BETWEEN 'AF20' AND 'BC58'        
                       THEN        
                             V_RETURN := V_RETURN || 'y';        
                       WHEN V_COMPARE BETWEEN 'BC59' AND 'C7B4'        
                       THEN        
                             V_RETURN := V_RETURN || 'z';        
                       ELSE        
                             V_RETURN := V_RETURN || V_SUBSTR;        
                  END CASE;        
            END LOOP; 
    END CASE;                
    RETURN V_RETURN;        
END GETPINYIN;
/

