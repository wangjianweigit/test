create PROCEDURE auto_up_down_sku
/**
     自动上架下架处理
     shifan
     2016-03-23
     返回值：取消成功或取消失败消息
     
     自动上架过滤掉停用状态的商品货号/sku zhengfangyuan 2019.02.27
     预售结束无库存自动下架优化          wangpeng 2019.03.13
     去除商品表中预售字段          zhenghui 2019.04.10
  **/
is
  temp_count                   INT := 0; --临时变量
  temp_id                      number:=0;--临时ID
  temp_str                     varchar2(1000);--提醒内容
begin

  --自动下架：查询没有库存  SKU状态为上架状态  商品状态为上架状态  同时：商品不支持缺货订购 没有参加预售活动 没有参加订货会 的sku
   declare cursor down_skus is
        select a.id PRODUCT_SKU,PRODUCT_ITEMNUMBER,PARENT_ID from tbl_product_sku a,tbl_product_info b
            where PRODUCT_GROUP = '尺码' and a.STATE = '上架' and a.product_itemnumber = b.ITEMNUMBER and (b.state='上架' or b.state='暂下架')  and b.IS_OUTSTOCK = '0' 
            and b.product_type in( 0,3)
            and not exists (
                select 1 from TBL_PRODUCT_SKU_STOCK c where a.id = C.PRODUCT_SKU and PRODUCT_TOTAL_COUNT>PRODUCT_ORDER_OCCUPY_COUNT+PRE_ORDER_OCCUPY_COUNT
            )
            and not exists (
                select 1 from TBL_ACTIVITY_INFO a,TBL_ACTIVITY_DETAIL b,TBL_ACTIVITY_PRODUCT c 
                    where  a.id = b.ACTIVITY_ID and a.id = c.ACTIVITY_ID 
                    and a.ACTIVITY_TYPE in ('2','4') and a.ACTIVITY_STATE = '3' and a.STATE = '2' and c.PRODUCT_ITEMNUMBER = b.ITEMNUMBER
                    and sysdate between c.activity_start_DATE and c.activity_END_DATE 
            );
   begin
        for down_sku in down_skus loop

                    --DBMS_OUTPUT.put_line(down_sku.PRODUCT_ITEMNUMBER||'-基础数据-'||down_sku.PRODUCT_SKU);
                   --查询sku是否参加锁定库存的活动，并且活动状态为：未开始或进行中
                   select count(1) into temp_count from TBL_ACTIVITY_INFO a ,TBL_ACTIVITY_DETAIL b,TBL_ACTIVITY_PRODUCT c
                   where a.ACTIVITY_STATE = '3' and a.STATE = '2'
                   and (
                        (sysdate between c.activity_start_DATE and c.activity_END_DATE)
                        or sysdate <= c.activity_start_DATE
                       )
                   and a.id = b.ACTIVITY_ID and b.LOCKED_STOCK = '2'
                   and c.ACTIVITY_ID = a.id
                   and c.product_itemnumber =down_sku.PRODUCT_ITEMNUMBER;

                   --没有参加参加锁定库存的活动
                   if temp_count = 0 then
                          --DBMS_OUTPUT.put_line(down_sku.PRODUCT_ITEMNUMBER||'-------SKU下架--'||down_sku.PRODUCT_SKU);
                          --修改SKU状态为下架
                          update tbl_product_sku set state='下架' where id = down_sku.PRODUCT_SKU;

                          --查询这个SKU的规格是否有上架的SKU
                          select count(1) into temp_count from tbl_product_sku where PARENT_ID=down_sku.PARENT_ID and STATE = '上架';
                          --不存在上架的SKU
                          if temp_count =0 then
                                --DBMS_OUTPUT.put_line(down_sku.PRODUCT_ITEMNUMBER||'--------------规格下架--'||down_sku.PRODUCT_SKU);
                                 --下架规格
                                 update tbl_product_sku set state='下架' where id = down_sku.PARENT_ID;

                                 --查询这个规格的颜色ID
                                 select PARENT_ID into temp_id from tbl_product_sku where id = down_sku.PARENT_ID;

                                 --查询这个规格的颜色是否有上架的规格
                                 select count(1) into temp_count from tbl_product_sku where PARENT_ID = temp_id and STATE = '上架';
                                 if temp_count = 0 then
                                       --DBMS_OUTPUT.put_line(down_sku.PRODUCT_ITEMNUMBER||'---------------------颜色下架--'||down_sku.PRODUCT_SKU);
                                        --下架颜色
                                        update tbl_product_sku set state='下架' where id = temp_id;

                                        --查询货号是否有上架的颜色数据
                                        select count(1) into temp_count from tbl_product_sku where state='上架' and product_itemnumber = down_sku.PRODUCT_ITEMNUMBER and PRODUCT_GROUP='颜色';
                                        if temp_count =0 then
                                            --DBMS_OUTPUT.put_line(down_sku.PRODUCT_ITEMNUMBER||'----------------------------商品下架--'||down_sku.PRODUCT_SKU);
                                            --下架商品主表数据
                                            update tbl_product_info set state='下架' where itemnumber = down_sku.PRODUCT_ITEMNUMBER;
                                        end if;
                                 end if;
                          end if;


                   end if;

        end loop;
    end;

    --自行下架主货号（查询所有sku已下架，但主货号未下架的问题）
     declare cursor down_products is
         SELECT a.PRODUCT_ITEMNUMBER
            FROM tbl_product_sku a ,tbl_product_info b
           WHERE a.PRODUCT_GROUP = '尺码'  and a.PRODUCT_ITEMNUMBER = b.ITEMNUMBER and b.state in ( '上架','暂下架')
        GROUP BY a.PRODUCT_ITEMNUMBER
        having 
        COUNT (CASE WHEN a.STATE = '下架' THEN 1 END) = COUNT (1);
     begin
            for down_product in down_products loop
               --下架商品主表数据
               update tbl_product_info set state='下架' where itemnumber = down_product.PRODUCT_ITEMNUMBER;
            end loop;
    end;

    --自动上架：商品参加订货会或预售活动商品  自动上架
    declare cursor dhh_products is
          select c.PRODUCT_ITEMNUMBER from TBL_ACTIVITY_INFO a,TBL_ACTIVITY_PRODUCT c 
        where  a.id = c.ACTIVITY_ID 
        and a.ACTIVITY_TYPE in ('2','4') and a.ACTIVITY_STATE = '3' and a.STATE = '2' 
        and sysdate between c.activity_start_DATE and c.activity_END_DATE
        and exists(
            select 1
            from tbl_product_info dd
            where dd.itemnumber = c.product_itemnumber 
            and dd.start_stop_state = 1
        );
    begin
            for dhh_product in dhh_products loop
                --商品SKU自动上架，状态为：下架、待上架   则上架
               update tbl_product_sku set state='上架' where state in ( '下架','待上架') and PRODUCT_ITEMNUMBER = dhh_product.PRODUCT_ITEMNUMBER and start_stop_state = 1;
               --商品自动上架
               update tbl_product_info set state='上架' where state in ('下架','暂下架') and ITEMNUMBER = dhh_product.PRODUCT_ITEMNUMBER;
               --商品自动上架
               update tbl_product_info set state='上架',SELL_STATE_DATE=sysdate,FIRST_SELL_STATE_DATE=sysdate,first_sell_sort_value = seq_first_sell_sort_value.nextval where state = '待上架' and ITEMNUMBER = dhh_product.PRODUCT_ITEMNUMBER;
            end loop;
    end;

    --自动上架：查询有库存  SKU状态为下架状态的sku，并上架
    declare cursor up_skus is
          select a.id PRODUCT_SKU,PRODUCT_ITEMNUMBER,PARENT_ID,a.STATIONED_USER_ID from tbl_product_sku a
                    where PRODUCT_GROUP = '尺码' and a.STATE = '下架' and a.start_stop_state = 1
                    and exists (
                        select 1 from TBL_PRODUCT_SKU_STOCK c where a.id = C.PRODUCT_SKU and PRODUCT_TOTAL_COUNT > PRODUCT_ORDER_OCCUPY_COUNT+PRE_ORDER_OCCUPY_COUNT
                    )
                    and exists (
                        select 1 from tbl_product_info tpi where tpi.ITEMNUMBER = a.PRODUCT_ITEMNUMBER and tpi.PRODUCT_TYPE in( 0,3) and tpi.start_stop_state = 1
                    );
    begin
            for up_sku in up_skus loop
                --修改SKU状态为上架
                update tbl_product_sku set state='上架' where state='下架' and id = up_sku.PRODUCT_SKU and start_stop_state = 1;
                --上架规格
                update tbl_product_sku set state='上架' where state='下架' and id = up_sku.PARENT_ID and start_stop_state = 1;

                --查询这个规格的颜色ID
                select PARENT_ID into temp_id from tbl_product_sku where id = up_sku.PARENT_ID;
                --上架颜色
                update tbl_product_sku set state='上架' where state='下架' and id = temp_id and start_stop_state = 1;
                
            end loop;
    end;


    --自动上架：查询参加锁定库存活动   暂时废弃
    /*
    declare cursor hd_products is
        select c.product_itemnumber itemnumber from TBL_ACTIVITY_INFO a ,TBL_SALE_ACTIVITY_INFO b,TBL_ACTIVITY_PRODUCT c
       where a.ACTIVITY_STATE = '3' and a.STATE = '2'
       and (
           (sysdate between c.activity_start_DATE and c.activity_END_DATE)
           or sysdate <= c.activity_start_DATE
       )
       and a.id = b.ACTIVITY_ID and b.LOCKED_STOCK = '2'
       and c.ACTIVITY_ID = a.id 
       and exists(
            select 1
            from tbl_product_info dd
            where dd.itemnumber = c.product_itemnumber 
            and dd.start_stop_state = 1
        );
    begin
        for hd_product in hd_products loop
            --上架SKU表数据
            update tbl_product_sku set state='上架' where state='下架' and PRODUCT_ITEMNUMBER = hd_product.itemnumber  and start_stop_state = 1;
            --商品自动上架
            update tbl_product_info set state='上架' where state != '上架' and ITEMNUMBER = hd_product.itemnumber;
        end loop;
    end;
    */
    

    --自动上架：参加缺货订购
    
    declare cursor outstock_products is
        select itemnumber from tbl_product_info a where a.PRODUCT_TYPE in ( 0,3) and IS_OUTSTOCK = 1  
        and exists (
            select 1 from tbl_product_sku b where state='下架' and b.PRODUCT_ITEMNUMBER = a.itemnumber and b.start_stop_state = 1
        )
        and a.start_stop_state = 1
        ;
    begin
        for outstock_product in outstock_products loop
            --上架SKU表数据
            update tbl_product_sku set state='上架' where state='下架' and PRODUCT_ITEMNUMBER = outstock_product.itemnumber and start_stop_state = 1;
            --商品自动上架
            update tbl_product_info set state='上架' where state='下架' and ITEMNUMBER = outstock_product.itemnumber;
        end loop;
    end;
    
    --上架提醒：有SKU为上架状态，商品为下架状态的商品
    declare cursor up_products is
        select STATIONED_USER_ID,ITEMNUMBER,IS_OUTSTOCK from tbl_product_info a where state='下架' and product_type in ( 0,3)
        and 
        (
            exists (
                select 1 from tbl_product_sku b where a.itemnumber = b.PRODUCT_ITEMNUMBER and a.STATIONED_USER_ID= b.STATIONED_USER_ID and state='上架' and b.start_stop_state = 1
                and exists (select 1 from TBL_PRODUCT_SKU_STOCK c where b.id = C.PRODUCT_SKU and PRODUCT_TOTAL_COUNT > PRODUCT_ORDER_OCCUPY_COUNT)
            )
        )
        and a.start_stop_state = 1;
    begin
            for up_product in up_products loop
                --查询货号是否已经有了上架提醒
                SELECT COUNT(1) INTO temp_count FROM TBL_REMIND_INFO WHERE TYPE = '0' AND STATE = '0' AND key = up_product.ITEMNUMBER;
                IF temp_count < 1 THEN
                   temp_str :='商品【'||up_product.ITEMNUMBER||'】为下架状态，但存在有库存商品，建议上架';
                   /*
                   if up_product.IS_OUTSTOCK = 1 then 
                       temp_str :='商品【'||up_product.ITEMNUMBER||'】为下架状态，但支持缺货订购，可以上架销售';
                   end if;
                   if up_product.is_presale = 1 and up_product.presale_deadline_date>=sysdate then 
                       temp_str :='商品【'||up_product.ITEMNUMBER||'】为下架状态，但当前销售模式，可以上架销售';
                   end if;
                */
                   INSERT INTO TBL_REMIND_INFO(ID,TYPE,TITLE,CONTENT,KEY,STATE,CREATE_DATE,STATIONED_USER_ID,OMS_STATE)
                   VALUES(seq_remind_info.nextval,'0',temp_str,temp_str,
                          up_product.ITEMNUMBER,'0',sysdate,up_product.STATIONED_USER_ID,'0');
                END IF;
            end loop;
    end;


    UPDATE tbl_product_info
       SET SELL_STATE_DATE = (CASE WHEN SELL_STATE_DATE IS NULL THEN SYSDATE ELSE SELL_STATE_DATE END),
           FIRST_SELL_STATE_DATE = (CASE WHEN FIRST_SELL_STATE_DATE IS NULL THEN SYSDATE ELSE FIRST_SELL_STATE_DATE END),
           first_sell_sort_value = (CASE WHEN first_sell_sort_value IS NULL THEN seq_first_sell_sort_value.NEXTVAL ELSE first_sell_sort_value END)
     WHERE     
        product_type = 0
        and state = '上架'
        and (SELL_STATE_DATE IS NULL OR FIRST_SELL_STATE_DATE IS NULL OR first_sell_sort_value IS NULL);


  commit;
exception
  when others then
    rollback;
end auto_up_down_sku;
/

