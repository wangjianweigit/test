create function           is_pre_product
/**
    （新版）通过用户、货号判断商品类型( 1（普通商品） 2:订货会商品)
    wangpeng
    2017-09-28
   显示规则
    返回值：1（普通商品） 2:订货会商品
**/
(
    c_user_name   varchar2,            --用户名
    c_product_itemnumber   varchar2    --商品货号
) return varchar2
 is
     v_site_id number:=0;                           --客户站点id
     v_flag number:=1;                              --商品类型   1（普通商品） 2:订货会商品
     v_count number:=0;                       --临时变量
begin

    --查询用户城市代码和站点
    select site_id into v_site_id from tbl_user_info where user_name = c_user_name;

    /***********************************************订货会相关代码****begin*****wangpeng***2017-09-26****************************************************/
    --查询用户是否为订货会用户并且商品为订货会内的商品
    select count(1) into v_count from tbl_activity_info a,tbl_activity_detail a1,tbl_activity_product c 
        where  a.id = a1.activity_id and a.id = c.activity_id and a.activity_type = '2'
        and a.activity_type = '2' and a.activity_state = '3' and a.state = '2' and c.product_itemnumber = c_product_itemnumber
        and sysdate between c.activity_start_date and c.activity_end_date 
        and  
        case 
           when (a1.user_group_id = 0 or a1.user_group_id is null)
               then 1
           else
               case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and a1.user_group_id = aa.id and  bb.user_id = c_user_name)
               then 
                   1
               else
                   0
               end
        end  = 1
        and exists (select 1 from tbl_activity_site tas where tas.activity_id = a.id and tas.site_id = v_site_id);
    if v_count>0 then 
        v_flag :=2;
    end if;   
   return v_flag;

end is_pre_product;
/

