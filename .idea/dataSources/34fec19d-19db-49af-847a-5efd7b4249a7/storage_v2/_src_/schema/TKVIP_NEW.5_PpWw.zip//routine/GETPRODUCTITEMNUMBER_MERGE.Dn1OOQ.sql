create FUNCTION getProductItemNumber_merge
    /**
    生成定制商品货号
    create by yejingquan 2018-01-02
    update by reid 2019.11.13 私有商品与童库商品货号不允许重复
    update by reid 2019.11.28 生成的定制货号重复问题
    update by reid 2019.12.02 生成的定制货号重复问题BUG修改
  **/
  (c_user_id   IN NUMBER --用户ID
  ) RETURN VARCHAR2 IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  v_count       NUMBER :=0; --临时变量
  v_temp_count  NUMBER :=0; --临时变量
  v_rank_code   NUMBER :=0; --定制用户的排序值
  v_seq_number  NUMBER :=0;
  v_itemnumber  VARCHAR2(50); --货号
BEGIN
  select count(1) into v_count from TBL_PRODUCT_ITEMNUMBER_MERGE where user_id=c_user_id;
  if v_count = 1 then
        while v_itemnumber is null OR v_temp_count <> 0 loop
        begin   
              --获取上次货号生成规则
              select rank_code,seq_number into v_rank_code,v_seq_number from TBL_PRODUCT_ITEMNUMBER_MERGE where user_id=c_user_id;
              --根据规则生成货号
              select 9||lpad(v_rank_code,3,'0')||lpad(v_seq_number,3,'0') into v_itemnumber from dual;
              --判断货号是否被使用
              select 
              (SELECT COUNT(1) FROM TBL_PRODUCT_INFO WHERE ITEMNUMBER = v_itemnumber)
                +
              (SELECT COUNT(1) FROM TBL_PRODUCT_INFO_APPLY WHERE ITEMNUMBER = v_itemnumber)
                +
              (SELECT COUNT(1)  FROM TBL_PVTP_PRODUCT_INFO_APPLY WHERE ITEMNUMBER = v_itemnumber)
                +
              (SELECT COUNT(1)  FROM TBL_PVTP_PRODUCT_INFO WHERE ITEMNUMBER = v_itemnumber)
              INTO v_temp_count
              from dual;
                --货号已被使用，则将序列号自增，递归当前函数
              update TBL_PRODUCT_ITEMNUMBER_MERGE set seq_number = to_number(lpad(v_seq_number+1,3,'0')) where user_id = c_user_id;
        end;
     end loop;
    if v_seq_number = 999 then
        return '';
    end if;
  else
     --第一次生成货号
     select SEQ_USER_RANK_CODE.nextVal into v_rank_code from dual;
     select count(1) into v_temp_count from TBL_PRODUCT_ITEMNUMBER_MERGE where rank_code = v_rank_code;
     while v_temp_count = 1 loop
        begin   
            select SEQ_USER_RANK_CODE.nextVal into v_rank_code from dual;
            select count(1) into v_temp_count from TBL_PRODUCT_ITEMNUMBER_MERGE where rank_code = v_rank_code;
            if v_rank_code = 999 and v_temp_count = 1 then
                return '';
            end if;
        end;
     end loop;
     select 9||lpad(v_rank_code,3,'0')||lpad(v_seq_number+1,3,'0') into v_itemnumber from dual;
     insert into TBL_PRODUCT_ITEMNUMBER_MERGE (USER_ID,RANK_CODE,SEQ_NUMBER) values(c_user_id,v_rank_code,1);
  end if;
  COMMIT;
  RETURN v_itemnumber;
EXCEPTION
 WHEN OTHERS THEN
  rollback;
  return '';
END getProductItemNumber_merge;
/

