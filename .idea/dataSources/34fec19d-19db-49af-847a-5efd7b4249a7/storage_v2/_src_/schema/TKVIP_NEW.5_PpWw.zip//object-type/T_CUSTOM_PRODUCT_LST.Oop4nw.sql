create TYPE           T_CUSTOM_PRODUCT_LST                                                                            
AS TABLE OF T_CUSTOM_PRODUCT
/

