create FUNCTION getSku_User_SalePrice_NoHd
/**
    （新版）定制商品价格（普通定制价）
    wangpeng
    2018-01-31
    修改：2018-08-16，特殊折扣支持入驻商会员服务费折扣  for wangpeng
    修改：2018-12-25   update  for wangpeng  支持新老商品不同费率计算
    修改：2019-01-09   update  for wangpeng  支持私有站特殊价格计算
    修改：2019-09-05   update  for wangpeng  支持新老商品不同费率计算 针对2019-09-15新费率调整
    返回值：商品商品定制价（不使用会员卡）
**/
(
    c_user_name   varchar2,         --用户名
    c_product_sku_id   number       --商品SKUID 
) return number
 is
     v_product_prize number:=0;             --需要返回的商品价格
     v_user_id number:=0;                   --用户ID
     v_product_itemnumber   varchar2(50);   --商品货号
     v_hy_discount number:=1;               --会员等级折扣
     v_site_discount number:=1;             --站点折扣
     v_ts_discount number:=1;               --特殊价折扣
     v_hyfwf_discount number :=1 ;          --会员服务费折扣率,站点或会员等级折扣
     v_site_id number:=0;                   --会员站点
     v_ts_flag number:=-1;                  --是否有特殊价  -1为没有   非-1为有特殊价
     
          
     v_product_prize_cost number:=0;                 --商品报价
     v_product_sale_prize number:=0;                 --应售价
     v_member_service_rate number:=0;                --会员服务费比例-汇总
     v_member_service_rate_rzs number:=0;            --会员服务费比例-入驻商
     v_member_service_rate_qj number:=0;             --会员服务费比例-全局
     v_member_service_money_rzs number:=0;           --会员服务费-入驻商
     v_member_service_money_qj number:=0;            --会员服务费-全局
     v_product_create_date date;                                             --商品创建时间                          --界线新加配置
     v_sys_line date:=to_date('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置
     v_sys_line2 date:=to_date('2019-09-15 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置  针对2019-09-15新费率调整
     v_sys_default_hy_dis number := 0.7;                                     --新注册会员老商品采用默认费率折扣      --界线新加配置
     
     v_product_type number:=0;                        --商品类型（0：普通商品，1：定制商品，2：菜鸟商品，3：私有平台商品）   --私有平台特殊价格新加配置
     v_sta_user_spec_pr_temp_id number:=-1;           --用户特殊价格模板                                                     --私有平台特殊价格新加配置
     v_product_type_id number:=0;                     --商品分类                                                             --私有平台特殊价格新加配置
     v_product_specs_id number :=0;                   --商品规格ID                                                           --私有平台特殊价格新加配置
     v_product_specs varchar2(500);                   --商品规格名称                                                         --私有平台特殊价格新加配置
     v_off_price number :=0;                          --优惠金额                                                             --私有平台特殊价格新加配置
     v_is_show_userprice     number :=0;              --是否可见价格 1.可见 0.不可见
BEGIN
    select is_show_userprice(c_user_name) into v_is_show_userprice from dual;
    if v_is_show_userprice = 0 then
        v_product_prize := 9999;
        return v_product_prize;
    end if;
    
    /*************************商品新老计费费率控制*********begin**********************/
    select a.create_date,a.product_type,a.product_type_id into v_product_create_date,v_product_type,v_product_type_id from tbl_product_info a,tbl_product_sku b where b.id = c_product_sku_id  and a.ITEMNUMBER = b.PRODUCT_ITEMNUMBER and rownum<2;
    if v_product_create_date < v_sys_line then
        --查询入驻商会员服务费比例-老费率
        select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RATE where STATIONED_USER_ID = (
            select STATIONED_USER_ID from tbl_product_sku where id = c_product_sku_id and rownum<2
        );
    end if;
    /*************************商品新老计费费率控制*********end**********************/

   --查询全局会员服务费比例
   --select member_service_rate into v_member_service_rate_qj from TBL_SYS_CONFIG where id = 1;

    if v_product_create_date >= v_sys_line then
       --查询入驻商会员服务费比例-按当前费率计算
        select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_USER_INFO where id = (
            select STATIONED_USER_ID from tbl_product_sku where id = c_product_sku_id
        );
    end if;

        
    /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
    if v_sys_line2 > v_product_create_date and v_product_create_date >= v_sys_line then
        --查询入驻商会员服务费比例-老费率2次调整
        select nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RAT2 where STATIONED_USER_ID = (
            select STATIONED_USER_ID from tbl_product_sku where id = c_product_sku_id and rownum<2
        );
    end if;
    /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/

   --查询SKU基本信息
   select product_itemnumber,product_prize_cost,parent_id,product_specs into v_product_itemnumber,v_product_prize_cost,v_product_specs_id,v_product_specs from tbl_product_sku where product_group = '尺码' and id = c_product_sku_id ;

   --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
   v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;

   --计算应销售价
   v_product_sale_prize:=v_product_prize_cost/(1-v_member_service_rate);

    
   --计算入驻商会员服务费 = 应销售价*入驻商会员服务费比例
   v_member_service_money_rzs := v_product_sale_prize * v_member_service_rate_rzs;
        
   --计算全局会员服务费 = 应销售价*全局会员服务费比例
   v_member_service_money_qj := v_product_sale_prize * v_member_service_rate_qj;

   --查询会员站点
   select nvl(min(site_id),0),nvl(min(id),0),nvl(min(discount),1),nvl(min(sta_user_spec_pr_temp_id),-1) into v_site_id,v_user_id,v_hy_discount,v_sta_user_spec_pr_temp_id from tbl_user_info where user_name = c_user_name;
   
   --(按照老的费率计算)
   if v_product_create_date < v_sys_line then
        select nvl(min(discount),v_sys_default_hy_dis) into v_hy_discount from TBL_USER_OLD_DISCOUNT where user_name = c_user_name;
   end if;
   
   --查询站点折扣
   select nvl(min(discount),1) into v_site_discount from tbl_site_info  where id = v_site_id;
   
   --如果没有查询到用户信息，则返回原价
   if v_user_id=0 then
        v_product_prize:=v_product_sale_prize;
   else
        --特殊价格查询--私有平台商品
       if v_product_type = 3 then
           --用户配置了特殊价格模板
           if v_sta_user_spec_pr_temp_id != -1 then 
               --模板详情的类型 1:按照商品规格设置；2:按照全局规格设置；3:按照商品分类设置
               --如果某规格3个维度都符合，则优先级按商品>规格>分类确定特殊价
                select nvl(min(off_price),0),nvl(min(id),-1) into v_off_price,v_ts_flag 
                from (
                    select b.id,b.off_price from tbl_sta_user_spec_pr_temp a,tbl_sta_user_spec_pr_temp_del b where a.id = b.template_id and a.is_delete = 1 
                    and a.begin_date <= sysdate and a.end_date >=sysdate 
                    and a.id = v_sta_user_spec_pr_temp_id 
                    and (
                        (b.type = 1 and product_specs_id = v_product_specs_id)
                        or
                        (b.type = 2 and product_specs = v_product_specs)
                        or
                        (b.type = 3 and product_type_id = v_product_type_id)
                    )
                    order by b.type asc
                ) where rownum <2;
          end if;
       else 
           --查询特殊价格折扣
           select nvl(min(discount),1),nvl(min(id),-1) into v_ts_discount,v_ts_flag from 
           (
            select a.* from TBL_USER_DISCOUNT_PRODUCT a,tbl_product_sku b ,TBL_USER_DISCOUNT c
            where a.user_name = c_user_name 
              and B.PRODUCT_COLOR = A.PRODUCT_COLOR 
              and B.PRODUCT_SPECS = A.PRODUCT_SPECS
              and B.PRODUCT_ITEMNUMBER = A.PRODUCT_ITEMNUMBER
             and c.state = '3' 
             and C.APPLY_NUMBER = a.APPLY_NUMBER
             AND SYSDATE BETWEEN A.BEGIN_TIME AND a.END_TIME
             AND B.PRODUCT_GROUP = '尺码'
             and B.ID = c_product_sku_id
             order by a.id desc
            ) where rownum <2;
        end if;
       --没有特殊价格
       if v_ts_flag = -1 then 
           
            --获取 会员折扣 或  站点折扣  中最低的
            v_hyfwf_discount:= least(v_hy_discount,v_site_discount);
            
            --按照会员折扣或站点折扣计算  报价 + 入驻商会员服务费 + 全局会员服务费*会员折扣与活动中最低折扣
            v_product_prize := v_product_prize_cost + v_member_service_money_rzs + (v_member_service_money_qj*v_hyfwf_discount);
            
       else
            --特殊价格处理-私有站商品
            if v_product_type = 3 then
                --私有站特殊价格处理 = 应售价 - 优惠价格
                v_product_prize := v_product_sale_prize - v_off_price;
                if v_product_prize  < 0 then
                    v_product_prize := 0 ;
                end if;
            else
                --特殊价格处理-童库平台
                --按照会员特殊折扣计算  销售价= 报价 + 入驻商会员服务费 + （全局会员服务费 * 预设的特殊折扣）--正常使用此公式，临时方案使用第二种公式
                --v_product_prize := v_product_prize_cost+v_member_service_money_rzs+(v_member_service_money_qj*v_ts_discount);
               
                --按照会员特殊折扣计算  销售价= 报价 +（入驻商会员服务费 + 全局会员服务费）* 特殊折扣 
                v_product_prize := v_product_prize_cost + (v_member_service_money_rzs + v_member_service_money_qj) * v_ts_discount;
            end if;
            
       end if;

   end if;

   if ceil(v_product_prize)-v_product_prize<0.5 then
      v_product_prize := ceil(v_product_prize);
   elsif ceil(v_product_prize)-v_product_prize=0 then
      v_product_prize := v_product_prize;
   else 
      v_product_prize := ceil(v_product_prize)-0.5;
   end if;
   
   return v_product_prize;
   
END getSku_User_SalePrice_NoHd;
/

