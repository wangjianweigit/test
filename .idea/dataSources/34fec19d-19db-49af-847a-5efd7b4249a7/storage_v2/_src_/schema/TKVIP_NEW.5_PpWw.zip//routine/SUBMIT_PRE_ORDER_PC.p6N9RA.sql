create procedure           SUBMIT_PRE_ORDER_PC
/**
    提交预付订单(商品定制)
    yejingquan
    2017-12-28
    
    reid 2018.09.26  定制类型拆分为品牌定制、普通定制
    reid 2019.01.22  已经下架的SKU也支持定制

*/
(
    c_user_name            in  number,       --下单用户名
    c_order_product        in  T_ORDER_PRODUCT_LST,
    c_order_source         in  varchar2,     --下单来源
    c_custom_product       in  T_CUSTOM_PRODUCT_LST,
    c_product_money        in  number,       --商品总价
    c_order_remark         in  varchar2,     --备注
    c_mbr_card             in  number,        --是否使用了会员卡优化（1：未使用，2：使用）
    c_pre_order_type       in  number,        --是定制类型    2：品牌定制订单 3：普通定制订单
    output_status          out number,       --返回码：0、失败；1、成功
    output_msg             out varchar2,     --返回信息
    output_earnest_money   out number        --返回预付定金金额
) as
    t_result_count     number := 0;         --数量零时结果
    t_sku_count        number := 0;         --下单SKU数量
    t_index            number := 1;
    v_order_product    T_ORDER_PRODUCT;
    v_custom_product   T_CUSTOM_PRODUCT;

    v_user_manage_name varchar2(50);        --下单用户姓名
    v_ywjl_user_name   varchar2(50);        --业务经理用户名
    v_ywy_user_name    varchar2(50);        --业务员用户名
    v_store_id         number;              --门店ID


    v_product_count    number := 0;         --下单商品总数
    v_product_money    number := 0;         --下单商品总价
    v_order_number     varchar2(50);        --预付订单单号
    v_earnest_money    number := 0;         --预付定金金额
    v_custom_deposit_rate  number := 0;     --预付比例
    v_mbr_card_reduce  number := 0;         --订单在使用会员卡优惠后，减少的金额，没有使用会员卡优化，则为0

begin
    output_status := 0;

    --获取用户信息
    select count(1) into t_result_count from tbl_user_info where id = c_user_name;
    if t_result_count <> 0 then
        select user_manage_name,(select user_name from tbl_sys_user_info where id = i.market_supervision_user_id) as ywjl_user_name,
            (select user_name from tbl_sys_user_info where id = i.referee_user_id) as ywy_user_name,store_id
        into v_user_manage_name,v_ywjl_user_name,v_ywy_user_name,v_store_id from tbl_user_info i where id = c_user_name;
    else
        output_msg := '未找到用户信息，请检查！';
        return;
    end if;


    --集合数据插入临时表
    if c_order_product.count = 0 then
        output_msg := '未选择需要购买的商品，请检查！';
        return;
    end if;
    --如果是【品牌定制】，则一些品牌的信息（如品牌名称、LOGO等必须存在，需要校验）
    --插入定制商品定制信息
    if c_pre_order_type = 2 and c_custom_product.count = 0 then
        output_msg := '未选择定制信息，请检查！';
        return;
    end if;

    for i in c_order_product.first..c_order_product.last loop
        v_order_product := c_order_product(i);
        insert into TMP_ORDER_PRODUCT_SKU(product_sku,count,product_gbcode) values(v_order_product.product_sku, v_order_product.count,v_order_product.product_gbcode);
    end loop;

    t_sku_count := c_order_product.count;

    --校验SKU合法性
    SELECT t_sku_count - COUNT(1) INTO t_result_count FROM TBL_PRODUCT_SKU a,TMP_ORDER_PRODUCT_SKU b WHERE a.ID = b.product_sku AND a.STATE in ('上架','下架');
    IF t_result_count <> 0 THEN
        output_msg:='SKU错误或不允许定制请检查SKU的有效性！';
        RETURN;
    END IF;

    --获取订单号
    v_order_number := '2'||getAutoNumber('D');

    --插入预付订单主表
    INSERT INTO TBL_PRE_ORDER_INFO(
        ID,ORDER_NUMBER,USER_ID,USER_MANAGE_NAME,ORDER_SOURCE,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,PRE_ORDER_TYPE,REMARK,MBR_CARD,MBR_CARD_REDUCE
    )
    VALUES(
        SEQ_PRE_ORDER_INFO.NEXTVAL,v_order_number,c_user_name,v_user_manage_name,c_order_source,
        v_ywjl_user_name,v_ywy_user_name,v_store_id,c_pre_order_type,c_order_remark,c_mbr_card,0
    );

    --插入预付订单详细表
    INSERT INTO TBL_PRE_ORDER_DETAIL
    (
        ID,ORDER_NUMBER,USER_ID,PRODUCT_SKU,PRODUCT_ITEMNUMBER,PRODUCT_COLOR,PRODUCT_SPECS,PRODUCT_SIZE,PRODUCT_COUNT,PRODUCT_UNIT_PRICE,PRODUCT_MONEY,PRODUCT_GBCODE,MBR_CARD_REDUCE
    )
    SELECT
        SEQ_PRE_ORDER_DETAIL.NEXTVAL,v_order_number,c_user_name,ID,PRODUCT_ITEMNUMBER,PRODUCT_COLOR,PRODUCT_SPECS,PRODUCT_GROUP_MEMBER,b.count,
        decode(c_mbr_card,2,getSku_User_VipPrice_NoHd(c_user_name,ID),getSku_User_SalePrice_NoHd(c_user_name,ID)),
        decode(c_mbr_card,2,getSku_User_VipPrice_NoHd(c_user_name,ID) * b.count,getSku_User_SalePrice_NoHd(c_user_name,ID) * b.count),
        b.product_gbcode,
        decode(c_mbr_card,2,getSku_User_SalePrice_NoHd(c_user_name,ID) - getSku_User_VipPrice_NoHd(c_user_name,ID),0)
     FROM TBL_PRODUCT_SKU a,TMP_ORDER_PRODUCT_SKU b
    WHERE a.ID = b.product_sku;

    --获取商品总数
    SELECT SUM(PRODUCT_COUNT) into v_product_count FROM TBL_PRE_ORDER_DETAIL WHERE ORDER_NUMBER = v_order_number;

    --获取商品总价
    SELECT SUM(PRODUCT_MONEY) INTO v_product_money FROM TBL_PRE_ORDER_DETAIL WHERE ORDER_NUMBER = v_order_number;
    
    --获取 订单在使用会员卡优惠后，减少的金额
    SELECT SUM(MBR_CARD_REDUCE*PRODUCT_COUNT) INTO v_mbr_card_reduce FROM TBL_PRE_ORDER_DETAIL WHERE ORDER_NUMBER = v_order_number;
    --校验商品总价是否被篡改
    IF v_product_money <> c_product_money THEN
        output_msg:='商品价格被篡改或商品价格发生变化,订单总价（'||v_product_money||'），请重新下单！';
        ROLLBACK;
        RETURN;
    END IF;

    --获取预付定金比例
    select custom_deposit_rate
      into v_custom_deposit_rate
      from tbl_product_info
     where itemnumber = (SELECT product_itemnumber  FROM TBL_PRE_ORDER_DETAIL WHERE ORDER_NUMBER = v_order_number and rownum < 2);

    --计算预付定金金额
    v_earnest_money := round(v_product_money * v_custom_deposit_rate, 2);

    --更新预付订单主表信息
    UPDATE TBL_PRE_ORDER_INFO SET PRODUCT_MONEY = v_product_money,PRODUCT_COUNT = v_product_count,earnest_money = v_earnest_money,mbr_card_reduce=v_mbr_card_reduce
    WHERE ORDER_NUMBER = v_order_number;

    --记录预付订单商品清分规则
    --入驻商货款
    insert into TBL_PRE_ORDER_DIVIDE(ID,ORDER_NUMBER,PRODUCT_SKU,DIVIDE_TYPE,STATIONED_USER_ID,DIVIDE_MONEY,PRODUCT_PRICE)
    select SEQ_PRE_ORDER_DIVIDE.nextval,
        v_order_number,
        PRODUCT_SKU,
        '1',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        getSku_LiquidationPrice_pre(1,c_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,1,c_mbr_card),
        PRODUCT_UNIT_PRICE
    from TBL_PRE_ORDER_DETAIL where ORDER_NUMBER = v_order_number;

    --平台服务费
    insert into TBL_PRE_ORDER_DIVIDE(ID,ORDER_NUMBER,PRODUCT_SKU,DIVIDE_TYPE,STATIONED_USER_ID,DIVIDE_MONEY,PRODUCT_PRICE)
    select SEQ_PRE_ORDER_DIVIDE.nextval,
        v_order_number,
        PRODUCT_SKU,
        '2',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        getSku_LiquidationPrice_pre(2,c_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,1,c_mbr_card),
        PRODUCT_UNIT_PRICE
    from TBL_PRE_ORDER_DETAIL where ORDER_NUMBER = v_order_number;

    --仓储费
    insert into TBL_PRE_ORDER_DIVIDE(ID,ORDER_NUMBER,PRODUCT_SKU,DIVIDE_TYPE,STATIONED_USER_ID,DIVIDE_MONEY,PRODUCT_PRICE)
    select SEQ_PRE_ORDER_DIVIDE.nextval,
        v_order_number,
        PRODUCT_SKU,
        '3',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        getSku_LiquidationPrice_pre(3,c_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,1,c_mbr_card),
        PRODUCT_UNIT_PRICE
    from TBL_PRE_ORDER_DETAIL where ORDER_NUMBER = v_order_number;

    --入驻商服务费
    insert into TBL_PRE_ORDER_DIVIDE(ID,ORDER_NUMBER,PRODUCT_SKU,DIVIDE_TYPE,STATIONED_USER_ID,DIVIDE_MONEY,PRODUCT_PRICE)
    select SEQ_PRE_ORDER_DIVIDE.nextval,
        v_order_number,
        PRODUCT_SKU,
        '4',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        getSku_LiquidationPrice_pre(4,c_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,1,c_mbr_card),
        PRODUCT_UNIT_PRICE
    from TBL_PRE_ORDER_DETAIL where ORDER_NUMBER = v_order_number;
    
    --入驻商支付服务费
    insert into TBL_PRE_ORDER_DIVIDE(ID,ORDER_NUMBER,PRODUCT_SKU,DIVIDE_TYPE,STATIONED_USER_ID,DIVIDE_MONEY,PRODUCT_PRICE)
    select SEQ_PRE_ORDER_DIVIDE.nextval,
        v_order_number,
        PRODUCT_SKU,
        '5',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        getSku_LiquidationPrice_pre(5,c_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,1,c_mbr_card),
        PRODUCT_UNIT_PRICE
    from TBL_PRE_ORDER_DETAIL where ORDER_NUMBER = v_order_number;
    --如果是【品牌定制】，则一些品牌的信息（如品牌名称、LOGO等必须存在）存储这些信息
    if c_pre_order_type = 2 and c_custom_product.count > 0 then
        for i in c_custom_product.first..c_custom_product.last loop
        v_custom_product := c_custom_product(i);
        insert into tbl_custom_product_info(ID,ORDER_NUMBER,BRAND_NAME,BRAND_LOGO,INSOLE_FLAG,TONGUE_FLAG,TONGUE_LOGO,INSOLE_LOGO,BOX_SUPPLY_FLAG,BOX_SUPPLY_CONTACT_NAME,
        BOX_SUPPLY_CONTACT_PHONENUMBER,BAG_SUPPLY_FLAG,BAG_SUPPLY_CONTACT_NAME,BAG_SUPPLY_CONTACT_PHONENUMBER,TAG_SUPPLY_FLAG,TAG_SUPPLY_CONTACT_NAME,TAG_SUPPLY_CONTACT_PHONENUMBER,CERTIFICATE,REGISTRATION)
        values(seq_custom_product_info.nextVal,v_order_number,v_custom_product.brand_name,v_custom_product.brand_logo,v_custom_product.insole_flag,v_custom_product.tongue_flag,
        v_custom_product.tongue_logo,v_custom_product.insole_logo,v_custom_product.box_supply_flag,v_custom_product.box_supply_contact_name,v_custom_product.box_supply_contact_phonenumber,
        v_custom_product.bag_supply_flag,v_custom_product.bag_supply_contact_name,v_custom_product.bag_supply_contact_phonenumber,v_custom_product.tag_supply_flag,v_custom_product.tag_supply_contact_name,
        v_custom_product.tag_supply_contact_phonenumber,v_custom_product.certificate,v_custom_product.registration);
    end loop;
    end if;
    output_status := '1';
    output_msg := v_order_number;
    output_earnest_money := v_earnest_money;
exception when others then
    output_status := 0;
    output_msg:='提交订单出现未知错误::'||SQLCODE || '::'||SQLERRM||'----';
    ROLLBACK;
end submit_pre_order_pc;
/

