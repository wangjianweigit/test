create FUNCTION           GETSKU_LIQUIDATIONPRICE_PRE_N
/**
    通过用户名获取SKU商品的最终清分价格
    wanghai
    创建：2017-05-16   
    修改：2018-05-29，增加入驻商店铺活动的支持
    修改：2018-08-16，特殊折扣支持入驻商会员服务费折扣  for wangpeng
    价格计算规则：活动价（取所有活动中最低的折扣）、 站点价(按照用户站点折扣计算) 、  会员价（按照会员折扣计算）、  取最低
    修改：2017-09-27 增加传入销售单价参数，增加订货会活动折扣计算
    修改：2018-07-24 增加会员卡销售价格计算，增加会议价计算规则
    修改： 2018-12-25   update  for wangpeng  支持新老商品不同费率计算
    修改：2019-01-09   update  for wangpeng  支持私有站特殊价格计算
    修改：2019-05-30   update by wanghai VIP会员价与特殊价，优先使用VIP会员价
    修改：2019-06-15   update by zhenghui 限时折扣、预售、清尾，服务费折扣统一
    reid  2018.10.25  预售相关功能修改
    返回值：商品实际销售价格
    
**/
(
    C_TYPE  NUMBER,                 --清分类型  1、入驻商收入；2、平台服务费；3、仓储服务费；4、入驻商服务费
    C_USER_NAME   VARCHAR2,         --用户名
    C_PRODUCT_SKU_ID   NUMBER,       --商品SKUID
    C_PRODUCT_PRICE    NUMBER,       --商品单价
    C_CUSTOMIZED    NUMBER,           --是否定制商品：0、非定制商品；1、定制商品
    C_VIP   NUMBER                  --会员价标识
) RETURN NUMBER
 IS
     V_LIQUIDATION_PRIZE NUMBER:=0;         --需要返回的分成价格
     V_PRODUCT_PRIZE NUMBER:=0;             --最终商品价格
     V_USER_ID NUMBER:=0;                   --用户ID
     V_PRODUCT_ITEMNUMBER   VARCHAR2(50);   --商品货号
     V_HD_FLAG NUMBER:=-1;                  --是否参加了活动
     V_HD_DISCOUNT NUMBER:=1;               --活动折扣
     V_HY_DISCOUNT NUMBER:=1;               --会员等级折扣
     V_SITE_DISCOUNT NUMBER:=1;             --站点折扣
     V_TS_DISCOUNT NUMBER:=1;               --特殊价折扣
     V_HYFWF_DISCOUNT NUMBER :=1 ;          --最终会员服务费折扣率
     V_SITE_ID NUMBER:=0;                   --会员站点
     V_STORAGE_CHARGES NUMBER:=0;           --仓储服务费
     V_SERVICE_CHARGES NUMBER:=0;           --入驻商服务费率
     V_HDHY_DISCOUNT NUMBER:=1;             --活动会员折扣
     V_TS_FLAG NUMBER:=-1;                  --是否有特殊价  -1为没有   非-1为有特殊价
     V_PRODUCT_TYPE_ID NUMBER := 0;         --商品类型ID
     V_PRODUCT_TYPE_TYPE CHAR := '1';       --商品类型类别
     
     V_PRODUCT_PRIZE_COST NUMBER:=0;                 --商品报价
     V_PRODUCT_SALE_PRIZE NUMBER:=0;                 --应售价
     V_MEMBER_SERVICE_RATE NUMBER:=0;                --会员服务费比例-汇总
     V_MEMBER_SERVICE_RATE_RZS NUMBER:=0;            --会员服务费比例-入驻商
     V_MEMBER_SERVICE_RATE_QJ NUMBER:=0;             --会员服务费比例-全局
     V_MEMBER_SERVICE_MONEY_RZS NUMBER:=0;           --会员服务费-入驻商
     V_MEMBER_SERVICE_MONEY_QJ NUMBER:=0;            --会员服务费-全局
     V_PRODUCT_CREATE_DATE DATE;                                             --商品创建时间                          --界线新加配置
     V_SYS_LINE DATE:=TO_DATE('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置
     V_SYS_DEFAULT_HY_DIS NUMBER := 0.7;                                     --新注册会员老商品采用默认费率折扣      --界线新加配置
     
     V_PRODUCT_TYPE NUMBER:=0;                        --商品类型（0：普通商品，1：定制商品，2：菜鸟商品，3：私有平台商品）   --私有平台特殊价格新加配置
     V_STA_USER_SPEC_PR_TEMP_ID NUMBER:=-1;           --用户特殊价格模板                                                     --私有平台特殊价格新加配置
     V_PRODUCT_SPECS_ID NUMBER :=0;                   --商品规格ID                                                           --私有平台特殊价格新加配置
     V_PRODUCT_SPECS VARCHAR2(500);                   --商品规格名称                                                         --私有平台特殊价格新加配置
     V_OFF_PRICE NUMBER :=0;                          --优惠金额                                                             --私有平台特殊价格新加配置
     
     V_SERVICE_PAY_CHARGES NUMBER:=0;        --入驻商支付服务费率
     
     V_TS_PRODUCT_SALE_PRIZE NUMBER :=0;              --私有站商品 有特殊价情况下的商品售价      
BEGIN

    /*************************商品新老计费费率控制*********begin**********************/
    SELECT A.CREATE_DATE,A.PRODUCT_TYPE,A.PRODUCT_TYPE_ID INTO V_PRODUCT_CREATE_DATE,V_PRODUCT_TYPE,V_PRODUCT_TYPE_ID FROM TBL_PRODUCT_INFO A,TBL_PRODUCT_SKU B WHERE B.ID = C_PRODUCT_SKU_ID  AND A.ITEMNUMBER = B.PRODUCT_ITEMNUMBER AND ROWNUM<2;
    IF V_PRODUCT_CREATE_DATE < V_SYS_LINE THEN
        --查询入驻商会员服务费比例-老费率
        SELECT NVL(MEMBER_SERVICE_RATE,0),NVL(AREA_SERVICE_RATE,0) INTO V_MEMBER_SERVICE_RATE_RZS,V_MEMBER_SERVICE_RATE_QJ FROM TBL_STATIONED_OLD_SERVICE_RATE WHERE STATIONED_USER_ID = (
            SELECT STATIONED_USER_ID FROM TBL_PRODUCT_SKU WHERE ID = C_PRODUCT_SKU_ID AND ROWNUM<2
        );
    END IF;
    /*************************商品新老计费费率控制*********end**********************/
    
   --查询全局会员服务费比例
   --select member_service_rate into v_member_service_rate_qj from TBL_SYS_CONFIG where id = 1;

    IF V_PRODUCT_CREATE_DATE >= V_SYS_LINE THEN
        --查询入驻商会员服务费比例-按当前费率计算
        SELECT NVL(MEMBER_SERVICE_RATE,0),NVL(AREA_SERVICE_RATE,0),NVL(PAY_SERVICE_RATE,0) INTO V_MEMBER_SERVICE_RATE_RZS,V_MEMBER_SERVICE_RATE_QJ,V_SERVICE_PAY_CHARGES FROM TBL_STATIONED_USER_INFO WHERE ID = (
            SELECT STATIONED_USER_ID FROM TBL_PRODUCT_SKU WHERE ID = C_PRODUCT_SKU_ID
        );
    END IF;
    
    --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
    V_MEMBER_SERVICE_RATE := V_MEMBER_SERVICE_RATE_RZS + V_MEMBER_SERVICE_RATE_QJ;

   --查询SKU基本信息
   SELECT PRODUCT_ITEMNUMBER,PRODUCT_PRIZE_COST,PARENT_ID,PRODUCT_SPECS INTO V_PRODUCT_ITEMNUMBER,V_PRODUCT_PRIZE_COST,V_PRODUCT_SPECS_ID,V_PRODUCT_SPECS FROM TBL_PRODUCT_SKU WHERE PRODUCT_GROUP = '尺码' AND ID = C_PRODUCT_SKU_ID ;

   --计算应销售价
   V_PRODUCT_SALE_PRIZE:=V_PRODUCT_PRIZE_COST/(1-V_MEMBER_SERVICE_RATE);
   
   --计算入驻商会员服务费 = 应销售价*入驻商会员服务费比例
   V_MEMBER_SERVICE_MONEY_RZS := V_PRODUCT_SALE_PRIZE * V_MEMBER_SERVICE_RATE_RZS;
   
   --计算全局会员服务费 = 应销售价*全局会员服务费比例
   V_MEMBER_SERVICE_MONEY_QJ := V_PRODUCT_SALE_PRIZE * V_MEMBER_SERVICE_RATE_QJ;

   --查询会员站点
   SELECT NVL(MIN(SITE_ID),0),NVL(MIN(ID),0),NVL(MIN(DISCOUNT),1),NVL(MIN(STA_USER_SPEC_PR_TEMP_ID),-1) INTO V_SITE_ID,V_USER_ID,V_HY_DISCOUNT,V_STA_USER_SPEC_PR_TEMP_ID FROM TBL_USER_INFO WHERE USER_NAME = C_USER_NAME;
   
   --(按照老的费率计算)
   IF V_PRODUCT_CREATE_DATE < V_SYS_LINE THEN
        SELECT NVL(MIN(DISCOUNT),V_SYS_DEFAULT_HY_DIS) INTO V_HY_DISCOUNT FROM TBL_USER_OLD_DISCOUNT WHERE USER_NAME = C_USER_NAME;
   END IF;
   
   --查询站点折扣
   SELECT NVL(MIN(DISCOUNT),1) INTO V_SITE_DISCOUNT FROM TBL_SITE_INFO  WHERE ID = V_SITE_ID;
   
   --获取商品类型的类别
   SELECT TYPE INTO V_PRODUCT_TYPE_TYPE FROM TBL_DIC_PRODUCT_TYPE WHERE ID = V_PRODUCT_TYPE_ID;
   
   --查询SKU仓储费
   IF V_PRODUCT_TYPE_TYPE = '1' THEN
       SELECT NVL(MAX(STORAGE_CHARGES),0) INTO V_STORAGE_CHARGES FROM TBL_STATIONED_STORAGE_CHARGES SSC,TBL_PRODUCT_SKU PS 
       WHERE SSC.STATIONED_USER_ID(+) = PS.STATIONED_USER_ID AND SSC.PRODUCT_SIZE(+) = PS.PRODUCT_GROUP_MEMBER AND PS.ID = C_PRODUCT_SKU_ID AND TYPE = V_PRODUCT_TYPE_TYPE;
   ELSE
       SELECT NVL(MAX(STORAGE_CHARGES),0) INTO V_STORAGE_CHARGES FROM TBL_STATIONED_STORAGE_CHARGES SSC,TBL_PRODUCT_SKU PS 
       WHERE SSC.STATIONED_USER_ID(+) = PS.STATIONED_USER_ID AND SSC.PRODUCT_SIZE = V_PRODUCT_TYPE_ID AND PS.ID = C_PRODUCT_SKU_ID AND TYPE = V_PRODUCT_TYPE_TYPE;
   END IF;
   
   --查询入驻商服务费
   SELECT NVL(SERVICE_CHARGES,0) INTO V_SERVICE_CHARGES FROM TBL_STATIONED_USER_INFO
   WHERE ID = (SELECT STATIONED_USER_ID FROM TBL_PRODUCT_SKU WHERE ID = C_PRODUCT_SKU_ID);
   
   --如果没有查询到用户信息，则返回原价
   IF V_USER_ID=0 THEN
        V_PRODUCT_PRIZE:=V_PRODUCT_SALE_PRIZE;
   ELSE
         --特殊价格查询--私有平台商品
       IF V_PRODUCT_TYPE = 3 THEN
           --用户配置了特殊价格模板
           IF V_STA_USER_SPEC_PR_TEMP_ID != -1 THEN 
               --模板详情的类型 1:按照商品规格设置；2:按照全局规格设置；3:按照商品分类设置
               --如果某规格3个维度都符合，则优先级按商品>规格>分类确定特殊价
                SELECT NVL(MIN(OFF_PRICE),0),NVL(MIN(ID),-1) INTO V_OFF_PRICE,V_TS_FLAG 
                FROM (
                    SELECT B.ID,B.OFF_PRICE FROM TBL_STA_USER_SPEC_PR_TEMP A,TBL_STA_USER_SPEC_PR_TEMP_DEL B WHERE A.ID = B.TEMPLATE_ID AND A.IS_DELETE = 1 
                    AND A.BEGIN_DATE <= SYSDATE AND A.END_DATE >=SYSDATE 
                    AND A.ID = V_STA_USER_SPEC_PR_TEMP_ID 
                    AND (
                        (B.TYPE = 1 AND PRODUCT_SPECS_ID = V_PRODUCT_SPECS_ID)
                        OR
                        (B.TYPE = 2 AND PRODUCT_SPECS = V_PRODUCT_SPECS)
                        OR
                        (B.TYPE = 3 AND PRODUCT_TYPE_ID = V_PRODUCT_TYPE_ID)
                    )
                    ORDER BY B.TYPE ASC
                ) WHERE ROWNUM <2;
          END IF;
       ELSE 
           --查询特殊价格折扣
           SELECT NVL(MIN(DISCOUNT),1),NVL(MIN(ID),-1) INTO V_TS_DISCOUNT,V_TS_FLAG FROM 
           (
            SELECT A.* FROM TBL_USER_DISCOUNT_PRODUCT A,TBL_PRODUCT_SKU B ,TBL_USER_DISCOUNT C
            WHERE A.USER_NAME = C_USER_NAME 
              AND B.PRODUCT_COLOR = A.PRODUCT_COLOR 
              AND B.PRODUCT_SPECS = A.PRODUCT_SPECS
              AND B.PRODUCT_ITEMNUMBER = A.PRODUCT_ITEMNUMBER
             AND C.STATE = '3' 
             AND C.APPLY_NUMBER = A.APPLY_NUMBER
             AND SYSDATE BETWEEN A.BEGIN_TIME AND A.END_TIME
             AND B.PRODUCT_GROUP = '尺码'
             AND B.ID = C_PRODUCT_SKU_ID
             ORDER BY A.ID DESC
            ) WHERE ROWNUM <2;
        END IF;
       /*********有特殊价格：如果当前商品SKU对于当前用户存在特殊价，则需要先计算出特殊价情况下的售价信息**********/
       IF V_TS_FLAG<>-1 THEN 
       --特殊价格处理-私有站商品
        IF V_PRODUCT_TYPE = 3 THEN
            --私有站特殊价格处理 = 应售价 - 优惠价格
            V_TS_PRODUCT_SALE_PRIZE := V_PRODUCT_SALE_PRIZE - V_OFF_PRICE;
            IF V_TS_PRODUCT_SALE_PRIZE  < 0 THEN
                V_TS_PRODUCT_SALE_PRIZE := 0 ;
            END IF;
        END IF;
       END IF;---特殊价判断结束
        --非定制商品参与活动价
            IF C_CUSTOMIZED = 0 THEN
               --查询参加的活动----订货会、限时折扣、预售活动、清尾活動
               SELECT NVL(MIN(C.ACTIVITY_DISCOUNT),0),NVL(MIN(C.ID),-1),NVL(MIN(A.ACTIVITY_SERVICE_DISCOUNT),1) INTO V_HD_DISCOUNT,V_HD_FLAG,V_HDHY_DISCOUNT FROM TBL_ACTIVITY_INFO A ,TBL_ACTIVITY_DETAIL A1,TBL_ACTIVITY_PRODUCT C 
               WHERE A.ACTIVITY_STATE = '3' AND A.STATE = '2' AND A.ACTIVITY_TYPE='2'
               AND SYSDATE BETWEEN A.BEGIN_DATE AND A.END_DATE 
               AND SYSDATE BETWEEN C.ACTIVITY_START_DATE AND C.ACTIVITY_END_DATE 
               AND A.ID = A1.ACTIVITY_ID
               AND C.ACTIVITY_ID = A.ID 
               AND C.PRODUCT_ITEMNUMBER =V_PRODUCT_ITEMNUMBER
               AND (CASE WHEN (A1.USER_GROUP_ID = 0 OR A1.USER_GROUP_ID IS NULL) THEN 1 ELSE CASE WHEN EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND A1.USER_GROUP_ID = AA.ID AND  BB.USER_ID = C_USER_NAME) THEN 1 ELSE 0 END END) = 1
               AND EXISTS (SELECT 1 FROM TBL_ACTIVITY_SITE TAS WHERE TAS.ACTIVITY_ID = A.ID AND TAS.SITE_ID = V_SITE_ID);
           END IF;
           
           --获取 会员折扣 或  站点折扣  中最低的
           V_HYFWF_DISCOUNT:= LEAST(V_HY_DISCOUNT,V_SITE_DISCOUNT);
           
           --没有参加活动
           IF V_HD_FLAG=-1 THEN  
                
                --是否会员卡
                IF C_VIP = 2 THEN
                    --计算售价
                    V_PRODUCT_PRIZE := V_PRODUCT_PRIZE_COST+V_MEMBER_SERVICE_MONEY_RZS;
                ELSE
                    --计算售价
                    V_HYFWF_DISCOUNT := LEAST(V_HYFWF_DISCOUNT,V_TS_DISCOUNT); --比较特殊折扣是否是最低的折扣
                    V_PRODUCT_PRIZE := V_PRODUCT_PRIZE_COST+V_MEMBER_SERVICE_MONEY_RZS+(V_MEMBER_SERVICE_MONEY_QJ*V_HYFWF_DISCOUNT);
                END IF;
                
           --参加了活动
           ELSE  
                --是否会员卡
                IF C_VIP = 2 THEN
                    --按照活动计算  报价*活动折扣 + 入驻商会员服务费*活动折扣
                    V_PRODUCT_PRIZE := (V_PRODUCT_PRIZE_COST*V_HD_DISCOUNT) + (V_MEMBER_SERVICE_MONEY_RZS*V_HD_DISCOUNT);
                ELSE
                    --获取最低折扣   会员折扣与活动会员折扣与活动折扣中最低
                    V_HYFWF_DISCOUNT := LEAST(V_HYFWF_DISCOUNT,V_HDHY_DISCOUNT,V_HD_DISCOUNT);
                    V_HYFWF_DISCOUNT := LEAST(V_HYFWF_DISCOUNT,V_TS_DISCOUNT); --比较特殊折扣是否是最低的折扣
                    --按照活动计算  报价*活动折扣 + 入驻商会员服务费*活动折扣 + 全局会员服务费*会员折扣与活动会员折扣与活动折扣中最低
                    V_PRODUCT_PRIZE := (V_PRODUCT_PRIZE_COST*V_HD_DISCOUNT) + (V_MEMBER_SERVICE_MONEY_RZS*V_HD_DISCOUNT) + (V_MEMBER_SERVICE_MONEY_QJ*V_HYFWF_DISCOUNT);
                END IF;
           END IF; 
   END IF;
   ---如果私有站的特殊折扣售价不为0，则比较特殊价是否为最低价格
   IF V_TS_PRODUCT_SALE_PRIZE<> 0 THEN
       V_PRODUCT_PRIZE := LEAST(V_PRODUCT_PRIZE,V_TS_PRODUCT_SALE_PRIZE);
   END IF;
   IF CEIL(V_PRODUCT_PRIZE)-V_PRODUCT_PRIZE<0.5 THEN
      V_PRODUCT_PRIZE := CEIL(V_PRODUCT_PRIZE);
   ELSIF CEIL(V_PRODUCT_PRIZE)-V_PRODUCT_PRIZE=0 THEN
      V_PRODUCT_PRIZE := V_PRODUCT_PRIZE;
   ELSE 
      V_PRODUCT_PRIZE := CEIL(V_PRODUCT_PRIZE)-0.5;
   END IF;
   
   --判断价格取活动价还是普通价
   IF V_HD_FLAG=-1 THEN
        --如果报价小于仓储费，则不收取仓储费
        IF V_PRODUCT_PRIZE_COST <= V_STORAGE_CHARGES THEN
            V_STORAGE_CHARGES := 0;
        END IF;
        
        --报价大于售价，按照售价计算入驻商货款
        IF V_PRODUCT_PRIZE_COST > V_PRODUCT_PRIZE THEN
            V_PRODUCT_PRIZE_COST := V_PRODUCT_PRIZE;
        END IF;
       
        --普通价
        IF C_TYPE = 1 THEN
            --入驻商收入 报价-报价*入驻商服务费-仓储服务费
            V_LIQUIDATION_PRIZE := V_PRODUCT_PRIZE_COST - TRUNC(V_PRODUCT_PRIZE_COST*V_SERVICE_CHARGES,2) - TRUNC(V_PRODUCT_PRIZE_COST*V_SERVICE_PAY_CHARGES,2) - V_STORAGE_CHARGES;
        ELSIF C_TYPE = 2 THEN
            --会员服务费 普通价-报价
            V_LIQUIDATION_PRIZE := V_PRODUCT_PRIZE - V_PRODUCT_PRIZE_COST;
        ELSIF C_TYPE = 3 THEN
            --仓储费
            V_LIQUIDATION_PRIZE := V_STORAGE_CHARGES;
        ELSIF C_TYPE = 4 THEN
            --入驻商服务费
            V_LIQUIDATION_PRIZE := TRUNC(V_PRODUCT_PRIZE_COST*V_SERVICE_CHARGES,2);
        ELSIF C_TYPE = 5 THEN
            --入驻商支付服务费
            V_LIQUIDATION_PRIZE := TRUNC(V_PRODUCT_PRIZE_COST*V_SERVICE_PAY_CHARGES,2);
        END IF;
   ELSE
        --如果 报价*活动折扣小于仓储费，则不收取仓储费
        IF V_PRODUCT_PRIZE_COST*V_HD_DISCOUNT <= V_STORAGE_CHARGES THEN
            V_STORAGE_CHARGES := 0;
        END IF;
            
        --活动价
        IF C_TYPE = 1 THEN
            --入驻商收入 报价*活动折扣-报价*活动折扣*入驻商服务费-仓储费
            V_LIQUIDATION_PRIZE := TRUNC(V_PRODUCT_PRIZE_COST*V_HD_DISCOUNT,2) - TRUNC(V_PRODUCT_PRIZE_COST*V_HD_DISCOUNT*V_SERVICE_CHARGES,2) - TRUNC(V_PRODUCT_PRIZE_COST*V_HD_DISCOUNT*V_SERVICE_PAY_CHARGES,2) - V_STORAGE_CHARGES;
        ELSIF C_TYPE = 2 THEN
            --会员服务费 活动价-报价*活动折扣
            V_LIQUIDATION_PRIZE := V_PRODUCT_PRIZE - TRUNC(V_PRODUCT_PRIZE_COST*V_HD_DISCOUNT,2);
        ELSIF C_TYPE = 3 THEN
            V_LIQUIDATION_PRIZE := V_STORAGE_CHARGES;
        ELSIF C_TYPE = 4 THEN
            V_LIQUIDATION_PRIZE := TRUNC(V_PRODUCT_PRIZE_COST*V_HD_DISCOUNT*V_SERVICE_CHARGES,2);
        ELSIF C_TYPE = 5 THEN
            --入驻商支付服务费
            V_LIQUIDATION_PRIZE := TRUNC(V_PRODUCT_PRIZE_COST*V_HD_DISCOUNT*V_SERVICE_PAY_CHARGES,2);
        END IF;
   END IF;
   RETURN V_LIQUIDATION_PRIZE;
END GETSKU_LIQUIDATIONPRICE_PRE_N;
/

