create trigger TRI_PRODUCT_INFO
  before insert or update
  on TBL_PRODUCT_INFO
  for each row
DECLARE
   V_TEMP       VARCHAR2 (50);
   TEMP_COUNT   NUMBER := 0;
BEGIN
   IF    UPDATING ('LAST_UPDATE_TIME')
      OR UPDATING ('LAST_UP_DATE')
      OR UPDATING ('UP_PERIOD')
      OR UPDATING ('WEIGHT_VALUE')
      OR UPDATING ('SORT_VALUE')
      OR UPDATING ('PRODUCT_CONTENT')
      OR UPDATING ('IS_SALE_SORT')
      OR UPDATING ('WITH_CODE_ID')
      OR UPDATING ('FIRST_SELL_STATE_DATE')
      OR UPDATING ('PRODUCT_COUNT')
      OR UPDATING ('PRODUCT_COUNT15')
      OR UPDATING ('PRODUCT_COUNT7')
      OR UPDATING ('PRODUCT_COUNT30')
      OR UPDATING ('PRODUCT_COUNT90')
      OR UPDATING ('IS_NEW')
      OR UPDATING ('IS_HOT')
      OR UPDATING ('STOCK_QML')
      OR UPDATING ('STOCK_COUNT')
      OR UPDATING ('FIRST_SELL_SORT_VALUE')
   THEN
      V_TEMP := '1';
   ELSE
      :NEW.LAST_UPDATE_TIME := SYSDATE + (10 / (24 * 60 * 60));
   END IF;
   IF UPDATING
   THEN
      --检查当前商品上下架状态是否更改 如已更改 则新增聚水谭同步库存数据
      IF (:old.state <> '上架' and :new.state = '上架') or (:old.state = '上架' and :new.state <> '上架')
      THEN
          --定义 聚水谭已关联当前货号的sku数据 游标
          DECLARE
             CURSOR csr_saas_product_sku
             IS
                SELECT temp1.id, temp2.company_id
                  FROM (SELECT ps.id, aps.shop_id
                          FROM tbl_saas_product_sku aps
                               JOIN
                               tbl_product_sku ps
                                  ON     aps.platform_sku_id = ps.id
                                     AND ps.product_itemnumber = :new.itemnumber) temp1
                       JOIN tbl_saas_company_shop temp2 ON temp1.shop_id = temp2.shop_id;

          BEGIN
             FOR product_sku IN csr_saas_product_sku
             LOOP
                -- 获取sku当前未同步数量
                SELECT COUNT (1) INTO TEMP_COUNT FROM TBL_SAAS_STOCK_SYNC WHERE state <> '2' AND sku_id = product_sku.id AND saas_company = product_sku.company_id;

                -- 判断是否存在未同步数据
                IF TEMP_COUNT = 0
                THEN
                   INSERT INTO TBL_SAAS_STOCK_SYNC (id, sku_id, saas_company)
                        VALUES (
                                  SEQ_SAAS_STOCK_SYNC.NEXTVAL,
                                  product_sku.id,
                                  product_sku.company_id);
                END IF;
             END LOOP;
          END;
      END IF;
   END IF;
   IF INSERTING then 
        --判断是否已有对应货号，私有商品共享
        SELECT COUNT (1) INTO TEMP_COUNT FROM TBL_PRODUCT_SALE WHERE ITEMNUMBER = :NEW.ITEMNUMBER;
        if (:NEW.PRODUCT_TYPE is null or :new.PRODUCT_TYPE = 0 or :new.PRODUCT_TYPE = 3) AND TEMP_COUNT = 0 then 
            --插入销量临时表
            insert into TBL_PRODUCT_SALE(ITEMNUMBER) values(:NEW.ITEMNUMBER);
        end if;
   end if;
END;
--3.3私有商家账号表触发器
/

