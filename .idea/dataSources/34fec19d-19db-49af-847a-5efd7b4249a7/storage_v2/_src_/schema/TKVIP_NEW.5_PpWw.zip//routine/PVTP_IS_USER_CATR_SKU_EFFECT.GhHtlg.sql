create FUNCTION PVTP_IS_USER_CATR_SKU_EFFECT
/**
    私有平台专用，用于判断购物车商品是否有效
    reid 2019.09.17 判断普通购物车则的商品SKU是否有效
    以下情况商品会失效
    1、SKU已下架 或者商品下架
    2、商品库存为0,且不可缺货订购
    返回值：0 失效  1：有效
**/
(
    c_stationed_user_id     number,                 --当前访问的私有平台ID（即平台所属私有商家的ID）
    c_user_name             varchar2,               --用户名
    c_product_sku           number,                 --商品SKU ID
    c_warehouse_id          number                  --仓库ID（小仓ID,为0表示不限制仓库）
) return varchar2
 is
     v_count number:=0;                                    --临时变量
     v_activity_type number:=0;                            --商品参加活动的类型 
     v_product_itemnumber varchar2(50);                    --商品货号
     v_productsku_stocks number:=0;                        --库存数量
     v_is_outstock number:=0;                              --是否支持缺货订购 1：支持 0：不支持
BEGIN
    /*****查询仓库对当前用户是否可见*******/
    select count(1) into v_count
    from 
    tbl_site_warehouse t2
    where exists (select 1 from tbl_user_info t1 where t1.user_name = c_user_name and t1.site_id = t2.site_id)
    and t2.warehouse_id = c_warehouse_id;
    ---仓库不可见，直接标记为失效
    IF v_count = 0 THEN
        return 0;
    END IF;
     --判断商品是私有商品还是童库分享的商品
    select count(1) into v_count from TBL_PVTP_PRODUCT_INFO ppi where ppi.stationed_user_id = c_stationed_user_id
    and exists (select 1 from TBL_PVTP_PRODUCT_SKU pps where pps.product_id = ppi.id and pps.id = c_product_sku);
    IF v_count <> 0 THEN
    ---1、SKU已下架 或者商品下架
        SELECT count(1) into v_count FROM TBL_PVTP_PRODUCT_SKU ps WHERE ps.id = c_product_sku AND ps.state = '上架'
        AND exists (select 1 from TBL_PVTP_PRODUCT_INFO pi where pi.itemnumber = ps.product_itemnumber and pi.state in ('上架','暂下架'));
        IF v_count=0 THEN
            RETURN 0;
        END IF;
        --查询商品货号
        SELECT ps.product_itemnumber into v_product_itemnumber FROM TBL_PVTP_PRODUCT_SKU ps WHERE ps.id = c_product_sku;
        --查询库存信息
        select PVTP_GETPRODUCTSKU_STOCKS(c_stationed_user_id,c_product_sku,c_warehouse_id,c_user_name) into v_productsku_stocks from dual;
        select PVTP_IS_OUTSTOCK_PRODUCT_SKU(c_stationed_user_id,c_user_name,v_product_itemnumber,c_product_sku,c_warehouse_id) into v_is_outstock from dual;
    ELSE
        ---1、SKU已下架 或者商品下架
        SELECT count(1) into v_count FROM TBL_PRODUCT_SKU ps WHERE ps.id = c_product_sku AND ps.state = '上架'
        AND exists (
            select 1 from TBL_PRODUCT_INFO pi
            inner join TBL_PVTP_PRODUCT_INFO_REF ppir on pi.itemnumber = ppir.product_itemnumber
            where pi.itemnumber = ps.product_itemnumber and pi.state in ('上架','暂下架')
            and pi.is_private = 1 and ppir.platform_id = c_stationed_user_id and ppir.enabled_flag = 1
        );
        --查询商品货号
        SELECT ps.product_itemnumber into v_product_itemnumber FROM TBL_PRODUCT_SKU ps WHERE ps.id = c_product_sku;
        IF v_count=0 THEN
            RETURN 0;
        END IF;
        --查询库存信息
        select GETPRODUCTSKU_STOCKS(c_product_sku,c_warehouse_id,c_user_name) into v_productsku_stocks from dual;
        select IS_OUTSTOCK_PRODUCT_SKU(c_user_name,v_product_itemnumber,c_product_sku,c_warehouse_id) into v_is_outstock from dual;
    END IF;
    ----dbms_output.put_line('v_productsku_stocks：'||v_productsku_stocks);
    ----dbms_output.put_line('v_is_outstock：'||v_is_outstock);
    IF v_productsku_stocks = 0 and v_is_outstock=0 THEN
        RETURN 0;
    ELSE
        RETURN 1;
   END IF;
END PVTP_IS_USER_CATR_SKU_EFFECT;
/

