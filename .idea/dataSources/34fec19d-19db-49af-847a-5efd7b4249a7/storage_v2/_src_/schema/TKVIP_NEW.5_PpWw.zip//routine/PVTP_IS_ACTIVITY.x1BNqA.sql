create FUNCTION PVTP_IS_ACTIVITY
/**
    
   私有站商品是否参加活动
   返回值：activity_type
        0：未参加活动
        1：正在参加了平台的限时折扣活动
        3：正在参加了私有平台自己的活动
        reid  2019-09-12
**/
(
    c_stationed_user_id  IN  number,    --当前下单私有平台ID（即所属私有商家的ID）
    c_user_name             varchar2,   --用户名
    c_product_itemnumber    varchar2    --商品货号
) return varchar2
 is
    
     v_site_id number:=0;                           --客户站点id
     v_activity_type number:=0;                     --活动类型
     v_activity_id number:=0;                       --活动id
     v_count number:=0;                             --临时变量
     v_activity_count number:=0;                    --临时变量
begin
    /*******判断商品是私有商品还是童库商品**********/
    select count(1) into v_count
    from TBL_PVTP_PRODUCT_INFO ppi
    where ppi.itemnumber = c_product_itemnumber and ppi.stationed_user_id = c_stationed_user_id;
    IF v_count <> 0 then
           ---私有站商品，查询是否参加了店铺活动
           select count(1) into v_count
           from tbl_sta_sale_activity ssa where exists (
                select 1 from tbl_sta_sale_activity_product ssap where
                ssap.activity_id = ssa.id
                and ssap.is_delete = 1
                and ssap.product_itemnumber = c_product_itemnumber
           )
           and ssa.activity_state = 1
           and ssa.end_date >=sysdate
           and ssa.is_delete = 1
           and rownum <=1;
           IF v_count <> 0 THEN
                   select 
                   ssa.id,
                   3 activity_type
                   into v_activity_id,v_activity_type
                   from tbl_sta_sale_activity ssa
                   inner join tbl_sta_sale_activity_product ssap on ssap.activity_id = ssa.id
                   where  ssap.is_delete = 1
                   and ssap.product_itemnumber = c_product_itemnumber
                   and ssa.activity_state = 1
                   and sysdate between ssa.begin_date and ssa.end_date
                   and ssa.is_delete = 1
                   and rownum <=1;
           END IF;
    ELSE 
            --如果商品不是启用状态或者无启用状态的尺码，直接返回，不显示 zhengfangyuan 2019.02.27
            select count(1) into v_count  from tbl_product_info tpi 
            where tpi.product_type = 0
            and tpi.itemnumber = c_product_itemnumber 
            and tpi.start_stop_state = 1
             and exists(
                select 1
                from tbl_product_sku
                where product_itemnumber = tpi.itemnumber
                and start_stop_state = 1
                and product_group = '尺码'
            )
            and tpi.is_private = 1
            and exists (
                    select 1 from tbl_pvtp_product_info_ref pir where pir.platform_id = c_stationed_user_id
                    and pir.product_itemnumber =  tpi.itemnumber and pir.enabled_flag = 1
            );
            if v_count =0 then
                return 0;
            end if;
            --查询用户站点
            select site_id into v_site_id from tbl_user_info where user_name = c_user_name;
            /*******************查询商品是否参加了平台******************************************/
            select ai.id,to_number(ai.activity_type) into v_activity_id,v_activity_type 
            from tbl_activity_info ai,tbl_activity_detail ad,tbl_activity_product ap 
            where ai.id = ad.activity_id and ai.id = ap.activity_id
            and sysdate between ap.activity_start_date and ap.activity_end_date
            and ap.product_itemnumber = c_product_itemnumber
            and ai.state = 2
            and ai.is_delete = '1'
            and ai.activity_type = 1
            and exists (select 1 from tbl_activity_site tas where tas.activity_id = ai.id and tas.site_id = v_site_id)
            and (case when (ad.user_group_id = 0 or ad.user_group_id is null) then 1 else case when 
                exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb 
                where aa.id = bb.group_id and aa.state = '2' and ad.user_group_id = aa.id and bb.user_id = c_user_name
                AND (bb.ACTIVITY_ID = ad.activity_id OR bb.ACTIVITY_ID = 0)
            ) then 1 else 0 end end) = 1
            and rownum <=1;
    END IF;
    if v_activity_id = 0 then
        return 0;
    end if;
    return v_activity_type;

end PVTP_IS_ACTIVITY;
/

