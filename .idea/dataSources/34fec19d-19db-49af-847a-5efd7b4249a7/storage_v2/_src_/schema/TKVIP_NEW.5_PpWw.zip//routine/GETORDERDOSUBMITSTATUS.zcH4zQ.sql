create FUNCTION           getOrderDoSubmitStatus
/**
   获取多仓可下单状态信息

   songwangwen 2018.12.04 快递方式调整修改
**/
(
    c_user_id in number,                  --用户id
    c_place_order_number varchar2,        --下单批次订单号
    c_place_order_batch_number varchar2,  --下单批次号
    c_place_order_task_id number          --下单任务id(订单导入才有值，其他传0)
) RETURN VARCHAR2
 IS 
    v_can_place_order_state number:=1;          --可下单状态: 1、可下单 2、需处理
    type c_order is ref cursor return tbl_saas_order_edit%rowtype;                 --强类型动态游标声明
    order_edit tbl_saas_order_edit%rowtype;
    
    type c_order_product is ref cursor return tbl_saas_order_edit_product%rowtype; --强类型动态游标声明
    order_product tbl_saas_order_edit_product%rowtype;
    
    cur_order c_order;
    cur_order_product c_order_product;
    v_temp_count int:=0;                      --临时变量
    v_order_batch_state int:=0;               --订单批次状态
    v_issuing_grade_id number:=1;             --用户代发等级ID
    v_logistics_company_id number:=0;         --物流公司ID
    v_logistics_company_name varchar2(50);    --物流公司名称
    v_order_sku_ids  varchar2(4000);           --商品SKU集合  使用逗号分隔
    v_order_sku_counts  varchar2(1000);        --商品订购数量  使用逗号分隔
    v_piece_cost number:=0;                   --代发等级单价费用
    v_product_color varchar2(50);             --商品颜色
    v_product_size varchar2(50);              --商品尺码
    v_df_money number:=0;                     --代发费用
    v_product_total_count number:=0;          --购买商品总数
    v_ysyf number:=0;                         --应收运费 系统计算得出
    v_is_outstock int:=-1;                    --缺货预售标记
    v_sku_state varchar2(50);                 --商品sku上架状态
    v_message varchar2(2000 byte);
BEGIN
    v_message:='';
    select count(1) into v_temp_count from tbl_saas_order_batch where batch_number = c_place_order_number and out_order_number = c_place_order_number and state=2;
    IF v_temp_count >0 THEN
        v_message:=v_message||'当前订单暂未确认可下单状态，请核实!,';
    END IF;
    IF c_place_order_task_id <> 0 THEN
        --订单导入
        open cur_order for 
          select * from tbl_saas_order_edit oe
          where 
              exists (select 1 from tbl_saas_order_batch ob ,tbl_import_order o 
                          where ob.out_order_number = o.out_order_number 
                              and ob.batch_number = c_place_order_batch_number
                              and o.task_id = c_place_order_task_id
                              and o.out_order_number = c_place_order_number
                              and oe.order_id=o.id 
              )
              and (select count(1) from tbl_saas_order_edit_product op where op.order_edit_id = oe.id) >0
              and oe.user_id = c_user_id;
    ELSE
        --聚水潭
         open cur_order for
           select * from tbl_saas_order_edit oe
           where  
                exists (select 1 from tbl_saas_order_batch ob,tbl_saas_order o 
                            where ob.out_order_number = o.so_id 
                                and ob.batch_number = c_place_order_batch_number
                                and o.so_id = c_place_order_number
                                and oe.order_id=o.id     
                )
                and (select count(1) from tbl_saas_order_edit_product op where op.order_edit_id = oe.id) >0
                and oe.user_id = c_user_id;
    END IF;
    fetch cur_order into order_edit;
    while cur_order%found loop
        --1.校验下单仓库是否有效
        SELECT COUNT(1)
          INTO v_temp_count
          FROM TBL_SITE_WAREHOUSE T
         WHERE T.WAREHOUSE_ID = order_edit.WAREHOUSE_ID
               AND EXISTS (SELECT 1
                             FROM TBL_USER_INFO T1
                            WHERE T1.USER_NAME = c_user_id
                                  AND T1.SITE_ID = T.SITE_ID);
        IF v_temp_count = 0 THEN
            v_message:=v_message||'下单仓库不存在!,';
        END IF;
        
        --2.查询物流公司名称
        SELECT COUNT(*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE CODE = order_edit.LOGISTICS_COMPANY_CODE;
        IF v_temp_count<>0 THEN
            SELECT ID,NAME INTO v_logistics_company_id,v_logistics_company_name FROM TBL_LOGISTICS_COMPANY WHERE CODE = order_edit.LOGISTICS_COMPANY_CODE;
        ELSE
            v_message:=v_message||'物流信息不准确，请核实!,';
        END IF;

        --3.查询订单商品信息
        open cur_order_product for select * from tbl_saas_order_edit_product op where op.order_edit_id = order_edit.ID;
        fetch cur_order_product into order_product;
            while cur_order_product%found loop
                v_order_sku_ids:=v_order_sku_ids||','||order_product.PRODUCT_SKU;
                v_order_sku_counts:=v_order_sku_counts||','||order_product.PRODUCT_COUNT;
                --3.1判断该SKU是否为可缺货订购
                SELECT A.is_outstock,A.PRODUCT_COLOR,A.PRODUCT_GROUP_MEMBER,A.STATE INTO v_is_outstock,v_product_color,v_product_size,v_sku_state FROM TBL_PRODUCT_SKU A WHERE A.ID = order_product.PRODUCT_SKU;
                --3.11非缺货订单的商品，判断下单数是否大于库存可用数
                IF v_is_outstock = 0 THEN
                    select getproductsku_stocks (order_product.PRODUCT_SKU,order_product.WAREHOUSE_ID,c_user_id)
                           + nvl((select OCCUPY_COUNT from TBL_ORDER_WAREHOUSE_COUNT where ORDER_NUMBER =c_place_order_number and product_sku = order_product.PRODUCT_SKU and warehouse_id = order_product.WAREHOUSE_ID),0) 
                      into v_temp_count 
                      from dual;
                    IF order_product.PRODUCT_COUNT > v_temp_count THEN
                        v_message:=v_message||'商品(颜色：'||v_product_color||'，尺码：'||v_product_size||')，库存不足，实际下单：'||order_product.PRODUCT_COUNT||'，可下单数：'||v_temp_count||',';
                    END IF;
                ELSIF v_is_outstock = -1 THEN
                    v_message:=v_message||'商品(颜色：'||v_product_color||'，尺码：'||v_product_size||')，未找到,';
                END IF;
            fetch cur_order_product into order_product;
        end loop;
        
        --4.计算物流价格(默认需要先支付运费)
        v_ysyf := getFreightMoney(v_logistics_company_id,order_edit.PROVINCE_ID,v_order_sku_ids,v_order_sku_counts,order_edit.WAREHOUSE_ID,1);
        --4.1校验物流费用是否被篡改
        IF v_ysyf <> order_edit.LOGISTICS_MONEY THEN
            v_message:=v_message||'运费被篡改或运费计算错误,应收运费（'||v_ysyf||'）!,';
        END IF;
        --4.2计算购买商品总数
        SELECT SUM(substr(t,1,instr(t,',',1)-1)) INTO v_product_total_count
          FROM (
                SELECT substr(s,instr(s,',',1,ROWNUM)+1) AS T,ROWNUM AS d ,instr(s,',',1,ROWNUM)+1 FROM (
                    SELECT ','||v_order_sku_counts||','  AS s FROM DUAL
                )CONNECT BY instr(s,',','1',ROWNUM)>1
            ) WHERE T IS NOT NULL;

        --5.代发费计算及校验
        SELECT COUNT(*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE TYPE='2' AND CODE = order_edit.LOGISTICS_COMPANY_CODE;
        v_df_money:=order_edit.DF_MONEY;
        --当前订单为代发订单
        IF v_temp_count > 0 THEN
            --查询用户代发等级ID
            SELECT issuing_grade_id INTO v_issuing_grade_id FROM TBL_USER_INFO WHERE USER_NAME = c_user_id;
            IF v_issuing_grade_id = 0 THEN
                v_issuing_grade_id := 1;
            END IF;
            --5.1查询代发等级的单价费用
            SELECT PIECE_COST INTO v_piece_cost FROM TBL_ISSUING_GRADE WHERE ID = v_issuing_grade_id;
            v_piece_cost := v_product_total_count * v_piece_cost;
            IF v_piece_cost != v_df_money THEN
                v_message:=v_message||'代发费用被篡改或代发费用收取标准发生变化,应收代发费用（'||v_piece_cost||'），请核实,';
            END IF;
        ELSE
           v_message:=v_message||'物流错误，请选择代发物流!,';
        END IF;
        IF v_order_sku_ids <> '' THEN
            IF order_edit.ORDER_STATE = 2 THEN
                v_message:=v_message||'当前订单已下单,';
            END IF;
        
            IF order_edit.PRODUCT_MONEY = 0 or order_edit.PRODUCT_MONEY is null THEN
                v_message:=v_message||'订单金额有误,';
            END IF;
            
            IF order_edit.RECEIVER_ADDRESS is null or order_edit.RECEIVER_ADDRESS='' THEN
                v_message:=v_message||'收货地址未填写,';
            END IF;
            
            IF order_edit.RECEIVER_PHONE is null or order_edit.RECEIVER_PHONE='' THEN
                v_message:=v_message||'收货人手机号码未填写,';
            END IF;
            
            IF order_edit.RECEIVER_NAME is null or order_edit.RECEIVER_NAME='' THEN
                v_message:=v_message||'收货人信息未填写,';
            END IF;
            
            IF order_edit.PROVINCE_ID is null or order_edit.PROVINCE_ID=0 THEN
                v_message:=v_message||'收货地址信息不完整，请编辑完善,';
            END IF;
            
            IF order_edit.DF_MONEY is null or order_edit.DF_MONEY=0 THEN
                v_message:=v_message||'代发费用为空,';
            END IF;
            
            IF order_edit.WAREHOUSE_ID is null or order_edit.WAREHOUSE_ID=0 THEN
                v_message:=v_message||'仓库信息为空,';
            END IF;
        END IF;
        v_order_sku_ids:='';
        v_order_sku_counts:='';
        fetch cur_order into order_edit;
    end loop;
    
   return v_message;
    
END getOrderDoSubmitStatus;
------------------------------------------------
/

