create FUNCTION           get_sample_itemNumber
    /**
    生成样品货号
    songwangwen
    2017-11-27
  **/
  RETURN VARCHAR2 IS
  --自治事务
  PRAGMA AUTONOMOUS_TRANSACTION;
  returnstr     VARCHAR2(50); --返回货号
  t_date_str    VARCHAR2(50); --日期字符串
  t_itemnumber_index NUMBER:=null; --临时变量,货号的序列数字
  v_count    NUMBER;         --临时变量,计数器
BEGIN
  --根据当前时间得到年月日的字符串，作为货号的起始值
  select to_char(sysdate,'yymmdd') into t_date_str from dual;
  --查询货号计数表中是否存在当前的日期，存在则读取其序列号直接使用，不存在则插入，序列化默认为001
  select count(*) into v_count from TBL_SAMPLE_ITEMNUMBER_COUNT sic where sic.sample_date = t_date_str;
  if v_count = 1 then
       select sic.itemnumber_index into t_itemnumber_index from TBL_SAMPLE_ITEMNUMBER_COUNT sic where sic.sample_date = t_date_str;
       select  t_date_str||REPLACE(lpad(t_itemnumber_index+1,3,'0'), '4', '5') into returnstr from dual;
       --更新序列号
       update TBL_SAMPLE_ITEMNUMBER_COUNT set itemnumber_index = to_number(REPLACE(lpad(t_itemnumber_index+1,3,'0'), '4', '5')) where sample_date = t_date_str;
  else
     --第一次生成货号
     select  t_date_str||'001' into returnstr from dual;
     --插入数据记录
     insert into TBL_SAMPLE_ITEMNUMBER_COUNT (SAMPLE_DATE,ITEMNUMBER_INDEX) values(t_date_str,1);
  end if;
  commit;
  RETURN returnstr;
END get_sample_itemNumber;
/

