create FUNCTION PVTP_IS_DISPLAY_LIST
/**
    私有站商品列表商品是否展示查查询专用函数   
    显示规则如下：
    1、商品所属商家必须与会员所属私有站对应
    2、商品必须是对于的私有站商品；或者是该私有站导入的童库商品
    3、如果该商品是私有商品
        1)、商品必须是【上架】或者【暂下架】状态
        2)、商品必须在用户的所在区域展示
    ---create by reid 2019.09.03
    返回值：1（显示）  0：不显示
**/
(
    c_stationed_user_id     number,      --当前访问的私有平台ID（即所属私有商家的ID）
    c_user_name             varchar2,            --会员用户名
    c_product_itemnumber    varchar2    --商品货号
) return varchar2
 is
     v_product_type number:=0;                      --商品类型 1：私有站商品   2：童库平台分享至私有站的商品
     v_id number:=0;                                --商品id
     v_sell_state_date date;                        --商品最后上架时间
     v_district_templet_id number:=0;               --商品显示区域模板id
     v_user_company_address_prov number:=0;         --用户经营地 省代码
     v_user_company_address_city number:=0;         --用户经营地 市代码
     v_site_id number:=0;                           --客户站点id
     v_flag number:=1;                              --是否显示   1（显示）  0：不显示 
     v_month_statement number:=2;                   --入驻商是否支持月结  1、不支持月结   2、支持月结
     v_credit_money number:=0;                      --会员月结额度
     v_count number:=0;                             --临时变量
     v_exists number:=0;                            --是否存在临时变量
     v_user_type number:=0;                         --用户类型 1 用户会员 2 店铺会员 3店铺查看用户 4：游客 5：私有平台用户
begin
    
    --查询会员相关信息
    SELECT user_company_address_province,user_company_address_city,site_id,user_type
    INTO v_user_company_address_prov,v_user_company_address_city,v_site_id,v_user_type
    FROM TBL_USER_INFO WHERE user_name = c_user_name and rownum<=1;
    IF  v_site_id = 0 THEN
        return 0;
    END IF;
    --判断商品是私有商品还是童库分享得商品
    select count(1) into v_count from TBL_PVTP_PRODUCT_INFO where itemnumber = c_product_itemnumber and stationed_user_id = c_stationed_user_id;
    --DBMS_OUTPUT.put_line('v_count===='||v_count);
    --私有站专用商品
    IF v_count<>0 THEN
        --查询商品id和上架时间,区域模板
        select id,sell_state_date,district_templet_id 
        into v_id,v_sell_state_date,v_district_templet_id 
        from TBL_PVTP_PRODUCT_INFO where itemnumber = c_product_itemnumber and state in ('上架','暂下架'); 
        ---判断商品在当前站点是否显示
        IF v_flag !=0 then
            --查询商品是否在站点显示
            select count(1) into v_flag from tbl_site_product_delay where site_id = v_site_id and product_id = v_id and v_sell_state_date+delay_days<=sysdate;
        END IF;       
        IF v_flag !=0 THEN
            --填写了省市信息,则需要判断当前商品在该用户的区域是否展示，未填写省市县，则直接不展示该商品
            IF v_user_company_address_prov is not null AND v_user_company_address_prov != 0 and v_user_company_address_city is not null and v_user_company_address_city != 0  then 
                --查询商品是否在用户区域显示
                select count(1) into v_flag from tbl_district_templet_rel where template_id = v_district_templet_id and (region_id = v_user_company_address_prov or region_id = v_user_company_address_city);
            END IF;
        END IF;
    ELSE 
        --是否是童库平台分享过来的商品
         SELECT COUNT(1) INTO v_count from TBL_PRODUCT_INFO pi 
         where pi.itemnumber = c_product_itemnumber 
         and pi.is_private = 1
         AND EXISTS(
            select 1 from TBL_PVTP_PRODUCT_INFO_REF ppir
            WHERE ppir.product_id = pi.id and ppir.platform_id = c_stationed_user_id
            AND ppir.enabled_flag = 1
         );
         IF v_count= 0 THEN
            return 0;
         END IF;
         SELECT COUNT(1) INTO v_count  FROM TBL_PRODUCT_INFO tpi WHERE tpi.product_type in (0) AND tpi.itemnumber = c_product_itemnumber AND tpi.start_stop_state = 1
         AND EXISTS(
            select 1
            from TBL_PRODUCT_SKU
            where product_itemnumber = tpi.itemnumber
            and start_stop_state = 1
            and product_group = '尺码'
         );
         IF v_count =0 THEN
             return 0;
         END IF;
        --查询商品id和上架时间,区域模板
        select id,sell_state_date,district_templet_id 
        into v_id,v_sell_state_date,v_district_templet_id 
        from 
        tbl_product_info where itemnumber = c_product_itemnumber and state in ('上架','暂下架');
         ---判断商品在当前站点是否显示
         IF v_flag !=0 then
            --查询商品是否在站点显示
            select count(1) into v_flag from tbl_site_product_delay where site_id = v_site_id and product_id = v_id and v_sell_state_date+delay_days<=sysdate;
         END IF;
         IF v_flag !=0 THEN
            --填写了省市信息,则需要判断当前商品在该用户的区域是否展示，未填写省市县，则直接不展示该商品
            IF v_user_company_address_prov is not null AND v_user_company_address_prov != 0 and v_user_company_address_city is not null and v_user_company_address_city != 0  then 
                --查询商品是否在用户区域显示
                select count(1) into v_flag from tbl_district_templet_rel where template_id = v_district_templet_id and (region_id = v_user_company_address_prov or region_id = v_user_company_address_city);
            END IF;
         END IF;
               /**********************进行区域控货的判断********************************/
               --全部控货的过滤处理
               select count(1) into v_count
                 from tbl_product_info tpi,mv_user_product_control_detail vupc
                where tpi.itemnumber = c_product_itemnumber
                  and vupc.user_id = c_user_name
                  and vupc.product_control_mode = '1'
                  and vupc.product_control_brand = tpi.brand_id;
               --当前商品在控货范围内
               if v_count > 0 then
                  v_flag := 0;
               else
                 --根据货号校验被控货人是否是最小下单时间
                 select count(1) into v_exists
                   from (select itemnumber,order_date from mv_order_product_control where control_user_id = c_user_name and itemnumber = c_product_itemnumber) a,
                        (select itemnumber,order_date from mv_order_product_control where user_id = c_user_name and itemnumber = c_product_itemnumber) b
                  where a.itemnumber = b.itemnumber;
                 if v_exists > 0 then
                    --下单控货的过滤处理
                     select count(1) into v_count
                       from tbl_product_info tpi,mv_user_product_control_detail vupc,mv_user_order_product tops,
                   (select case when a.order_date < b.order_date then a.itemnumber
                      else '1' end itemnumber from (select itemnumber,order_date from mv_order_product_control where control_user_id = c_user_name and itemnumber = c_product_itemnumber) a,
                        (select itemnumber,order_date from mv_order_product_control where user_id = c_user_name and itemnumber = c_product_itemnumber) b
                        where a.itemnumber = b.itemnumber) t
                      where tpi.itemnumber = c_product_itemnumber
                            and vupc.product_control_mode = '2'
                            and vupc.user_id = c_user_name
                            and vupc.product_control_brand = tpi.brand_id
                            and tops.user_id = vupc.control_user_id
                            and tops.itemnumber = tpi.itemnumber
                            --过滤被控货人可以看的商品 yejingquan 2019.05.31
                            and tpi.itemnumber != t.itemnumber;
                 else
                     --下单控货的过滤处理
                     select count(1) into v_count
                       from tbl_product_info tpi,mv_user_product_control_detail vupc,mv_user_order_product tops
                      where tpi.itemnumber = c_product_itemnumber
                            and vupc.product_control_mode = '2'
                            and vupc.user_id = c_user_name
                            and vupc.product_control_brand = tpi.brand_id
                            and tops.user_id = vupc.control_user_id
                            and tops.itemnumber = tpi.itemnumber;
                 end if;
                 if v_count > 0 then
                  v_flag := 0;
                 end if;
               end if;
    END IF;
    if v_flag = 0 then
        return 0;
    end if;

    if v_flag !=0 then
        v_flag := 1;
    end if;
   return v_flag;

end PVTP_IS_DISPLAY_LIST;
/

