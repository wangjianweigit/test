create PROCEDURE           pro_payment_deposit
/**
    店铺订货单支付--【货品押金】支付
    shif
    2018-03-14  店铺订货单押金支付
    返回值：支付结果消息
**/
(
        client_user_name in varchar2,               --操作用户名
        client_order_number in varchar2,            --订货单号码
        output_status  out varchar2,                --返回的状态码 0-失败 1-成功
        output_msg out varchar2                     --返回的信息
) AS
    V_COUNT                             INT := 0;                           --临时变量 -检查数量
    V_AUDIT_USER_REALNAME               VARCHAR2 (50);                      --审核人用户姓名
    V_AUDIT_USER_ID                     INT := 0;                           --审核人用户ID
    V_ORDER_USER_NAME                   VARCHAR2 (100);                     --订单所属用户名
    V_ORDER_USER_MANAGE_NAME            VARCHAR2 (100);                     --订单所属用户姓名
    V_ORDER_PAYMENT_MONEY               NUMBER;                             --待付款金额
    V_ORDER_STORE_PAYMENT_MONEY         NUMBER;                             --待店铺付款金额
    V_ORDER_PAYMENT_TYPE                VARCHAR2 (50);                      --付款渠道
    V_ORDER_PRODUCT_COUNT               INT := 0;                           --商品数量
    V_ORDER_STATE                       INTEGER:=0;                         --订单总状态
    V_PARTNER_USER_NAME                 VARCHAR2 (50);                      --合作商用户名
    V_DACCOUNT_BALANCE                  NUMBER:=0;                          --货品押金余额
    V_DACCOUNT_BALANCE_CHECKCODE        VARCHAR2(32);                       --货品押金余额校验码
    V_DCREATE_CODE                      VARCHAR2(32);                       --计算的货品押金校验码
    V_GDACCOUNT_BALANCE                 NUMBER:=0;                          --店铺货品押金余额
    V_GDACCOUNT_BALANCE_CHECKCODE       VARCHAR2(32);                       --店铺货品押金余额校验码
    V_GDCREATE_CODE                     VARCHAR2(32);                       --计算的店铺货品押金校验码
    V_USER_KEY                          VARCHAR2(32);                       --用户KEY
    V_USER_ID                           NUMBER;                             --会员id
    V_USER_TYPE                         NUMBER;                             --会员类型
    V_SYS_USER_TYPE                     NUMBER:=0;                          --系统用户类型
    V_RECORD_REMARK                     VARCHAR2(300);                      --摘要
    V_RECORD_NUMBER                     VARCHAR2(50);                       --收付单号
    V_PARTNER_USER_ID                   NUMBER;                             --订单会员类型
    V_REGION_ID                         NUMBER;                             --区域ID
    v_goods_deposit_balance             NUMBER:=0;                          
    v_product_money                     NUMBER:=0;
BEGIN
    output_status:='0';
   --1.获取用户信息
   SELECT COUNT (1)
     INTO V_COUNT
     FROM TBL_SYS_USER_INFO
    WHERE USER_NAME = client_user_name;

   IF V_COUNT <> 0 THEN
      SELECT USER_REALNAME, ID,USER_TYPE
        INTO V_AUDIT_USER_REALNAME, V_AUDIT_USER_ID,V_SYS_USER_TYPE
        FROM TBL_SYS_USER_INFO
       WHERE USER_NAME = client_user_name;
   ELSE
      OUTPUT_MSG := '当前操作用户信息不存在，请检查!';
      RETURN;
   END IF;
   
   IF V_SYS_USER_TYPE <> 9 THEN
      OUTPUT_MSG := '当前操作用户非区域合作用户!';
      RETURN;
   END IF;

   --2.订单号校验，未付款、店铺会员订单、属于操作合作商的
   SELECT COUNT (1)
     INTO V_COUNT
     FROM TBL_ORDER_INFO
    WHERE ORDER_NUMBER = CLIENT_ORDER_NUMBER
          AND PAYMENT_STATE = 1
          AND IS_STORE_ORDER = 1
          AND PARTNER_USER_NAME = client_user_name;

   IF V_COUNT <> 0 THEN
      --店铺订货单暂不考虑物流代发费问题
      SELECT PRODUCT_MONEY AS PAYMENT_MONEY, '货品押金',USER_NAME,USER_MANAGE_NAME,PRODUCT_COUNT,ORDER_STATE,PARTNER_USER_NAME,PRODUCT_STORE_MONEY
        INTO V_ORDER_PAYMENT_MONEY, V_ORDER_PAYMENT_TYPE,V_ORDER_USER_NAME,V_ORDER_USER_MANAGE_NAME,V_ORDER_PRODUCT_COUNT,V_ORDER_STATE,
             V_PARTNER_USER_NAME,V_ORDER_STORE_PAYMENT_MONEY
        FROM TBL_ORDER_INFO
       WHERE ORDER_NUMBER = CLIENT_ORDER_NUMBER;
       IF V_ORDER_STATE != '1' THEN
            OUTPUT_MSG := '订货单为非待付款状态，请检查!';
            RETURN;
       END IF;
   ELSE
      OUTPUT_MSG := '订货单已付款或状态异常，请检查!';
      RETURN;
   END IF;

   --3.0验证订货会员是否是店铺会员
   SELECT ID,USER_TYPE
     INTO V_USER_ID,V_USER_TYPE
     FROM TBL_USER_INFO
    WHERE USER_NAME = V_ORDER_USER_NAME;
   IF V_USER_TYPE!=2 THEN
      OUTPUT_MSG := '订货单不属于店铺会员，请检查！';
      RETURN;
   END IF;

  --2.0获取合作商id
    SELECT ID
     INTO V_PARTNER_USER_ID
     FROM TBL_SYS_USER_INFO
    WHERE USER_NAME = V_PARTNER_USER_NAME;

   --3.0获取店铺账号信息
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TBL_STORE_BANK_ACCOUNT T1
     WHERE T1.USER_ID = V_USER_ID;
     IF V_COUNT <> 0 THEN
       --获取所属区域
       select partner_user_id
         into V_REGION_ID
         from tbl_user_info 
        where id = V_USER_ID;
       --押金余额校验
       SELECT nvl(sum(GOODS_DEPOSIT_BALANCE),0)
         INTO v_goods_deposit_balance
         FROM tbl_store_bank_account
        WHERE user_id in (select id from tbl_user_info where partner_user_id = V_REGION_ID and user_state = 1);
    
       --获取待付款的订单金额
       SELECT NVL (SUM (PRODUCT_MONEY), 0)
         INTO v_product_money
         FROM tbl_order_info
        WHERE order_state = 1 
          AND order_number != client_order_number
          AND user_name in (select id from tbl_user_info where partner_user_id = V_REGION_ID and user_state = 1);
       --店铺会员帐号表加锁处理,防止余额变动异常
       SELECT NVL(T1.GOODS_DEPOSIT_BALANCE,0), GOODS_DEPOSIT_BAL_CHECKCODE,NVL(T1.STORE_GOODS_DEPOSIT_BALANCE,0), STORE_GOODS_DPST_BAL_CHECKCODE
         INTO V_DACCOUNT_BALANCE,V_DACCOUNT_BALANCE_CHECKCODE,V_GDACCOUNT_BALANCE,V_GDACCOUNT_BALANCE_CHECKCODE
         FROM TBL_STORE_BANK_ACCOUNT T1
        WHERE T1.USER_ID = V_USER_ID
        FOR UPDATE;
     ELSE
         OUTPUT_MSG := '订货单所属店铺帐户异常，请检查！';
         RETURN;
     END IF;
    --4.0校验货品押金余额
    --获取用户KEY
    SELECT getUserKey(V_ORDER_USER_NAME,'old','5')
      INTO V_USER_KEY
      FROM DUAL;
    --获取余额校验码并判断是否被篡改
    V_DCREATE_CODE := getCheck_Code(V_ORDER_USER_NAME,V_DACCOUNT_BALANCE,V_USER_KEY);
    V_GDCREATE_CODE := getCheck_Code(V_ORDER_USER_NAME,V_GDACCOUNT_BALANCE,V_USER_KEY);
    IF V_DACCOUNT_BALANCE_CHECKCODE IS NULL OR V_DACCOUNT_BALANCE_CHECKCODE <> V_DCREATE_CODE
       OR V_GDACCOUNT_BALANCE_CHECKCODE IS NULL OR V_GDACCOUNT_BALANCE_CHECKCODE <> V_GDCREATE_CODE  THEN
        OUTPUT_MSG:='店铺货品押金余额发生篡改，无法完成当前操作!';
        RETURN;
    END IF;
    --5.0验证押金余额是否足够
    IF v_product_money > v_goods_deposit_balance THEN
       OUTPUT_MSG := '货品押金余额不足，请检查！';
       RETURN;
    END IF;

    --6.0生成店铺货品押金收支记录
    V_RECORD_NUMBER:=GETAUTONUMBER('XD');
    V_RECORD_REMARK:='门店订货单付款,店铺货品押金支出（交易号：'||CLIENT_ORDER_NUMBER||'）';
    INSERT INTO TBL_STORE_ACCOUNT_RECORD(
      ID,
      RECORD_NUMBER,
      RECORD_CHANNEL,
      RECORD_TYPE,
      REMARK,
      COLLECT_USER_ID,
      COLLECT_USER_MANAGER_NAME,
      COLLECT_STORE_NAME,
      COLLECT_USER_PARTNER_ID,
      MONEY,
      COUNT,
      SURPLUS_MONEY,
      DOCKET_NUMBER,
      DOCKET_TYPE,
      CREATE_DATE
    )
    VALUES(
      SEQ_STORE_ACCOUNT_RECORD.NEXTVAL,
      V_RECORD_NUMBER,
      '店铺货品押金',
      2,
      V_RECORD_REMARK,
      V_USER_ID,
      V_ORDER_USER_MANAGE_NAME,
      V_ORDER_USER_MANAGE_NAME,
      V_PARTNER_USER_ID,
      -V_ORDER_STORE_PAYMENT_MONEY,
      V_ORDER_PRODUCT_COUNT,
      V_GDACCOUNT_BALANCE - V_ORDER_STORE_PAYMENT_MONEY,
      CLIENT_ORDER_NUMBER,
      '门店订货',
      SYSDATE
    );

    --7.0生成货品押金收支记录
    V_RECORD_NUMBER:=GETAUTONUMBER('XD');
    V_RECORD_REMARK:='门店订货单付款,货品押金支出（交易号：'||CLIENT_ORDER_NUMBER||'）';
    INSERT INTO TBL_STORE_ACCOUNT_RECORD(
      ID,
      RECORD_NUMBER,
      RECORD_CHANNEL,
      RECORD_TYPE,
      REMARK,
      COLLECT_USER_ID,
      COLLECT_USER_MANAGER_NAME,
      COLLECT_STORE_NAME,
      COLLECT_USER_PARTNER_ID,
      MONEY,
      COUNT,
      SURPLUS_MONEY,
      DOCKET_NUMBER,
      DOCKET_TYPE,
      CREATE_DATE
    )
    values(
      SEQ_STORE_ACCOUNT_RECORD.NEXTVAL,
      V_RECORD_NUMBER,
      '货品押金',
      2,
      V_RECORD_REMARK,
      V_USER_ID,
      V_ORDER_USER_MANAGE_NAME,
      V_ORDER_USER_MANAGE_NAME,
      V_PARTNER_USER_ID,
      -V_ORDER_PAYMENT_MONEY,
      V_ORDER_PRODUCT_COUNT,
      V_DACCOUNT_BALANCE - V_ORDER_PAYMENT_MONEY,
      CLIENT_ORDER_NUMBER,
      '门店订货',
      SYSDATE
    );

    --8.0 更新账户余额、授信
     UPDATE TBL_STORE_BANK_ACCOUNT
        SET GOODS_DEPOSIT_BALANCE = GOODS_DEPOSIT_BALANCE - V_ORDER_PAYMENT_MONEY,
            STORE_GOODS_DEPOSIT_BALANCE = STORE_GOODS_DEPOSIT_BALANCE - V_ORDER_STORE_PAYMENT_MONEY
      WHERE USER_ID = V_USER_ID;
    --9.0更新用户账户校验码
    --获取新的账户KEY
    SELECT getUserKey(V_ORDER_USER_NAME,'new',5)
      INTO V_USER_KEY
      FROM DUAL;
    --更新校验码
    UPDATE TBL_STORE_BANK_ACCOUNT T
       SET T.ACCOUNT_BALANCE_CHECKCODE = getcheck_code(V_ORDER_USER_NAME,T.ACCOUNT_BALANCE,V_USER_KEY),
           T.GOODS_DEPOSIT_BAL_CHECKCODE = getcheck_code(V_ORDER_USER_NAME,T.GOODS_DEPOSIT_BALANCE,V_USER_KEY),
           T.STORE_GOODS_DPST_BAL_CHECKCODE = getcheck_code(V_ORDER_USER_NAME,T.STORE_GOODS_DEPOSIT_BALANCE,V_USER_KEY),
           T.STORE_DEPOSIT_CHECKCODE = getcheck_code(V_ORDER_USER_NAME,T.STORE_DEPOSIT,V_USER_KEY),
           T.SHELF_DEPOSIT_CHECKCODE = getcheck_code(V_ORDER_USER_NAME,T.SHELF_DEPOSIT,V_USER_KEY),
           T.UPDATE_DATE = SYSDATE
     WHERE T.USER_ID = V_USER_ID;
    --更新缓存key
    UPDATE TBL_STORE_CACHE_KEY
       SET CACHE_KEY = V_USER_KEY,
           CREATE_TIME = SYSDATE
     WHERE USER_NAME = V_ORDER_USER_NAME;
    --10.0 更新订单支付状态
      UPDATE TBL_ORDER_INFO
         SET PAYMENT_STATE = 2,
             ORDER_STATE = 2,
             PAYMENT_DATE = SYSDATE,
             PAYMENT_TYPE = '货品押金',
             PAYMENT_MONEY = PRODUCT_MONEY,
             CHECK_STATE = 1,
             PAYMENT_NUMBER = V_RECORD_NUMBER
       WHERE ORDER_NUMBER = client_order_number;
     output_status:='1';
     output_msg:='审核成功';
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='订货单审核时出现未知错误';
    ROLLBACK;
END pro_payment_deposit;
/

