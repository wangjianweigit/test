create FUNCTION           pvtp_getSku_U_LiquidationPrice
/**
    通过用户名获取SKU商品的最终清分价格
    wanghai
    创建：2019-09-06 create by wanghai 私有平台清分规则计算
    
    返回值：商品清分价格
**/
(
    c_type  number,                 --清分类型  1、私有商家收入；2、平台服务费；3、仓储服务费；4、私有商家服务费
    c_user_name   varchar2,         --用户名
    c_product_sku_id   number,       --商品SKUID
    c_product_price    number,       --商品单价
    c_vip   number                  --会员价标识
) return number
 is
     v_liquidation_prize number:=0;         --需要返回的分成价格
     v_product_prize number:=0;             --最终商品价格
     v_user_id number:=0;                   --用户ID
     v_product_itemnumber   varchar2(50);   --商品货号
     v_hd_flag number:=-1;                  --是否参加了活动
     v_hd_discount number:=1;               --活动折扣
     v_hy_discount number:=1;               --会员等级折扣
     v_site_discount number:=1;             --站点折扣
     v_ts_discount number:=1;               --特殊价折扣
     v_hyfwf_discount number :=1 ;          --最终会员服务费折扣率
     v_site_id number:=0;                   --会员站点
     v_storage_charges number:=0;           --仓储服务费
     v_service_charges number:=0;           --私有商家服务费率
     v_hdhy_discount number:=1;             --活动会员折扣
     v_ts_flag number:=-1;                  --是否有特殊价  -1为没有   非-1为有特殊价
     v_product_type_id number := 0;         --商品类型ID
     v_product_type_type char := '1';       --商品类型类别
     
     v_product_prize_cost number:=0;                 --商品报价
     v_product_sale_prize number:=0;                 --应售价
     v_member_service_rate number:=0;                --会员服务费比例-汇总
     v_member_service_rate_rzs number:=0;            --会员服务费比例-私有商家
     v_member_service_rate_qj number:=0;             --会员服务费比例-全局
     v_member_service_money_rzs number:=0;           --会员服务费-私有商家
     v_member_service_money_qj number:=0;            --会员服务费-全局
     v_product_create_date date;                                             --商品创建时间                          --界线新加配置
     v_sys_default_hy_dis number := 0.7;                                     --新注册会员老商品采用默认费率折扣      --界线新加配置
     
     v_sta_user_spec_pr_temp_id number:=-1;           --用户特殊价格模板                                                     --私有平台特殊价格新加配置
     v_product_specs_id number :=0;                   --商品规格ID                                                           --私有平台特殊价格新加配置
     v_product_specs varchar2(500);                   --商品规格名称                                                         --私有平台特殊价格新加配置
     v_off_price number :=0;                          --优惠金额                                                             --私有平台特殊价格新加配置
     
     v_service_pay_charges number:=0;        --私有商家支付服务费率
     
     v_ts_product_sale_prize number :=0;              --私有站商品 有特殊价情况下的商品售价      
     v_ts_discount_min       number :=0;              --临时变量，用于存储特殊折扣与活动折扣的较低值
BEGIN

    select a.create_date,a.product_type_id into v_product_create_date,v_product_type_id from TBL_PVTP_PRODUCT_INFO a,TBL_PVTP_PRODUCT_SKU b where b.id = c_product_sku_id  and a.ITEMNUMBER = b.PRODUCT_ITEMNUMBER and rownum<2;
    --查询私有商家会员服务费比例
    select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_PVTP_CONFIG where STATIONED_USER_ID = (
        select STATIONED_USER_ID from TBL_PVTP_PRODUCT_SKU where id = c_product_sku_id and rownum<2
    );
    
    --查询私有商家支付服务费和商家服务费费率-按当前费率计算
    select nvl(pay_service_rate,0),nvl(service_charges,0) into v_service_pay_charges,v_service_charges from TBL_PVTP_CONFIG where STATIONED_USER_ID = (
        select STATIONED_USER_ID from TBL_PVTP_PRODUCT_SKU where id = c_product_sku_id
    );
    
    --会员服务费比例汇总 = 私有商家会员服务费比例 + 全局会员服务费比例
    v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;

   --查询SKU基本信息
   select product_itemnumber,product_prize_cost,parent_id,product_specs into v_product_itemnumber,v_product_prize_cost,v_product_specs_id,v_product_specs from TBL_PVTP_PRODUCT_SKU where product_group = '尺码' and id = c_product_sku_id ;

   --计算应销售价
   v_product_sale_prize:=v_product_prize_cost/(1-v_member_service_rate);
   
   --计算私有商家会员服务费 = 应销售价*私有商家会员服务费比例
   v_member_service_money_rzs := v_product_sale_prize * v_member_service_rate_rzs;
   
   --计算全局会员服务费 = 应销售价*全局会员服务费比例
   v_member_service_money_qj := v_product_sale_prize * v_member_service_rate_qj;

   --查询会员站点
   select nvl(min(site_id),0),nvl(min(id),0),nvl(min(discount),1),nvl(min(sta_user_spec_pr_temp_id),-1) into v_site_id,v_user_id,v_hy_discount,v_sta_user_spec_pr_temp_id from tbl_user_info where user_name = c_user_name;
   
   --查询站点折扣
   select nvl(min(discount),1) into v_site_discount from tbl_site_info  where id = v_site_id;
   
   --获取商品类型的类别
   select type into v_product_type_type from TBL_DIC_PRODUCT_TYPE where id = v_product_type_id;
   
    --查询SKU仓储费
    if v_product_type_type = '1' then
       select nvl(max(storage_charges),0) into v_storage_charges from TBL_PVTP_STAT_STORAGE_CHARGES ssc,TBL_PVTP_PRODUCT_SKU ps 
       where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size(+) = ps.product_group_member and ps.id = c_product_sku_id and type = v_product_type_type;
    else
       select nvl(max(storage_charges),0) into v_storage_charges from TBL_PVTP_STAT_STORAGE_CHARGES ssc,TBL_PVTP_PRODUCT_SKU ps 
       where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size = v_product_type_id and ps.id = c_product_sku_id and type = v_product_type_type;
    end if;
   
   --如果没有查询到用户信息，则返回原价
   if v_user_id=0 then
        v_product_prize:=v_product_sale_prize;
   else
       --用户配置了特殊价格模板
       if v_sta_user_spec_pr_temp_id != -1 then 
           --模板详情的类型 1:按照商品规格设置；2:按照全局规格设置；3:按照商品分类设置
           --如果某规格3个维度都符合，则优先级按商品>规格>分类确定特殊价
            select nvl(min(off_price),0),nvl(min(id),-1) into v_off_price,v_ts_flag 
            from (
                select b.id,b.off_price from tbl_sta_user_spec_pr_temp a,tbl_sta_user_spec_pr_temp_del b where a.id = b.template_id and a.is_delete = 1 
                and a.begin_date <= sysdate and a.end_date >=sysdate 
                and a.id = v_sta_user_spec_pr_temp_id 
                and (
                    (b.type = 1 and product_specs_id = v_product_specs_id)
                    or
                    (b.type = 2 and product_specs = v_product_specs)
                    or
                    (b.type = 3 and product_type_id = v_product_type_id)
                )
                order by b.type asc
            ) where rownum <2;
      end if;
       /*********有特殊价格：如果当前商品SKU对于当前用户存在特殊价，则需要先计算出特殊价情况下的售价信息**********/
       IF v_ts_flag<>-1 THEN 
            --私有站特殊价格处理 = 应售价 - 优惠价格
            v_ts_product_sale_prize := v_product_sale_prize - v_off_price;
            if v_ts_product_sale_prize  < 0 then
                v_ts_product_sale_prize := 0 ;
            end if;
       END IF;---特殊价判断结束
        /***********************************************查询参加的活动----订货会、限时折扣、预售活动、清尾活动 start ****************************************************/
       select nvl(min(c.activity_discount),1),nvl(min(c.id),-1),nvl(min(a.activity_service_discount),1) 
       into v_hd_discount,v_hd_flag,v_hdhy_discount 
       from tbl_activity_info a ,tbl_activity_detail a1,tbl_activity_product c 
       where a.activity_state = '3' and a.state = '2'
       and sysdate between a.begin_date and a.end_date 
       and sysdate between c.activity_start_date and c.activity_end_date 
       and a.id = a1.activity_id
       and c.activity_id = a.id 
       and c.product_itemnumber =v_product_itemnumber
       and  
        case 
           when (a1.user_group_id = 0 or a1.user_group_id is null)
               then 1
           else
               case when 
                 exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb 
                     where aa.id = bb.group_id and aa.state = '2' and a1.user_group_id = aa.id and  bb.user_id = c_user_name 
                     AND (bb.ACTIVITY_ID = a1.activity_id OR bb.ACTIVITY_ID = 0)
                 )
               then 
               1
               else
               0
               end
        end  = 1
       and exists (select 1 from tbl_activity_site tas where tas.activity_id = a.id and tas.site_id = v_site_id);
       /***********************************************查询参加的活动----订货会、限时折扣、预售活动、清尾活动 end ****************************************************/
           
           if v_hd_flag=-1 then 
               --查询参加的活动----限时折扣--------店铺活动
               select nvl(min(c.ACTIVITY_DISCOUNT),1),nvl(min(c.id),-1),nvl(min(c.ACTIVITY_DISCOUNT),1) into v_hd_discount,v_hd_flag,v_hdhy_discount from TBL_STA_SALE_ACTIVITY a ,TBL_STA_SALE_ACTIVITY_PRODUCT c 
               where c.IS_DELETE = 1 and a.IS_DELETE = 1  and a.ACTIVITY_STATE=1
               and sysdate between a.BEGIN_DATE and a.END_DATE 
               and a.id = c.ACTIVITY_ID
               and c.product_itemnumber =v_product_itemnumber;
               
           end if;
           
           --获取 会员折扣 或  站点折扣  中最低的
           v_hyfwf_discount:= least(v_hy_discount,v_site_discount);
           --没有参加活动
           if v_hd_flag=-1 then  
                --是否会员卡
                if c_vip = 2 then
                    --计算售价
                    v_product_prize := v_product_prize_cost+ v_member_service_money_rzs*v_ts_discount;
                else
                    --计算售价
                    v_hyfwf_discount := least(v_hyfwf_discount,v_ts_discount); --比较特殊折扣是否是最低的折扣
                    v_product_prize := v_product_prize_cost + v_member_service_money_rzs*v_ts_discount+(v_member_service_money_qj*v_hyfwf_discount);
                end if;
                
           --参加了活动
           else  
                --是否会员卡
                if c_vip = 2 then
                    ----比较活动折扣与特殊折扣，两者取较低值，作为 【私有商家会员服务费】的最终折扣
                    v_ts_discount_min := least(v_hd_discount,v_ts_discount);
                    --按照活动计算  报价*活动折扣 + 私有商家会员服务费*活动折扣
                    v_product_prize := (v_product_prize_cost*v_hd_discount) + (v_member_service_money_rzs*v_ts_discount_min);
                else
                    ----比较活动折扣与特殊折扣，两者取较低值，作为 【私有商家会员服务费】的最终折扣
                    v_ts_discount_min := least(v_hd_discount,v_ts_discount);
                    --获取最低折扣   会员折扣与活动会员折扣与活动折扣中最低
                    v_hyfwf_discount := least(v_hyfwf_discount,v_hdhy_discount,v_hd_discount);
                    v_hyfwf_discount := least(v_hyfwf_discount,v_ts_discount); --比较特殊折扣是否是最低的折扣
                    --按照活动计算  报价*活动折扣 + 私有商家会员服务费*活动折扣 + 全局会员服务费*会员折扣与活动会员折扣与活动折扣中最低
                    v_product_prize := (v_product_prize_cost*v_hd_discount) + (v_member_service_money_rzs*v_ts_discount_min) + (v_member_service_money_qj*v_hyfwf_discount);
                end if;
           end if; 
   end if;
    ---如果私有站的特殊折扣售价不为0，则比较特殊价是否为最低价格
   IF v_ts_product_sale_prize<> 0 THEN
       v_product_prize := least(v_product_prize,v_ts_product_sale_prize);
   END IF;
   if ceil(v_product_prize)-v_product_prize<0.5 then
      v_product_prize := ceil(v_product_prize);
   elsif ceil(v_product_prize)-v_product_prize=0 then
      v_product_prize := v_product_prize;
   else 
      v_product_prize := ceil(v_product_prize)-0.5;
   end if;
   
   if c_product_price is not null then
      v_product_prize := c_product_price;
   end if;
   
   --判断价格取活动价还是普通价
   if v_hd_flag=-1 then
        --如果报价小于仓储费，则不收取仓储费
        if v_product_prize_cost <= v_storage_charges then
            v_storage_charges := 0;
        end if;
        
        --报价大于售价，按照售价计算私有商家货款
        if v_product_prize_cost > v_product_prize then
            v_product_prize_cost := v_product_prize;
        end if;
       
        --普通价
        if c_type = 1 then
            --私有商家收入 报价-报价*私有商家服务费-仓储服务费
            v_liquidation_prize := v_product_prize_cost - trunc(v_product_prize_cost*v_service_charges,2) - trunc(v_product_prize_cost*v_service_pay_charges,2) - v_storage_charges;
        elsif c_type = 2 then
            --会员服务费 普通价-报价
            v_liquidation_prize := v_product_prize - v_product_prize_cost;
        elsif c_type = 3 then
            --仓储费
            v_liquidation_prize := v_storage_charges;
        elsif c_type = 4 then
            --私有商家服务费
            v_liquidation_prize := trunc(v_product_prize_cost*v_service_charges,2);
        elsif c_type = 5 then
            --私有商家支付服务费
            v_liquidation_prize := trunc(v_product_prize_cost*v_service_pay_charges,2);
        end if;
        
   else
        --如果 报价*活动折扣小于仓储费，则不收取仓储费
        if v_product_prize_cost*v_hd_discount <= v_storage_charges then
            v_storage_charges := 0;
        end if;
            
        --活动价
        if c_type = 1 then
            --私有商家收入 报价*活动折扣-报价*活动折扣*私有商家服务费-仓储费
            v_liquidation_prize := trunc(v_product_prize_cost*v_hd_discount,2) - trunc(v_product_prize_cost*v_hd_discount*v_service_charges,2) - trunc(v_product_prize_cost*v_hd_discount*v_service_pay_charges,2) - v_storage_charges;
        elsif c_type = 2 then
            --会员服务费 活动价-报价*活动折扣
            v_liquidation_prize := v_product_prize - trunc(v_product_prize_cost*v_hd_discount,2);
        elsif c_type = 3 then
            v_liquidation_prize := v_storage_charges;
        elsif c_type = 4 then
            v_liquidation_prize := trunc(v_product_prize_cost*v_hd_discount*v_service_charges,2);
        elsif c_type = 5 then
            --私有商家支付服务费
            v_liquidation_prize := trunc(v_product_prize_cost*v_hd_discount*v_service_pay_charges,2);
        end if;
   end if;
   
   return v_liquidation_prize;
   
END pvtp_getSku_U_LiquidationPrice;
/

