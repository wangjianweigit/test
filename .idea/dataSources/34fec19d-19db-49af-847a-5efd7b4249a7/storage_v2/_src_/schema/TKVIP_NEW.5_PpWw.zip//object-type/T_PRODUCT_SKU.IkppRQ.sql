create TYPE T_PRODUCT_SKU  as object 
(
    product_color_imgurl   varchar2(200 byte),
    product_prize_tag      number,
    product_prize_cost     number,
    product_warning_count  number,
    product_weight         number,
    product_gbcode         varchar2(50 byte),
    product_inlong         number,
    product_color          varchar2(50 byte),
    product_specs          varchar2(50 byte),
    product_size           varchar2(50 byte),
    product_sku_id         number,
    product_specs_id       number,
    product_sku_code       varchar2(50 byte)
);
/

