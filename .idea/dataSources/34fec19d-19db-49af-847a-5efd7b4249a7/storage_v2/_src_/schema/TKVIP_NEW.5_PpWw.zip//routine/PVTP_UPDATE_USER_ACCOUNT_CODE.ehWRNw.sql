create PROCEDURE pvtp_update_user_account_code
/**
   更新私有商家校验码
    zhengfy
    2019-09-16
**/
(
        client_user_name in varchar2               --用户名
) AS
    v_user_key varchar2(32);               --用户KEY
    v_account_balance_checkcode varchar2(32);--余额校验码
    v_deposit_checkcode varchar2(32);        --保证金余额校验码
BEGIN
    --获取新的账户KEY
    select getUserKey(client_user_name,'new','8') into v_user_key from dual;

    select getcheck_code(client_user_name,account_balance,v_user_key),
        getcheck_code(client_user_name,deposit_money_balance,v_user_key) into v_account_balance_checkcode,v_deposit_checkcode 
    from tbl_pvtp_bank_account where user_id = client_user_name;

    --更新余额校验码、保证金余额校验码
    update tbl_pvtp_bank_account 
    set account_balance_checkcode=v_account_balance_checkcode,
        deposit_checkcode=v_deposit_checkcode
    where user_id = client_user_name;
    --更新用户账户KEY                            

    update TBL_PVTP_STATIONED_CACHE_KEY set cache_key = v_user_key,create_time=sysdate where user_name = client_user_name;


END pvtp_update_user_account_code;
/

