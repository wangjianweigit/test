create PROCEDURE           PRO_RETURN_REFUND_ORDER
/**
     订单退款单执行退款
     wangjianwei
     2017-05-17
     返回值：退款成功或退款失败消息
     
     songwangwen 20180827 修改预售相关内容
     yejingquan 20190521 订单退款 超退校验
  **/
(
 client_operate_type           IN VARCHAR2,  --操作类型  --01 执行退款 02--退货退款驳回
 client_return_number          IN VARCHAR2,  --退货单号
 client_return_reject_reson    IN VARCHAR2,  --退款订单驳回原因
 client_refund_operation_name  IN VARCHAR2,  --执行退款操作人用户名
 output_status                 OUT VARCHAR2,  --返回的状态码 0-退款失败 1-退款成功
 output_msg                    OUT VARCHAR2   --返回的信息
 ) IS
  temp_count                     INT := 0;      --临时变量
  temp_return_type               CHAR(1);       --退款订单类型(1.取消订单类型,2.部分退货退款类型)
  temp_order_number              VARCHAR2(50);  --订单号
  temp_user_realname             VARCHAR2(50);  --审核操作人姓名
  temp_order_return_money        NUMBER := 0;   --退款金额
  temp_turnover_number           VARCHAR2(100); --收支记录收付关联号
  temp_order_user_name           VARCHAR2(50);  --订单用户名
  temp_user_manage_name          VARCHAR2(50);  --订单用户姓名
  temp_user_id                   NUMBER := 0;   --订单用户id
  temp_account_balance           NUMBER := 0;   --账号余额
  temp_return_count              NUMBER := 0;   --退款单退货商品数量
  temp_account_balance_checkcode VARCHAR2(500); --余额校验码
  temp_create_code               VARCHAR2(32);  --计算的校验码
  temp_user_key                  VARCHAR2(32);  --用户KEY
  v_ywy_username                 VARCHAR2(100); --业务员用户名-【收支记录】
  v_ywjl_username                VARCHAR2(100); --业务经理用户名-【收支记录】
  v_mdid                         NUMBER;        --门店id-【收支记录】
  v_stop_deliver_state           VARCHAR2(10);  --终止发货状态
  v_order_warehouse_id           NUMBER:=0;     --订单下达仓库id
  v_product_sku                  NUMBER:=0;     --临时变量 退货单sku
  v_return_count                 NUMBER:=0;     --临时变量 退货单sku数量
  v_occupy_count                 NUMBER:=0;     --临时变量 订单sku占用量
  v_yd_count                     NUMBER:=0;     --临时变量 sku已退数
  v_product_count                NUMBER:=0;     --临时变量 订单sku需发数
  v_total_send_count             NUMBER:=0;     --临时变量 订单sku已发数
BEGIN
  output_status := '0';
  output_msg    := '操作失败！';
  --1.0判断用户是否存在
  SELECT COUNT(*)
    INTO temp_count
    FROM TBL_SYS_USER_INFO
   WHERE USER_NAME = client_refund_operation_name;
  IF temp_count = 0 THEN
     output_msg := '用户信息不能为空，请检查！';
     RETURN;
  ELSE
     --获取用户姓名（赋值）
     SELECT USER_REALNAME
       INTO temp_user_realname
       FROM TBL_SYS_USER_INFO
      WHERE USER_NAME = client_refund_operation_name;
  END IF;
  --2.0退款单校验
  SELECT COUNT(*)
    INTO temp_count
    FROM TBL_ORDER_RETURN_INFO
   WHERE RETURN_NUMBER = client_return_number
         AND STATE = '1';
  IF temp_count < 1 THEN
     output_msg := '退款单不存在或状态异常';
     RETURN;
  END IF;
  --3.0订单号、退款类型（赋值）
  SELECT ORDER_NUMBER,RETURN_TYPE,PRODUCT_COUNT
    INTO temp_order_number,temp_return_type,temp_return_count
    FROM TBL_ORDER_RETURN_INFO
   WHERE RETURN_NUMBER = client_return_number;
  --4.0退款单审核通过
  IF CLIENT_OPERATE_TYPE ='01' THEN
      --订单退款 超退校验
      DECLARE CURSOR row_order_sku IS
        SELECT T.PRODUCT_ITEMNUMBER,T.PRODUCT_COLOR,T.CODENUMBER,T.PRODUCT_SKU,T.COUNT
          FROM TBL_ORDER_RETURN_PRODUCT T
         WHERE T.RETURN_NUMBER = client_return_number;
        BEGIN
            FOR c_row in row_order_sku LOOP
              --已退数
              SELECT NVL(SUM(T1.COUNT),0)
                INTO v_yd_count
                FROM TBL_ORDER_RETURN_INFO T,TBL_ORDER_RETURN_PRODUCT T1
               WHERE T.ORDER_NUMBER = temp_order_number
                 AND T.RETURN_NUMBER = T1.RETURN_NUMBER
                 AND T1.PRODUCT_SKU = c_row.PRODUCT_SKU
                 AND T.STATE = 2;
              --订单sku数量
              SELECT NVL(T.COUNT,0),NVL(T.TOTAL_SEND_COUNT,0)
                INTO v_product_count,v_total_send_count
                FROM TBL_ORDER_PRODUCT_SKU T
               WHERE T.PRODUCT_SKU = c_row.PRODUCT_SKU
                 AND T.ORDER_NUMBER = temp_order_number;
                 
              IF v_total_send_count+v_yd_count+c_row.COUNT > v_product_count THEN
                output_msg := '货号【'||c_row.PRODUCT_ITEMNUMBER||'】颜色【'||c_row.PRODUCT_COLOR||'】尺码【'||c_row.CODENUMBER||'】退款申请数量异常，请联系管理员!';
                RETURN;
              END IF;
            END LOOP;
        END;
      --4.1订单相关信息初始化处理
      SELECT B.RETURN_TOTAL_MONEY, A.PAYMENT_NUMBER, A.USER_NAME,A.MD_ID,A.YWY_USER_NAME,A.YWJL_USER_NAME,B.STOP_DELIVER_STATE
        INTO temp_order_return_money, temp_turnover_number,temp_order_user_name,v_mdid,v_ywy_username,v_ywjl_username,v_stop_deliver_state
        FROM TBL_ORDER_INFO A,TBL_ORDER_RETURN_INFO B
       WHERE A.ORDER_NUMBER = B.ORDER_NUMBER
             AND B.RETURN_NUMBER = client_return_number;
      --4.2当退款类型为部分退货退款时 增加终止发货状态判断
      IF V_STOP_DELIVER_STATE != '1' and temp_return_type='2' THEN
         output_msg := '仓库未终止发货，不能执行退款';
         RETURN;
      END IF;
      --4.3获取订单用户信息
      SELECT COUNT(*)
        INTO temp_count
        FROM TBL_USER_INFO
       WHERE USER_NAME = temp_order_user_name;
      IF temp_count <> 0 THEN
        SELECT USER_MANAGE_NAME, ID
          INTO temp_user_manage_name, temp_user_id
          FROM TBL_USER_INFO
         WHERE USER_NAME = temp_order_user_name;
      ELSE
        output_msg := '订单用户信息不存在';
        RETURN;
      END IF;
      --4.4获取订单用户账户信息
      SELECT COUNT(*)
        INTO temp_count
        FROM TBL_BANK_ACCOUNT
       WHERE USER_ID = temp_user_id;
      IF temp_count <> 0 THEN
        SELECT NVL(ACCOUNT_BALANCE, 0),ACCOUNT_BALANCE_CHECKCODE
          INTO temp_account_balance,temp_account_balance_checkcode
          FROM TBL_BANK_ACCOUNT
         WHERE USER_ID = temp_user_id;
      ELSE
        output_msg := '订单用户账户信息不存在';
        RETURN;
      END IF;
      --4.5校验余额是否被篡改
      SELECT getUserKey(temp_order_user_name, 'old','1') INTO temp_user_key FROM DUAL;
      --获取余额校验码并判断是否被篡改
      temp_create_code := getCheck_Code(temp_order_user_name, temp_account_balance, temp_user_key);
      IF temp_account_balance_checkcode IS NULL OR temp_account_balance_checkcode <> temp_create_code THEN
         output_msg := '余额发生篡改，无法完成当前操作!';
         RETURN;
      END IF; 
      --非预售商品活动
      UPDATE TBL_SALE_ACTIVITY_SKU TSAS
          SET TSAS.ACTIVITY_SELL_AMOUNT = TSAS.ACTIVITY_SELL_AMOUNT - NVL((SELECT TOPS.COUNT
                                                                             FROM TBL_ORDER_RETURN_PRODUCT TORP,TBL_ORDER_PRODUCT_SKU TOPS
                                                                            WHERE TORP.RETURN_NUMBER = client_return_number
                                                                                  AND TORP.ORDER_NUMBER = TOPS.ORDER_NUMBER
                                                                                  AND TOPS.PRODUCT_SKU = TSAS.PRODUCT_SKU
                                                                                  AND TOPS.WAREHOUSE_ID = TSAS.WAREHOUSE_ID),0)
          WHERE EXISTS (SELECT 1
                          FROM TBL_ACTIVITY_INFO TAI, 
                          TBL_ACTIVITY_DETAIL TSAI,
                          TBL_ACTIVITY_PRODUCT AP,
                          TBL_ORDER_RETURN_PRODUCT TORP, 
                          TBL_ORDER_PRODUCT_SKU TOPS
                         WHERE TORP.RETURN_NUMBER = client_return_number
                               AND TAI.ID = AP.ACTIVITY_ID
                               AND AP.PRODUCT_ITEMNUMBER = TOPS.PRODUCT_ITEMNUMBER
                               AND TORP.ORDER_NUMBER = TOPS.ORDER_NUMBER
                               AND TOPS.PRODUCT_SKU = TSAS.PRODUCT_SKU
                               AND TOPS.WAREHOUSE_ID = TSAS.WAREHOUSE_ID
                               AND TAI.ID = TSAS.ACTIVITY_ID
                               AND TSAI.ACTIVITY_ID = TSAS.ACTIVITY_ID
                               AND AP.ACTIVITY_START_DATE <= TOPS.ORDER_DATE
                               AND AP.ACTIVITY_END_DATE >= TOPS.ORDER_DATE
                               AND TAI.ACTIVITY_STATE = '3'
                               AND TAI.STATE = '2'
							   AND TAI.ACTIVITY_TYPE != '4'
							   AND TSAI.LOCKED_STOCK = '2'
                               AND EXISTS (SELECT 1
                                    FROM TBL_ACTIVITY_SITE tas,tbl_user_info tui
                                   WHERE tas.site_id = tui.site_id
                                   AND tas.ACTIVITY_ID = TAI.ID
                                   and tops.user_name = tui.user_name
                               )
						AND (CASE WHEN (TSAI.USER_GROUP_ID = 0 OR TSAI.USER_GROUP_ID IS NULL) THEN 1 ELSE CASE WHEN EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND TSAI.USER_GROUP_ID = AA.ID AND  BB.USER_ID = temp_user_id) THEN 1 ELSE 0 END END) = 1 
            );
      --4.10更新退款单状态为已退款状态
      UPDATE TBL_ORDER_RETURN_INFO
         SET CHECK_DATE = SYSDATE, state = '2' , check_user_name = client_refund_operation_name, check_user_realname = temp_user_realname
       WHERE RETURN_NUMBER = client_return_number;
       
       --4.81当订单状态为取消订单退款时更新订单主表为关闭状态(6)
      IF temp_return_type = '1' THEN
        UPDATE TBL_ORDER_INFO
         SET REFUND_STATE = '2', ORDER_STATE = '6',CANCEL_DATE = sysdate,CANCEL_REASON = '订单自动取消：购买商品已全部退款'
        WHERE ORDER_NUMBER = temp_order_number;
      ELSE
        --4.82当退货单商品退货的总数量和订单的数量相等，更新订单状态为交易关闭
         --退货总数量-订单商品数量
        SELECT sum(T1.PRODUCT_COUNT)-max(T2.PRODUCT_COUNT)
          INTO temp_return_count
          FROM tbl_order_return_info t1,tbl_order_info t2
         WHERE t1.order_number = t2.order_number
           AND t2.order_number = temp_order_number
           AND t1.state ='2';
        IF temp_return_count = 0 THEN  --更新订单状态：交易关闭
          UPDATE TBL_ORDER_INFO
             SET ORDER_STATE = '6',CANCEL_DATE = sysdate,CANCEL_REASON = '订单自动取消：购买商品已全部退款'
           WHERE ORDER_NUMBER = temp_order_number;
        END IF;
      END IF; 
       
       
      --4.11订单占用量处理
      SELECT WAREHOUSE_ID INTO v_order_warehouse_id FROM TBL_ORDER_INFO WHERE ORDER_NUMBER =  temp_order_number;
      DECLARE
          CURSOR order_return_list IS
            SELECT T.PRODUCT_SKU,T.COUNT FROM TBL_ORDER_RETURN_PRODUCT T WHERE T.RETURN_NUMBER = client_return_number;
      BEGIN
          FOR order_return IN order_return_list LOOP
            v_product_sku := order_return.PRODUCT_SKU;
            v_return_count := order_return.COUNT;
            v_occupy_count := 0;
            SELECT COUNT(1) INTO temp_count FROM TBL_ORDER_WAREHOUSE_COUNT T WHERE T.ORDER_NUMBER = temp_order_number AND T.PRODUCT_SKU = v_product_sku AND T.WAREHOUSE_ID <> v_order_warehouse_id;
            IF temp_count = 1 THEN
               SELECT NVL(T.OCCUPY_COUNT,0) INTO v_occupy_count FROM TBL_ORDER_WAREHOUSE_COUNT T WHERE T.ORDER_NUMBER = temp_order_number AND T.PRODUCT_SKU = v_product_sku AND T.WAREHOUSE_ID <> v_order_warehouse_id;
               IF v_return_count >= v_occupy_count THEN
                  DELETE FROM TBL_ORDER_WAREHOUSE_COUNT T WHERE T.ORDER_NUMBER = temp_order_number AND T.PRODUCT_SKU = v_product_sku AND T.WAREHOUSE_ID <> v_order_warehouse_id;
                  UPDATE TBL_ORDER_WAREHOUSE_COUNT T SET T.OCCUPY_COUNT = T.OCCUPY_COUNT - (v_return_count - v_occupy_count) WHERE T.ORDER_NUMBER = temp_order_number AND T.PRODUCT_SKU = v_product_sku AND T.WAREHOUSE_ID = v_order_warehouse_id;
               ELSE
                  UPDATE TBL_ORDER_WAREHOUSE_COUNT T SET T.OCCUPY_COUNT = T.OCCUPY_COUNT - v_return_count WHERE T.ORDER_NUMBER = temp_order_number AND T.PRODUCT_SKU = v_product_sku AND T.WAREHOUSE_ID <> v_order_warehouse_id;
               END IF;
            ELSE
               UPDATE TBL_ORDER_WAREHOUSE_COUNT T SET T.OCCUPY_COUNT = T.OCCUPY_COUNT - v_return_count WHERE T.ORDER_NUMBER = temp_order_number AND T.PRODUCT_SKU = v_product_sku AND T.WAREHOUSE_ID = v_order_warehouse_id;
            END IF;
          END LOOP;
      END;
      DELETE FROM TBL_ORDER_WAREHOUSE_COUNT T WHERE T.OCCUPY_COUNT < 1 AND T.ORDER_NUMBER = temp_order_number;
  --5.0退款单驳回操作
  ELSIF CLIENT_OPERATE_TYPE ='02' THEN
      IF temp_return_type = '1' THEN
         update tbl_order_info
         set order_state = 2,refund_state=0
       where order_number = temp_order_number;
      END IF;
      --更新退货单驳回信息
      UPDATE TBL_ORDER_RETURN_INFO
         SET CHECK_DATE = SYSDATE, CHECK_USER_NAME = client_refund_operation_name, CHECK_USER_REALNAME = temp_user_realname, STATE='3',CHECK_CANCLE_REASON =client_return_reject_reson
       WHERE RETURN_NUMBER = client_return_number;
  ELSE
     output_msg := '不支持的操作类型';
     RETURN;
  End If;
  output_status := '1';
  output_msg    := '操作成功';
EXCEPTION
  WHEN OTHERS THEN
    output_msg := '操作出现未知错误！';
    ROLLBACK;
END PRO_RETURN_REFUND_ORDER;
/

