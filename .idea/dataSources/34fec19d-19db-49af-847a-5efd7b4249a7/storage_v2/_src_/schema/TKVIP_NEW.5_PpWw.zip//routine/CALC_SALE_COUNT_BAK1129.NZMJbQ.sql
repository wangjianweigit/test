create PROCEDURE           CALC_SALE_COUNT_bak1129
/**
     计算商品销量固话
     定时执行，每10分钟执行一次   新版备份，已停用
     wangpeng
     2018-11-28
  **/
IS
    D_COUNT number := 0 ;--临时变量
BEGIN

   ------------统计所有销量-公式：固化数据+所有待支付+今日创建或今日支付---begin--------------------
   MERGE INTO TBL_PRODUCT_INFO P
        USING (  
            SELECT 
                (     
                    (
                        SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                        WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER AND PI.ITEMNUMBER = OP.ITEMNUMBER(+)
                        AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                        AND  OI.PAYMENT_STATE = 2 and ( TRUNC(OI.CREATE_DATE) = TRUNC(SYSDATE) or TRUNC(OI.PAYMENT_DATE) = TRUNC(SYSDATE))
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                        WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE = 1
                        AND POI.PAYMENT_STATE = '2' and ( TRUNC(POI.CREATE_DATE) = TRUNC(SYSDATE) or TRUNC(POI.PAYMENT_DATE) = TRUNC(SYSDATE))
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_DETAIL POD,TBL_PRE_ORDER_INFO POI,TBL_CUSTOM_PRODUCT_REL CPR
                        WHERE POI.ORDER_NUMBER = POD.ORDER_NUMBER and POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE  and PI.ITEMNUMBER = CPR.ORIGINAL_PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE IN (2,3) 
                        AND POI.PAYMENT_STATE = '2' and ( TRUNC(POI.CREATE_DATE) = TRUNC(SYSDATE) or TRUNC(POI.PAYMENT_DATE) = TRUNC(SYSDATE))
                    )
                ) SALE_COUNT_TODAY,
                (     
                    (
                        SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                        WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER AND PI.ITEMNUMBER = OP.ITEMNUMBER(+)
                        AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                        AND OI.PAYMENT_STATE = 1
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                        WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE = 1
                        AND POI.PAYMENT_STATE = '1'
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_DETAIL POD,TBL_PRE_ORDER_INFO POI,TBL_CUSTOM_PRODUCT_REL CPR
                        WHERE POI.ORDER_NUMBER = POD.ORDER_NUMBER and POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE  and PI.ITEMNUMBER = CPR.ORIGINAL_PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE IN (2,3) 
                        AND POI.PAYMENT_STATE = '1'
                    )
                ) SALE_COUNT_ALLNOPAY,
                (     
                    (
                        SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                        WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER AND PI.ITEMNUMBER = OP.ITEMNUMBER(+)
                        AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                        AND OI.PAYMENT_STATE = 1 AND OI.CREATE_DATE > TRUNC(SYSDATE-7)
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                        WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE = 1
                        AND POI.PAYMENT_STATE = '1' AND POI.CREATE_DATE > TRUNC(SYSDATE-7)
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_DETAIL POD,TBL_PRE_ORDER_INFO POI,TBL_CUSTOM_PRODUCT_REL CPR
                        WHERE POI.ORDER_NUMBER = POD.ORDER_NUMBER and POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE  and PI.ITEMNUMBER = CPR.ORIGINAL_PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE IN (2,3) 
                        AND POI.PAYMENT_STATE = '1' AND POI.CREATE_DATE > TRUNC(SYSDATE-7)
                    )
                ) SALE_COUNT_7NOPAY,
                (     
                    (
                        SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                        WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER AND PI.ITEMNUMBER = OP.ITEMNUMBER(+)
                        AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                        AND OI.PAYMENT_STATE = 1 AND OI.CREATE_DATE > TRUNC(SYSDATE-15)
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                        WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE = 1
                        AND POI.PAYMENT_STATE = '1' AND POI.CREATE_DATE > TRUNC(SYSDATE-15)
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_DETAIL POD,TBL_PRE_ORDER_INFO POI,TBL_CUSTOM_PRODUCT_REL CPR
                        WHERE POI.ORDER_NUMBER = POD.ORDER_NUMBER and POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE  and PI.ITEMNUMBER = CPR.ORIGINAL_PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE IN (2,3) 
                        AND POI.PAYMENT_STATE = '1' AND POI.CREATE_DATE > TRUNC(SYSDATE-15)
                    )
                ) SALE_COUNT_15NOPAY,
                (     
                    (
                        SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                        WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER AND PI.ITEMNUMBER = OP.ITEMNUMBER(+)
                        AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                        AND OI.PAYMENT_STATE = 1 AND OI.CREATE_DATE > TRUNC(SYSDATE-30)
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                        WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE = 1
                        AND POI.PAYMENT_STATE = '1' AND POI.CREATE_DATE > TRUNC(SYSDATE-30)
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_DETAIL POD,TBL_PRE_ORDER_INFO POI,TBL_CUSTOM_PRODUCT_REL CPR
                        WHERE POI.ORDER_NUMBER = POD.ORDER_NUMBER and POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE  and PI.ITEMNUMBER = CPR.ORIGINAL_PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE IN (2,3) 
                        AND POI.PAYMENT_STATE = '1' AND POI.CREATE_DATE > TRUNC(SYSDATE-30)
                    )
                ) SALE_COUNT_30NOPAY,
                (     
                    (
                        SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                        WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER AND PI.ITEMNUMBER = OP.ITEMNUMBER(+)
                        AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                        AND OI.PAYMENT_STATE = 1 AND OI.CREATE_DATE > TRUNC(SYSDATE-90)
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                        WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE = 1
                        AND POI.PAYMENT_STATE = '1' AND POI.CREATE_DATE > TRUNC(SYSDATE-90)
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_DETAIL POD,TBL_PRE_ORDER_INFO POI,TBL_CUSTOM_PRODUCT_REL CPR
                        WHERE POI.ORDER_NUMBER = POD.ORDER_NUMBER and POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE  and PI.ITEMNUMBER = CPR.ORIGINAL_PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE IN (2,3) 
                        AND POI.PAYMENT_STATE = '1' AND POI.CREATE_DATE > TRUNC(SYSDATE-90)
                    )
                ) SALE_COUNT_90NOPAY,
             PI.SALE_ALL,
             PI.SALE_7,
             PI.SALE_15,
             PI.SALE_30,
             PI.SALE_90,
             PI.ITEMNUMBER
            FROM TBL_PRODUCT_SALE PI
        ) NP  
        ON (P.ITEMNUMBER = NP.ITEMNUMBER)
   WHEN MATCHED THEN
      UPDATE SET 
            P.PRODUCT_COUNT = NP.SALE_ALL + NVL(NP.SALE_COUNT_ALLNOPAY, 0) + NVL(NP.SALE_COUNT_TODAY,0),
            P.PRODUCT_COUNT7 = NP.SALE_7 + NVL(NP.SALE_COUNT_7NOPAY, 0) + NVL(NP.SALE_COUNT_TODAY,0),
            P.PRODUCT_COUNT15 = NP.SALE_15 + NVL(NP.SALE_COUNT_15NOPAY, 0) + NVL(NP.SALE_COUNT_TODAY,0),
            P.PRODUCT_COUNT30 = NP.SALE_30 + NVL(NP.SALE_COUNT_30NOPAY, 0) + NVL(NP.SALE_COUNT_TODAY,0),
            P.PRODUCT_COUNT90 = NP.SALE_90 + NVL(NP.SALE_COUNT_90NOPAY, 0) + NVL(NP.SALE_COUNT_TODAY,0)
      WHERE P.ITEMNUMBER = NP.ITEMNUMBER 
      and 
        (
            NVL(NP.SALE_COUNT_TODAY,0) <> 0
            OR NVL(NP.SALE_COUNT_ALLNOPAY, 0) <> 0
            OR NVL(NP.SALE_COUNT_7NOPAY, 0) <> 0
            OR NVL(NP.SALE_COUNT_7NOPAY, 0) <>0
            OR NVL(NP.SALE_COUNT_7NOPAY, 0) <> 0
        );
  ------------统计所有销量-公式：固化数据+所有待支付+今日创建或今日支付---end--------------------
 


  COMMIT;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
END CALC_SALE_COUNT_bak1129;
/

