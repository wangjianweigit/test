create materialized view MV_STATIONED_PRODUCT_DATA
  refresh force on demand
as
select pi.stationed_user_id,
    pi.product_type,
    (case when pi.product_type = 1 
    then (select ORIGINAL_PRODUCT_ITEMNUMBER from TBL_CUSTOM_PRODUCT_REL where CUSTOM_PRODUCT_ITEMNUMBER = pi.itemnumber)
    else pi.itemnumber
    end
    )itemnumber,
    pi.year,
    pi.SEASON_ID,
    pi.BRAND_ID,
    nvl(sku.sku_count, 0) sku_count,
    nvl(instorage.instorage_count, 0 ) instorage_count,
    nvl(pi.product_count,0) sale_count,
    nvl(rpd.rpd_count,0) rpd_count,
    nvl(orp.orp_count,0)orp_count,
    nvl(deliver.deliver_day,0) deliver_day,
    nvl(fqc.fqc_count,0) fqc_count,
    nvl(sale_return.sale_return_num,0) sale_return_num
from tbl_product_info pi
left join (
    select product_itemnumber, count(1) sku_count
    from tbl_product_sku
    group by product_itemnumber
) sku on pi.itemnumber = sku.product_itemnumber
left join (
    SELECT isd.product_itemnumber, COUNT (isd.PRODUCT_UNIQUE_CODE) instorage_count
    FROM tkerp.tbl_in_storage_detail isd
    WHERE exists(
        select 1
        from tkerp.tbl_in_storage_order iso
        where iso.state = '2' 
        and isd.in_storage_number = iso.in_storage_number
    )
    GROUP BY isd.product_itemnumber
) instorage on pi.itemnumber = instorage.product_itemnumber
left join (
    SELECT ps.product_itemnumber, COUNT (rpd.PRODUCT_UNIQUE_CODE) rpd_count
    FROM tkerp.TBL_NEW_RETURN_CONFIRM rpd
    inner join tbl_product_sku ps on rpd.product_sku = ps.id
    WHERE RPD.RETURN_FLAG = 1 
    and exists(
        select 1
        from tkerp.TBL_NEW_RETURN_ORDER ri
        where ri.state = 8 
        and ri.RETURN_NUMBER = rpd.RETURN_NUMBER
    )
    GROUP BY ps.product_itemnumber
) rpd on pi.itemnumber = rpd.product_itemnumber
left join (
    select orp.product_itemnumber, sum(orp.count) orp_count
    from tbl_order_return_product orp
    where exists(
        select 1
        from tbl_order_return_info ori
        where ori.state = 2
        and ori.return_number= orp.return_number
    )
    GROUP BY orp.product_itemnumber
) orp on pi.itemnumber = orp.product_itemnumber
left join (
    select product_itemnumber, TRUNC(sum(TOTAL_COUNT * delivery_date) / 30,1) deliver_day
    from (
        select t.product_itemnumber, t.purchase_number, sum(t.PRODUCT_COUNT) TOTAL_COUNT,
            SUM((t.APPROVAL_DATE - t.REVIEWERS_DATE) * t.PRODUCT_COUNT) /30 delivery_date
        from (
            select
                isd.product_itemnumber,
                po.purchase_number,
                min(po.REVIEWERS_DATE) REVIEWERS_DATE,
                iso.in_storage_number,
                count(isd.product_unique_code) product_count,
                min(iso.APPROVAL_DATE) APPROVAL_DATE
            from tkerp.tbl_purchase_order po
            inner join tkerp.tbl_in_storage_detail isd on isd.purchase_number = po.purchase_number
            inner join tkerp.tbl_in_storage_order iso on isd.in_storage_number = iso.in_storage_number
            where po.state= 3
            group by isd.product_itemnumber, po.purchase_number, iso.in_storage_number
        ) t
        group by t.product_itemnumber, t.purchase_number
    )
    group by product_itemnumber
)deliver on pi.itemnumber = deliver.product_itemnumber
left join (
    select pd.product_itemnumber , count(tod.product_unique_code) fqc_count
    from tkerp.TBL_TEMPORARY_OUT_DETAIL tod
    inner join tkerp.tbl_barcode_collect bc on tod.product_unique_code = bc.product_unique_code
    inner join tkerp.TBL_PURCHASE_DETAIL pd ON bc.PURCHASE_NUMBER = pd.purchase_number and bc.product_sku = pd.product_sku
    where exists(
        select 1
        from tkerp.tbl_temporary_out_order too
        where tod.temporary_out_number = too.temporary_out_number
        and too.state = 2
    )
    group by pd.product_itemnumber
)fqc on pi.itemnumber= fqc.product_itemnumber
left join (
    select ps.product_itemnumber, count(1) sale_return_num
    from tkerp.tbl_new_return_detail_code tnrdc
    inner join tkerp.tbl_product_sku ps on tnrdc.product_sku = ps.id
    where tnrdc.qualified_flag = '2' 
    group by ps.product_itemnumber
) sale_return on pi.itemnumber= sale_return.product_itemnumber
where pi.product_type in(0,1)
/

