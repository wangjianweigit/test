create PROCEDURE           iniUserProductState_Public
/**
    固化用户商品状态（通用列表中的状态生成）
     wangpeng
     2018-03-05
  **/
(
    d_user_name number               --用户名  
)
as
    v_data_time date;               --上次数据固化时间
    v_flag      number;             --是否有固化标志
    v_after     number:=1/24; --数据失效时间 1小时
    v_data_type   number:=1;          --搜索商品
begin
            --查询上次的数据固化时间
            select min(data_time),nvl(min(user_name),-1) into v_data_time,v_flag from TBL_USER_DATA_MANAGE where data_type = v_data_type and user_name = d_user_name;
            
            --有历史固化数据
            if v_flag != -1 then
                --比对数据固化时间
                if v_data_time+v_after < sysdate then
                    
                    --更新数据固化时间
                    update TBL_USER_DATA_MANAGE set data_time=sysdate where user_name = d_user_name and data_type = v_data_type;
                    
                    --删除历史固化数据
                    delete TBL_USER_DATA_DISPLAY_LIST where USER_NAME = d_user_name ;
                    
                    --数据失效重新固化数据
                    insert into TBL_USER_DATA_DISPLAY_LIST   select d_user_name,itemnumber,is_display_list_pro (d_user_name, itemnumber) from tbl_product_info where STATE <> '下架';
                    commit;
                end if;
            else
                --无历史固化数据
                insert into TBL_USER_DATA_MANAGE values(d_user_name,v_data_type,sysdate);
                
                --数据失效重新固化数据
                insert into TBL_USER_DATA_DISPLAY_LIST   select d_user_name,itemnumber,is_display_list_pro (d_user_name, itemnumber) from tbl_product_info where STATE <> '下架';
                commit;
                
            end if;
            
exception
  when others then
    rollback;
end iniUserProductState_Public;
/

