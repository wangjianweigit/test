create function           get_activity_tag
/**
   reid 2019.03.06 根据商家查询当前商品是否参加活动,同时返回活动的一些信息
   reid 2019.03.27 如果是预售活动，增加返回商品的预计到货时间
   reid 2019.07.17 参加店铺活动，返回activity_product_id数据
   
  activity_id:表示商品参加的活动的id
  activity_type：表示商品参加的活动的类型
        0：未参加活动
        1：限时折扣（数据表：tbl_sale_activity_info）;
        2：订货会（表tbl_preorder_activity_info）
        3:店铺活动
        4：预售（表tbl_presell_activity_info）
        5：清尾活动（表tbl_clear_activity_info）
   activity_state：表示商品参加的活动的状态
        waiting：活动未开始
        going：活动进行中
   返回值：activity_id + activity_type + activity_state + plan_delivery_date（仅activity_type=4时有值）+ activity_product_id
**/
(
    c_user_name             varchar2,   --用户名
    c_product_itemnumber    varchar2    --商品货号
) return varchar2
 is
     v_return_tags varchar2(500):='';                   --需要返回的标签
     v_site_id number:=0;                           --客户站点id
     v_activity_type number:=0;                     --活动类型
     v_activity_id number:=0;                       --活动id
     v_activity_state varchar2(50);                   --表示商品参加的活动的状态
     v_count number:=0;                             --临时变量
     v_activity_count number:=0;                    --临时变量
     v_plan_delivery_date varchar2(50):='';         --预计发货时间，仅activity_type=4时有值
     v_activity_product_id number:=0;               --活动商品id，关联表tbl_activity_product的id
begin
    
    --如果商品不是启用状态或者无启用状态的尺码，直接返回，不显示 zhengfangyuan 2019.02.27
    select count(1) into v_count  from tbl_product_info tpi where tpi.product_type in (0,3) and tpi.itemnumber = c_product_itemnumber and tpi.start_stop_state = 1
     and exists(
        select 1
        from tbl_product_sku
        where product_itemnumber = tpi.itemnumber
        and start_stop_state = 1
        and product_group = '尺码'
    );
    if v_count =0 then
        return v_return_tags;
    end if;
    
    --查询用户站点
    select site_id into v_site_id from tbl_user_info where user_name = c_user_name;
    /*******************查询商品是否参加了平台**********************/
    select count(ai.id) into v_count from tbl_activity_info ai,tbl_activity_detail a1 
    where a1.activity_id = ai.id 
    and exists(
        select 1 from tbl_activity_product ap 
        where  ap.activity_end_date >sysdate
        and ap.product_itemnumber = c_product_itemnumber
        and ap.activity_id = ai.id
    )
    and ai.state = 2
    and ai.is_delete = '1'
    and exists (select 1 from tbl_activity_site tas where tas.activity_id = ai.id and tas.site_id = v_site_id)
    /********订货会活动需要控制可见用户组******/
    and (case when (a1.user_group_id = 0 or a1.user_group_id is null) then 1 else case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' 
    and a1.user_group_id = aa.id and  bb.user_id = c_user_name AND (bb.ACTIVITY_ID = a1.activity_id OR bb.ACTIVITY_ID = 0)
    ) then 1 else 0 end end) = 1 
    and rownum <=1;
    /*******************查询商品是否参加了平台活动******************/
    if v_count > 0 then
        select 
        ai.id,
        ai.activity_type,
        (
            select case when tap.activity_start_date > sysdate then 'waiting' when tap.activity_start_date <= sysdate then 'going' end 
            from tbl_activity_product tap
            where tap.activity_id = ai.id
            and tap.product_itemnumber = c_product_itemnumber and rownum<2
         )  as activity_state,
         (
            select to_char(tap.plan_delivery_date,'yyyy-mm-dd hh24:mi:ss')
            from tbl_activity_product tap
            where tap.activity_id = ai.id
            and tap.product_itemnumber = c_product_itemnumber and rownum<2
         )  as plan_delivery_date,
         (
            select tap.id
            from tbl_activity_product tap
            where tap.activity_id = ai.id
            and tap.product_itemnumber = c_product_itemnumber and rownum<2
         )  as activity_product_id
         into v_activity_id,v_activity_type,v_activity_state,v_plan_delivery_date,v_activity_product_id 
         from tbl_activity_info ai,tbl_activity_detail a1
         where a1.activity_id = ai.id 
         and exists(
            select 1 from tbl_activity_product ap 
            where  ap.activity_end_date >sysdate
            and ap.product_itemnumber = c_product_itemnumber
            and ap.activity_id = ai.id
        )
        and ai.state = 2
        and ai.is_delete = '1'
        and exists (select 1 from tbl_activity_site tas where tas.activity_id = ai.id and tas.site_id = v_site_id)
        /********订货会活动需要控制可见用户组******/
        and (case when (a1.user_group_id = 0 or a1.user_group_id is null) then 1 else case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and a1.user_group_id = aa.id and  bb.user_id = c_user_name) then 1 else 0 end end) = 1
        and rownum <=1;
    end if;
    /********如果商品未参加平台活动，再查询商品是否是参加了店铺活动************/
    if v_count=0 and v_activity_id=0 then 
       select count(1) into v_count
       from tbl_sta_sale_activity ssa where exists (
            select 1 from tbl_sta_sale_activity_product ssap where
            ssap.activity_id = ssa.id
            and ssap.is_delete = 1
            and ssap.product_itemnumber = c_product_itemnumber
       )
       and ssa.activity_state = 2
       and ssa.end_date >=sysdate
       and ssa.is_delete = 1
       and rownum <=1;
    end if; 
    /***************查询参加的店铺活动*****************************/
    if v_count>0 and v_activity_id=0 then 
       select 
       ssa.id,
       3 activity_type,
       (case when ssa.begin_date > sysdate then 'waiting' when ssa.begin_date <= sysdate then 'going' end ) activity_state,
       ssap.id activity_product_id
       into v_activity_id,v_activity_type,v_activity_state,v_activity_product_id
       from tbl_sta_sale_activity ssa
       inner join tbl_sta_sale_activity_product ssap on ssap.activity_id = ssa.id
       where  ssap.is_delete = 1
       and ssap.product_itemnumber = c_product_itemnumber
       and ssa.activity_state = 2
       and ssa.end_date >=sysdate
       and ssa.is_delete = 1
       and rownum <=1;
    end if; 
    if v_activity_id =0 then 
         v_return_tags := '';
    else 
         v_return_tags := v_activity_id||'#-#'||v_activity_type||'#-#'||v_activity_state||'#-#'||v_plan_delivery_date||'#-#'||v_activity_product_id;
    end if;
    return v_return_tags;
end get_activity_tag;
/

