create PROCEDURE CANCEL_PAYMENT_STATISTICS /**
                                                                  收支报表历史数据补充
                                                                  wangjianwei
                                                                  2017-09-18
                                                                **/
                                                                (
   set_time        IN     VARCHAR2,               --指定补充收支报表历史数据年月 格式 例：201706
   output_status      OUT VARCHAR2,                         --返回的状态码 0-失败 1-成功
   output_msg         OUT VARCHAR2                                     --返回的信息
                                  )
IS
   TYPE ref_cursor_type IS REF CURSOR;                              --定义一个动态游标

   c_set_time       ref_cursor_type;                                  --定义游标类型
   t_temp_num       NUMBER := 0;                                        --临时变量
   t_current_date   VARCHAR2 (20);
   t_now_date       DATE;
   t_set_date       DATE;
BEGIN
   output_status := '0';

   SELECT TO_DATE (TO_CHAR (SYSDATE, 'yyyy-mm'), 'yyyy-mm'),
          TO_DATE (set_time, 'yyyy-mm')
     INTO t_now_date, t_set_date
     FROM DUAL;

   IF t_set_date > t_now_date
   THEN
      output_msg := '历史数据生成指定时间错误';
      RETURN;
   ELSIF t_set_date = t_now_date
   THEN
      OPEN c_set_time FOR
             SELECT TO_CHAR (
                         TRUNC (
                            TO_DATE (TO_CHAR (SYSDATE - 1, 'yyyymm'), 'yyyymm'),
                            'MM')
                       + ROWNUM
                       - 1,
                       'yyyy-MM-dd')
                       s_date
               FROM DUAL
         CONNECT BY ROWNUM <= TO_NUMBER (TO_CHAR (SYSDATE - 1, 'dd'));
   ELSE
      OPEN c_set_time FOR
             SELECT TO_CHAR (
                       TRUNC (TO_DATE (set_time, 'yyyymm'), 'MM') + ROWNUM - 1,
                       'yyyy-MM-dd')
               FROM DUAL
         CONNECT BY ROWNUM <=
                       TO_NUMBER (
                          TO_CHAR (LAST_DAY (TO_DATE (set_time, 'yyyymm')),
                                   'dd'));
   END IF;

   LOOP
      FETCH c_set_time INTO t_current_date;

      EXIT WHEN c_set_time%NOTFOUND;

      --排除已生成的收支记录
      SELECT COUNT (1)
        INTO t_temp_num
        FROM tbl_payments_settlement
       WHERE TO_CHAR (statistics_date, 'yyyy-mm-dd') = t_current_date;

      IF t_temp_num = 0
      THEN
         INSERT INTO TBL_PAYMENTS_SETTLEMENT (id,
                                              statistics_date,
                                              after_sale_return_count,
                                              after_sale_return_amount,
                                              not_send_return_count,
                                              not_send_return_amount,
                                              sales_amount,
                                              sales_count,
                                              withdrawal_amount,
                                              account_balance,
                                              ensure_amount,
                                              wait_settlement_balance,
                                              stationed_user_id)
            SELECT SEQ_PAYMENTS_SETTLEMENT.NEXTVAL,
                   TO_DATE (t_current_date, 'YYYY-MM-DD') AS statistics_date,
                   NVL (t1.after_sale_return_count, 0)
                      AS after_sale_return_count,
                   NVL (t1.after_sale_return_amount, 0)
                      AS after_sale_return_amount,
                   NVL (t2.not_send_return_count, 0) AS not_send_return_count,
                   NVL (t2.not_send_return_amount, 0)
                      AS not_send_return_amount,
                   NVL (t3.sales_amount, 0) AS sales_amount,
                   NVL (t3.sales_count, 0) AS sales_count,
                   NVL (t4.withdrawal_amount, 0) AS withdrawal_amount,
                    NVL (t5.account_balance, 0) AS account_balance,
                   NVL (t5.ensure_amount, 0) AS ensure_amount,
                   NVL (t6.wait_settlement_balance, 0)
                      AS wait_settlement_balance,
                   t_main.id AS stationed_user_id
              FROM tbl_stationed_user_info t_main,
                   --售后退货数
                   (  SELECT SUM (COUNT) after_sale_return_count,
                             SUM (return_amount) after_sale_return_amount,
                             return_user_id AS stationed_user_id
                        FROM tbl_return_amount
                       WHERE     return_type = 1
                             AND return_user_id NOT IN
                                    (SELECT VALUE
                                       FROM TBL_SYS_PARAM_CONFIG
                                      WHERE key IN
                                               ('platform_user_id',
                                                'storage_user_id'))
                             AND TO_CHAR (create_date, 'yyyy-MM-dd') =
                                    t_current_date
                    GROUP BY return_user_id) t1,
                   --未发退货
                   (  SELECT SUM (COUNT) not_send_return_count,
                             SUM (return_amount) not_send_return_amount,
                             return_user_id AS stationed_user_id
                        FROM tbl_return_amount
                       WHERE     return_type IN (2, 3)
                             AND return_user_id NOT IN
                                    (SELECT VALUE
                                       FROM TBL_SYS_PARAM_CONFIG
                                      WHERE key IN
                                               ('platform_user_id',
                                                'storage_user_id'))
                             AND TO_CHAR (create_date, 'yyyy-MM-dd') =
                                    t_current_date
                    GROUP BY return_user_id) t2,
                   --销售金额
                   (  SELECT SUM (o.product_count) AS sales_count,
                             SUM (o.product_total_money) AS sales_amount,
                             p.stationed_user_id
                        FROM v_order_station_money o,
                             tbl_product_info p,
                             tbl_order_info oi
                       WHERE     o.itemnumber = p.itemnumber
                             AND o.order_number = oi.order_number
                             AND oi.order_state IN (2, 3, 4, 5, 6)
                             AND payment_state = 2
                             AND TO_CHAR (payment_date, 'yyyy-MM-dd') =
                                    t_current_date
                    GROUP BY p.stationed_user_id) t3,
                   --提现金额
                   (  SELECT stationed_user_id,
                             SUM (withdrawal_amount) AS withdrawal_amount
                        FROM tbl_stationed_withdrawal_apply
                       WHERE TO_CHAR (create_date, 'yyyy-MM-dd') =
                                t_current_date
                    GROUP BY stationed_user_id) t4,
                   --账户余额、可提现余额、待结算余额
                   (  SELECT SUM (account_balance) AS account_balance,
                             SUM (deposit_balance) AS ensure_amount,
                             stationed_user_id
                        FROM tbl_stationed_capital_logs
                       WHERE TO_CHAR (create_date, 'yyyy-MM-dd') =
                                t_current_date
                    GROUP BY stationed_user_id) t5,
                   --结算
                   (  SELECT SUM (settlement_amount) AS wait_settlement_balance,
                             stationed_user_id
                        FROM tbl_buss_settlement_info
                       WHERE     settlement_state IN (1, 3)
                             AND bank_account_type = 1
                             AND TO_CHAR (create_date, 'yyyy-MM-dd') <=
                                    t_current_date
                    GROUP BY stationed_user_id) t6
             WHERE     t_main.id = t1.stationed_user_id(+)
                   AND t_main.id = t2.stationed_user_id(+)
                   AND t_main.id = t3.stationed_user_id(+)
                   AND t_main.id = t4.stationed_user_id(+)
                   AND t_main.id = t5.stationed_user_id(+)
                   AND t_main.id = t6.stationed_user_id(+)
                   and t_main.STATIONED_USER_TYPE = 2
                   ;
      END IF;

      t_temp_num := 0;
   END LOOP;

   output_status := 1;
   output_msg := '历史数据生成成功';
   COMMIT;
EXCEPTION
   WHEN OTHERS
   THEN
      output_msg := '历史数据生成异常';
      output_status := 0;
      ROLLBACK;
END CANCEL_PAYMENT_STATISTICS;
/

