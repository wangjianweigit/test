create TYPE "T_ORDER_PRODUCT_LST"                                                                                         AS TABLE OF T_ORDER_PRODUCT
/

