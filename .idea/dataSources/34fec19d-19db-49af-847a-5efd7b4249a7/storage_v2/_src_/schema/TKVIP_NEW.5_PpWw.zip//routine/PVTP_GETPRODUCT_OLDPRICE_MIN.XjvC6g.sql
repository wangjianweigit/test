create FUNCTION PVTP_GETPRODUCT_OLDPRICE_MIN
/**
   （新版） 获取商品             原价最低价
    reid 2019.09.16
    返回值：格式化后的商品原价
**/
(
    c_stationed_user_id    number,             --当前下单私有平台ID（即所属私有商家的ID）
    c_product_itemnumber   varchar2            --商品货号    
) return varchar2
is
    v_count number:=0;                          --临时变量
    v_product_prize_str varchar2(50):='0.00';   --需要返回的商品价格
    v_min_prize number:=0;                      --商品原价最小价
    v_min_prize_cost number:=0;                 --商品最小报价
    
    v_member_service_rate number:=0;            --会员服务费比例-汇总
    v_member_service_rate_rzs number:=0;        --会员服务费比例-入驻商
    v_member_service_rate_qj number:=0;         --会员服务费比例-全局
    v_product_create_date date;                                             --商品创建时间                          --界线新加配置
    v_sys_line date:=to_date('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置
    v_sys_line2 date:=to_date('2019-09-13 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置  针对2019-09-13新费率调整
BEGIN
    --判断商品是私有商品还是童库分享得商品
    select count(1) into v_count from TBL_PVTP_PRODUCT_INFO ppi where ppi.stationed_user_id = c_stationed_user_id and ppi.itemnumber = c_product_itemnumber;
    IF v_count <> 0 THEN
                select nvl(member_service_rate,0),nvl(area_service_rate,0) into v_member_service_rate_rzs,v_member_service_rate_qj 
                from TBL_PVTP_CONFIG where stationed_user_id = c_stationed_user_id;
                --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
                v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;
                --查询报价区间
                select nvl(min(f.product_prize_cost),0)
                into v_min_prize_cost from TBL_PVTP_PRODUCT_SKU f where f.product_group='尺码' and f.state='上架' and f.product_itemnumber = c_product_itemnumber;
    ELSE 
                /*************************商品新老计费费率控制*********begin**********************/
                select a.create_date into v_product_create_date from tbl_product_info a where a.ITEMNUMBER=c_product_itemnumber;
                if v_product_create_date < v_sys_line then
                    --查询入驻商会员服务费比例-老费率
                    select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RATE where STATIONED_USER_ID = (
                        select STATIONED_USER_ID from tbl_product_info where ITEMNUMBER=c_product_itemnumber
                    );
                end if;
                /*************************商品新老计费费率控制*********end**********************/
                
               --查询全局会员服务费比例
               --select member_service_rate into v_member_service_rate_qj from TBL_SYS_CONFIG where id = 1;
             
               if v_product_create_date >= v_sys_line then
                   --查询入驻商会员服务费比例-按当前费率计算
                   select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_USER_INFO where id = (
                       select STATIONED_USER_ID from tbl_product_info where ITEMNUMBER=c_product_itemnumber
                   );
               end if;
               
                /*************************商品新老计费费率控制****针对2019-09-13新费率调整*****begin**********************/
                if v_sys_line2 > v_product_create_date and v_product_create_date >= v_sys_line then
                    --查询入驻商会员服务费比例-老费率2次调整
                    select nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RAT2 where STATIONED_USER_ID = (
                        select STATIONED_USER_ID from tbl_product_info where ITEMNUMBER=c_product_itemnumber
                    );
                end if;
                /*************************商品新老计费费率控制****针对2019-09-13新费率调整*****begin**********************/
               
               --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
               v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;
               
               --查询原价最低价
               select nvl(min(f.product_prize_cost),0) into v_min_prize_cost from tbl_product_sku f where f.product_group='尺码' and f.state='上架' and f.product_itemnumber = c_product_itemnumber;          
    END IF;

   
    --计算应销售价（最低）=报价/（1-会员服务费比例）
    v_min_prize:=v_min_prize_cost/(1-v_member_service_rate);
    if ceil(v_min_prize)-v_min_prize<0.5 then
      v_min_prize := ceil(v_min_prize);
    elsif ceil(v_min_prize)-v_min_prize=0 then
      v_min_prize := v_min_prize;
    else 
      v_min_prize := ceil(v_min_prize)-0.5;
    end if;
    v_product_prize_str:=to_char(v_min_prize,'fm999999990.00');
   
   return v_product_prize_str;
   
END PVTP_GETPRODUCT_OLDPRICE_MIN;
/

