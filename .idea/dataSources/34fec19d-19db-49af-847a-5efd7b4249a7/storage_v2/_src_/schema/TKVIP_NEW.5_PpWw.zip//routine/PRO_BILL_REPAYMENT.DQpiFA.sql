create PROCEDURE           pro_bill_repayment
/**
   账单还款
    wanghai
    2017-05-17
    返回值：付款结果消息
**/
(

    c_user_name in varchar2,               --用户名
    c_tran_number in varchar2,            --付款交易号
    c_repayment_money in number,               --支付金额 余额+第三方支付
    c_third_type in varchar2,              --第三方信息体  支付宝 微信 银联
    c_third_number in varchar2,            --第三方支付号码
    output_status  out varchar2,                --返回的状态码 0-失败 1-成功 2-充值成功，但无法完成订单支付
    output_msg out varchar2                     --返回的信息
) AS
    v_ywjl_user_name varchar2(50);              --业务经理名称
    v_ywy_user_name varchar2(50);               --业务员名称
    v_md_id number:=0;                          --门店ID
    v_record_number varchar2(50);          --收付单号
    v_temp_count number:=0;                     --临时变量
    v_user_manage_name varchar2(50);            --客户姓名
    v_account_balance_begin number:=0;                --客户充值前余额
    v_account_balance number:=0;                --客户余额
    v_credit_money_balance number:=0;           --授信余额
    v_account_balance_checkcode varchar2(32);  --余额校验码
    v_credit_checkcode varchar2(32);       --授信余额校验码
    v_create_code varchar2(32);             --计算的校验码
    v_user_key varchar2(32);               --用户KEY
    v_credit_money_use number:=0;           --授信已使用
    v_user_id number:=0;                        --用户ID
    v_posting_type char(1) := '1';           --还款入账状态
    v_tran_amount number := 0;              --还款金额
    v_bill_id number := 0;                  --账单ID
    v_bill_number varchar2(50);             --账单号 
    v_repayment_balance number := 0;        --还款结算余额
    v_settlement_balance number := 0;       --结算余额
    v_bill_amount number := 0;              --账单金额
    v_repayment_amount number := 0;         --实际还款金额
    v_repayment_amount_o number := 0;         --已还款金额
    v_repayment_state char := '1';           --还款状态
    v_credit_money number := 0;             --授信额度
    v_upper_remain_amount number := 0;      --上月剩余需还款金额
    v_remain_amount number := 0;            --剩余还款金额
    v_bill_repayment_amount number := 0;    --最终上月账单还款金额
BEGIN
    output_status:='0';
    --获取用户信息
    select count(*) into v_temp_count from tbl_user_info where user_name = c_user_name;
    if v_temp_count<>0 then
        select user_manage_name,id,market_supervision_user_realna,referee_user_realname,store_id into v_user_manage_name,v_user_id,v_ywjl_user_name,v_ywy_user_name,v_md_id from tbl_user_info where user_name = c_user_name;
    else
        output_msg:='用户信息不能为空，请检查!';
        return;
    end if;

    --获取账户信息
    select count(*) into v_temp_count from TBL_BANK_ACCOUNT where USER_ID = v_user_id;
    if v_temp_count<>0 then
        select account_balance,credit_money,credit_money_balance,credit_money_use,account_balance_checkcode,credit_checkcode into v_account_balance_begin,v_credit_money,v_credit_money_balance,v_credit_money_use,v_account_balance_checkcode,v_credit_checkcode from TBL_BANK_ACCOUNT where USER_ID = v_user_id;
    else
        output_msg:='用户账户信息不能为空，请检查!';
        return;
    end if;

    --验证余额是否被篡改-----------------------------------------------------------------------------------------------------------------------------------------
    --获取用户KEY
    select getUserKey(c_user_name,'old','1') into v_user_key from dual;
    --获取余额校验码并判断是否被篡改
    v_create_code:=getCheck_Code(c_user_name,v_account_balance_begin,v_user_key);
    --DBMS_OUTPUT.put_line('比对余额校验码========='||v_account_balance_checkcode||'-------'||v_create_code);
    if v_account_balance_checkcode is null or v_account_balance_checkcode<>v_create_code then
        output_msg:='余额发生篡改，无法完成当前操作!';
        return;
    end if;
    --验证授信是否被篡改---------------------------------------------------------------------------------------------------------------------------------------------
    --获取授信校验码并判断是否被篡改
    v_create_code:=getCheck_Code(c_user_name,v_credit_money_balance,v_user_key);
    --DBMS_OUTPUT.put_line('比对授信校验码========='||v_credit_checkcode||'-------'||v_create_code);
    if v_credit_checkcode is null or v_credit_checkcode<>v_create_code then
        output_msg:='授信余额发生篡改，无法完成当前操作!';
        return;
    end if;

    --验证还款交易是否存在
    select  count(1) into v_temp_count
    from TBL_CREDIT_REPAYMENT_APPLY t1
    where user_id = v_user_id and tran_logno = c_tran_number;  

    if v_temp_count<>0 then
        --获取还款金额
        select bill_amount into v_tran_amount from TBL_CREDIT_REPAYMENT_APPLY t1
        where t1.user_id = v_user_id and tran_logno = c_tran_number;
    else
        output_msg:='还款交易号有误，无法完成该还款，请检查!';
        if c_third_number != '' then
            output_msg:='账单还款时，但由于还款交易号错误，无法完成还款，钱款已转入您的余额!';
        end if;
        output_status:='2';
        return;
    end if;

    --验证还款交易是否入账
    if v_posting_type = '2' then
        output_msg := c_tran_number||'还款已付款，无需重复付款!';
        if c_third_number != '' then
            output_msg:=c_tran_number||'还款已付款，无需重复付款，钱款已转入您的余额!';
        end if;
        output_status:='2';
        return;
    end if;
   
    --验证金额是否相同
    if v_tran_amount <> c_repayment_money then
        output_msg:='您支付的金额与还款金额不符!';
        if c_third_number != '' then
            output_msg:='您支付的金额与还款金额不符，钱款已转入您的余额!';
        end if;
        output_status:='2';
        return;
     end if;
     
    --获取会员待结算余额
    select nvl(max(settlement_balance), 0) into v_settlement_balance from tbl_user_settlement_balance where user_id = v_user_id;
     
    --判断上月是否已出账单
    select count(1) into v_temp_count
        from tbl_credit_bill where id = (select max(id) from tbl_credit_bill WHERE user_id = v_user_id);
    if v_temp_count<>0 then
        --获取上月已出账单
        select bill_amount-repayment_amount,repayment_amount,id into v_upper_remain_amount,v_repayment_amount,v_bill_id
            from tbl_credit_bill where id = (select max(id) from tbl_credit_bill WHERE user_id = v_user_id);
        
        --结算余额参与还款
        v_repayment_balance := c_repayment_money+v_settlement_balance;
        
        --判断上月是否有未还清账单，有，则先还清上月账单
        if v_upper_remain_amount >0 then 
            if v_upper_remain_amount <= v_repayment_balance then
                --还完
                v_bill_repayment_amount := v_upper_remain_amount;
                v_repayment_state := 3;
                v_remain_amount := v_repayment_balance - v_bill_repayment_amount;
            else
                --还部分
                v_bill_repayment_amount := v_repayment_balance;
                v_repayment_state := 2;
                v_remain_amount :=0;
            end if;   
            update tbl_credit_bill set repayment_amount = v_bill_repayment_amount,repayment_state = v_repayment_state,repayment_date = sysdate where id = v_bill_id;
        end if;
    end if;
    
    --顺序查询会员月结授信还款订单列表
    declare cursor order_list is
        select order_number,payment_money from tbl_order_info t1 
        where user_name = c_user_name and exists (
                select 1 from tbl_buss_settlement_info t2 
                where t2.order_number = t1.order_number and t2.settlement_group = '2' and t2.settlement_state = '3'
            )
        order by confirm_date;
    
    --循环订单
    begin
        for o_row in order_list loop
            --判断当前还款结算余额够不够订单还款，够则更新结算单
            if v_repayment_balance > o_row.payment_money then
                v_repayment_balance := v_repayment_balance - o_row.payment_money;
                --更新待结算单信息
                update tbl_buss_settlement_info set settlement_state = '1',pay_number = v_user_id where order_number = o_row.order_number;
            else
                exit;
            end if;
        end loop;
    end;
    
    --更新用户结算余额
    merge into tbl_user_settlement_balance c
        using (
            select
                v_user_id as user_id,
                v_repayment_balance as repayment_balance
            from dual
        ) t on (c.user_id = t.user_id)
        when matched then
            update set c.settlement_balance = t.repayment_balance
        when not matched then
            insert
            (
                user_id,
                settlement_balance
            )
            values(
                t.user_id,
                t.repayment_balance
            );
    
    --处理授信余额
    v_credit_money_balance := v_credit_money_balance + c_repayment_money;
    v_credit_money_use := v_credit_money_use - c_repayment_money;

   --生成还款记录，并扣减余额为 用户余额-还款金额      收付渠道为：支付宝、微信、银联
   insert into TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
       CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
       ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
       PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
       MONEY, SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,
       CHECK_DATE,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,
       TURNOVER_NUMBER,third_number,CREDIT_BALANCE)
   values(SEQ_USER_ACCOUNT_RECORD.NEXTVAL,c_tran_number||'3',1,c_third_type,'还款', '授信账单还款',
       sysdate,c_user_name,v_user_manage_name,
       '3131TK','童库',
       '3131','账单还款',
       c_repayment_money,v_account_balance_begin,'已审核',c_tran_number,c_user_name,c_user_name,
       sysdate,v_ywjl_user_name,v_ywy_user_name,v_md_id,
       c_tran_number,c_third_number,v_credit_money_balance);   

    --新增还款入账明细
    insert into TBL_CREDIT_BILL_DETAIL(
            id,
            tran_type,
            tran_number,
            tran_amount,
            user_id,
            posting_type,
            posting_date,
            remark
        )
        values (
            SEQ_CREDIT_BILL_DETAIL.nextval,
            '3',
            c_tran_number,
            -c_repayment_money,
            v_user_id,
            '2',
            sysdate,
            'PDA授信还款'
        ); 
    
    --更新还款申请为待审批状态
    update TBL_CREDIT_REPAYMENT_APPLY set STATE =2,PAYMENT_TYPE = c_third_type,PAY_TRAN_LOGNO = c_third_number,APPROVAL_DATE= sysdate where tran_logno = c_tran_number;
    
    --更新账户余额、授信
    update TBL_BANK_ACCOUNT set account_balance=(account_balance-c_repayment_money),credit_money_balance=v_credit_money_balance,credit_money_use=v_credit_money_use where user_id = v_user_id;

    --更新用户账户校验码
    PRO_UPDATE_USER_ACCOUNT_CODE(c_user_name);

    output_status:='1';
    output_msg:='还款成功';
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='还款出现未知错误';
    ROLLBACK;
END pro_bill_repayment;
/

