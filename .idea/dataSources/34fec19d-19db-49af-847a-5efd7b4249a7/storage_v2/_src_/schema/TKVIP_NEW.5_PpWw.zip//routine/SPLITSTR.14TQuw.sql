create FUNCTION           splitstr
/**
    目标字符串以指定字符串进行拆分，并通过表结构返回结果。
    CREATE OR REPLACE TYPE str_split IS TABLE OF VARCHAR2 (4000);
    例子：select t.column_value as dd  from (select * from table(SPLITSTR('2495,2845',','))) t
**/
(p_string IN VARCHAR2, p_delimiter IN VARCHAR2)
    RETURN str_split 
    PIPELINED
AS
    v_length   NUMBER := LENGTH(p_string);
    v_start    NUMBER := 1;
    v_index    NUMBER;
BEGIN
    WHILE(v_start <= v_length)
    LOOP
        v_index := INSTR(p_string, p_delimiter, v_start);

        IF v_index = 0
        THEN
            PIPE ROW(SUBSTR(p_string, v_start));
            v_start := v_length + 1;
        ELSE
            PIPE ROW(SUBSTR(p_string, v_start, v_index - v_start));
            v_start := v_index + 1;
        END IF;
    END LOOP;

    RETURN;
END splitstr;
/

