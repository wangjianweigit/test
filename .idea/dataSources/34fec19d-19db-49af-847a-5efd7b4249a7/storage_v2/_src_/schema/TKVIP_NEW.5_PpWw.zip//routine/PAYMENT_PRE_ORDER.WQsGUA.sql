create PROCEDURE           payment_pre_order
/**
    预付订单付订金
    wanghai
    2017-09-26
    返回值：付款结果消息
    
    reid  2018.09.26 商品定制拆分为 品牌定制，普通定制两种
    reid  2018.10.22 定制商品SKU数据中，生产SKU编码信息，规则如下
        鞋类商品：SKU编码 = 货号+颜色编码+尺码
        非鞋类商品：SKU编码 = 定制原货号的product_sku_code数据替换掉开头的货号数据
    去除商品表中预售字段          zhenghui 2019.04.10
**/
(

        client_user_name in varchar2,               --用户名
        client_order_number in varchar2,            --预付款订单号
        client_balance_money in number,             --余额支付金额
        client_credit_money in number,              --授信支付金额
        client_third_money in number,               --第三方支付金额
        client_third_type in varchar2,              --第三方信息体  支付宝 微信 银联
        client_third_number in varchar2,            --第三方支付号码
        output_status  out varchar2,                --返回的状态码 0-失败 1-成功 2-充值成功，但无法完成订单支付
        output_msg out varchar2                     --返回的信息
) AS
    v_record_number varchar2(50);          --收付单号
    v_remark varchar2(300);                 --摘要
    v_total_count number:=0;                   --总商品数量
    v_temp_count number:=0;                     --临时变量
    v_user_manage_name varchar2(50);            --客户姓名
    v_account_balance_begin number:=0;                --客户充值前余额
    v_account_balance number:=0;                --客户余额
    v_credit_money_balance number:=0;           --授信余额
    v_account_balance_checkcode varchar2(32);  --余额校验码
    v_credit_checkcode varchar2(32);       --授信余额校验码
    v_create_code varchar2(32);             --计算的校验码
    v_user_key varchar2(32);               --用户KEY
    v_credit_money_use number:=0;           --授信已使用
    v_user_id number:=0;                        --用户ID
    v_payment_state varchar2(50);               --付款状态
    v_order_state varchar2(50);            --订单流程状态
    v_logistics_money number:=0;                --数据库中的物流费用
    v_product_money number:=0;                  --数据库中的商品总价
    v_all_record_type varchar(30);              --付款渠道组合信息
    v_ORDER_TYPE varchar(50);                   --订单类型
    v_df_money number:=0;                        --代发费用
    V_YWY_USERNAME VARCHAR2(100);--业务员用户名-【收支记录】
    V_YWJL_USERNAME VARCHAR2(100);--业务经理用户名-【收支记录】
    V_MDID NUMBER;--门店ID-【收支记录】
    v_temp_order_numbers varchar2(1000) :='1001';--已付款的订单号列表
    v_frozen_balance number := 0;                --冻结余额
    v_frozen_checkcode varchar2(32);            --冻结余额校验码
    v_frozen_balance_use number := 0;           --冻结余额使用金额
    v_EARNEST_MONEY number := 0;                --应付订金
    v_pre_order_type number :=0;                --预定类型 1:预定订单(订货会)；2：定制订单（商品定制）
    v_old_product_itemnumber varchar2(50);       --原商品货号
    v_new_product_itemnumber varchar2(50);       --新商品货号
    v_brand_id  number := 0;                    --商品品牌ID
    v_year      number := 0;                    --年份
    v_season_id number := 0;                    --季节ID
    v_product_id number := 0;                   --商品ID
    v_product_type_type number:=0;              --当前生产SKU的商品类型   1.鞋类商品   2.非鞋类商品
    
BEGIN
    output_status:='0';
    --获取用户信息
    select count(*) into v_temp_count from tbl_user_info where user_name = client_user_name;
    if v_temp_count<>0 then
        select user_manage_name,id into v_user_manage_name,v_user_id from tbl_user_info where user_name = client_user_name;
    else
        output_msg:='用户信息不能为空，请检查!';
        return;
    end if;

    --获取账户信息
    select count(*) into v_temp_count from TBL_BANK_ACCOUNT where USER_ID = v_user_id;
    if v_temp_count<>0 then
        select account_balance,credit_money_balance,credit_money_use,account_balance_checkcode,credit_checkcode,frozen_balance,frozen_checkcode 
        into v_account_balance_begin,v_credit_money_balance,v_credit_money_use,v_account_balance_checkcode,v_credit_checkcode,v_frozen_balance,v_frozen_checkcode 
        from TBL_BANK_ACCOUNT where USER_ID = v_user_id;
    else
        output_msg:='用户账户信息不能为空，请检查!';
        return;
    end if;

    --获取商品总数量和预定类型
    select PRODUCT_COUNT,PRE_ORDER_TYPE into v_total_count,v_pre_order_type from TBL_PRE_ORDER_INFO where ORDER_NUMBER = client_order_number and USER_ID = client_user_name;
    
    --获取收付单号
    v_record_number:=getAutoNumber('XD');

    --验证余额是否被篡改-----------------------------------------------------------------------------------------------------------------------------------------
    --获取用户KEY
    select getUserKey(client_user_name,'old','1') into v_user_key from dual;
    --获取余额校验码并判断是否被篡改
    v_create_code:=getCheck_Code(client_user_name,v_account_balance_begin,v_user_key);
    --DBMS_OUTPUT.put_line('比对余额校验码========='||v_account_balance_checkcode||'-------'||v_create_code);
    if v_account_balance_checkcode is null or v_account_balance_checkcode<>v_create_code then
        output_msg:='余额发生篡改，无法完成当前操作!';
        return;
    end if;
    --验证授信是否被篡改---------------------------------------------------------------------------------------------------------------------------------------------
    --获取授信校验码并判断是否被篡改
    v_create_code:=getCheck_Code(client_user_name,v_credit_money_balance,v_user_key);
    --DBMS_OUTPUT.put_line('比对授信校验码========='||v_credit_checkcode||'-------'||v_create_code);
    if v_credit_checkcode is null or v_credit_checkcode<>v_create_code then
        output_msg:='授信余额发生篡改，无法完成当前操作!';
        return;
    end if;
    --验证冻结余额是否被篡改---------------------------------------------------------------------------------------------------------------------------------------------
    --获取冻结余额校验码并判断是否被篡改
    v_create_code:=getCheck_Code(client_user_name,v_frozen_balance,v_user_key);
    --DBMS_OUTPUT.put_line('比对授信校验码========='||v_credit_checkcode||'-------'||v_create_code);
    if v_frozen_checkcode is null or v_frozen_checkcode<>v_create_code then
        output_msg:='冻结余额发生篡改，无法完成当前操作!';
        return;
    end if;

    --验证订单号码是否存在
    select count(*) into v_temp_count from TBL_PRE_ORDER_INFO where ORDER_NUMBER=client_order_number and USER_ID=client_user_name;

    if v_temp_count<>0 then
       SELECT MD_ID AS MDID,YWY_USER_NAME AS YWY_USER_NAME,YWJL_USER_NAME AS YWJL_USERNAME,ORDER_STATE,EARNEST_MONEY Into V_MDID,V_YWY_USERNAME,V_YWJL_USERNAME,v_order_state,v_earnest_money
       FROM TBL_PRE_ORDER_INFO where ORDER_NUMBER=client_order_number and USER_ID=client_user_name;
    else
        output_msg:='订单号码有误，无法完成该订单，请检查!';
        if client_third_money>0 then
            output_msg:='付订单订金时，但由于订单号码错误，无法完成订单，钱款已转入您的余额!';
        end if;
        output_status:='2';
        return;
    end if;

    --验证订单状态和支付状态是否为 未支付, 【已支付的订单】
    if v_order_state <> '1' then
        output_msg:=client_order_number||'订单已付订金，无需重复付款!';
        if client_third_money>0 then
            output_msg:=client_order_number||'订单已付订金，无需重复付款，钱款已转入您的余额!';
        end if;
        output_status:='2';
        return;
    end if;
    
    --验证应付订金是否等于 余额支付金额+授信支付金额+第三方支付金额
    if (client_balance_money+client_credit_money+client_third_money) <> v_earnest_money then
        output_msg:='您支付的金额与应付订金不符!';
            if client_third_money>0 then
                output_msg:='您支付的金额与应付订金不符，钱款已转入您的余额!';
            end if;
            output_status:='2';
            return;
     end if;

   --如果第三方支付不为0，则生成消费记录，并扣减余额为 用户余额-第三方支付金额      收付渠道为：支付宝、微信、银联
    if client_third_money<>0 then
        v_all_record_type:=v_all_record_type||client_third_type;
        v_remark:='付订单订金,商品明细请见预付订单号码:'||client_order_number;
        insert into TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
                         CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
                         ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
                         PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
                         MONEY, COUNT, SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,
                         CHECK_DATE,TURNOVER_NUMBER,third_number,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,CREDIT_BALANCE)
        values(SEQ_USER_ACCOUNT_RECORD.NEXTVAL,v_record_number||'2',1,client_third_type,'付款', v_remark,
               sysdate,client_user_name,v_user_manage_name,
               '2121TK','童库',
               '2121','应付账款',
                client_third_money,v_total_count,v_account_balance_begin-client_third_money,'已审核',client_order_number,client_user_name,client_user_name,
                sysdate,v_record_number,client_third_number,V_YWJL_USERNAME,V_YWY_USERNAME,V_MDID,v_credit_money_balance);

    end if;

    --如果余额支付不为0
     if client_balance_money<>0 then
        if v_all_record_type !='' then
            v_all_record_type:=v_all_record_type||'+';
        end if;
        v_all_record_type:=v_all_record_type||'余额';
        --验证余额是否大于支付金额
        if client_balance_money>v_account_balance_begin then
            output_msg:='账户余额不足!无法完成该订单!';
            if client_third_money>0 then
                output_msg:='账户余额不足!无法完成该订单，钱款已转入您的余额!';
            end if;
            output_status:='2';
            return;
        else
            --生成消费记录，并扣减余额为 用户余额=用户余额-第三方支付金额-余额支付金额  收付渠道为：余额
            v_remark:='付订单订金,';
            v_account_balance:=v_account_balance_begin-client_third_money-client_balance_money;
            if v_frozen_balance > client_balance_money then
                v_frozen_balance := v_frozen_balance - client_balance_money;
                v_frozen_balance_use := client_balance_money;
                v_remark := v_remark||'其中冻结余额支付'||v_frozen_balance_use||'元，';
            else
                if v_frozen_balance > 0 then
                    v_frozen_balance_use := v_frozen_balance;
                    v_frozen_balance := 0;
                    v_remark := v_remark||'其中冻结余额支付'||v_frozen_balance_use||'元，';
                end if;
            end if;
            
            v_remark := v_remark||'商品明细请见预付订单号码:'||client_order_number;
            insert into TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
                             CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
                             ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
                             PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
                             MONEY, COUNT, SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,
                             CHECK_DATE,TURNOVER_NUMBER,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,CREDIT_BALANCE)
            values(SEQ_USER_ACCOUNT_RECORD.NEXTVAL,v_record_number||'3',1,'余额','付款', v_remark,
                   sysdate,client_user_name,v_user_manage_name,
                   '2121TK','童库',
                   '2121','应付账款',
                    client_balance_money,v_total_count,v_account_balance,'已审核',client_order_number,client_user_name,client_user_name,
                    sysdate,v_record_number,V_YWJL_USERNAME,V_YWY_USERNAME,V_MDID,v_credit_money_balance);
        end if;
    end if;

    --如果授信支付不为0
     if client_credit_money<>0 then
         if v_all_record_type!='' then
            v_all_record_type:=v_all_record_type||'+';
        end if;
        v_all_record_type:=v_all_record_type||'授信';
        --验证授信是否大于授信支付金额
        if client_credit_money>v_credit_money_balance then
            output_msg:='授信余额不足!无法完成该订单!';
            if client_third_money>0 then
                output_msg:='授信余额不足!无法完成该订单，钱款已转入您的余额!';
            end if;
            output_status:='2';
            return;
        else
            --生成消费记录，并扣减用户授信为  用户授信余额=用户授信余额-授信支付金额   收付渠道为：授信
            v_remark:='付订单订金,商品明细请见预付订单号码:'||client_order_number;
            v_credit_money_use:=v_credit_money_use+client_credit_money;
            insert into TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
                             CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
                             ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
                             PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
                             MONEY, COUNT, SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,
                             CHECK_DATE,TURNOVER_NUMBER,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,CREDIT_BALANCE)
            values(SEQ_USER_ACCOUNT_RECORD.NEXTVAL,v_record_number||'4',1,'授信','付款', v_remark,
                   sysdate,client_user_name,v_user_manage_name,
                   '2121TK','童库',
                   '2121','应付账款',
                    client_credit_money,v_total_count,v_account_balance_begin,'已审核',client_order_number,client_user_name,client_user_name,
                    sysdate,v_record_number,V_YWJL_USERNAME,V_YWY_USERNAME,V_MDID,v_credit_money_balance);
            
        end if;
    end if;

    --更新订单支付状态
    update TBL_PRE_ORDER_INFO set payment_number=v_record_number,order_state='2',payment_state='2',payment_date=sysdate,payment_type=v_all_record_type
    where ORDER_NUMBER=client_order_number and USER_ID=client_user_name;

    --更新账户余额、授信
    update TBL_BANK_ACCOUNT set account_balance=(account_balance-client_balance_money-client_third_money),
        credit_money_balance=(credit_money_balance-client_credit_money),credit_money_use=(credit_money_use+client_credit_money),frozen_balance=v_frozen_balance where user_id = v_user_id;

    --更新用户账户校验码
    PRO_UPDATE_USER_ACCOUNT_CODE(client_user_name);
    
    --增加冻结余额使用记录
    insert into TBL_FROZEN_BALANCE_USE(id,order_number,user_id,use_money) values(SEQ_FROZEN_BALANCE_USE.nextval,client_order_number,v_user_id,v_frozen_balance_use);
    
    --预定类型 为商品定制(品牌定制或者普通定制都属于定制)
    if v_pre_order_type = '2' or v_pre_order_type = '3' then
        --查询该用户订单的货号，品牌，年份，季节等数据
        select t.product_itemnumber,t1.brand_id,t1.year,t1.season_id,(select type from TBL_DIC_PRODUCT_TYPE where id = t1.PRODUCT_TYPE_ID)
          into v_old_product_itemnumber,v_brand_id,v_year,v_season_id,v_product_type_type
          from TBL_PRE_ORDER_DETAIL t, tbl_product_info t1
         where t.order_number = client_order_number 
               and t.product_itemnumber = t1.itemnumber
               and t.user_id = client_user_name and rownum < 2;
        
        --查询该用户 原货号是否有定制货号
        select count(1) into v_temp_count from tbl_custom_product_rel where  ORIGINAL_PRODUCT_ITEMNUMBER = v_old_product_itemnumber and CUSTOM_USER_ID = client_user_name and PRE_ORDER_TYPE = v_pre_order_type;
        if v_temp_count > 0 then 
           select custom_product_itemnumber into v_new_product_itemnumber from tbl_custom_product_rel where  ORIGINAL_PRODUCT_ITEMNUMBER = v_old_product_itemnumber and CUSTOM_USER_ID = client_user_name and PRE_ORDER_TYPE = v_pre_order_type;
        end if;
        --如果定制货号为空
        if v_new_product_itemnumber is null then
            --生成新的定制货号
            v_new_product_itemnumber := getProductItemNumber_merge(client_user_name);
            --商品ID
            select seq_product_info.nextVal into v_product_id from dual;
            --生成新的商品信息
            insert into TBL_PRODUCT_INFO
            (ID,STATIONED_USER_ID,BRAND_ID,ITEMNUMBER,PRODUCT_NAME,PRODUCT_SUBTITLE,PRODUCT_TYPE_ID,YEAR,SEASON_ID,SEX,CREATE_DATE,CREATE_USER_ID,
                    UPDATE_DATE,UPDATE_USER_ID,APPROVAL_DATE,APPROVAL_USER_ID,UNIT,PRODUCT_IMG_URL,STATE,IS_OUTSTOCK,IS_OUTSTOCK_DAY,PRODUCT_TYPE,
                    LAST_UP_DATE,UP_PERIOD,DISTRICT_TEMPLET_ID,SELL_STATE_DATE,FREIGHT_TEMPLATE_ID,WITH_CODE_ID,IS_DISTRIBUTION,SORT_VALUE,FIRST_SELL_STATE_DATE)
                select v_product_id,
                       STATIONED_USER_ID,BRAND_ID,v_new_product_itemnumber,PRODUCT_NAME,PRODUCT_SUBTITLE,PRODUCT_TYPE_ID,YEAR,SEASON_ID,SEX,CREATE_DATE,CREATE_USER_ID,
                    UPDATE_DATE,UPDATE_USER_ID,APPROVAL_DATE,APPROVAL_USER_ID,UNIT,PRODUCT_IMG_URL,STATE,IS_OUTSTOCK,IS_OUTSTOCK_DAY,1,
                    LAST_UP_DATE,UP_PERIOD,DISTRICT_TEMPLET_ID,SELL_STATE_DATE,FREIGHT_TEMPLATE_ID,WITH_CODE_ID,IS_DISTRIBUTION,SORT_VALUE,FIRST_SELL_STATE_DATE
                  from TBL_PRODUCT_INFO
                 where itemnumber = v_old_product_itemnumber;
                 
             --生成新的商品参数信息
             insert into TBL_PRODUCT_PARAMS_INFO
             (ID,STATIONED_USER_ID,PRODUCT_ID,PRODUCT_ITEMNUMBER,PARAMETER_ID,PARAMETER_VALUE)
             select SEQ_PRODUCT_PARAMS_INFO.nextVal,
                    STATIONED_USER_ID,v_product_id,v_new_product_itemnumber,PARAMETER_ID,PARAMETER_VALUE
               from TBL_PRODUCT_PARAMS_INFO
              where PRODUCT_ITEMNUMBER = v_old_product_itemnumber;
             
             --sku_id临时表
             insert into TMP_SKU_ID (old_id,new_id)
             select id,seq_product_sku.nextVal from
                (select id
                   from TBL_PRODUCT_SKU
                  where product_itemnumber = v_old_product_itemnumber
                  order by id);
             if v_product_type_type=1 then --如果当前商品是【鞋类】
                     insert into TBL_PRODUCT_SKU
                     (ID,STATIONED_USER_ID,PRODUCT_ITEMNUMBER,PRODUCT_COLOR,PRODUCT_SPECS,PARENT_ID,PRODUCT_GROUP,PRODUCT_GROUP_MEMBER,PRODUCT_COLOR_IMGURL,
                           PRODUCT_PRIZE_TAG,PRODUCT_PRIZE_COST,PRODUCT_WARNING_COUNT,PRODUCT_WEIGHT,PRODUCT_GBCODE,PRODUCT_SKU_NAME,
                           PRODUCT_INLONG,STATE,SELL_STATE_DATE,SORT_ID,IS_OUTSTOCK,PRODUCT_SKU_CODE)
                     select 
                           t1.new_id,t.STATIONED_USER_ID,v_new_product_itemnumber,t.PRODUCT_COLOR,t.PRODUCT_SPECS,t.PARENT_ID,t.PRODUCT_GROUP,t.PRODUCT_GROUP_MEMBER,t.PRODUCT_COLOR_IMGURL,
                           t.PRODUCT_PRIZE_TAG,t.PRODUCT_PRIZE_COST,t.PRODUCT_WARNING_COUNT,t.PRODUCT_WEIGHT,t.PRODUCT_GBCODE,t.PRODUCT_SKU_NAME,
                           t.PRODUCT_INLONG,t.STATE,SELL_STATE_DATE,t.SORT_ID,t.IS_OUTSTOCK,
                           (
                            case when 
                                (t.PRODUCT_GROUP = '尺码'and dpc.color_number is not null) then t.product_itemnumber||dpc.color_number||t.product_group_member
                            else 
                                ''
                            end
                           ) product_sku_code
                       from TBL_PRODUCT_SKU t
                       inner join TMP_SKU_ID t1 on T.ID = t1.old_id
                       left join TBL_DIC_PRODUCT_COLORS dpc on t.product_color = dpc.color_name
                       where T.PRODUCT_ITEMNUMBER = v_old_product_itemnumber;
             else --如果当前商品是【非鞋类】,直接使用原有的product_sku_code数据进行货号替换
                    insert into TBL_PRODUCT_SKU
                     (ID,STATIONED_USER_ID,PRODUCT_ITEMNUMBER,PRODUCT_COLOR,PRODUCT_SPECS,PARENT_ID,PRODUCT_GROUP,PRODUCT_GROUP_MEMBER,PRODUCT_COLOR_IMGURL,
                           PRODUCT_PRIZE_TAG,PRODUCT_PRIZE_COST,PRODUCT_WARNING_COUNT,PRODUCT_WEIGHT,PRODUCT_GBCODE,PRODUCT_SKU_NAME,
                           PRODUCT_INLONG,STATE,SELL_STATE_DATE,SORT_ID,IS_OUTSTOCK,PRODUCT_SKU_CODE)
                     select 
                           t1.new_id,t.STATIONED_USER_ID,v_new_product_itemnumber,t.PRODUCT_COLOR,t.PRODUCT_SPECS,t.PARENT_ID,t.PRODUCT_GROUP,t.PRODUCT_GROUP_MEMBER,t.PRODUCT_COLOR_IMGURL,
                           t.PRODUCT_PRIZE_TAG,t.PRODUCT_PRIZE_COST,t.PRODUCT_WARNING_COUNT,t.PRODUCT_WEIGHT,t.PRODUCT_GBCODE,t.PRODUCT_SKU_NAME,
                           t.PRODUCT_INLONG,t.STATE,SELL_STATE_DATE,t.SORT_ID,t.IS_OUTSTOCK,
                           (
                            case when 
                                (t.PRODUCT_GROUP = '尺码'and dpc.color_number is not null) then 
                                    v_new_product_itemnumber||SUBSTR(t.product_sku_code,length(t.product_itemnumber),length(t.product_sku_code))
                                else 
                                ''
                            end
                           ) product_sku_code
                       from TBL_PRODUCT_SKU t
                       inner join TMP_SKU_ID t1 on T.ID = t1.old_id
                       left join TBL_DIC_PRODUCT_COLORS dpc on t.product_color = dpc.color_name
                       where T.PRODUCT_ITEMNUMBER = v_old_product_itemnumber;
             end if;
             --更新sku的父类ID
             update TBL_PRODUCT_SKU t
                set parent_id = (select new_id from TMP_SKU_ID where old_id = t.parent_id)
              where PRODUCT_ITEMNUMBER = v_new_product_itemnumber
                and parent_id != 0;
            --生成新的商品图片信息
            insert into TBL_PRODUCT_IMAGES
            (id,product_id,product_itemnumber,image_url,create_user_id,create_date,sortid,is_primary,type)
            select
                SEQ_PRODUCT_IMAGES.nextval,
                v_product_id,
                v_new_product_itemnumber,
                image_url,
                create_user_id,
                sysdate,
                SEQ_PRODUCT_IMAGES.currval as sortid,
                is_primary,
                type
              from TBL_PRODUCT_IMAGES
             where PRODUCT_ITEMNUMBER = v_old_product_itemnumber;
            --更新预定订单明细数据的商品货号和SKU
            update TBL_PRE_ORDER_DETAIL t
               set (product_itemnumber,product_sku) = (select v_new_product_itemnumber,new_id from TMP_SKU_ID where old_id = t.product_sku)
             where order_number = client_order_number
                   and user_id = client_user_name;
            --更新预定订单分成表sku信息
            update TBL_PRE_ORDER_DIVIDE t
               set product_sku = (select new_id from TMP_SKU_ID where old_id = t.product_sku)
             where order_number = client_order_number;
            
            insert into TBL_CUSTOM_PRODUCT_REL
            (ORIGINAL_PRODUCT_ITEMNUMBER,CUSTOM_PRODUCT_ITEMNUMBER,CUSTOM_USER_ID,PRE_ORDER_TYPE)
            values (v_old_product_itemnumber,v_new_product_itemnumber,client_user_name,v_pre_order_type);
            
        else
            /*select count(1)
              into v_temp_count
              from TBL_PRODUCT_SKU t
             where t.product_itemnumber = v_old_product_itemnumber
                    and not exists (select 1 from TBL_PRODUCT_SKU where product_itemnumber = v_new_product_itemnumber
                    and replace(t.product_sku_name,' ','')  = replace(t.product_sku_name,' ',''))
                    order by id;*/
             select count(1)
               into v_temp_count
               from (select id,nvl(product_color,'0') product_color,
                     nvl(product_specs,'0') product_specs,
                     product_group_member from TBL_PRODUCT_SKU where product_itemnumber = v_old_product_itemnumber) t
             where not exists (
               select 1 from (select nvl(product_color,'0') product_color, 
                                     nvl(product_specs,'0') product_specs,
                                     product_group_member 
                                from TBL_PRODUCT_SKU where product_itemnumber = v_new_product_itemnumber) t1
                where t.product_color = t1.product_color
                 and t.product_specs = t1.product_specs
                 and t.product_group_member = t1.product_group_member)
                 order by t.id;
            if v_temp_count > 0 then
                --sku_id临时表
                insert into TMP_SKU_ID (old_id,new_id)
                select id,seq_product_sku.nextVal from
                   (select t.id
                       from (select id,nvl(product_color,'0') product_color,
                             nvl(product_specs,'0') product_specs,
                             product_group_member from TBL_PRODUCT_SKU where product_itemnumber = v_old_product_itemnumber) t
                     where not exists (
                       select 1 from (select nvl(product_color,'0') product_color, 
                                             nvl(product_specs,'0') product_specs,
                                             product_group_member 
                                        from TBL_PRODUCT_SKU where product_itemnumber = v_new_product_itemnumber) t1
                        where t.product_color = t1.product_color
                         and t.product_specs = t1.product_specs
                         and t.product_group_member = t1.product_group_member)
                         order by t.id);
                        
                --生成新的商品sku信息
                 insert into TBL_PRODUCT_SKU
                 (ID,STATIONED_USER_ID,PRODUCT_ITEMNUMBER,PRODUCT_COLOR,PRODUCT_SPECS,PARENT_ID,PRODUCT_GROUP,PRODUCT_GROUP_MEMBER,PRODUCT_COLOR_IMGURL,
                       PRODUCT_PRIZE_TAG,PRODUCT_PRIZE_COST,PRODUCT_WARNING_COUNT,PRODUCT_WEIGHT,PRODUCT_GBCODE,PRODUCT_SKU_NAME,
                       PRODUCT_INLONG,STATE,SELL_STATE_DATE,SORT_ID,IS_OUTSTOCK)
                 select t1.new_id,t.STATIONED_USER_ID,v_new_product_itemnumber,t.PRODUCT_COLOR,t.PRODUCT_SPECS,t.PARENT_ID,t.PRODUCT_GROUP,t.PRODUCT_GROUP_MEMBER,t.PRODUCT_COLOR_IMGURL,
                       t.PRODUCT_PRIZE_TAG,t.PRODUCT_PRIZE_COST,t.PRODUCT_WARNING_COUNT,t.PRODUCT_WEIGHT,t.PRODUCT_GBCODE,t.PRODUCT_SKU_NAME,
                       t.PRODUCT_INLONG,t.STATE,SELL_STATE_DATE,t.SORT_ID,t.IS_OUTSTOCK
                   from TBL_PRODUCT_SKU t, TMP_SKU_ID t1
                  where T.PRODUCT_ITEMNUMBER = v_old_product_itemnumber
                        and T.ID = t1.old_id;
                 --更新sku的父类ID
                 update TBL_PRODUCT_SKU t
                    set parent_id = (select new_id from TMP_SKU_ID where old_id = t.parent_id)
                  where PRODUCT_ITEMNUMBER = v_new_product_itemnumber
                    and parent_id != 0;
                --查询商品ID
                select id into v_product_id from tbl_product_info where itemnumber = v_new_product_itemnumber;

                --生成新的商品图片信息
                insert into TBL_PRODUCT_IMAGES
                (id,product_id,product_itemnumber,image_url,create_user_id,create_date,sortid,is_primary,type)
                select
                    SEQ_PRODUCT_IMAGES.nextval,
                    v_product_id,
                    v_new_product_itemnumber,
                    image_url,
                    create_user_id,
                    sysdate,
                    SEQ_PRODUCT_IMAGES.currval as sortid,
                    is_primary,
                    type
                  from TBL_PRODUCT_IMAGES t
                 where t.product_itemnumber = v_old_product_itemnumber
                 and not exists (select 1 from TBL_PRODUCT_IMAGES where image_url = t.image_url and product_itemnumber = v_new_product_itemnumber);
                 
                 --生成新的商品参数信息
                 insert into TBL_PRODUCT_PARAMS_INFO
                 (ID,STATIONED_USER_ID,PRODUCT_ID,PRODUCT_ITEMNUMBER,PARAMETER_ID,PARAMETER_VALUE)
                 select SEQ_PRODUCT_PARAMS_INFO.nextVal,
                        STATIONED_USER_ID,v_product_id,v_new_product_itemnumber,PARAMETER_ID,PARAMETER_VALUE
                  from TBL_PRODUCT_PARAMS_INFO t
                 where t.product_itemnumber = v_old_product_itemnumber
                 and not exists (select 1 from TBL_PRODUCT_PARAMS_INFO where PARAMETER_ID = t.PARAMETER_ID and product_itemnumber = v_new_product_itemnumber);
            end if;
            
            --更新预定订单明细数据的商品货号和SKU
            update TBL_PRE_ORDER_DETAIL t
               set (product_itemnumber,product_sku) = (select product_itemnumber,id from tbl_product_sku where product_itemnumber = v_new_product_itemnumber and product_color = t.product_color and PRODUCT_GROUP_MEMBER = t.product_size)
             where order_number = client_order_number
                   and user_id = client_user_name;
            --skuid临时表
            insert into TMP_SKU_ID (new_id,old_id)
            select t.id as new_id, t1.id as old_id 
              from (select id,product_color,PRODUCT_GROUP_MEMBER as product_size from tbl_product_sku where product_itemnumber = v_new_product_itemnumber) t, 
              (select id,product_color,PRODUCT_GROUP_MEMBER as product_size from tbl_product_sku where product_itemnumber = v_old_product_itemnumber) t1 
              where t.product_color = t1.product_color
                and t.product_size = t1.product_size
                and t.id not in (select new_id from TMP_SKU_ID);
                
            --更新预定订单分成表sku信息
            update TBL_PRE_ORDER_DIVIDE t
               set product_sku = (select new_id from TMP_SKU_ID where old_id = t.product_sku)
             where order_number = client_order_number;   
            
        end if;
        --查询当前定制货号所有的颜色、规格、国标码
           DECLARE CURSOR order_sku_list
              IS
                    SELECT product_color, product_specs, product_gbcode
                        FROM tbl_pre_order_detail
                    WHERE product_itemnumber = v_new_product_itemnumber
                          and order_number = client_order_number
                    GROUP BY product_color, product_specs, product_gbcode;
           BEGIN
              FOR c_row IN order_sku_list
              LOOP
                  --更新当前定制货号所有号码的国标码
                 update tbl_product_sku set product_gbcode=c_row.product_gbcode
                 where product_itemnumber = v_new_product_itemnumber
                 and product_color=c_row.product_color and product_specs=c_row.product_specs;
                 --更新当前定制货号规格的国标码
                 update tbl_product_sku set product_gbcode=c_row.product_gbcode
                 where id in(select parent_id  from tbl_product_sku where product_itemnumber = v_new_product_itemnumber and product_color=c_row.product_color and product_specs=c_row.product_specs);
              END LOOP;
           END;
    end if;
    
    output_status:='1';
    output_msg:='订单订金支付成功';
EXCEPTION WHEN OTHERS THEN
    output_msg:='订单支付出现未知错误::'||SQLCODE || '::'||SQLERRM||'----';
    ROLLBACK;
END payment_pre_order;
/

