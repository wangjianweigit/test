create FUNCTION           getSku_User_SalePrice_v7
/**
    （新版）通过用户名获取SKU商品的             用户站点v7价
    wangpeng
    2019-03-13
    2019-09-05   update  for wangpeng  支持新老商品不同费率计算 针对2019-09-15新费率调整
    返回值：当前用户站点商品v7价格
    
**/
(
     c_user_name   varchar2,         --用户名
     c_product_sku_id   number       --商品SKUID 
) return number
 is
     v_product_prize number:=0;             --需要返回的商品价格
     v_user_id number:=0;                   --用户ID
     v_product_itemnumber   varchar2(50);   --商品货号
     v_hy_discount number:=1;               --会员等级折扣
     v_site_discount number:=1;             --站点折扣
     v_hyfwf_discount number :=1 ;          --会员服务费折扣率,站点或会员等级折扣
     v_site_id number:=0;                   --会员站点
     
     v_product_prize_cost number:=0;                 --商品报价
     v_product_sale_prize number:=0;                 --应售价
     v_member_service_rate number:=0;                --会员服务费比例-汇总
     v_member_service_rate_rzs number:=0;            --会员服务费比例-入驻商
     v_member_service_rate_qj number:=0;             --会员服务费比例-全局
     v_member_service_money_rzs number:=0;           --会员服务费-入驻商
     v_member_service_money_qj number:=0;            --会员服务费-全局
     v_product_create_date date;                                             --商品创建时间                          --界线新加配置
     v_sys_line date:=to_date('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置
     v_sys_line2 date:=to_date('2019-09-15 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置  针对2019-09-15新费率调整
     v_sys_default_hy_dis number := 0.7;                                     --新注册会员老商品采用默认费率折扣      --界线新加配置
     
BEGIN

    /*************************商品新老计费费率控制*********begin**********************/
    select a.create_date into v_product_create_date from tbl_product_info a,tbl_product_sku b where b.id = c_product_sku_id  and a.ITEMNUMBER = b.PRODUCT_ITEMNUMBER and rownum<2;
    if v_product_create_date < v_sys_line then
        --查询入驻商会员服务费比例-老费率
        select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RATE where STATIONED_USER_ID = (
            select STATIONED_USER_ID from tbl_product_sku where id = c_product_sku_id and rownum<2
        );
    end if;
    /*************************商品新老计费费率控制*********end**********************/
    
   --查询全局会员服务费比例
   --select member_service_rate into v_member_service_rate_qj from TBL_SYS_CONFIG where id = 1;
   
   if v_product_create_date >= v_sys_line then
       --查询入驻商会员服务费比例-按当前费率计算
        select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_USER_INFO where id = (
            select STATIONED_USER_ID from tbl_product_sku where id = c_product_sku_id
        );
   end if;
   
    /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
    if v_sys_line2 > v_product_create_date and v_product_create_date >= v_sys_line then
        --查询入驻商会员服务费比例-老费率2次调整
        select nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RAT2 where STATIONED_USER_ID = (
            select STATIONED_USER_ID from tbl_product_sku where id = c_product_sku_id and rownum<2
        );
    end if;
    /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/

    --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
    v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;

   --查询SKU基本信息
   select product_itemnumber,product_prize_cost into v_product_itemnumber,v_product_prize_cost from tbl_product_sku where product_group = '尺码' and id = c_product_sku_id ;

   --计算应销售价
   v_product_sale_prize:=v_product_prize_cost/(1-v_member_service_rate);

   --计算入驻商会员服务费 = 应销售价*入驻商会员服务费比例
   v_member_service_money_rzs := v_product_sale_prize * v_member_service_rate_rzs;
        
   --计算全局会员服务费 = 应销售价*全局会员服务费比例
   v_member_service_money_qj := v_product_sale_prize * v_member_service_rate_qj;

   --查询会员站点、特殊价格模板（私有站）
   select nvl(min(site_id),0),nvl(min(id),0),0.7 into v_site_id,v_user_id,v_hy_discount from tbl_user_info where user_name = c_user_name;
   
   --(按照老的费率计算)
   if v_product_create_date < v_sys_line then
        select nvl(min(discount),v_sys_default_hy_dis) into v_hy_discount from TBL_USER_OLD_DISCOUNT where user_name = c_user_name;
   end if;
   
   --查询站点折扣
   select nvl(min(discount),1) into v_site_discount from tbl_site_info  where id = v_site_id;
   
   --如果没有查询到用户信息，则返回原价
   if v_user_id=0 then
        v_product_prize:=v_product_sale_prize;
   else
           --获取 会员折扣 或  站点折扣  中最低的
           v_hyfwf_discount:= least(v_hy_discount,v_site_discount);
           
           --计算售价
           v_product_prize := v_product_prize_cost+v_member_service_money_rzs+(v_member_service_money_qj*v_hyfwf_discount);
                
   end if;

   if ceil(v_product_prize)-v_product_prize<0.5 then
      v_product_prize := ceil(v_product_prize);
   elsif ceil(v_product_prize)-v_product_prize=0 then
      v_product_prize := v_product_prize;
   else 
      v_product_prize := ceil(v_product_prize)-0.5;
   end if;
   
   return v_product_prize;
   
END getSku_User_SalePrice_v7;
/

