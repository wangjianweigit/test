create PROCEDURE           pro_update_user_account_code
/**
   更新用户校验码
    wangpeng
    2016-03-25
**/
(
        client_user_name in varchar2               --用户名
) AS
    v_user_key varchar2(32);               --用户KEY
    v_account_balance_checkcode varchar2(32);--余额校验码
    v_credit_checkcode varchar2(32);            --授信校验码
    v_frozen_checkcode varchar2(32);         --冻结余额校验码
    v_deposit_checkcode varchar2(32);        --保证金余额校验码
    v_user_type char(1);                    --账户类型
BEGIN
    select user_type into v_user_type from tbl_bank_account where user_id = client_user_name;

    --获取新的账户KEY
    select getUserKey(client_user_name,'new',v_user_type) into v_user_key from dual;

    select getcheck_code(client_user_name,account_balance,v_user_key),
        getcheck_code(client_user_name,credit_money_balance,v_user_key),
        getcheck_code(client_user_name,frozen_balance,v_user_key),
        getcheck_code(client_user_name,deposit_money_balance,v_user_key) into v_account_balance_checkcode,v_credit_checkcode,v_frozen_checkcode,v_deposit_checkcode 
    from tbl_bank_account where user_id = client_user_name;

   --DBMS_OUTPUT.put_line('生成的校验码:'||v_account_balance_checkcode||'-------'||v_credit_checkcode);

    --更新余额校验码、授信校验码、冻结余额校验码、保证金余额校验码
     update tbl_bank_account set account_balance_checkcode=v_account_balance_checkcode,
                                credit_checkcode=v_credit_checkcode,frozen_checkcode=v_frozen_checkcode,
                                deposit_checkcode=v_deposit_checkcode
                                where user_id = client_user_name;
    --更新用户账户KEY                            
    if v_user_type = '1' then
        update tbl_user_cache_key set cache_key = v_user_key,create_time=sysdate where user_name = client_user_name;
    elsif v_user_type = '2' then
        update TBL_STATIONED_CACHE_KEY set cache_key = v_user_key,create_time=sysdate where user_name = client_user_name;
    else
        update TBL_SP_CACHE_KEY set cache_key = v_user_key,create_time=sysdate where user_name = client_user_name;
    end if;


END pro_update_user_account_code;
/

