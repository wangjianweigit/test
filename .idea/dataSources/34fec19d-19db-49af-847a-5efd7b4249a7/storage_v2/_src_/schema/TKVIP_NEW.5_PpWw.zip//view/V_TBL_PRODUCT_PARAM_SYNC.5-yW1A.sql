create view V_TBL_PRODUCT_PARAM_SYNC as
SELECT T1.ID,                                                   --商品参数表同步视图
          nvl(T1.PRODUCT_ITEMNUMBER,(select ITEMNUMBER from tbl_product_info t where t.id = t1.PRODUCT_ID )) PRODUCT_ITEMNUMBER,
          T1.PARAMETER_VALUE AS PARAM_VALUE,
          T2.IS_DISPLAY,
          T1.PARAMETER_ID AS BASE_ID,
          T2.PARAMETER_NAME AS PARAM_NAME,
          T2.PRODUCT_TYPE_ID AS "type",
          T2.SORT_ID AS ORDER_NUMBER,
          T1.LAST_UPDATE_TIME
     FROM TBL_PRODUCT_PARAMS_INFO T1, tbl_dic_product_parameter T2
    WHERE T1.PARAMETER_ID = T2.ID
/

