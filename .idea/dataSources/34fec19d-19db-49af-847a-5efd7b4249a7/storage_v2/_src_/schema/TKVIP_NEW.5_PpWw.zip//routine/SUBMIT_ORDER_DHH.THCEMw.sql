create PROCEDURE           SUBMIT_ORDER_DHH
/**
    提交订单(预付订单产生普通订单)
    shif
    2017-09-27
    预付订单付尾款产生普通订单时，存在手工占用时，占用处理 shif 2017-10-08
    支持会员卡处理   shif ----------20180713

    songwangwen 2018.11.29  发货方式调整相关修改
    返回值：订单提交结果消息
    
    liujialong  2019.1.8  订单主表增加用户是否支持送货入户
    
    yejingquan 20190311 下单用户是否存在快递配置
**/
(
        client_user_name in varchar2,              --用户名
        client_pre_order_number in varchar2,       --预付订单号
        client_receiving_name in varchar2,         --收货人姓名
        client_receiving_phone in varchar2,        --收货电话
        client_user_province_id in number,         --收货地省ID
        client_receiving_address in varchar2,      --收货地址
        client_order_remark in varchar2,           --订单备注
        client_order_itemnumbers in varchar2,       --商品货号集合  使用逗号分隔
        client_order_colors in varchar2,           --商品颜色集合  使用逗号分隔
        client_order_specs in varchar2,            --商品规格集合  使用逗号分隔
        client_logistics_company_code in varchar2, --物流公司代码
        client_product_money in number,            --前台传递 商品总价
        client_logistics_money in number,          --前台传递 物流总价
        client_df_money in number,                 --前台传递 代发费用
        client_order_source  in varchar2,          --订单来源
        client_submode char,                       --下单模式   0:正常下单   1：代客户下单
        client_xdr_user_name  in varchar2,         --下单人用户名
        client_xdr_type char,                      --下单人用户类型（3：业务员，4：业务经理，5：店长，6：营业员，7：自行下单）
        client_warehouse_id number,                --下单仓库id
    client_freight_payment_type IN NUMBER,       --运费是否到付  1.先支付运费   ；2：到付运费
        output_status  out varchar2,               --返回的状态码 0-失败 1-成功
        output_msg out varchar2                    --返回的信息
) AS
    v_user_manage_name varchar2(50);          --客户姓名
    v_logistics_company_id number:=0;         --物流公司ID
    v_logistics_company_name varchar2(50);    --物流公司名称
    v_product_money number:=0;                --后台计算 商品总价
    v_logistics_money number:=0;              --后台计算 物流总价
    v_itemnumber_count int:=0;                --商品货号数组个数
    v_color_count int:=0;                     --商品颜色数组个数
    v_spec_count int:=0;                      --商品规格数组个数
    temp_count int:=1;                        --临时变量 计数
    temp_color varchar2(500);                  --临时变量 订购货号颜色
    temp_itemnumber  varchar2(500);            --临时变量 订购货号
    temp_spec  varchar2(500);                  --临时变量 订购规格
    temp_sku_ids varchar2(3000);               --临时变量 SKUID
    temp_sku_counts varchar2(3000);            --临时变量 SKU数量
    temp_product_count number:=0;             --临时变量 商品数量
    v_order_number varchar2(21);              --订单号
    v_product_total_money number:=0;          --商品总价 系统计算得出
    v_ysyf number:=0;                         --应收运费 系统计算得出
    v_temp_count int:=0;                      --临时变量
    v_order_type varchar2(50);                --订单类型  批发  代发
    v_issuing_grade_id number:=1;             --用户代发等级ID
    v_piece_cost number:=0;                   --代发等级单价费用
    v_product_total_count number:=0;          --购买商品总数
    v_df_money number:=0;                     --代发费用
    v_ywjl_user_name varchar2(50);            --业务经理username
    v_ywy_user_name  varchar2(50);            --业务员username
    v_md_id number:=0;                        --门店ID
    v_order_sku_ids varchar2(3000);           --下单sku集合，逗号分隔
    v_order_sku_counts varchar2(3000);        --下单sku数量集合，逗号分隔
    v_pay_trade_number varchar2(50 byte);     --付款交易号,
    v_earnest_money_to_use number:=0;         --订单提交使用定金
    v_earnest_money_can_use number:=0;        --可使用定金
    v_warehouse_id  number:=2;                --下单仓库【默认华东仓】
    v_activity_id  number:=0;                 --订货会活动id
    v_mbr_card     number:=1;                 --订单是否使用了会员卡优惠价格 1.未使用  2.已经使用
    v_shipping_method_id NUMBER;          --标准配送方式ID,关联表TBL_SHIPPING_METHOD的ID字段
    v_is_delivery_home NUMBER:=2;          --用户是否支持送货入户
    v_user_logistics_count     NUMBER :=0; --用户是否存在快递配置
BEGIN
    output_status:='0';
    --1.校验下单仓库是否有效
    SELECT COUNT(1)
      INTO v_temp_count
      FROM TBL_SITE_WAREHOUSE T
     WHERE T.WAREHOUSE_ID = v_warehouse_id
           AND EXISTS (SELECT 1
                         FROM TBL_USER_INFO T1
                        WHERE T1.USER_NAME = client_user_name
                              AND T1.SITE_ID = T.SITE_ID);
    IF v_temp_count = 0 THEN
        OUTPUT_MSG:='下单仓库不存在';
        RETURN;
    END IF;
    --2.校验预付订单是否符合
    SELECT COUNT(1) INTO v_temp_count FROM TBL_PRE_ORDER_INFO TPOI WHERE TPOI.USER_ID = client_user_name AND TPOI.ORDER_STATE IN('2','3') AND TPOI.ORDER_NUMBER = client_pre_order_number;
    IF v_temp_count = 0 THEN
        OUTPUT_MSG:='预付订单不存在或预付订单状态异常';
        RETURN;
    END IF;
    SELECT ACTIVITY_ID INTO v_activity_id FROM TBL_PRE_ORDER_INFO TPOI WHERE  TPOI.ORDER_NUMBER = client_pre_order_number;

    --2.数据有效性校验
    v_color_count := LENGTH(REPLACE(client_order_colors,',',',-'))-LENGTH(client_order_colors)+1;
    v_spec_count := LENGTH(REPLACE(client_order_specs,',',',-'))-LENGTH(client_order_specs)+1;
    v_itemnumber_count := LENGTH(REPLACE(client_order_itemnumbers,',',',-'))-LENGTH(client_order_itemnumbers)+1;
    IF v_color_count <> v_spec_count AND v_color_count <> v_itemnumber_count THEN
        output_msg:='商品颜色或规格个数不符!';
        RETURN;
    END IF;

    --4.查询物流公司名称
    SELECT COUNT(*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE CODE = client_logistics_company_code;
    IF v_temp_count<>0 THEN
        SELECT ID, NAME,shipping_method_id
        INTO v_logistics_company_id, v_logistics_company_name,v_shipping_method_id
    FROM TBL_LOGISTICS_COMPANY WHERE CODE = client_logistics_company_code;
    ELSE
        output_msg:='物流信息不能为空，请检查!';
        RETURN;
    END IF;

    --5.查询客户姓名
    SELECT COUNT(*) INTO v_temp_count FROM TBL_USER_INFO WHERE USER_NAME = client_user_name;
    IF v_temp_count<>0 THEN
        SELECT USER_MANAGE_NAME,ISSUING_GRADE_ID INTO v_user_manage_name,v_issuing_grade_id FROM TBL_USER_INFO WHERE USER_NAME = client_user_name;
    ELSE
        output_msg:='用户信息不能为空，请检查!';
        RETURN;
    END IF;

    --6.判断下单模式【仅限普通下单】
    IF client_submode != '0' THEN
        output_msg:='下单模式异常，请检查';
        RETURN;
    END IF;

    --7.0查询用户所属业务经理
    SELECT YWJL_USER_NAME,YWY_USER_NAME,MD_ID,MBR_CARD
      INTO v_ywjl_user_name,v_ywy_user_name,v_md_id,v_mbr_card
      FROM TBL_PRE_ORDER_INFO TPOI
     WHERE ORDER_NUMBER = client_pre_order_number;

    --8.0校验颜色规格是否已下单成功,并计算商品总数及为运费计算组装sku数据
    v_product_total_count := 0;
    v_order_sku_ids := '';
    v_order_sku_counts := '';
    WHILE temp_count <= v_color_count LOOP
        --DBMS_OUTPUT.PUT_LINE('当前SKU：'||getStrforArrid(','||client_order_sku_ids||',',',',temp_count));
        temp_product_count :=0;
        temp_sku_ids :='';
        temp_sku_counts :='';
        temp_itemnumber := getStrforArrid_str(','||client_order_itemnumbers||',',',',temp_count);
        temp_color := getStrforArrid_str(','||client_order_colors||',',',',temp_count);
        temp_spec := getStrforArrid_str(','||client_order_specs||',',',',temp_count);
        SELECT COUNT(1)
          INTO v_temp_count
          FROM TBL_ORDER_PRODUCT TOP
         WHERE TOP.USER_NAME = client_user_name
               AND TOP.ITEMNUMBER = temp_itemnumber
               AND TOP.PRODUCT_COLOR = temp_color
               AND TOP.PRODUCT_SPECS = temp_spec
               AND EXISTS (SELECT 1
                             FROM TBL_ORDER_INFO TOI
                            WHERE TOI.ORDER_NUMBER = TOP.ORDER_NUMBER
                                   AND (TOI.ORDER_STATE <> 6 or (TOI.ORDER_STATE =6 and toi.PAYMENT_STATE = 2)))
               AND EXISTS
                   (SELECT 1
                      FROM TBL_PRE_ORDER_RELATE TPOR
                     WHERE TPOR.PRE_ORDER_NUMBER = client_pre_order_number
                           AND TPOR.ORDER_NUMBER = TOP.ORDER_NUMBER);
        IF v_temp_count <> 0 THEN
           OUTPUT_MSG:='商品可下单数不足！';
           RETURN;
        END IF;
        SELECT WM_CONCAT(TPOD.PRODUCT_SKU), WM_CONCAT(TPOD.PRODUCT_COUNT),SUM(TPOD.PRODUCT_COUNT)
          INTO temp_sku_ids, temp_sku_counts,temp_product_count
          FROM TBL_PRE_ORDER_DETAIL TPOD
         WHERE TPOD.ORDER_NUMBER = client_pre_order_number
               AND TPOD.PRODUCT_ITEMNUMBER = temp_itemnumber
               AND TPOD.PRODUCT_COLOR = temp_color
               AND TPOD.PRODUCT_SPECS = temp_spec;
        IF v_color_count = temp_count THEN
            v_order_sku_ids := v_order_sku_ids || temp_sku_ids;
            v_order_sku_counts := v_order_sku_counts || temp_sku_counts;
        ELSE
            v_order_sku_ids := v_order_sku_ids || temp_sku_ids ||',';
            v_order_sku_counts := v_order_sku_counts || temp_sku_counts ||',';
        END IF;
        v_product_total_count := v_product_total_count + temp_product_count;
        temp_count := temp_count+1;
    END LOOP;

    --9.0计算物流价格
    v_ysyf := getFreightMoney(v_logistics_company_id,client_user_province_id,v_order_sku_ids,v_order_sku_counts,v_warehouse_id,client_freight_payment_type);
    --校验物流费用是否被篡改
    IF v_ysyf <> client_logistics_money THEN
        output_msg:='运费被篡改或运费计算规则发生变化,应收运费（'||v_ysyf||'），请重新下单!';
        RETURN;
    END IF;
    --11.0代发费计算及校验
    SELECT COUNT(*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE TYPE='2' AND CODE = client_logistics_company_code;
    v_df_money:=client_df_money;
    IF v_df_money IS NULL THEN
       v_df_money:=0;
    END IF;
    --当前订单为代发订单
    IF v_temp_count > 0 THEN
        --查询用户代发等级ID
        IF v_issuing_grade_id = 0 THEN
            v_issuing_grade_id := 1;
        END IF;
        --查询代发等级的单价费用
        SELECT PIECE_COST INTO v_PIECE_COST FROM TBL_ISSUING_GRADE WHERE ID = v_issuing_grade_id;
        v_piece_cost := v_product_total_count * v_piece_cost;
        IF v_piece_cost != v_df_money THEN
            output_msg:='代发费用被篡改或代发费用收取标准发生变化,应收代发费用（'||v_PIECE_COST||'），请重新下单';
            RETURN;
        END IF;
        v_order_type:='代发';
    ELSE
        IF v_df_money <>0 THEN
            output_msg:='代发费（'||v_df_money||'），当前订单不属于代发订单,无需收取代发费用，请重新下单!';
            RETURN;
        END IF;
        v_order_type:='批发';
    END IF;
      --判断当前下单用户是否支持送货入户
    select count(1) into v_temp_count  from TBL_MEMBER_DELIVERY_HOME where user_id=client_user_name and IS_SUPPORT=1 and effect_begin_date<=sysdate and  effect_end_date>=sysdate;
    if v_temp_count>0 then
        v_is_delivery_home:= 1;
    end if;
    --获取订单号
    v_order_number:=getAutoNumber('D');
    --12.0插入订单主表
    INSERT INTO TBL_ORDER_INFO(
        ID,ORDER_NUMBER,CREATE_DATE,USER_NAME,USER_MANAGE_NAME,ORDER_TYPE,
        ORDER_STATE,ORDER_REMARK,RECEIVING_NAME,RECEIVING_ADDRESS,RECEIVING_PHONE,
        LOGISTICS_COMPANY_CODE,LOGISTICS_COMPANY_NAME,LOGISTICS_MONEY,DF_MONEY,
        PAYMENT_STATE,ORDER_SOURCE,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,XDR_USER_TYPE,XDR_USER_NAME,WAREHOUSE_ID,
        OLD_LOGISTICS_MONEY,OLD_DF_MONEY,ORDER_ACTIVITY_TYPE,MBR_CARD,MBR_CARD_REDUCE,DELIVERY_TYPE,FREIGHT_PAYMENT_TYPE, IS_DELIVERY_HOME
    )
    VALUES(
        SEQ_ORDER_INFO.NEXTVAL,v_order_number,SYSDATE,client_user_name,v_user_manage_name,v_order_type,
        1,client_order_remark,client_receiving_name,client_receiving_address,client_receiving_phone,
        client_logistics_company_code,v_logistics_company_name,client_logistics_money,v_df_money,
        1,client_order_source,v_ywjl_user_name,v_ywy_user_name,v_md_id,client_xdr_type,client_xdr_user_name,v_warehouse_id,
        client_logistics_money,v_df_money,'2',v_mbr_card,0,v_shipping_method_id,client_freight_payment_type,v_is_delivery_home
    );
    --用户是否存在快递配置
   --select count(1) into v_user_logistics_count
   --  from tbl_user_logistics_config
   -- where user_id = client_user_name
   --   and state = 2;
   select (select count(1)
           from table (splitstr (t.enable_logistics, ',')) a,
                tbl_standard_logistics b
          where a.column_value = b.logistics_code
                and b.shipping_method_id = v_shipping_method_id)
          +(select count(1)
              from table (splitstr (t.enable_logistics, ',')) a,
                   tbl_standard_logistics b
             where a.column_value = b.logistics_code
                   and b.shipping_method_id = v_shipping_method_id) 
          into v_user_logistics_count
     from tbl_user_logistics_config t
    where t.user_id = client_user_name
      and t.state = 2;
    if v_user_logistics_count > 0 then
        insert into tbl_order_remark
            (
                id,
                order_number,
                disabled_logistics,
                enable_logistics,
                disabled_logistics_name,
                enabled_logistics_name,
                create_user_id,
                create_user_realname,
                create_date,
                state
            ) 
            select seq_order_remark.nextVal,
                   v_order_number,
                   disabled_logistics,
                   (select to_char (wm_concat (a.column_value))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics,
                   disabled_logistics_name,
                   (select to_char (wm_concat (b.logistics_name))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics_name,
                   create_user_id,
                   '客户设置' create_user_realname,
                   sysdate,
                   state
              from tbl_user_logistics_config t
             where user_id = client_user_name
               and state = 2;
    else
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 start
        SELECT 
        count(1) into v_temp_count
        FROM 
        TBL_LOGISTICS_COMPANY tlc
        INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
        INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
        where tlc.code = client_logistics_company_code;
        --需要新增备注数据
        IF v_temp_count<>0 THEN
            Insert into TBL_ORDER_REMARK
            (ID, ORDER_NUMBER,STATE,ENABLE_LOGISTICS,ENABLED_LOGISTICS_NAME,CREATE_DATE,CREATE_USER_ID,CREATE_USER_REALNAME)
            select
            seq_order_remark.nextval,temp.*
            from 
            (
            SELECT 
            v_order_number ORDER_NUMBER,
            2 STATE,
            to_char(wm_concat(lc.LOGISTICS_CODE)) ENABLE_LOGISTICS, 
            (wm_concat(lc.LOGISTICS_NAME)) ENABLED_LOGISTICS_NAME,
        sysdate,
        0 CREATE_USER_ID,
        '系统设置' CREATE_USER_REALNAME
            FROM 
            TBL_LOGISTICS_COMPANY tlc
            INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
            INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
            where tlc.code = client_logistics_company_code
            ) temp;
        END IF;
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 end
    end if;
    --13.0插入订单商品表
    INSERT INTO TBL_ORDER_PRODUCT(
        ID,ORDER_NUMBER, ORDER_ITEM_NUMBER,USER_NAME,USER_MANAGE_NAME,ITEMNUMBER,
        PRODUCT_NAME,PRODUCT_COLOR,
        PRODUCT_UNIT_PRICE,
        PRODUCT_UNIT_PRICE_TAG,
        PRODUCT_OLD_UNIT_PRICE,ORDER_DATE,ORDER_TYPE,PRODUCT_SPECS,
        PRODUCT_LACK_COUNT,
        WAREHOUSE_ID,
        PRODUCT_ACTIVITY_ID,
        MBR_CARD_REDUCE
    )
    SELECT SEQ_ORDER_PRODUCT.NEXTVAL,C.ORDER_NUMBER,
           C.ORDER_ITEM_NUMBER,C.USER_NAME,C.USER_MANAGE_NAME,C.PRODUCT_ITEMNUMBER,C.PRODUCT_NAME,C.PRODUCT_COLOR,
           C.PRODUCT_UNIT_PRICE,C.PRODUCT_PRIZE_TAG,C.PRODUCT_OLD_UNIT_PRICE,C.ORDER_DATE,C.ORDER_TYPE,C.PRODUCT_SPECS,
           C.PRODUCT_LACK_COUNT,C.WAREHOUSE_ID,v_activity_id,0
      FROM (
        SELECT DISTINCT
            v_order_number AS ORDER_NUMBER,
            DENSE_RANK() OVER(ORDER BY A.PRODUCT_SPECS) AS ORDER_ITEM_NUMBER,
            client_user_name AS USER_NAME,v_user_manage_name AS USER_MANAGE_NAME,
            A.PRODUCT_ITEMNUMBER,
            (SELECT F.PRODUCT_NAME FROM TBL_PRODUCT_INFO F WHERE F.ITEMNUMBER = A.PRODUCT_ITEMNUMBER AND ROWNUM = 1) AS PRODUCT_NAME,
            A.PRODUCT_COLOR,
            A.PRODUCT_UNIT_PRICE ,
            (SELECT F.PRODUCT_PRIZE_TAG FROM TBL_PRODUCT_SKU F WHERE F.ID = A.PRODUCT_SKU AND ROWNUM = 1) AS PRODUCT_PRIZE_TAG,
            A.PRODUCT_UNIT_PRICE AS PRODUCT_OLD_UNIT_PRICE,
            SYSDATE AS ORDER_DATE,
            V_ORDER_TYPE AS ORDER_TYPE,
            A.PRODUCT_SPECS,
            0 AS PRODUCT_LACK_COUNT,
            v_warehouse_id AS WAREHOUSE_ID
        FROM TBL_PRE_ORDER_DETAIL A,
        (SELECT substr(t,1,instr(t,',',1)-1) color ,substr(spec,1,instr(spec,',',1)-1) spec,substr(itemnumber,1,instr(itemnumber,',',1)-1) itemnumber FROM (
                SELECT substr(s,instr(s,',',1,ROWNUM)+1) AS t,substr(spec,instr(spec,',',1,ROWNUM)+1) AS spec,substr(itemnumber,instr(itemnumber,',',1,ROWNUM)+1) AS itemnumber,ROWNUM as d ,instr(s,',',1,ROWNUM)+1 FROM (
                    SELECT ','||client_order_colors||','  AS s,','||client_order_specs||',' as spec,','||client_order_itemnumbers||',' as itemnumber FROM DUAL
                )CONNECT BY instr(s,',','1',ROWNUM)>1
            ) WHERE T IS NOT NULL
        ) B
        WHERE A.ORDER_NUMBER = client_pre_order_number AND A.PRODUCT_ITEMNUMBER = itemnumber AND A.PRODUCT_COLOR = B.color AND A.PRODUCT_SPECS = B.spec
        ORDER BY A.PRODUCT_COLOR,A.PRODUCT_SPECS
    ) C;

    --14.0插入订单详细表
    temp_count := 1;
    WHILE temp_count<=v_color_count LOOP
        temp_itemnumber := getStrforArrid_str(','||client_order_itemnumbers||',',',',temp_count);
        temp_color := getStrforArrid_str(','||client_order_colors||',',',',temp_count);
        temp_spec := getStrforArrid_str(','||client_order_specs||',',',',temp_count);
        INSERT INTO TBL_ORDER_PRODUCT_SKU
        (
            ID,ORDER_NUMBER,ORDER_ITEM_NUMBER,USER_NAME,CODENUMBER,
            COUNT,PRODUCT_UNIT_PRICE,PRODUCT_TOTAL_MONEY,PRODUCT_OLD_UNIT_PRICE,ORDER_DATE,PRODUCT_SKU,
            PRODUCT_SKU_NAME,PRODUCT_ITEMNUMBER,PRODUCT_COLOR,PRODUCT_SPECS,PRODUCT_LACK_COUNT,PRODUCT_OLDSALE_PRIZE,WAREHOUSE_ID,MBR_CARD_REDUCE
        )
        SELECT
            SEQ_ORDER_PRODUCT_SKU.NEXTVAL,
            v_order_number,
            (SELECT TOP.ORDER_ITEM_NUMBER FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER = v_order_number AND TOP.ITEMNUMBER = A.PRODUCT_ITEMNUMBER AND ROWNUM =1) AS ORDER_ITEM_NUMBER,
            client_user_name,
            A.PRODUCT_SIZE,
            A.PRODUCT_COUNT,
            A.PRODUCT_UNIT_PRICE,
            A.PRODUCT_UNIT_PRICE * PRODUCT_COUNT,
            A.PRODUCT_UNIT_PRICE,
            SYSDATE,
            A.PRODUCT_SKU,
            (SELECT F.PRODUCT_SKU_NAME FROM TBL_PRODUCT_SKU F WHERE F.ID = A.PRODUCT_SKU AND ROWNUM = 1) AS PRODUCT_SKU_NAME,
            A.PRODUCT_ITEMNUMBER,
            A.PRODUCT_COLOR,
            A.PRODUCT_SPECS,
            0,
            getSku_OldPrice(A.PRODUCT_SKU),
            v_warehouse_id,
            A.MBR_CARD_REDUCE
         FROM TBL_PRE_ORDER_DETAIL A
        WHERE A.ORDER_NUMBER = client_pre_order_number
              AND A.PRODUCT_ITEMNUMBER = temp_itemnumber
              AND A.PRODUCT_COLOR = temp_color
              AND A.PRODUCT_SPECS = temp_spec;
        temp_count:=temp_count+1;
    END LOOP;

    --15.0修改各表的统计性数据
    UPDATE TBL_ORDER_PRODUCT TOP
        SET PRODUCT_COUNT = (SELECT SUM(TOPS.COUNT)
                               FROM TBL_ORDER_PRODUCT_SKU TOPS
                              WHERE TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER AND TOPS.PRODUCT_ITEMNUMBER = TOP.ITEMNUMBER AND TOPS.PRODUCT_COLOR = TOP.PRODUCT_COLOR AND TOPS.PRODUCT_SPECS = TOP.PRODUCT_SPECS ),
            PRODUCT_TOTAL_MONEY = (SELECT SUM(TOPS.PRODUCT_TOTAL_MONEY)
                                     FROM TBL_ORDER_PRODUCT_SKU TOPS
                                    WHERE TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER AND TOPS.PRODUCT_ITEMNUMBER = TOP.ITEMNUMBER AND TOPS.PRODUCT_COLOR = TOP.PRODUCT_COLOR AND TOPS.PRODUCT_SPECS = TOP.PRODUCT_SPECS),
            MBR_CARD_REDUCE = (SELECT SUM(TOPS.MBR_CARD_REDUCE * TOPS.COUNT)
                                     FROM TBL_ORDER_PRODUCT_SKU TOPS
                                    WHERE TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER AND TOPS.PRODUCT_ITEMNUMBER = TOP.ITEMNUMBER AND TOPS.PRODUCT_COLOR = TOP.PRODUCT_COLOR AND TOPS.PRODUCT_SPECS = TOP.PRODUCT_SPECS)                       
        WHERE TOP.ORDER_NUMBER = v_order_number;
    --处理一下,防止总价没有计算
    UPDATE TBL_ORDER_PRODUCT TOP
       SET PRODUCT_TOTAL_MONEY = ROUND(TOP.PRODUCT_COUNT * TOP.PRODUCT_UNIT_PRICE,2)
     WHERE TOP.ORDER_NUMBER = v_order_number AND NVL(PRODUCT_TOTAL_MONEY,0) = 0;
    --16.0计算商品总价
    SELECT SUM(TOP.PRODUCT_TOTAL_MONEY) INTO v_product_total_money FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER=v_order_number;
    --校验商品总价是否被篡改
    IF v_product_total_money <> client_product_money THEN
        output_msg:='商品总金额被篡改或商品总金额发生变化,应收货款（'||v_product_total_money||'），请重新下单!';
        ROLLBACK;
        RETURN;
    END IF;
    UPDATE TBL_ORDER_INFO TOI
       SET PRODUCT_MONEY = v_product_total_money,
           PRODUCT_COUNT=(SELECT SUM(TOP.PRODUCT_COUNT) FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER = TOI.ORDER_NUMBER),
           MBR_CARD_REDUCE=(SELECT SUM(TOP.MBR_CARD_REDUCE) FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER = TOI.ORDER_NUMBER)
     WHERE TOI.ORDER_NUMBER = v_order_number;
    --16.1预付订单与订单关联信息数据处理
    SELECT EARNEST_MONEY - PAYMENT_USE_MONEY,(EARNEST_MONEY/PRODUCT_MONEY) * v_product_total_money
      INTO v_earnest_money_can_use,v_earnest_money_to_use
    FROM TBL_PRE_ORDER_INFO TPOI WHERE TPOI.ORDER_NUMBER = client_pre_order_number;
    IF v_earnest_money_can_use < v_earnest_money_to_use THEN
       v_earnest_money_to_use :=v_earnest_money_can_use;
    END IF;
    --记录订单使用定金额度
    INSERT INTO TBL_PRE_ORDER_RELATE (ID,PRE_ORDER_NUMBER,ORDER_NUMBER,CREATE_DATE,EARNEST_MONEY)
         VALUES(SEQ_PRE_ORDER_RELATE.NEXTVAL,client_pre_order_number,v_order_number,SYSDATE,v_earnest_money_to_use);
    --17.0更新订单占用量
    INSERT INTO TBL_ORDER_WAREHOUSE_COUNT
       (ID, ORDER_NUMBER, WAREHOUSE_ID,PRODUCT_SKU, OCCUPY_COUNT, CREATE_DATE)
    SELECT SEQ_ORDER_WAREHOUSE_COUNT.NEXTVAL, ORDER_NUMBER, v_warehouse_id,PRODUCT_SKU, COUNT, SYSDATE
      FROM TBL_ORDER_PRODUCT_SKU
     WHERE ORDER_NUMBER = v_order_number;
    --17.1 预付订单手工占用相关处理
    DELETE FROM TBL_PRE_ORDER_WAREHOUSE_COUNT TPOW
     WHERE TPOW.PRE_ORDER_NUMBER = client_pre_order_number
           AND EXISTS(SELECT 1 FROM TBL_PRE_ORDER_INFO TPOI WHERE TPOI.WAREHOUSE_STATE = '2' AND TPOI.ORDER_NUMBER = TPOW.PRE_ORDER_NUMBER)
           AND EXISTS(
            SELECT 1
              FROM TBL_ORDER_PRODUCT_SKU TOPS
             WHERE TOPS.ORDER_NUMBER = v_order_number
                   AND TOPS.PRODUCT_SKU = TPOW.PRODUCT_SKU
                   AND TOPS.WAREHOUSE_ID = TPOW.WAREHOUSE_ID
           );
    --18.订单分成表需要从预付订单转移过去
     INSERT INTO TBL_ORDER_DIVIDE_RECORD
              (ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,ORDER_MONEY,DIVIDE_MONEY,CREATE_DATE)
    SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
           v_order_number,
           TPOD.PRODUCT_SKU,
           (SELECT TPS.PRODUCT_ITEMNUMBER  FROM TBL_PRODUCT_SKU TPS WHERE TPS.ID = TPOD.PRODUCT_SKU AND ROWNUM =1) AS PRODUCT_ITEMNUMBER,
           TPOD.DIVIDE_TYPE,
           TPOD.STATIONED_USER_ID,
           TPOD.PRODUCT_PRICE,
           TPOD.DIVIDE_MONEY,
           SYSDATE
      FROM TBL_PRE_ORDER_DIVIDE TPOD
     WHERE TPOD.ORDER_NUMBER = client_pre_order_number;
    v_pay_trade_number:='1'||getAutoNumber('D');
    INSERT INTO TBL_ORDER_UNION_PAY(ID,PAY_TRADE_NUMBER,STATE,CREATE_DATE,ORDER_SUBMOD,ORDER_XDR_TYPE,ORDER_SALE_USER_NAME)
         VALUES(SEQ_ORDER_UNION_PAY.NEXTVAL,v_pay_trade_number,0,sysdate,client_submode,client_xdr_type,client_xdr_user_name);
    INSERT INTO TBL_ORDER_UNION_PAY_DETAIL(ID,PAY_TRADE_NUMBER,ORDER_NUMBER,CREATE_DATE)
         VALUES(SEQ_ORDER_UNION_PAY_DETAIL.NEXTVAL,V_PAY_TRADE_NUMBER,v_order_number,SYSDATE);
    output_status:='1';
    output_msg:=v_pay_trade_number;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
        output_status := '0';
        output_msg:='提交订单出现未知错误::'||SQLCODE || '::'||SQLERRM||'----';
        ROLLBACK;
END SUBMIT_ORDER_DHH;
------------------------------------------------
/

