create PROCEDURE           SUBMIT_RETAIL_ORDER
/**
   新版新零售订单默认代发,不允许到付运费 
   reid   2019-07-16
**/
(
        client_user_name            in varchar2,                --用户名
        client_receiving_name       in varchar2,                --收货人姓名
        client_receiving_phone      in varchar2,                --收货电话
        client_user_province_id     in number,                  --收货地省ID
        client_receiving_address    in varchar2,                --收货地址
        client_order_id             in number,                  --订单ID，使用表TMP_NEW_ORDER的order_id字段
        output_status               out varchar2,               --返回的状态码 0-失败 1-成功
        output_msg                  out varchar2                --返回的信息
) AS
    v_user_manage_name varchar2(50);          --客户姓名
    v_logistics_company_id number:=0;         --物流公司ID
    v_logistics_company_name varchar2(50);    --物流公司名称
    v_order_number varchar2(21);              --订单号
    v_product_total_money number:=0;          --商品总价 系统计算得出
    v_temp_count int:=0;                      --临时变量
    v_is_outstock int:=0;                     --缺货预售标记
    v_order_type varchar2(50):='代发';                --订单类型   批发  代发
    v_issuing_grade_id number:=1;             --用户代发等级ID
    v_piece_cost number:=0;                   --代发等级单价费用
    v_product_total_count number:=0;          --购买商品总数
    v_user_state number:=0;                   --用户状态
    v_ywjl_user_name varchar2(50);            --业务经理用户名
    v_ywy_user_name varchar2(50);             --业务员用户名
    v_md_id number:=0;                        --门店ID
    v_xdr_user_type CHAR(1):='7';             --下单人用户类型    自行下单
    v_xdr_user_name VARCHAR2(50);             --下单人用户名
    v_distribution_state number:=0;           --是否开通了分销权限   0 未开通   1已开通              --分销绑定仓库
    v_site_id number:=0;                      --下单用户绑定仓库
    v_pay_trade_number varchar2(50 byte);     --付款交易号
    v_outstock_flag number:=0;                --是否缺货订购订单标识
    v_shipping_method_id NUMBER;              --标准配送方式ID,关联表TBL_SHIPPING_METHOD的ID字段
    v_is_delivery_home NUMBER:=2;             --用户是否支持送货入户
    v_user_logistics_count     NUMBER :=0;    --用户是否存在快递配置
    v_order_source varchar2(50):='零售';      --订单来源
    v_warehouse_id  NUMBER :=0;                --订单仓库ID
    v_product_money NUMBER :=0;                --订单仓库ID
    v_logistics_company_code varchar2(50);     --物流公司code
    v_logistics_money NUMBER :=0;              --物流费用
    v_df_money        NUMBER :=0;              --代发费用
    v_freight_payment_type NUMBER:=1;          --运费是否到付  1.先支付运费   ；2：到付运费  
    v_order_remark VARCHAR2 (1000 Byte);       --订单备注信息
    client_mbr_card  NUMBER:=1;                --是否使用会员卡金额结算  1:不使用   2：使用
    v_temp_activity_product_count NUMBER :=0;  --当前订单中，是否包含正在参加活动的商品
BEGIN
    output_status:='0';
    ---1.1根据订单id查询临时表的订单信息
    select count(1) into v_temp_count from tmp_new_order where order_id = client_order_id;
    IF v_temp_count = 0 THEN
        output_msg:='订单ID错误!';
        RETURN;
    END IF;
    SELECT warehouse_id,product_money,logistics_company_code,df_money,freight_payment_type,order_remark
    into v_warehouse_id,v_product_money,v_logistics_company_code,v_df_money,v_freight_payment_type,v_order_remark
    from TMP_NEW_ORDER where order_id = client_order_id;
    v_temp_count := 0;
    --2.1查询物流公司名称
    SELECT ID,NAME,shipping_method_id
    INTO v_logistics_company_id,v_logistics_company_name,v_shipping_method_id
    FROM TBL_LOGISTICS_COMPANY WHERE CODE = v_logistics_company_code;
    ---2.2 计算物流费用
    v_logistics_money := getFreightMoneyNew(v_logistics_company_id, client_user_province_id,v_warehouse_id,1,client_order_id);
    --3.0查询客户姓名
    SELECT COUNT(*) INTO v_temp_count FROM TBL_USER_INFO WHERE user_name = client_user_name;
    IF v_temp_count<>0 THEN
        select (select tsui.user_name from tbl_sys_user_info tsui where tsui.id = tui.market_supervision_user_id ) as market_supervision_user_name,
               (select tsui.user_name from tbl_sys_user_info tsui where tsui.id = tui.referee_user_id ) as referee_user_name,
               tui.store_id,
               tui.distribution_state,
               tui.user_manage_name,
               tui.issuing_grade_id,
               tui.user_state,
               tui.site_id
          into v_ywjl_user_name,v_ywy_user_name,v_md_id,v_distribution_state,v_user_manage_name,v_issuing_grade_id,v_user_state,v_site_id
          from tbl_user_info tui
         where user_name = client_user_name;
        IF v_user_state = 2 THEN
            output_msg:='当前经销商被禁用，无法生成代发订单!';
            RETURN;
        END IF;
        --检查当前用户是否开通了分销权限   0未开通   1已开通
        IF v_distribution_state = 0 THEN
            output_msg:='当前经销商没有开通分销权限，无法生成代发订单!';
            RETURN;
        END IF;
        v_xdr_user_name:=client_user_name;
    ELSE
        output_msg:='经销商信息不能为空，请检查!';
        RETURN;
    END IF;
    --4.0--------------------------获取订单号
    v_order_number:=getAutoNumber('D');
    --5.0-------------------------插入订单主表
    INSERT INTO TBL_ORDER_INFO(
        id,order_number, create_date,user_name,user_manage_name,order_type,
        order_state,order_remark,receiving_name,receiving_address,receiving_phone,
        logistics_company_code,logistics_company_name,logistics_money,df_money,payment_state,
        order_source,ywjl_user_name,ywy_user_name,md_id,xdr_user_type,xdr_user_name,warehouse_id,
        old_logistics_money,old_df_money,delivery_type,freight_payment_type,is_delivery_home
    )
    VALUES(
        seq_order_info.nextval,v_order_number,sysdate,client_user_name,v_user_manage_name,v_order_type,
        1,v_order_remark,client_receiving_name,client_receiving_address,client_receiving_phone,
        v_logistics_company_code,v_logistics_company_name,v_logistics_money,v_df_money,
        1,v_order_source,v_ywjl_user_name,v_ywy_user_name,v_md_id,v_xdr_user_type,v_xdr_user_name,v_warehouse_id,
        v_logistics_money,v_df_money,v_shipping_method_id,v_freight_payment_type,v_is_delivery_home
    );
    --6.1-------------------------用户是否存在快递配置,存在，则需要自动插入一条订单备注信息
    --select count(1) into v_user_logistics_count from tbl_user_logistics_config where user_id = client_user_name and state = 2;
    select (select count(1)
           from table (splitstr (t.enable_logistics, ',')) a,
                tbl_standard_logistics b
          where a.column_value = b.logistics_code
                and b.shipping_method_id = v_shipping_method_id)
          +(select count(1)
              from table (splitstr (t.enable_logistics, ',')) a,
                   tbl_standard_logistics b
             where a.column_value = b.logistics_code
                   and b.shipping_method_id = v_shipping_method_id) 
          into v_user_logistics_count
     from tbl_user_logistics_config t
    where t.user_id = client_user_name
      and t.state = 2;
    IF v_user_logistics_count > 0 THEN
        insert into tbl_order_remark
            (
                id,
                order_number,
                disabled_logistics,
                enable_logistics,
                disabled_logistics_name,
                enabled_logistics_name,
                create_user_id,
                create_user_realname,
                create_date,
                state
            ) 
            select seq_order_remark.nextVal,
                   v_order_number,
                   disabled_logistics,
                   (select to_char (wm_concat (a.column_value))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics,
                   disabled_logistics_name,
                   (select to_char (wm_concat (b.logistics_name))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics_name,
                   create_user_id,
                   '客户设置' create_user_realname,
                   sysdate,
                   state
              from tbl_user_logistics_config t
              where user_id = client_user_name
              and state = 2;
    else
    --6.2-------------------------用户不存在快递配置  插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 start
        SELECT 
        count(1) into v_temp_count
        FROM 
        TBL_LOGISTICS_COMPANY tlc
        INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
        INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
        where tlc.code = v_logistics_company_code;
        --需要新增备注数据
        IF v_temp_count<>0 THEN
            INSERT INTO TBL_ORDER_REMARK
            (id, order_number,state,enable_logistics,enabled_logistics_name,create_date,create_user_id,create_user_realname)
            select
            seq_order_remark.nextval,temp.*
            from 
            (
            SELECT 
            v_order_number order_number,
            2 state,
            to_char(wm_concat(lc.logistics_code)) enable_logistics, 
            (wm_concat(lc.logistics_name)) enabled_logistics_name,
            sysdate,
            0 create_user_id,
            '系统设置' create_user_realname
            FROM 
            TBL_LOGISTICS_COMPANY tlc
            INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
            INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
            where tlc.code = v_logistics_company_code
            ) temp;
        END IF;
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 end
    end if;
    --7.0------------------------- 插入订单商品信息表数据 start---------------------------------------
    INSERT INTO TBL_ORDER_PRODUCT (id,
                                  order_number,
                                  order_item_number,
                                  user_name,
                                  user_manage_name,
                                  itemnumber,
                                  product_name,
                                  product_color,
                                  product_unit_price,
                                  product_unit_price_tag,
                                  product_old_unit_price,
                                  order_date,
                                  order_type,
                                  product_specs,
                                  product_lack_count,
                                  warehouse_id,
                                  mbr_card_reduce,
                                  product_activity_id,
                                  activity_product_id
                                  )
      select seq_order_product.nextval,
             c.order_number,
             c.order_item_number,
             c.user_name,
             c.user_manage_name,
             c.product_itemnumber,
             c.product_name,
             c.product_color,
             c.product_unit_price,
             c.product_prize_tag,
             c.product_old_unit_price,
             c.order_date,
             c.order_type,
             c.product_specs,
             c.product_lack_count,
             c.warehouse_id,
             0,
             c.activity_id,
             c.activity_product_id
        FROM (
                     SELECT  DISTINCT
                     v_order_number      as order_number,
                     dense_rank () over (order by ps.parent_id)  as order_item_number,
                     client_user_name    AS USER_NAME,
                     v_user_manage_name  as user_manage_name,
                     ps.product_itemnumber,
                     pi.product_name, 
                     ps.product_color,
                     ops.sku_unit_price PRODUCT_UNIT_PRICE,
                     ps.product_prize_tag,
                     ops.sku_unit_price  as product_old_unit_price,
                     sysdate       as order_date,
                     v_order_type  as order_type,
                     ps.product_specs,
                     0   as product_lack_count,
                     oo.warehouse_id as warehouse_id,
                     op.activity_id,
                     op.activity_product_id
                FROM TBL_PRODUCT_SKU ps
                INNER JOIN TMP_NEW_ORDER_PRODUCT_SKU ops ON ps.id = ops.sku_id
                INNER JOIN TMP_NEW_ORDER_PRODUCT op ON ops.order_product_id = op.order_product_id
                INNER JOIN TMP_NEW_ORDER oo ON oo.order_id = op.order_id
                INNER JOIN TBL_PRODUCT_INFO pi on  pi.ITEMNUMBER = ps.PRODUCT_ITEMNUMBER
                WHERE oo.order_id = client_order_id
        ) c;
    --8.0------------------------- 插入订单SKU表信息--------------------------------------
   INSERT INTO TBL_ORDER_PRODUCT_SKU (ID,
                                      ORDER_NUMBER,
                                      ORDER_ITEM_NUMBER,
                                      USER_NAME,
                                      CODENUMBER,
                                      COUNT,
                                      PRODUCT_UNIT_PRICE,
                                      PRODUCT_TOTAL_MONEY,
                                      PRODUCT_OLD_UNIT_PRICE,
                                      ORDER_DATE,
                                      PRODUCT_SKU,
                                      PRODUCT_SKU_NAME,
                                      PRODUCT_ITEMNUMBER,
                                      PRODUCT_COLOR,
                                      PRODUCT_SPECS,
                                      PRODUCT_LACK_COUNT,
                                      PRODUCT_OLDSALE_PRIZE,
                                      WAREHOUSE_ID,
                                      MBR_CARD_REDUCE,
                                      PRODUCT_PRIZE_COST,
                                      ACTIVITY_PRODUCT_PRIZE_COST
                                      )
      SELECT       
             seq_order_product_sku.nextval,
             v_order_number,
             top.order_item_number,
             client_user_name,
             ps.product_group_member codenumber,
             ops.count,
             ops.sku_unit_price  product_unit_price,
             ops.sku_unit_price * ops.count product_total_money,
             ops.sku_unit_price product_old_unit_price,
             sysdate,
             ps.id product_sku,
             ps.product_sku_name,
             ps.product_itemnumber,
             ps.product_color,
             ps.product_specs,
             0,
             getsku_oldprice(ps.id),
             oo.warehouse_id,
             --如果使用会员了会员卡，且会员卡价格是最低价格，则有优惠额
             (
                case when (client_mbr_card =2 and ops.sku_unit_price<ops.original_sku_unit_price) 
                then (ops.original_sku_unit_price - ops.sku_unit_price)
                else 0
                end
             ) mbr_card_reduce,
              ops.product_prize_cost,
              ops.activity_product_prize_cost
        FROM TBL_PRODUCT_SKU ps
                INNER JOIN TMP_NEW_ORDER_PRODUCT_SKU ops ON ps.id = ops.sku_id
                INNER JOIN TMP_NEW_ORDER_PRODUCT op ON ops.order_product_id = op.order_product_id
                INNER JOIN TMP_NEW_ORDER oo ON oo.order_id = op.order_id
                INNER JOIN TBL_PRODUCT_INFO pi on  pi.itemnumber = ps.product_itemnumber
                LEFT JOIN TBL_ORDER_PRODUCT top on top.itemnumber = ps.product_itemnumber 
                                                    and top.product_color = ps.product_color 
                                                    and top.product_specs = ps.product_specs
                                                    and top.user_name = client_user_name
                                                    and top.order_number = v_order_number
                WHERE oo.order_id = client_order_id;
    --9.0------------------------- 修改各表的统计性数据 --------------------------------------
    UPDATE TBL_ORDER_PRODUCT TOP
        SET PRODUCT_COUNT = (SELECT SUM(TOPS.COUNT)
                               FROM TBL_ORDER_PRODUCT_SKU TOPS
                              WHERE TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER AND TOPS.ORDER_ITEM_NUMBER = TOP.ORDER_ITEM_NUMBER),
            PRODUCT_TOTAL_MONEY = (SELECT SUM(TOPS.PRODUCT_TOTAL_MONEY)
                                     FROM TBL_ORDER_PRODUCT_SKU TOPS
                                    WHERE TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER AND TOPS.ORDER_ITEM_NUMBER = TOP.ORDER_ITEM_NUMBER)
        WHERE TOP.ORDER_NUMBER = v_order_number;
    --处理一下,防止总价没有计算
    UPDATE TBL_ORDER_PRODUCT TOP
       SET PRODUCT_TOTAL_MONEY = ROUND(TOP.PRODUCT_COUNT * TOP.PRODUCT_UNIT_PRICE,2)
     WHERE TOP.ORDER_NUMBER = v_order_number AND NVL(PRODUCT_TOTAL_MONEY,0) = 0;
    --13.0计算商品总价
    SELECT SUM(TOP.PRODUCT_TOTAL_MONEY) INTO v_product_total_money FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER=v_order_number;
    --校验订单中是否包含活动商品
    select count(1) into v_temp_activity_product_count
    from tbl_order_info oi
    where oi.order_number = v_order_number
    and exists(
        select 1
        from tbl_order_product op
        where oi.order_number = op.order_number
        and op.activity_product_id > 0 and op.product_activity_id > 0
    );
    UPDATE TBL_ORDER_INFO TOI
       SET PRODUCT_MONEY = v_product_total_money,
           PRODUCT_COUNT = (SELECT SUM(TOP.PRODUCT_COUNT) FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER = TOI.ORDER_NUMBER),
           IS_OUTSTOCK_ORDER = v_outstock_flag,
           last_cancel_date = (
            CASE WHEN v_temp_activity_product_count > 0 then GETORDERLASTCANCELDATE(v_order_number)
            else toi.create_date + 1
            end
          )
     WHERE TOI.ORDER_NUMBER = v_order_number;
    --10.0------------------------- 更新订单占用量 --------------------------------------
    INSERT INTO TBL_ORDER_WAREHOUSE_COUNT
       (ID, ORDER_NUMBER, WAREHOUSE_ID,PRODUCT_SKU, OCCUPY_COUNT, CREATE_DATE)
    SELECT SEQ_ORDER_WAREHOUSE_COUNT.NEXTVAL, ORDER_NUMBER, v_warehouse_id,PRODUCT_SKU, COUNT, SYSDATE
      FROM TBL_ORDER_PRODUCT_SKU
     WHERE ORDER_NUMBER = v_order_number;
    v_pay_trade_number:='1'||getAutoNumber('D');
    --16.0------------------------- 生成清分相关记录 --------------------------------------
    --16.1 生成入驻商单个商品SKU收入
    INSERT INTO TBL_ORDER_DIVIDE_RECORD
             (ID, ORDER_NUMBER, PRODUCT_SKU, PRODUCT_ITEMNUMBER, DIVIDE_TYPE, DIVIDE_USER_ID, ORDER_MONEY, DIVIDE_MONEY, CREATE_DATE)
      SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
             ORDER_NUMBER,
             PRODUCT_SKU,
             PRODUCT_ITEMNUMBER,
             '1',
             STATIONED_USER_ID DIVIDE_USER_ID,
             PRODUCT_OLD_UNIT_PRICE ORDER_MONEY,
             GETSKU_USER_LIQUIDATIONPRICE(1, USER_NAME, PRODUCT_SKU,round(product_total_money/count,5),1) AS DIVIDE_MONEY,
             SYSDATE
        FROM (SELECT OS.ORDER_NUMBER,
                     OS.PRODUCT_SKU,
                     OS.PRODUCT_ITEMNUMBER,
                     OS.PRODUCT_OLD_UNIT_PRICE,
                     OI.USER_NAME,
                     PI.STATIONED_USER_ID,
                     os.product_total_money,
                     os.count
                FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP, TBL_ORDER_PRODUCT_SKU OS, TBL_PRODUCT_INFO PI
               WHERE OI.ORDER_NUMBER = OP.ORDER_NUMBER
                    and op.order_number = os.order_number and op.itemnumber = os.product_itemnumber and op.product_color = os.product_color and op.product_specs = os.product_specs
                     AND OS.PRODUCT_ITEMNUMBER = PI.ITEMNUMBER
                     AND OI.ORDER_NUMBER = v_order_number);

     --16.2生成平台服务单个商品SKU收入
    INSERT INTO TBL_ORDER_DIVIDE_RECORD
             (ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,ORDER_MONEY,DIVIDE_MONEY,CREATE_DATE)
      SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
             ORDER_NUMBER,
             PRODUCT_SKU,
             PRODUCT_ITEMNUMBER,
             '2',
             STATIONED_USER_ID,
             PRODUCT_OLD_UNIT_PRICE ORDER_MONEY,
             GETSKU_USER_LIQUIDATIONPRICE(2,USER_NAME,PRODUCT_SKU,round(product_total_money/count,5),1) AS DIVIDE_MONEY,
             SYSDATE
        FROM   (SELECT OS.ORDER_NUMBER,
                     OS.PRODUCT_SKU,
                     OS.PRODUCT_ITEMNUMBER,
                     OS.PRODUCT_OLD_UNIT_PRICE,
                     OI.USER_NAME,
                     PI.STATIONED_USER_ID,
                     os.product_total_money,
                     os.count
                FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP, TBL_ORDER_PRODUCT_SKU OS, TBL_PRODUCT_INFO PI
               WHERE OI.ORDER_NUMBER = OP.ORDER_NUMBER
                    and op.order_number = os.order_number and op.itemnumber = os.product_itemnumber and op.product_color = os.product_color and op.product_specs = os.product_specs
                     AND OS.PRODUCT_ITEMNUMBER = PI.ITEMNUMBER
                     AND OI.ORDER_NUMBER = v_order_number);

     --16.3生成仓储服务单个商品SKU收入
    INSERT INTO TBL_ORDER_DIVIDE_RECORD
             (ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,ORDER_MONEY,DIVIDE_MONEY,CREATE_DATE)
      SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
             ORDER_NUMBER,
             PRODUCT_SKU,
             PRODUCT_ITEMNUMBER,
             '3',
             STATIONED_USER_ID,
             PRODUCT_OLD_UNIT_PRICE ORDER_MONEY,
             GETSKU_USER_LIQUIDATIONPRICE(3,USER_NAME,PRODUCT_SKU,round(product_total_money/count,5),1) AS DIVIDE_MONEY,
             SYSDATE
        FROM   (SELECT OS.ORDER_NUMBER,
                     OS.PRODUCT_SKU,
                     OS.PRODUCT_ITEMNUMBER,
                     OS.PRODUCT_OLD_UNIT_PRICE,
                     OI.USER_NAME,
                     PI.STATIONED_USER_ID,
                     os.product_total_money,
                     os.count
                FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP, TBL_ORDER_PRODUCT_SKU OS, TBL_PRODUCT_INFO PI
               WHERE OI.ORDER_NUMBER = OP.ORDER_NUMBER
                    and op.order_number = os.order_number and op.itemnumber = os.product_itemnumber and op.product_color = os.product_color and op.product_specs = os.product_specs
                     AND OS.PRODUCT_ITEMNUMBER = PI.ITEMNUMBER
                     AND OI.ORDER_NUMBER = v_order_number);

     --16.4生成入驻商服务单个商品SKU收入
     INSERT INTO TBL_ORDER_DIVIDE_RECORD
              (ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,ORDER_MONEY,DIVIDE_MONEY,CREATE_DATE)
        SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
               ORDER_NUMBER,
               PRODUCT_SKU,
               PRODUCT_ITEMNUMBER,
               '4',
               STATIONED_USER_ID,
               PRODUCT_OLD_UNIT_PRICE ORDER_MONEY,
               GETSKU_USER_LIQUIDATIONPRICE(4,USER_NAME,PRODUCT_SKU,round(product_total_money/count,5),1) AS DIVIDE_MONEY,
               SYSDATE
          FROM (SELECT OS.ORDER_NUMBER,
                     OS.PRODUCT_SKU,
                     OS.PRODUCT_ITEMNUMBER,
                     OS.PRODUCT_OLD_UNIT_PRICE,
                     OI.USER_NAME,
                     PI.STATIONED_USER_ID,
                     os.product_total_money,
                     os.count
                FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP, TBL_ORDER_PRODUCT_SKU OS, TBL_PRODUCT_INFO PI
               WHERE OI.ORDER_NUMBER = OP.ORDER_NUMBER
                    and op.order_number = os.order_number and op.itemnumber = os.product_itemnumber and op.product_color = os.product_color and op.product_specs = os.product_specs
                     AND OS.PRODUCT_ITEMNUMBER = PI.ITEMNUMBER
                     AND OI.ORDER_NUMBER = v_order_number);

     --16.5生成入驻商服务单个商品SKU收入
     INSERT INTO TBL_ORDER_DIVIDE_RECORD
              (ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,ORDER_MONEY,DIVIDE_MONEY,CREATE_DATE)
        SELECT SEQ_ORDER_DIVIDE_RECORD.NEXTVAL,
               ORDER_NUMBER,
               PRODUCT_SKU,
               PRODUCT_ITEMNUMBER,
               '5',
               STATIONED_USER_ID,
               PRODUCT_OLD_UNIT_PRICE ORDER_MONEY,
               GETSKU_USER_LIQUIDATIONPRICE(5,USER_NAME,PRODUCT_SKU,round(product_total_money/count,5),1) AS DIVIDE_MONEY,
               SYSDATE
          FROM (SELECT OS.ORDER_NUMBER,
                     OS.PRODUCT_SKU,
                     OS.PRODUCT_ITEMNUMBER,
                     OS.PRODUCT_OLD_UNIT_PRICE,
                     OI.USER_NAME,
                     PI.STATIONED_USER_ID,
                     os.product_total_money,
                     os.count
                FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP, TBL_ORDER_PRODUCT_SKU OS, TBL_PRODUCT_INFO PI
               WHERE OI.ORDER_NUMBER = OP.ORDER_NUMBER
                    and op.order_number = os.order_number and op.itemnumber = os.product_itemnumber and op.product_color = os.product_color and op.product_specs = os.product_specs
                     AND OS.PRODUCT_ITEMNUMBER = PI.ITEMNUMBER
                     AND OI.ORDER_NUMBER = v_order_number);
     --17.0返回结果
     output_status:='1';
     output_msg:=v_order_number;
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='提交订单出现未知错误!Error line:'||dbms_utility.format_error_backtrace()||',Error code:'||SQLCODE || ',Error info:'||SQLERRM||'----';
    ROLLBACK;
END SUBMIT_RETAIL_ORDER;
------------------------------------------------
/

