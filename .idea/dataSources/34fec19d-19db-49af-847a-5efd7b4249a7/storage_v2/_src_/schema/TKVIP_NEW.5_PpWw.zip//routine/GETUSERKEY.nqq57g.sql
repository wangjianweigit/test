create FUNCTION           getUserKey
/**
    获取用户账户KEY   
    2016-03-15 wangpeng
    私有商家单独账号支持 2019-09-10 shif
**/
(
    c_user_name   varchar2,           --用户名
    c_typeid   varchar2,               --new获取新的KEY   old 老的KEY，拿来验证使用
    c_user_type   varchar2           --用户类型  用户类型：1、平台会员；2、入驻商;    3、店铺会员;   4、系统用户; 8、私有商家
) return varchar2
 is
     return_key varchar2(32);       --需要返回的key
     public_key varchar2(200);       --key的种子
     temp_str varchar2(500);         --需要md5的字符串
BEGIN
   if c_typeid='old' then
        --查询数据库保存的原始KEY
        if c_user_type='1' then
             select CACHE_KEY into return_key from TBL_USER_CACHE_KEY where user_name=c_user_name;
        elsif c_user_type='2' then
             select CACHE_KEY into return_key from TBL_STATIONED_CACHE_KEY where user_name=c_user_name;
        elsif c_user_type='5' then
             select CACHE_KEY into return_key from TBL_STORE_CACHE_KEY where user_name=c_user_name;
        elsif c_user_type='6' then
             select CACHE_KEY into return_key from TBL_SYS_CACHE_KEY where user_name=c_user_name;
        elsif c_user_type='7' then      /***平台用户会员卡余额校验码key**/
             select CACHE_KEY into return_key from TBL_USER_MBR_CARD_CACHE_KEY where user_name=c_user_name;
        elsif c_user_type='8' then      /***私有商家余额校验码key**/
             select CACHE_KEY into return_key from TBL_PVTP_STATIONED_CACHE_KEY where user_name=c_user_name;     
        else
             select CACHE_KEY into return_key from TBL_SP_CACHE_KEY where user_name=c_user_name;
        end if;
   else
        --根据种子KEY生成新的KEY
        select KEY_VALUE into public_key from TBL_SYS_CONFIG where rownum<2;
        temp_str:=sys_guid()||public_key;
        return_key:=Utl_Raw.Cast_To_Raw(sys.dbms_obfuscation_toolkit.md5(input_string => temp_str));
   end if;
   return return_key;
END getUserKey;
/

