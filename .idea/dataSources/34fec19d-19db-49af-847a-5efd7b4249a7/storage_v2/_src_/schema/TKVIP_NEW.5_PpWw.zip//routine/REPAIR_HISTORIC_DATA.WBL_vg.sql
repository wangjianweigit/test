create procedure REPAIR_HISTORIC_DATA
(
 output_status                  OUT VARCHAR2, --返回的状态码 0-失败 1-成功
 output_msg                     OUT VARCHAR2 --返回的信息
)
IS

    cache_key  varchar2(50);
    cache_node varchar2(50);

BEGIN
    output_status := '0';
    output_msg := '修复历史数据失败！';
   declare cursor item is  
        select 
            (
                case when 
                (
                    select id from tbl_user_info where login_name = st.user_name 
                ) is not null then concat(st.user_name,'_1')
                else st.user_name
            end) user_name, st.user_pwd, st.stationed_user_id
        from tbl_stationed_user_info st
        where is_open_shop = 2 
        and not exists (
            select stationed_user_id, user_id
            from tbl_stationed_user_relate
            where stationed_user_id = st.stationed_user_id
        );
   begin

        for c_row in item loop
            insert into tbl_user_info(
                id, user_name, login_name, user_pwd,
                user_type, site_id, user_state
            ) values (
                seq_user_info_apply.nextval, seq_user_info_apply.currval , c_row.user_name,c_row.user_pwd,
                3, 1, 1
            );
            
            select getUserKey(seq_user_info_apply.currval, 'new', '1' ) into cache_key from dual;

            select getCheck_Code(seq_user_info_apply.currval,0,cache_key ) into cache_node from dual;
            
            insert into TBL_USER_CACHE_KEY (user_name,cache_key,create_time)
            values (seq_user_info_apply.currval, cache_key, sysdate);
            
             insert into TBL_BANK_ACCOUNT
            (
                id,
                user_id,
                user_type,
                bank_account,
                account_balance,
                account_balance_checkcode,
                credit_money,
                credit_money_use,
                credit_money_balance,
                credit_checkcode,
                payment_password,
                score,
                update_date,
                sub_merchant_id
            )
            values
            (
                SEQ_BANK_ACCOUNT.nextval,
                seq_user_info_apply.currval,
                1,
                '',
                0,
                cache_node,
                0,
                0,
                0,       
                cache_node,
                null,
                6001,
                null,
                ''
            );  
            insert into tbl_stationed_user_relate values (
                c_row.stationed_user_id, seq_user_info_apply.currval
            );  
        end loop;
    end;
    
EXCEPTION
  WHEN OTHERS THEN
    output_status:=SQLCODE;
    output_msg := SUBSTR(SQLERRM, 1, 200);
    ROLLBACK;
END REPAIR_HISTORIC_DATA;
/

