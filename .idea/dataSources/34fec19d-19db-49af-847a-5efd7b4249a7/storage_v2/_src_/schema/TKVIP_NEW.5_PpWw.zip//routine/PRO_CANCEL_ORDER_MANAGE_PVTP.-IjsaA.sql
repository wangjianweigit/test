create PROCEDURE           PRO_CANCEL_ORDER_MANAGE_PVTP

/**
     私有站取消订单【未付款或待配货】
     zhenghui
     1.更新预售数量
     2.取消订单的时候生成退货单
     预付订单付尾款产生的普通订单，存在手工占用，取消订单时占用处理（未付款）
     
     reid 20190319 参数client_user_name由原先传递的ID改为user_name
     返回值：取消成功或取消失败消息
  **/
(client_user_name     in varchar2, --批发平台用户名
 client_order_number  in varchar2, --订单号
 client_cancel_reason in varchar2, --取消订单原因
 return_deposit_type  in number,   --是否退定金 1-是 2-否
 output_status        out varchar2, --返回的状态码 0-取消失败 1-取消成功
 output_msg           out varchar2 --返回的信息
 ) is
  temp_count                   INT := 0; --临时变量
  v_order_state INT := 0; --订单总状态
  v_payment_state INT := 0; --订单付款状态
  temp_user_realname varchar2(50); --用户姓名
  v_warehouse_id  int :=0;--订单下单仓库
  v_return_number varchar2(100);--退货单号
begin
  output_status := '0';
  output_msg    := '取消失败';
  
   --定制订单产生的普通订单不能自动取消
  select count(*) into temp_count from TBL_PRE_ORDER_RELATE tror where order_number=client_order_number
    and exists (select 1 from TBL_PRE_ORDER_INFO tpoi where tpoi.order_number=tror.pre_order_number and tpoi.pre_order_type=2);
    IF temp_count > 0 Then
    output_msg := '定制订单产生的普通订单不能取消！';
    RETURN;
  END IF;
  
  SELECT COUNT(*)
    INTO temp_count
    FROM TBL_STATIONED_USER_INFO
   WHERE user_name = client_user_name;
  IF temp_count = 0 Then
    output_msg := '用户信息不能为空，请检查！';
    RETURN;
  END IF;

 select CONTACTS into temp_user_realname from TBL_STATIONED_USER_INFO where user_name =client_user_name;

  select order_state ,payment_state,warehouse_id into v_order_state, v_payment_state,v_warehouse_id
    from tbl_order_info
   where order_number = client_order_number;
  --当订单总状态为待付款，付款状态为待付款时的取消订单，最终订单总状态更新为交易关闭
  if (v_order_state = 1 And v_payment_state= 1) or (v_order_state = 2 And v_payment_state= 3) Then
    update tbl_order_info
       set cancel_reason = client_cancel_reason, cancel_date = sysdate, order_state = 6, cancel_user_name=client_user_name,cancel_user_realname=temp_user_realname
     where order_number = client_order_number;
    --删除占用量
     delete  from tbl_order_warehouse_count where ORDER_NUMBER= client_order_number;
    --当前订单为预付订单付尾款产生订单，取消时，占用回溯处理。
    INSERT INTO TBL_PRE_ORDER_WAREHOUSE_COUNT (ID,PRE_ORDER_NUMBER,USER_NAME,WAREHOUSE_ID,PRODUCT_SKU,OCCUPY_COUNT,CREATE_DATE)
        SELECT SEQ_PRE_ORDER_WAREHOUSE_COUNT.NEXTVAL,
                 PRE_ORDER_NUMBER,
                 USER_NAME,
                 WAREHOUSE_ID,
                 PRODUCT_SKU,
                 COUNT,
                 SYSDATE
         FROM (SELECT TOPS.USER_NAME,
                  TOPS.PRODUCT_SKU,
                  TOPS.COUNT,
                 (SELECT TPOR.PRE_ORDER_NUMBER
                    FROM TBL_PRE_ORDER_RELATE TPOR
                   WHERE TPOR.ORDER_NUMBER = TOPS.ORDER_NUMBER
                         AND EXISTS(SELECT 1
                                      FROM TBL_PRE_ORDER_INFO TPOI
                                     WHERE TPOI.ORDER_NUMBER = TPOR.PRE_ORDER_NUMBER
                                           AND TPOI.WAREHOUSE_STATE = '2')) AS PRE_ORDER_NUMBER,
                  (SELECT TPOI.WAREHOUSE_ID
                          FROM TBL_PRE_ORDER_RELATE TPOR,TBL_PRE_ORDER_INFO TPOI
                         WHERE TPOR.ORDER_NUMBER = TOPS.ORDER_NUMBER
                               AND TPOR.PRE_ORDER_NUMBER = TPOI.ORDER_NUMBER(+)
                               AND ROWNUM <=1) AS WAREHOUSE_ID
            FROM TBL_ORDER_PRODUCT_SKU TOPS
               WHERE TOPS.ORDER_NUMBER = client_order_number) T1
    WHERE T1.PRE_ORDER_NUMBER IS NOT NULL;
    /*********************如果当前商品参加了预售活动，则在订单取消时，需要将已销售的预售数量恢复***********************************/
   UPDATE TBL_PRESELL_ACTIVITY_SKU pas 
   SET pas.ACTIVITY_SELL_AMOUNT = pas.ACTIVITY_SELL_AMOUNT - NVL((SELECT TOPS.COUNT
                                                                     FROM TBL_ORDER_PRODUCT_SKU TOPS
                                                                     WHERE TOPS.ORDER_NUMBER = client_order_number
                                                                            AND TOPS.PRODUCT_SKU = pas.PRODUCT_SKU),0)
   WHERE EXISTS (
   
                SELECT 1
                    FROM TBL_ACTIVITY_INFO tai,TBL_ACTIVITY_DETAIL A1,
                    TBL_ACTIVITY_PRODUCT AP,
                    TBL_ORDER_PRODUCT_SKU TOPS
                WHERE TOPS.ORDER_NUMBER = client_order_number
                     AND TAI.ID = AP.ACTIVITY_ID AND TAI.ID = A1.ACTIVITY_ID 
                     AND AP.PRODUCT_ITEMNUMBER = TOPS.PRODUCT_ITEMNUMBER
                     AND TOPS.PRODUCT_SKU = pas.PRODUCT_SKU
                     AND TAI.ID = pas.ACTIVITY_ID
                     AND AP.ACTIVITY_START_DATE <= TOPS.ORDER_DATE
                     AND AP.ACTIVITY_END_DATE >= TOPS.ORDER_DATE
                     AND TAI.ACTIVITY_STATE = '3'
                     AND TAI.STATE = '2'
                     AND TAI.ACTIVITY_TYPE = '4'
                     AND EXISTS (SELECT 1
                                    FROM TBL_ACTIVITY_SITE tas,tbl_user_info tui
                                   WHERE tas.site_id = tui.site_id
                                   AND tas.ACTIVITY_ID = TAI.ID
                                   and tops.user_name = tui.user_name
                                   )
				AND (CASE WHEN (A1.USER_GROUP_ID = 0 OR A1.USER_GROUP_ID IS NULL) THEN 1 ELSE CASE WHEN EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND A1.USER_GROUP_ID = AA.ID AND  BB.USER_ID = client_user_name) THEN 1 ELSE 0 END END) = 1 
   );
    --非预售商品活动
    UPDATE TBL_SALE_ACTIVITY_SKU TSAS
        SET TSAS.ACTIVITY_SELL_AMOUNT = TSAS.ACTIVITY_SELL_AMOUNT - NVL((SELECT TOPS.COUNT
                                                                     FROM TBL_ORDER_PRODUCT_SKU TOPS
                                                                     WHERE TOPS.ORDER_NUMBER = client_order_number
                                                                            AND TOPS.PRODUCT_SKU = TSAS.PRODUCT_SKU
                                                                            AND TOPS.WAREHOUSE_ID = TSAS.WAREHOUSE_ID),0)
        WHERE EXISTS (
        SELECT 1
                    FROM TBL_ACTIVITY_INFO TAI, 
            TBL_ACTIVITY_DETAIL TSAI, 
            TBL_ACTIVITY_PRODUCT ap,
            TBL_ORDER_PRODUCT_SKU TOPS
                   WHERE TOPS.ORDER_NUMBER = client_order_number
             AND TAI.ID = AP.ACTIVITY_ID
                     AND AP.PRODUCT_ITEMNUMBER = TOPS.PRODUCT_ITEMNUMBER
                     AND TOPS.PRODUCT_SKU = TSAS.PRODUCT_SKU
                     AND TOPS.WAREHOUSE_ID = TSAS.WAREHOUSE_ID
                     AND TAI.ID = TSAS.ACTIVITY_ID
                     AND TSAI.ACTIVITY_ID = TSAS.ACTIVITY_ID
                     AND AP.ACTIVITY_START_DATE <= TOPS.ORDER_DATE
                     AND AP.ACTIVITY_END_DATE >= TOPS.ORDER_DATE
                     AND TAI.ACTIVITY_STATE = '3'
                     AND TAI.STATE = '2'
					 AND TAI.ACTIVITY_TYPE != '4'
					 AND TSAI.LOCKED_STOCK = '2'
                     AND EXISTS (SELECT 1
                                    FROM TBL_ACTIVITY_SITE tas,tbl_user_info tui
                                   WHERE tas.site_id = tui.site_id
                                   AND tas.ACTIVITY_ID = TAI.ID
                                   and tops.user_name = tui.user_name
                                   )		   
					AND (CASE WHEN (TSAI.USER_GROUP_ID = 0 OR TSAI.USER_GROUP_ID IS NULL) THEN 1 ELSE CASE WHEN EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND TSAI.USER_GROUP_ID = AA.ID AND  BB.USER_ID = client_user_name) THEN 1 ELSE 0 END END) = 1 
    );
    output_status := '1';
    output_msg    := '取消成功';
  else
    if v_order_state = 2 and v_payment_state= 2  Then  --当订单状态为待发货，付款状态为已付款，最终订单总状态更新为退款中，退款状态修改为：待退款
      update tbl_order_info
         set cancel_reason = client_cancel_reason, cancel_date = sysdate, order_state = 4,refund_state=1, cancel_user_name=client_user_name,cancel_user_realname=temp_user_realname
       where order_number = client_order_number;
       --生成退货单号
       select GETAUTONUMBER('TQ') into v_return_number from dual;
       --新增退货单
       insert into tbl_order_return_info (
        id,
        return_number,
        return_type,
        order_number,
        user_name,
        user_manage_name,
        product_money,
        product_count,
        logistics_money,
        df_money,
        return_total_money,
        state,
        return_remark,
        apply_user_name,
        apply_user_realname,
        create_date,
        apply_type,
        STATIONED_USER_ID,
        ORDER_TYPE)
       select seq_order_return_id.nextval,
              v_return_number,
              '1',
              a.order_number,
              a.user_name,
              a.user_manage_name,
              a.product_money,
              a.product_count,
              a.logistics_money,
              a.df_money,
              a.payment_money,
              '1',
              client_cancel_reason,
              client_user_name,
              temp_user_realname,
              sysdate,
              '2',
              stationed_user_id,
              case when is_store_order = 2 then 2 else 1 end as order_type
          from tbl_order_info a
         where a.order_number=client_order_number;
       --新增 退货单商品信息
       insert into tbl_order_return_product (
        id,
        return_number,
        order_number,
        codenumber,
        count,
        product_unit_price,
        product_total_money,
        product_old_unit_price,
        product_total_discount_money,
        user_name,
        return_date,
        product_sku,
        product_sku_name,
        product_itemnumber,
        product_color,
        product_specs,
        product_oldsale_prize
        )
        select seq_order_return_product_id.nextval,
               v_return_number,
               b.order_number,
               b.codenumber,
               b.count,
               b.product_unit_price,
               b.product_total_money,
               b.product_old_unit_price,
               b.product_total_discount_money,
               b.user_name,
               sysdate,
               b.product_sku,
               b.product_sku_name,
               b.product_itemnumber,
               b.product_color,
               b.product_specs,
               b.product_oldsale_prize
          from tbl_order_product_sku b
         where  b.order_number=client_order_number;
     
     output_status := '1';
     output_msg    := '取消成功';
    elsif v_order_state = 1 and v_payment_state= 4 then --当订单状态为待付款，付款状态为已支付部分定金，最终订单总状态更新为退款中，退款状态修改为：待退款，生成退款申请记录
          if return_deposit_type= 1 then
            --退定金,订单状态为：退款中
              update tbl_order_info
                 set cancel_reason = client_cancel_reason, cancel_date = sysdate, order_state = 4,refund_state=1, cancel_user_name=client_user_name,cancel_user_realname=temp_user_realname
               where order_number = client_order_number;
          else
            --不退定金,订单状态为：终止中
              update tbl_order_info
                     set cancel_reason = client_cancel_reason, cancel_date = sysdate, order_state = 7, cancel_user_name=client_user_name,cancel_user_realname=temp_user_realname
                   where order_number = client_order_number;
          end if;
      
           --生成退货单号
           select GETAUTONUMBER('TQ') into v_return_number from dual;
           --新增退货单
           insert into tbl_order_return_info (
            id,
            return_number,
            return_type,
            order_number,
            user_name,
            user_manage_name,
            product_money,
            product_count,
            logistics_money,
            df_money,
            return_total_money,
            state,
            return_remark,
            apply_user_name,
            apply_user_realname,
            create_date,
            apply_type,
            STATIONED_USER_ID,
            ORDER_TYPE,
            return_deposit_state)
           select seq_order_return_id.nextval,
                  v_return_number,
                  '3',
                  a.order_number,
                  a.user_name,
                  a.user_manage_name,
                  0,
                  0,
                  0,
                  0,
                  a.earnest_money,
                  '1',
                  client_cancel_reason,
                  client_user_name,
                  temp_user_realname,
                  sysdate,
                  '2',
                  stationed_user_id,
                  case when is_store_order = 2 then 2 else 1 end as order_type,
                  return_deposit_type
              from tbl_order_info a
             where a.order_number=client_order_number;
           --新增 退货单商品信息
           insert into tbl_order_return_product (
            id,
            return_number,
            order_number,
            codenumber,
            count,
            product_unit_price,
            product_total_money,
            product_old_unit_price,
            product_total_discount_money,
            user_name,
            return_date,
            product_sku,
            product_sku_name,
            product_itemnumber,
            product_color,
            product_specs,
            product_oldsale_prize
            )
            select seq_order_return_product_id.nextval,
                   v_return_number,
                   b.order_number,
                   b.codenumber,
                   b.count,
                   b.product_unit_price,
                   b.product_total_money,
                   b.product_old_unit_price,
                   b.product_total_discount_money,
                   b.user_name,
                   sysdate,
                   b.product_sku,
                   b.product_sku_name,
                   b.product_itemnumber,
                   b.product_color,
                   b.product_specs,
                   b.product_oldsale_prize
              from tbl_order_product_sku b
             where  b.order_number=client_order_number;
            output_status := '1';
            output_msg    := '取消成功';
      else
        if v_payment_state =3 then
        output_msg := '订单现金付款审批中，不允许关闭订单!';
        return;
        output_msg := '暂时不支持其它状态取消订单!';
        return;
      end if;
    end if;
  end if;
   commit;
exception
  when others then
    output_msg := '取消订单出现未知错误';
    rollback;
end PRO_CANCEL_ORDER_MANAGE_PVTP;
/

