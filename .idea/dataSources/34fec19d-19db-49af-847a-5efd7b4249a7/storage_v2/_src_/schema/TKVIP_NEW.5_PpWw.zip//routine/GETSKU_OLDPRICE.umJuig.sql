create FUNCTION           getSku_OldPrice
/**
   （新版） 获取SKU            应销售价
    wangpeng
    2017-05-12
    2018-12-25   update  for wangpeng  支持新老商品不同费率计算
    2019-09-05   update  for wangpeng  支持新老商品不同费率计算 针对2019-09-15新费率调整
    返回值：格式化后的商品原价
**/
(
    c_sku_id   varchar2--商品SKUID    
) return varchar2
 is
     v_product_prize number:=0;                          --需要返回的SKU应销售价格
     v_prize_cost number:=0;                             --SKU报价
     
     v_member_service_rate number:=0;                    --会员服务费比例-汇总
     v_member_service_rate_rzs number:=0;                --会员服务费比例-入驻商
     v_member_service_rate_qj number:=0;                 --会员服务费比例-全局
     v_product_create_date date;                                             --商品创建时间                          --界线新加配置
     v_sys_line date:=to_date('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置
    v_sys_line2 date:=to_date('2019-09-15 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置  针对2019-09-15新费率调整
BEGIN

    /*************************商品新老计费费率控制*********begin**********************/
    select a.create_date into v_product_create_date from tbl_product_info a,tbl_product_sku b where b.id = c_sku_id  and a.ITEMNUMBER = b.PRODUCT_ITEMNUMBER and rownum<2;
    if v_product_create_date < v_sys_line then
        --查询入驻商会员服务费比例-老费率
        select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RATE where STATIONED_USER_ID = (
            select STATIONED_USER_ID from tbl_product_sku where id = c_sku_id and rownum<2
        );
    end if;
    /*************************商品新老计费费率控制*********end**********************/
    
   --查询全局会员服务费比例
   --select member_service_rate into v_member_service_rate_qj from TBL_SYS_CONFIG where id = 1;
   
   if v_product_create_date >= v_sys_line then
       --查询入驻商会员服务费比例-按当前费率计算
        select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_USER_INFO where id = (
            select STATIONED_USER_ID from tbl_product_sku where id = c_sku_id
        );
   end if;
           
    /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
    if v_sys_line2 > v_product_create_date and v_product_create_date >= v_sys_line then
        --查询入驻商会员服务费比例-老费率2次调整
        select nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RAT2 where STATIONED_USER_ID = (
            select STATIONED_USER_ID from tbl_product_sku where id = c_sku_id and rownum<2
        );
    end if;
    /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
   
   --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
   v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;
   
   --查询原价最低价
   select nvl(f.product_prize_cost,0) into v_prize_cost from tbl_product_sku f where id=c_sku_id;
   
   --计算应销售价 = 报价/（1-会员服务费比例）
   v_product_prize:=v_prize_cost/(1-v_member_service_rate);
   
   
     if ceil(v_product_prize)-v_product_prize<0.5 then
      v_product_prize := ceil(v_product_prize);
   elsif ceil(v_product_prize)-v_product_prize=0 then
      v_product_prize := v_product_prize;
   else 
      v_product_prize := ceil(v_product_prize)-0.5;
   end if;
   
   return v_product_prize;
   
END getSku_OldPrice;
/

