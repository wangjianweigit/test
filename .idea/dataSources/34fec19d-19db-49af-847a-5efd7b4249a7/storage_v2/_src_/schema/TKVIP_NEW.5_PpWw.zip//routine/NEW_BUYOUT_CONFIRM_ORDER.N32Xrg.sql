create PROCEDURE           new_buyout_confirm_order
/**
     【清尾活动】买断商品确认订单存储过程
     reid  2019.05.17 创建
  **/
(
 c_user_name IN  varchar2,                  --用户名
 c_product_itemnumber IN  varchar2,         --买断商品货号
 output_status    OUT varchar2,             --返回的状态码 0-失败 1-成功
 output_msg       OUT varchar2              --返回的信息
) AS
v_temp_count                number :=0;--临时变量
v_activity_id               number :=0;--商品参加的活动ID
v_activity_type             number :=0;--商品参加的活动类型（1、限时折扣；2:订货会；4：预售；5：清尾）
v_activity_product_id       number :=0;--活动商品ID，关联表TBL_ACTIVITY_PRODUCT的ID
v_product_order_count       number :=0;--商品的总下单量（货号维度，汇总所有订单）
v_order_id                  number :=0;--临时变量，订单ID
v_order_product_id          number :=0;--临时变量，订单商品ID
v_buy_out_flag              number :=0;--是否使用买断价结算  1：不使用买断价  2：使用买断价

BEGIN
  output_status:='0';
  --查询商品参加的活动ID
    SELECT
    (case when temp2.activity_state='going' then temp2.activity_id else 0 end),
    (case when temp2.activity_state='going' then temp2.activity_type else 0 end),
    (case when temp2.activity_state='going' then temp2.activity_product_id else 0 end)
    into v_activity_id,v_activity_type,v_activity_product_id
    FROM
    (
        select 
        (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,0,instr(activity_tag,'#-#',1,1)-1)) else 0 end) activity_id,
        (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,instr(activity_tag,'#-#',1,1)+3,1)) else 0 end) activity_type,
        (case when length(temp.activity_tag)>0 then substr(temp.activity_tag,instr(activity_tag,'#-#',1,2)+3,5) else '' end) activity_state,
        (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,instr(activity_tag,'#-#',1,4)+3)) else 0 end) activity_product_id
        from (
            select NVL(GET_ACTIVITY_TAG(c_user_name,c_product_itemnumber),'') activity_tag from dual
        ) temp
    ) temp2;
   IF v_activity_type<>5 OR v_activity_id=0 THEN
     OUTPUT_MSG := '商品['||c_product_itemnumber||']未参加清尾活动，不允许买断';
     RETURN;
   END IF;
  --查询是否设置了买断价格
    SELECT count(1) into v_temp_count FROM TBL_ACTIVITY_PRODUCT_SPECPRIZE
    where activity_id = v_activity_id 
    and product_itemnumber = c_product_itemnumber
    and activity_product_id = v_activity_product_id
    and min_count = -1;
    --没有设置买断价格
    IF v_temp_count=0 THEN
       v_buy_out_flag:= 1;
    ELSE
       v_buy_out_flag:= 2;
    END IF;
  /****第1次循环，完成临时表的插入操作******/
  BEGIN
      FOR sku_tb IN(
              select 
              sku_id,
              warehouse_id,
              product_stock
              from                       
              (
                       select 
                       ps.id sku_id,
                       sw.warehouse_id,
                       getproductsku_stocks(ps.id,sw.warehouse_id,c_user_name) product_stock
                       from TBL_WAREHOUSE_INFO wi,TBL_SITE_WAREHOUSE sw,TBL_PRODUCT_SKU ps
                       where wi.id = sw.parent_warehouse_id
                       and exists (select 1 from tbl_user_info ui where ui.user_name =c_user_name and ui.site_id = sw.site_id)
                       and ps.product_itemnumber = c_product_itemnumber
                       and ps.product_group = '尺码'
                       and ps.state = '上架'
                ) temp where product_stock > 0
                order by warehouse_id,sku_id
      ) LOOP
          v_product_order_count:=v_product_order_count+sku_tb.product_stock;
          ----1、判断是否已存在订单记录
          SELECT count(1) INTO v_temp_count from TMP_NEW_ORDER where warehouse_id = sku_tb.warehouse_id;
          IF v_temp_count = 0 THEN
                v_order_id:=v_order_id+1; 
                INSERT INTO TMP_NEW_ORDER 
                (
                    order_id,
                    warehouse_id
                ) 
                VALUES (
                    v_order_id,
                    sku_tb.warehouse_id
                );
          END IF;
          ---2、判断订单商品表是否已存在数据，不存在则插入(默认为买断)
          SELECT count(1) INTO v_temp_count from TMP_NEW_ORDER_PRODUCT where order_id = v_order_id AND product_itemnumber = c_product_itemnumber;
          IF v_temp_count = 0 THEN
                 v_order_product_id:=1;
                 INSERT INTO TMP_NEW_ORDER_PRODUCT (order_id,order_product_id,product_itemnumber,buy_out_flag,activity_id,activity_type,activity_product_id)
                 VALUES (v_order_id,to_number(v_order_id||''||v_order_product_id),c_product_itemnumber,v_buy_out_flag,v_activity_id,v_activity_type,v_activity_product_id);
          END IF;
          ---3、将数据信息插入sku表中；默认所有SKU可用
          INSERT INTO TMP_NEW_ORDER_PRODUCT_SKU (order_id,order_product_id,sku_id,count,valid_flag,stock_count) 
          VALUES (v_order_id,to_number(v_order_id||''||v_order_product_id),sku_tb.sku_id,sku_tb.product_stock,1,sku_tb.product_stock);
      END LOOP;
  END;
  /****第2次循环，计算SKU表中的单价******/
  BEGIN
      FOR t2 IN(
                SELECT ops.order_id,
                   ops.order_product_id,
                   ops.sku_id,
                   get_ByOut_SalePrice (c_user_name,op.activity_id,ops.sku_id,op.buy_out_flag,get_ByOut_SaleProductCount(ops.sku_id,ops.count)) sku_unit_price
                FROM TMP_NEW_ORDER_PRODUCT_SKU ops,TMP_NEW_ORDER_PRODUCT op where ops.order_product_id = op.order_product_id
     ) LOOP
     UPDATE TMP_NEW_ORDER_PRODUCT_SKU t1 
     SET t1.sku_unit_price = t2.sku_unit_price,t1.page_sku_unit_price = t2.sku_unit_price,t1.original_sku_unit_price = t2.sku_unit_price
     WHERE t1.order_id = t2.order_id and t1.order_product_id = t2.order_product_id and t1.sku_id = t2.sku_id;
  END LOOP;
  END;
  /****第3次循环，为订单临时表增加价格数据汇总******/
  merge into TMP_NEW_ORDER t1
  using (
        select order_id,sum(count*sku_unit_price) product_money 
        from tmp_new_order_product_sku
        group by order_id
  ) t2  on (t1.order_id = t2.order_id )
  when matched then 
  update set t1.product_money = t2.product_money;
  output_status:='1';
  output_msg := '订单信息校验成功';
EXCEPTION
   when others then  
        output_msg := 'errorCode=' || SQLCODE || ',errorMsg=' || SUBSTR(SQLERRM, 1, 200);  
  --WHEN OTHERS THEN
    ROLLBACK;
  --output_msg := '订单信息校验失败';  
END new_buyout_confirm_order;
------------------------------------------------
/

