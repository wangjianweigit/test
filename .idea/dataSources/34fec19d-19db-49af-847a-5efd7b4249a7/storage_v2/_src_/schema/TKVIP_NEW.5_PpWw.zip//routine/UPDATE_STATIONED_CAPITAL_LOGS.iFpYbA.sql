create PROCEDURE           update_STATIONED_CAPITAL_LOGS
/**
     处理资金流水待结算金额问题   临时
     wanghai
     2018-07-17 
  **/
 (
 p_STATIONED_user_id number
 )
 as
 v_UNLIQUIDATED_BALANCE number := 0;
BEGIN
  --20180712-201807171150之间的订单付款记录
   declare cursor log_record is  
        select id aac,TRAN_AMOUNT,UNLIQUIDATED_BALANCE,MILLIONS from TBL_STATIONED_CAPITAL_LOGS where log_type = '订单付款' and to_char(create_date,'yyyymmdd') > '20180712' and to_char(create_date,'yyyymmddhh24mi') < '201807171150' and stationed_user_id = p_STATIONED_user_id
        order by MILLIONS asc;
        
   begin
        for c_row in log_record loop
            --当前记录的上一条记录
            select UNLIQUIDATED_BALANCE into v_UNLIQUIDATED_BALANCE from (
            select UNLIQUIDATED_BALANCE from TBL_STATIONED_CAPITAL_LOGS where MILLIONS < c_row.MILLIONS and stationed_user_id = p_STATIONED_user_id
            order by MILLIONS desc) where rownum = 1;
            
           
           DBMS_OUTPUT.PUT_LINE('修改记录编号：【'||c_row.aac||'】修改前金额：【'||c_row.UNLIQUIDATED_BALANCE||'】修改后金额：【'||v_UNLIQUIDATED_BALANCE||'+'|| c_row.TRAN_AMOUNT||'】');
           update TBL_STATIONED_CAPITAL_LOGS set UNLIQUIDATED_BALANCE = v_UNLIQUIDATED_BALANCE + c_row.TRAN_AMOUNT where id = c_row.aac;
           
        end loop;
    end;
    
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END update_STATIONED_CAPITAL_LOGS;
/

