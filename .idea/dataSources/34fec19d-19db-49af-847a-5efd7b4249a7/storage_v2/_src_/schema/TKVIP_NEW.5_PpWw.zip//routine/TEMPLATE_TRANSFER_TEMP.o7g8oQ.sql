create PROCEDURE           template_transfer_temp
/**
     模板传送
     zhenghui
     2017-05-31
     返回值：传送成功或传送失败消息
  **/
(
    client_template_id      IN VARCHAR2,  --传送原装修模板ID
    temp_new_template_id          IN VARCHAR2,  --传送目标模板ID
    client_create_user_id   IN VARCHAR2  --创建用户ID
 ) IS
     temp_new_page_id         NUMBER; --新装修页面ID(临时变量)
     temp_page_id             NUMBER; --装修页面ID(临时变量)
     temp_layout_id           NUMBER; --页面布局ID(临时变量)
     temp_new_layout_id       NUMBER; --页面布局ID(临时变量)
     temp_module_id           NUMBER; --页面组件ID(临时变量)
     temp_new_module_id       NUMBER; --页面组件ID(临时变量)
     temp_PLATFORM_PAGE_MODULE_id number; --页面固定模块ID（临时变量）
     client_site_id number;
     temp_site_count          INT := 0;
     temp_template_count          INT := 0;
BEGIN
     
     --定义游标获取所需要传送的页面
     DECLARE CURSOR decorate_page_list IS SELECT id FROM tbl_decorate_page WHERE template_id = client_template_id;   
     BEGIN
        FOR page_row IN decorate_page_list LOOP
        
           --获取装修页面ID
           temp_page_id := page_row.id;
 
           --获取新的装修页面ID
           SELECT seq_decorate_page.nextval INTO temp_new_page_id FROM dual;
             
           select SITE_ID into client_site_id from TBL_DECORATE_TEMPLATE where id  =temp_new_template_id;
           
           --复制装修页面
           INSERT INTO tbl_decorate_page
              (id, site_id, template_id, page_name, page_state,home_page_flag, remark, create_date, create_user_id, page_content, is_delete,PAGE_TYPE)
           SELECT 
              temp_new_page_id, client_site_id, temp_new_template_id, page_name, page_state,home_page_flag, remark, sysdate, client_create_user_id, page_content, is_delete ,PAGE_TYPE
           FROM tbl_decorate_page WHERE id = temp_page_id;
           
           
           DECLARE CURSOR page_MODULE_list IS SELECT id,TEMP_NEW_PAGE_ID,MODULE_ID,FIXED_PERIOD,state FROM TBL_PLATFORM_PAGE_MODULE PM WHERE PM.PAGE_ID = temp_page_id;
           BEGIN
              FOR MODULE_row IN page_MODULE_list LOOP
              
                   temp_PLATFORM_PAGE_MODULE_id := SEQ_PLATFORM_PAGE_MODULE.NEXTVAL;
                  
                   --插入装修页面固定模块数据
                   INSERT INTO TBL_PLATFORM_PAGE_MODULE 
                   values(
                        temp_PLATFORM_PAGE_MODULE_id ,MODULE_row.TEMP_NEW_PAGE_ID,MODULE_row.MODULE_ID,MODULE_row.FIXED_PERIOD,SYSDATE,client_create_user_id,MODULE_row.state
                   );
                        
                   --插入装修页面固定模块明细数据
                   INSERT INTO TBL_PLATFORM_PAGE_MODULE_DTL 
                   select temp_PLATFORM_PAGE_MODULE_id,MODULE_BASE_CONF,sort,group_id,group_sort from TBL_PLATFORM_PAGE_MODULE_DTL where PAGE_MODULE_ID = MODULE_row.id ;
               
              END loop;
           end;
           
           
           
           --定义游标获取所需要传送的布局
           DECLARE CURSOR page_layout_list IS SELECT id FROM tbl_decorate_page_layout WHERE page_id = temp_page_id;
           BEGIN
              FOR layout_row IN page_layout_list LOOP
            
                 --获取页面布局ID
                 temp_layout_id := layout_row.id;
                 --获取新的页面布局ID
                 SELECT seq_decorate_page_layout.nextval INTO temp_new_layout_id FROM dual;
                 --复制页面布局
                 INSERT INTO tbl_decorate_page_layout
                     (id, page_id, layout_type, sort_id)
                 SELECT temp_new_layout_id, temp_new_page_id, layout_type, sort_id FROM tbl_decorate_page_layout WHERE id = temp_layout_id;
                 
                 --定义游标获取所需要传送的组件
                 DECLARE CURSOR page_module_list IS SELECT id FROM tbl_decorate_page_module WHERE page_id = temp_page_id AND layout_id = temp_layout_id;
                 BEGIN
                    FOR module_row IN page_module_list LOOP
                    
                       --获取页面组件ID
                       temp_module_id := module_row.id;
                       --获取新的页面组件ID
                       SELECT seq_decorate_page_module.nextval INTO temp_new_module_id FROM dual;
                       --复制页面组件
                       INSERT INTO tbl_decorate_page_module
                          (id, page_id, layout_id, module_id, module_base_conf,module_extend_conf, create_date, create_user_id, layout_column_id, sort_id)
                       select temp_new_module_id, temp_new_page_id, temp_new_layout_id, module_id, module_base_conf,module_extend_conf, sysdate, client_create_user_id, layout_column_id, sort_id 
                       from tbl_decorate_page_module where id = temp_module_id;
                    
                    END LOOP;
                 END;
              END LOOP;
           END;
        END LOOP;
     END;
      
     COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END template_transfer_temp;
/

