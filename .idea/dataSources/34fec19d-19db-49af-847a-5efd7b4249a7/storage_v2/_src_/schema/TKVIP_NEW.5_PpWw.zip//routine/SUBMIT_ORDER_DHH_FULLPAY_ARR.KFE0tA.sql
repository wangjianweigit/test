create PROCEDURE           SUBMIT_ORDER_DHH_FULLPAY_ARR
/**
    提交订单-订货会全款
    shif
    2017-10-11
    增加记录订单是否是缺货商品订单   shif 2017-11-23
    增加对会员卡的支持 shif 20180717
    返回值：订单提交结果消息（付款交易号）
    
    2018-08-06 增加入驻商支付服务费规则计算 by wanghai

    songwangwen 2018.11.29  发货方式调整相关修改
    liujialong  2019.1.8  订单主表增加用户是否支持送货入户
    yejingquan 20190311 下单用户是否存在快递配置
    zhengfy 20190716 记录活动id、活动商品id、商品报价、订单自动取消时间
    reid 2019.10.14 预订下单完成后，删除下单规格下的所有SKU数据，防止出现该规格下某个SKU失效未下单、未删除问题
**/
(
        client_user_name in varchar2,              --用户名
        client_receiving_name in varchar2,         --收货人姓名
        client_receiving_phone in varchar2,        --收货电话
        client_user_province_id in number,         --收货地省ID
        client_receiving_address in varchar2,      --收货地址
        client_order_remark in varchar2,           --订单备注
        client_product_list   T_ORDER_PRODUCT_LST, --订单订货会商品SKU列表
        client_logistics_company_code in varchar2, --物流公司代码
        client_product_money in number,            --前台传递 商品总价
        client_logistics_money in number,          --前台传递 物流总价
        client_df_money in number,                 --前台传递 代发费用
        client_order_source  in varchar2,          --订单来源
        client_submode char,                       --下单模式   0:正常下单
        client_xdr_user_name  in varchar2,         --下单人用户名
        client_xdr_type char,                      --下单人用户类型（7：自行下单）
        client_warehouse_id number,                --下单仓库id
        client_activity_id number,                 --订货会活动id
        client_mbr_card number,                    --是否使用了会员卡优化（1：未使用，2：使用）
        client_freight_payment_type in number,       --运费是否到付  1.先支付运费   ；2：到付运费
        output_status  out varchar2,               --返回的状态码 0-失败 1-成功
        output_msg out varchar2                    --返回的信息
) AS
    v_user_manage_name varchar2(50);          --客户姓名
    v_logistics_company_id number:=0;         --物流公司ID
    v_logistics_company_name varchar2(50);    --物流公司名称
    v_order_number varchar2(21);              --订单号
    v_product_total_money number:=0;          --商品总价 系统计算得出
    v_ysyf number:=0;                         --应收运费 系统计算得出
    v_temp_count int:=0;                      --临时变量
    v_order_type varchar2(50);                --订单类型  批发  代发
    v_issuing_grade_id number:=1;             --用户代发等级ID
    v_piece_cost number:=0;                   --代发等级单价费用
    v_product_total_count number:=0;          --购买商品总数
    v_df_money number:=0;                     --代发费用
    v_ywjl_user_name varchar2(50);            --业务经理username
    v_ywy_user_name  varchar2(50);            --业务员username
    v_md_id number:=0;                        --门店ID
    v_site_id number:=0;                      --用户所属站点
    v_pay_trade_number varchar2(50 byte);     --付款交易号
    v_warehouse_id  number:=2;                --下单仓库【默认华东仓】
    v_order_product T_ORDER_PRODUCT;          --订单商品对象
    v_outstock_flag number:=0;                --是否缺货订购订单标识
    v_shipping_method_id number;                --标准配送方式id,关联表tbl_shipping_method的id字段
    v_is_delivery_home NUMBER:=2;               --用户是否支持送货入户
    v_user_logistics_count     NUMBER :=0;      --用户是否存在快递配置
    v_temp_activity_product_count NUMBER :=0;
    v_product_type     number := 1;             --下单商品分类类型 1.表示鞋类（商品规格固定）  2.表示其他类型（商品规格自定义）
BEGIN
    output_status:='0';
    --1.校验下单仓库是否有效
    SELECT COUNT(1)
      INTO v_temp_count
      FROM TBL_SITE_WAREHOUSE T
     WHERE T.WAREHOUSE_ID = v_warehouse_id
           AND EXISTS (SELECT 1
                         FROM TBL_USER_INFO T1
                        WHERE T1.USER_NAME = client_user_name
                              AND T1.SITE_ID = T.SITE_ID);
    IF v_temp_count = 0 THEN
        OUTPUT_MSG:='下单仓库不存在';
        RETURN;
    END IF;

   IF client_product_list.COUNT > 0 THEN
      FOR i IN 1..client_product_list.COUNT LOOP
        v_order_product:=client_product_list(i);
        --计算购买商品总数
        v_product_total_count := v_product_total_count + v_order_product.COUNT;
        INSERT INTO TMP_ORDER_PRODUCT_SKU(WAREHOUSE_ID,PRODUCT_SKU,COUNT,ACTIVITY_PRODUCT_ID) 
        SELECT
            v_warehouse_id,v_order_product.PRODUCT_SKU,v_order_product.COUNT,
            (case when activity_state='going' then temp2.activity_product_id else null end) activity_product_id
        from  (
            select 
                (case when length(temp.activity_tag)>0 then substr(temp.activity_tag,instr(activity_tag,'#-#',1,2)+3,5) else '' end) activity_state,
                (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,instr(activity_tag,'#-#',1,4)+3)) else null end) activity_product_id
            from (
                select NVL(GET_ACTIVITY_TAG(client_user_name,product_itemnumber),'') activity_tag
                from TBL_PRODUCT_SKU
                where ID = v_order_product.PRODUCT_SKU
            ) temp
        ) temp2;
        
        --3.校验商品是否存在非订货会商品
        SELECT COUNT(1) INTO v_temp_count FROM TBL_PRODUCT_SKU a,(
            SELECT v_order_product.PRODUCT_SKU as skuid_str  FROM  dual
        ) b WHERE a.ID = b.SKUID_STR AND IS_DISPLAY(client_user_name,A.PRODUCT_ITEMNUMBER)='2' ;
        IF v_temp_count = 0 THEN
            output_msg:='存在非订货会商品，请检查!';
            RETURN;
        END IF;
      END LOOP;

      SELECT COUNT(1)
        INTO v_temp_count
        FROM TMP_ORDER_PRODUCT_SKU T
       WHERE T.WAREHOUSE_ID = v_warehouse_id
         AND (T.PRODUCT_SKU IS NULL OR T.COUNT IS NULL);
      IF v_temp_count>0 THEN
          output_msg:='商品参数部分为空，请检查';
          RETURN;
      END IF;
   ELSE
      output_msg:='订单商品SKU列表参数错误';
      RETURN;
   END IF;



    --4.查询物流公司名称
    SELECT COUNT(*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE CODE = client_logistics_company_code;
    IF v_temp_count<>0 THEN
        SELECT ID, NAME,shipping_method_id
        INTO v_logistics_company_id, v_logistics_company_name,v_shipping_method_id
    FROM TBL_LOGISTICS_COMPANY WHERE CODE = client_logistics_company_code;
    ELSE
        output_msg:='物流信息不能为空，请检查!';
        RETURN;
    END IF;

    --5.查询客户姓名
    SELECT COUNT(*) INTO v_temp_count FROM TBL_USER_INFO WHERE USER_NAME = client_user_name;
    IF v_temp_count<>0 THEN
        SELECT USER_MANAGE_NAME,ISSUING_GRADE_ID INTO v_user_manage_name,v_issuing_grade_id FROM TBL_USER_INFO WHERE USER_NAME = client_user_name;
    ELSE
        output_msg:='用户信息不能为空，请检查!';
        RETURN;
    END IF;

    --6.判断下单模式
    IF client_submode != '0' THEN
        output_msg:='下单模式异常，请检查';
        RETURN;
    END IF;

    --7.0查询用户所属业务经理
    SELECT (SELECT TSUI.USER_NAME FROM TBL_SYS_USER_INFO TSUI WHERE TSUI.ID = TUI.MARKET_SUPERVISION_USER_ID ) AS MARKET_SUPERVISION_USER_NAME,
           (SELECT TSUI.USER_NAME FROM TBL_SYS_USER_INFO TSUI WHERE TSUI.ID = TUI.REFEREE_USER_ID ) AS REFEREE_USER_NAME,
            TUI.STORE_ID,TUI.SITE_ID
      INTO v_ywjl_user_name,v_ywy_user_name,v_md_id,v_site_id
      FROM TBL_USER_INFO TUI
     WHERE USER_NAME = client_user_name;

    --8.0计算物流价格
    v_ysyf := getfreightmoney_tmp(v_logistics_company_id,client_user_province_id,v_warehouse_id,client_freight_payment_type);
    --校验物流费用是否被篡改
    IF v_ysyf <> client_logistics_money THEN
        output_msg:='运费被篡改或运费计算规则发生变化,应收运费（'||v_ysyf||'），请重新下单!';
        RETURN;
    END IF;

    --10.0代发费计算及校验
    SELECT COUNT(*) INTO v_temp_count FROM TBL_LOGISTICS_COMPANY WHERE TYPE='2' AND CODE = client_logistics_company_code;
    v_df_money:=client_df_money;
    --当前订单为代发订单
    IF v_temp_count > 0 THEN
        --查询用户代发等级ID
        IF v_issuing_grade_id = 0 THEN
            v_issuing_grade_id := 1;
        END IF;
        --查询代发等级的单价费用
        SELECT PIECE_COST INTO v_PIECE_COST FROM TBL_ISSUING_GRADE WHERE ID = v_issuing_grade_id;
        v_piece_cost := v_product_total_count * v_piece_cost;
        IF v_piece_cost != v_df_money THEN
            output_msg:='代发费用被篡改或代发费用收取标准发生变化,应收代发费用（'||v_PIECE_COST||'），请重新下单';
            RETURN;
        END IF;
        v_order_type:='代发';
    ELSE
        --IF v_product_total_count < 5 THEN
            --output_msg:='当前订购商品数量为（'||v_product_total_count||'）双，不满足批发要求5双及以上，请重新下单或选择代发下单';
            --RETURN;
        --END IF;

        IF v_df_money <>0 THEN
            output_msg:='代发费（'||v_df_money||'），当前订单不属于代发订单,无需收取代发费用，请重新下单!';
            RETURN;
        END IF;
        v_order_type:='批发';
    END IF;

    --11.0生成阶梯价临时表【计算订货会价格用】
    insert into TMP_TIERED_PRICE(PRODUCT_ITEMNUMBER,product_color,PRODUCT_SPECS,PRICE)
    select PRODUCT_ITEMNUMBER,product_color,PRODUCT_SPECS,min(prize) prize
    from (
        select bb.*,aa.PRIZE,aa.min_count from TBL_ACTIVITY_PRODUCT_SPECPRIZE aa,(
            select a.PRODUCT_ITEMNUMBER,a.product_color,a.PRODUCT_SPECS,sum(b.sku_count) sum_count from tbl_product_sku a,(
                   select product_sku as sku_id,count as sku_count from TMP_ORDER_PRODUCT_SKU
        ) b where a.id = b.sku_id
        group by a.PARENT_ID,a.PRODUCT_ITEMNUMBER,a.product_color,a.PRODUCT_SPECS
        ) bb where aa.PRODUCT_SPEC =bb.PRODUCT_SPECS and aa.PRODUCT_ITEMNUMBER  = bb.PRODUCT_ITEMNUMBER
            and aa.ACTIVITY_ID = client_activity_id
        and SUM_COUNT >= min_count
    ) group by PRODUCT_ITEMNUMBER,product_color,PRODUCT_SPECS;
     --判断当前下单用户是否支持送货入户
    select count(1) into v_temp_count  from TBL_MEMBER_DELIVERY_HOME where user_id=client_user_name and IS_SUPPORT=1 and effect_begin_date<=sysdate and  effect_end_date>=sysdate;
    if v_temp_count>0 then
        v_is_delivery_home:= 1;
    end if;
    --获取订单号
    v_order_number:=getAutoNumber('D');
    --12.0插入订单主表
    INSERT INTO TBL_ORDER_INFO(
        ID,ORDER_NUMBER,CREATE_DATE,USER_NAME,USER_MANAGE_NAME,ORDER_TYPE,
        ORDER_STATE,ORDER_REMARK,RECEIVING_NAME,RECEIVING_ADDRESS,RECEIVING_PHONE,
        LOGISTICS_COMPANY_CODE,LOGISTICS_COMPANY_NAME,LOGISTICS_MONEY,DF_MONEY,
        PAYMENT_STATE,ORDER_SOURCE,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,XDR_USER_TYPE,XDR_USER_NAME,WAREHOUSE_ID,
        OLD_LOGISTICS_MONEY,OLD_DF_MONEY,ORDER_ACTIVITY_TYPE,MBR_CARD,MBR_CARD_REDUCE,DELIVERY_TYPE,FREIGHT_PAYMENT_TYPE,IS_DELIVERY_HOME
    )
    VALUES(
        SEQ_ORDER_INFO.NEXTVAL,v_order_number,SYSDATE,client_user_name,v_user_manage_name,v_order_type,
        1,client_order_remark,client_receiving_name,client_receiving_address,client_receiving_phone,
        client_logistics_company_code,v_logistics_company_name,client_logistics_money,v_df_money,
        1,client_order_source,v_ywjl_user_name,v_ywy_user_name,v_md_id,client_xdr_type,client_xdr_user_name,v_warehouse_id,
        client_logistics_money,v_df_money,'2',client_mbr_card,0,v_shipping_method_id,client_freight_payment_type,v_is_delivery_home
    );
    --用户是否存在快递配置
   --select count(1) into v_user_logistics_count
    -- from tbl_user_logistics_config
   -- where user_id = client_user_name
    --  and state = 2;
   select (select count(1)
           from table (splitstr (t.enable_logistics, ',')) a,
                tbl_standard_logistics b
          where a.column_value = b.logistics_code
                and b.shipping_method_id = v_shipping_method_id)
          +(select count(1)
              from table (splitstr (t.enable_logistics, ',')) a,
                   tbl_standard_logistics b
             where a.column_value = b.logistics_code
                   and b.shipping_method_id = v_shipping_method_id) 
          into v_user_logistics_count
     from tbl_user_logistics_config t
    where t.user_id = client_user_name
      and t.state = 2;   
    if v_user_logistics_count > 0 then
        insert into tbl_order_remark
            (
                id,
                order_number,
                disabled_logistics,
                enable_logistics,
                disabled_logistics_name,
                enabled_logistics_name,
                create_user_id,
                create_user_realname,
                create_date,
                state
            ) 
            select seq_order_remark.nextVal,
                   v_order_number,
                   disabled_logistics,
                   (select to_char (wm_concat (a.column_value))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics,
                   disabled_logistics_name,
                   (select to_char (wm_concat (b.logistics_name))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics_name,
                   create_user_id,
                   '客户设置' create_user_realname,
                   sysdate,
                   state
              from tbl_user_logistics_config t
             where user_id = client_user_name
               and state = 2;
    else
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 start
        SELECT 
        count(1) into v_temp_count
        FROM 
        TBL_LOGISTICS_COMPANY tlc
        INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
        INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
        where tlc.code = client_logistics_company_code;
        --需要新增备注数据
        IF v_temp_count<>0 THEN
            Insert into TBL_ORDER_REMARK
            (ID, ORDER_NUMBER,STATE,ENABLE_LOGISTICS,ENABLED_LOGISTICS_NAME,CREATE_DATE,CREATE_USER_ID,CREATE_USER_REALNAME)
            select
            seq_order_remark.nextval,temp.*
            from 
            (
            SELECT 
            v_order_number ORDER_NUMBER,
            2 STATE,
            to_char(wm_concat(lc.LOGISTICS_CODE)) ENABLE_LOGISTICS, 
            (wm_concat(lc.LOGISTICS_NAME)) ENABLED_LOGISTICS_NAME,
        sysdate,
        0 CREATE_USER_ID,
        '系统设置' CREATE_USER_REALNAME
            FROM 
            TBL_LOGISTICS_COMPANY tlc
            INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
            INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
            where tlc.code = client_logistics_company_code
            ) temp;
        END IF;
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 end
    end if;
    --13.0插入订单规格表
    INSERT INTO TBL_ORDER_PRODUCT(
        ID,ORDER_NUMBER, ORDER_ITEM_NUMBER,USER_NAME,USER_MANAGE_NAME,ITEMNUMBER,
        PRODUCT_NAME,PRODUCT_COLOR,
        PRODUCT_UNIT_PRICE,
        PRODUCT_UNIT_PRICE_TAG,
        PRODUCT_OLD_UNIT_PRICE,ORDER_DATE,ORDER_TYPE,PRODUCT_SPECS,
        PRODUCT_LACK_COUNT,
        WAREHOUSE_ID,
        PRODUCT_ACTIVITY_ID,
        MBR_CARD_REDUCE,
        ACTIVITY_PRODUCT_ID
    )
    SELECT SEQ_ORDER_PRODUCT.NEXTVAL,C.ORDER_NUMBER,
           C.ORDER_ITEM_NUMBER,C.USER_NAME,C.USER_MANAGE_NAME,C.PRODUCT_ITEMNUMBER,C.PRODUCT_NAME,C.PRODUCT_COLOR,
           C.PRODUCT_UNIT_PRICE,C.PRODUCT_PRIZE_TAG,C.PRODUCT_OLD_UNIT_PRICE,C.ORDER_DATE,C.ORDER_TYPE,C.PRODUCT_SPECS,
           C.PRODUCT_LACK_COUNT,C.WAREHOUSE_ID,client_activity_id,0, C.ACTIVITY_PRODUCT_ID
      FROM (
        SELECT DISTINCT
            v_order_number AS ORDER_NUMBER,DENSE_RANK() OVER(ORDER BY A.PARENT_ID) AS ORDER_ITEM_NUMBER,
            client_user_name AS USER_NAME,v_user_manage_name AS USER_MANAGE_NAME,A.PRODUCT_ITEMNUMBER,
            (SELECT F.PRODUCT_NAME FROM TBL_PRODUCT_INFO F WHERE F.ITEMNUMBER = A.PRODUCT_ITEMNUMBER AND ROWNUM = 1) AS PRODUCT_NAME,A.PRODUCT_COLOR,
            decode(client_mbr_card,2,GETSKU_USER_VIPPRICE_PRE(client_user_name,A.ID),GETSKU_USER_SALEPRICE_PRE(client_user_name,A.ID)) AS PRODUCT_UNIT_PRICE,
            A.PRODUCT_PRIZE_TAG,
            decode(client_mbr_card,2,GETSKU_USER_VIPPRICE_PRE(client_user_name,A.ID),GETSKU_USER_SALEPRICE_PRE(client_user_name,A.ID)) AS PRODUCT_OLD_UNIT_PRICE,
            SYSDATE AS ORDER_DATE,V_ORDER_TYPE AS ORDER_TYPE,
            A.PRODUCT_SPECS,0 AS PRODUCT_LACK_COUNT,CLIENT_WAREHOUSE_ID AS WAREHOUSE_ID,
            B.ACTIVITY_PRODUCT_ID
        FROM TBL_PRODUCT_SKU A,TMP_ORDER_PRODUCT_SKU B
        WHERE A.ID = B.PRODUCT_SKU
              AND B.WAREHOUSE_ID = v_warehouse_id
    ) C;

    --14.0插入订单详细表
    INSERT INTO TBL_ORDER_PRODUCT_SKU
    (
        ID,ORDER_NUMBER,ORDER_ITEM_NUMBER,USER_NAME,CODENUMBER,
        COUNT,PRODUCT_UNIT_PRICE,PRODUCT_TOTAL_MONEY,PRODUCT_OLD_UNIT_PRICE,ORDER_DATE,PRODUCT_SKU,
        PRODUCT_SKU_NAME,PRODUCT_ITEMNUMBER,PRODUCT_COLOR,PRODUCT_SPECS,PRODUCT_LACK_COUNT,PRODUCT_OLDSALE_PRIZE,WAREHOUSE_ID,MBR_CARD_REDUCE,
        ACTIVITY_PRODUCT_PRIZE_COST
    )
    SELECT
        SEQ_ORDER_PRODUCT_SKU.NEXTVAL,v_order_number,B.ORDER_ITEM_NUMBER,client_user_name,A.PRODUCT_GROUP_MEMBER,
        C.COUNT,
        decode(client_mbr_card,2,GETSKU_USER_VIPPRICE_PRE(client_user_name,A.ID),GETSKU_USER_SALEPRICE_PRE(client_user_name,A.ID)),
        decode(client_mbr_card,2,GETSKU_USER_VIPPRICE_PRE(client_user_name,A.ID),GETSKU_USER_SALEPRICE_PRE(client_user_name,A.ID)) * C.COUNT,
        decode(client_mbr_card,2,GETSKU_USER_VIPPRICE_PRE(client_user_name,A.ID),GETSKU_USER_SALEPRICE_PRE(client_user_name,A.ID)),
        SYSDATE,A.ID,
        A.PRODUCT_SKU_NAME,A.PRODUCT_ITEMNUMBER,A.PRODUCT_COLOR,A.PRODUCT_SPECS,0,getSku_OldPrice(A.ID),v_warehouse_id,
        decode(client_mbr_card,2,GETSKU_USER_VIPPRICE_PRE(client_user_name,A.ID) - getSku_User_VIPPrice(client_user_name,A.ID),0),
        getSku_User_QuotePrice(client_user_name, A.ID, 1, C.COUNT, client_mbr_card)
     FROM TBL_PRODUCT_SKU A,TBL_ORDER_PRODUCT B, TMP_ORDER_PRODUCT_SKU C
    WHERE B.ORDER_NUMBER = v_order_number
          AND B.USER_NAME = client_user_name
          AND B.ITEMNUMBER = A.PRODUCT_ITEMNUMBER
          AND B.PRODUCT_COLOR = A.PRODUCT_COLOR
          AND B.PRODUCT_SPECS = A.PRODUCT_SPECS
          AND A.ID = C.PRODUCT_SKU
          AND C.WAREHOUSE_ID = client_warehouse_id;
    --14.11查询逻辑库存量,根据逻辑库存量与下单量比较，如果不足，则为缺货订购商品订单(批发5双以上)
    IF v_product_total_count >= 5 THEN
        SELECT COUNT(1)
          INTO v_temp_count
          FROM (SELECT T1.PRODUCT_SKU,T1.COUNT AS PRODUT_COUNT,
                        NVL((SELECT NVL(PRODUCT_TOTAL_COUNT,0) - NVL(PRODUCT_ORDER_OCCUPY_COUNT,0) - NVL(PRE_ORDER_OCCUPY_COUNT,0)
                          FROM TBL_PRODUCT_SKU_STOCK
                         WHERE PRODUCT_SKU = T1.PRODUCT_SKU AND WAREHOUSE_ID = T1.WAREHOUSE_ID),0) AS WAREHOUSE_PRODUCT_COUNT
                   FROM TBL_ORDER_PRODUCT_SKU T1
                  WHERE T1.ORDER_NUMBER = v_order_number)
         WHERE  WAREHOUSE_PRODUCT_COUNT <  PRODUT_COUNT;
        IF v_temp_count >0 THEN
           v_outstock_flag := 1;
        END IF;
    END IF;
    --15.0修改各表的统计性数据
    UPDATE TBL_ORDER_PRODUCT TOP
        SET PRODUCT_COUNT = (SELECT SUM(TOPS.COUNT)
                               FROM TBL_ORDER_PRODUCT_SKU TOPS
                              WHERE TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER AND TOPS.PRODUCT_ITEMNUMBER = TOP.ITEMNUMBER AND TOPS.PRODUCT_COLOR = TOP.PRODUCT_COLOR AND TOPS.PRODUCT_SPECS = TOP.PRODUCT_SPECS ),
            PRODUCT_TOTAL_MONEY = (SELECT SUM(TOPS.PRODUCT_TOTAL_MONEY)
                                     FROM TBL_ORDER_PRODUCT_SKU TOPS
                                    WHERE TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER AND TOPS.PRODUCT_ITEMNUMBER = TOP.ITEMNUMBER AND TOPS.PRODUCT_COLOR = TOP.PRODUCT_COLOR AND TOPS.PRODUCT_SPECS = TOP.PRODUCT_SPECS ),
            MBR_CARD_REDUCE = (SELECT SUM(TOPS.MBR_CARD_REDUCE * TOPS.COUNT)
                                     FROM TBL_ORDER_PRODUCT_SKU TOPS
                                    WHERE TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER AND TOPS.PRODUCT_ITEMNUMBER = TOP.ITEMNUMBER AND TOPS.PRODUCT_COLOR = TOP.PRODUCT_COLOR AND TOPS.PRODUCT_SPECS = TOP.PRODUCT_SPECS )
        WHERE TOP.ORDER_NUMBER = v_order_number;
    --处理一下,防止总价没有计算
    UPDATE TBL_ORDER_PRODUCT TOP
       SET PRODUCT_TOTAL_MONEY = ROUND(TOP.PRODUCT_COUNT * TOP.PRODUCT_UNIT_PRICE,2)
     WHERE TOP.ORDER_NUMBER = v_order_number AND NVL(PRODUCT_TOTAL_MONEY,0) = 0;
    --16.0计算商品总价
    SELECT SUM(TOP.PRODUCT_TOTAL_MONEY) INTO v_product_total_money FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER=v_order_number;
    --校验商品总价是否被篡改
    IF v_product_total_money <> client_product_money THEN
        output_msg:='商品价格被篡改或商品价格发生变化,应收货款（'||v_product_total_money||'），请重新下单!';
        ROLLBACK;
        RETURN;
    END IF;
    
    --校验订单中是否包含活动商品
    select count(1) into v_temp_activity_product_count
    from tbl_order_info oi
    where oi.order_number = v_order_number
    and exists(
        select 1
        from tbl_order_product op
        where oi.order_number = op.order_number
        and op.activity_product_id > 0 and op.product_activity_id > 0
    );
    
    
    UPDATE TBL_ORDER_INFO TOI
       SET PRODUCT_MONEY = v_product_total_money,
           PRODUCT_COUNT=(SELECT SUM(TOP.PRODUCT_COUNT) FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER = TOI.ORDER_NUMBER),
           IS_OUTSTOCK_ORDER = v_outstock_flag,
           MBR_CARD_REDUCE=(SELECT SUM(TOP.MBR_CARD_REDUCE) FROM TBL_ORDER_PRODUCT TOP WHERE TOP.ORDER_NUMBER = TOI.ORDER_NUMBER),
           LAST_CANCEL_DATE = (
              CASE WHEN v_temp_activity_product_count > 0 then GETORDERLASTCANCELDATE(v_order_number)
              else TOI.create_date + 1
              end
           )  
     WHERE TOI.ORDER_NUMBER = v_order_number;
    --17.0更新订单占用量
    INSERT INTO TBL_ORDER_WAREHOUSE_COUNT
       (ID, ORDER_NUMBER, WAREHOUSE_ID,PRODUCT_SKU, OCCUPY_COUNT, CREATE_DATE)
    SELECT SEQ_ORDER_WAREHOUSE_COUNT.NEXTVAL, ORDER_NUMBER, v_warehouse_id,PRODUCT_SKU, COUNT, SYSDATE
      FROM TBL_ORDER_PRODUCT_SKU
     WHERE ORDER_NUMBER = v_order_number;
    --18.0删除预付清单商品
   /*************
        2019.10.14 reid
        判断下单商品是鞋类还是非鞋类，
        如果是鞋类,则需要删除规格下的所有SKU
        如果是非鞋类，则需要删除该颜色下的所有SKU
     *************/
     BEGIN
         FOR tb IN(
                select product_itemnumber from TBL_ORDER_PRODUCT_SKU
                where order_number =  v_order_number
                group by product_itemnumber
         ) LOOP
                 select to_number(type) into v_product_type from tbl_dic_product_type dpt
                 where exists (
                    select 1 from TBL_PRODUCT_INFO pi
                    inner join TBL_PRODUCT_SKU ps on pi.itemnumber = ps.product_itemnumber
                    inner join TBL_ORDER_PRODUCT_SKU pod on pod.product_sku = ps.id
                    WHERE pod.order_number = v_order_number
                    and dpt.id = pi.product_type_id
                    and pi.itemnumber = tb.product_itemnumber
                 );
                 IF v_product_type = 1 THEN
                    --鞋类（删除规格下的所有尺码）
                    delete from TBL_PRE_USER_CART puc
                    where puc.product_sku in (
                        select id from TBL_PRODUCT_SKU tps where tps.parent_id in (
                            select 
                            ps.parent_id
                            from TBL_ORDER_PRODUCT_SKU pod 
                            inner join TBL_PRODUCT_SKU ps on pod.product_sku = ps.id
                            where pod.order_number =  v_order_number
                            and ps.product_group = '尺码'
                            and ps.product_itemnumber = tb.product_itemnumber
                        ) and tps.product_group = '尺码'
                    )
                    and puc.activity_id = client_activity_id
                    and puc.user_id = client_user_name;
                 ELSE
                    ---非鞋类（删除颜色下的所有尺码）
                     delete from TBL_PRE_USER_CART puc where puc.product_sku in (
                         select id from TBL_PRODUCT_SKU nod
                         start with nod.id in (
                           select parent_id from TBL_PRODUCT_SKU tps where tps.id in (
                                select 
                                ps.parent_id
                                from TBL_ORDER_PRODUCT_SKU pod 
                                inner join TBL_PRODUCT_SKU ps on pod.product_sku = ps.id
                                where pod.order_number = v_order_number
                                and ps.product_group = '尺码'
                                and ps.product_itemnumber = tb.product_itemnumber
                            ) 
                            and tps.product_group = '规格'
                         )
                         connect by PRIOR nod.id = nod.parent_id
                     )
                     and puc.activity_id = client_activity_id
                     and puc.user_id = client_user_name;
                 END IF;
         END LOOP;
     END;
    --19.0记录预付订单商品清分规则
    --入驻商货款
    insert into TBL_ORDER_DIVIDE_RECORD(ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,DIVIDE_MONEY,ORDER_MONEY,CREATE_DATE)
    select SEQ_ORDER_DIVIDE_RECORD.nextval,
        v_order_number,
        PRODUCT_SKU,PRODUCT_ITEMNUMBER,
        '1',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        GETSKU_USER_LIQUIDATIONPRICE(1,client_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,client_mbr_card),
        PRODUCT_UNIT_PRICE,
        SYSDATE
    from TBL_ORDER_PRODUCT_SKU where ORDER_NUMBER = v_order_number;

    --平台服务费
    insert into TBL_ORDER_DIVIDE_RECORD(ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,DIVIDE_MONEY,ORDER_MONEY,CREATE_DATE)
    select SEQ_ORDER_DIVIDE_RECORD.nextval,
        v_order_number,
        PRODUCT_SKU,PRODUCT_ITEMNUMBER,
        '2',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        GETSKU_USER_LIQUIDATIONPRICE(2,client_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,client_mbr_card),
        PRODUCT_UNIT_PRICE,
        SYSDATE
    from TBL_ORDER_PRODUCT_SKU where ORDER_NUMBER = v_order_number;

    --仓储费
    insert into TBL_ORDER_DIVIDE_RECORD(ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,DIVIDE_MONEY,ORDER_MONEY,CREATE_DATE)
    select SEQ_ORDER_DIVIDE_RECORD.nextval,
        v_order_number,
        PRODUCT_SKU,PRODUCT_ITEMNUMBER,
        '3',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        GETSKU_USER_LIQUIDATIONPRICE(3,client_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,client_mbr_card),
        PRODUCT_UNIT_PRICE,
        SYSDATE
    from TBL_ORDER_PRODUCT_SKU where ORDER_NUMBER = v_order_number;

    --入驻商服务费
    insert into TBL_ORDER_DIVIDE_RECORD(ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,DIVIDE_MONEY,ORDER_MONEY,CREATE_DATE)
    select SEQ_ORDER_DIVIDE_RECORD.nextval,
        v_order_number,
        PRODUCT_SKU,PRODUCT_ITEMNUMBER,
        '4',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        GETSKU_USER_LIQUIDATIONPRICE(4,client_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,client_mbr_card),
        PRODUCT_UNIT_PRICE,
        SYSDATE
    from TBL_ORDER_PRODUCT_SKU where ORDER_NUMBER = v_order_number;
    
    --入驻商支付服务费
    insert into TBL_ORDER_DIVIDE_RECORD(ID,ORDER_NUMBER,PRODUCT_SKU,PRODUCT_ITEMNUMBER,DIVIDE_TYPE,DIVIDE_USER_ID,DIVIDE_MONEY,ORDER_MONEY,CREATE_DATE)
    select SEQ_ORDER_DIVIDE_RECORD.nextval,
        v_order_number,
        PRODUCT_SKU,PRODUCT_ITEMNUMBER,
        '5',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        GETSKU_USER_LIQUIDATIONPRICE(5,client_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,client_mbr_card),
        PRODUCT_UNIT_PRICE,
        SYSDATE
    from TBL_ORDER_PRODUCT_SKU where ORDER_NUMBER = v_order_number;


    --20.0生成付款交易号
    v_pay_trade_number:='1'||getAutoNumber('D');
    INSERT INTO TBL_ORDER_UNION_PAY(ID,PAY_TRADE_NUMBER,STATE,CREATE_DATE,ORDER_SUBMOD,ORDER_XDR_TYPE,ORDER_SALE_USER_NAME)
         VALUES(SEQ_ORDER_UNION_PAY.NEXTVAL,v_pay_trade_number,0,sysdate,client_submode,client_xdr_type,client_xdr_user_name);
    INSERT INTO TBL_ORDER_UNION_PAY_DETAIL(ID,PAY_TRADE_NUMBER,ORDER_NUMBER,CREATE_DATE)
         VALUES(SEQ_ORDER_UNION_PAY_DETAIL.NEXTVAL,V_PAY_TRADE_NUMBER,v_order_number,SYSDATE);
    output_status:='1';
    output_msg:=v_pay_trade_number;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
        output_status := '0';
        output_msg:='提交订单出现未知错误::'||SQLCODE || '::'||SQLERRM||'----';
        ROLLBACK;
END SUBMIT_ORDER_DHH_FULLPAY_ARR;
------------------------------------------------
/

