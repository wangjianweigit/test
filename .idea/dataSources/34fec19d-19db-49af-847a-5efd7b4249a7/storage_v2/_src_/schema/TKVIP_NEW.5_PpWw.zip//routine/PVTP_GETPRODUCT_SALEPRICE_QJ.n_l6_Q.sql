create FUNCTION PVTP_GETPRODUCT_SALEPRICE_QJ
/**
    （私有平台）通过用户名获取商品货号价格价格区间   （精确价格）
    reid 2019-09-12
    返回值：商品价格
**/
(
    c_stationed_user_id     number,              --当前下单私有平台ID（即所属私有商家的ID）
    c_user_name   varchar2,   --用户名
    c_product_itemnumber   varchar2--商品货号    
) return varchar2
 is
    v_count number:=0;                                  --临时变量
    v_product_prize_str varchar2(50):='0.00-0.00';      --需要返回的商品价格区间
BEGIN
    --判断商品是私有商品还是童库分享得商品
    select count(1) into v_count from TBL_PVTP_PRODUCT_INFO ppi where ppi.stationed_user_id = c_stationed_user_id and ppi.itemnumber = c_product_itemnumber;
    IF v_count <> 0 THEN
        --通过sku获取最低价
       select nvl(to_char(min(price),'fm999999990.00'),'0.00')||'-'||nvl(to_char(max(price),'fm999999990.00'),'0.00') into v_product_prize_str  from (
            select pvtp_getSku_User_SalePrice(c_stationed_user_id,c_user_name,id) price from tbl_pvtp_product_sku where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架'
       );
    ELSE
        --通过sku获取最低价
       select nvl(to_char(min(price),'fm999999990.00'),'0.00')||'-'||nvl(to_char(max(price),'fm999999990.00'),'0.00') into v_product_prize_str  from (
            select pvtp_getSku_User_SalePrice(c_stationed_user_id,c_user_name,id) price from tbl_product_sku where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架'
       );
    END IF;
   
   return v_product_prize_str;
   
END PVTP_GETPRODUCT_SALEPRICE_QJ;
/

