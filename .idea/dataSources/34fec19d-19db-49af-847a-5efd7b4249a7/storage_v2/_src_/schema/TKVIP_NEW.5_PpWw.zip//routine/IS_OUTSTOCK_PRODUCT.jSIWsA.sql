create FUNCTION           IS_OUTSTOCK_PRODUCT
/**
    reid 2019.03.04 
    根据当前用户判断商品是否是缺货订购商品
    显示规则
    reid 2019.04.18 如果商品参加了【预售活动】，则直接返回0 
    reid 2019.04.25 如果商品参加了【清尾活动】，则直接返回0 
    reid 2019.05.10 根据仓库判断商品是否可以缺货订购
    
    返回值：0非缺货订购商品 ；1:是缺货订购商品
**/
(
    c_user_name             varchar2,            --用户名
    c_product_itemnumber    varchar2,            --商品货号
    c_warehouse_id          number:=0            --仓库ID 如果使用默认值0，则表示所有仓库中，只有有一个仓库可以缺货订购即可
) return varchar2
 is
     v_site_id number:=0;                                  --客户站点ID
     v_is_outstock number:=0;                              --商品类型  0非缺货订购商品 ；1:是缺货订购商品
     v_activity_type number:=0;                            --活动类型 1.限时折扣;2.订货会;4.预售;5.一口清;6.团批（TBL_GROUP_ACTIVITY_INFO） 
BEGIN
    select IS_ACTIVITY(c_user_name,c_product_itemnumber) into v_activity_type from dual;
    IF v_activity_type = 2 OR v_activity_type = 4 OR v_activity_type = 5 THEN
        RETURN v_is_outstock;
    END IF;
    --查询用户城市代码和站点
    select site_id into v_site_id from tbl_user_info where user_name = c_user_name;
    /**************查询当前用户对于该商品是否存在可以缺货订购的仓*******************/
    IF c_warehouse_id = 0 THEN
         SELECT 
            (case when sum(
                case when (
                    select default_outstock_warehouse 
                    from tbl_stationed_user_info sui,
                    tbl_product_info pi 
                    where pi.stationed_user_id = sui.id
                    and pi.itemnumber =  c_product_itemnumber
                ) = sw.warehouse_id 
                and (select is_outstock from tbl_product_info where itemnumber = c_product_itemnumber)=1 then
                1 else 0 end
            )>0 then 1 else 0 end) is_outstock into v_is_outstock
         FROM TBL_SITE_WAREHOUSE sw
         WHERE sw.site_id = v_site_id;
    ELSE
        SELECT
        (case when (
                case when (
                    select default_outstock_warehouse 
                    from tbl_stationed_user_info sui,
                    tbl_product_info pi 
                    where pi.stationed_user_id = sui.id
                    and pi.itemnumber =  c_product_itemnumber
                ) = c_warehouse_id
                and (select is_outstock from tbl_product_info where itemnumber = c_product_itemnumber)=1 then
                1 else 0 end
            )>0 then 1 else 0 end) into v_is_outstock
        FROM DUAL;
    END IF;
   
   return v_is_outstock;
END IS_OUTSTOCK_PRODUCT;
/

