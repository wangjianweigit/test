create PROCEDURE           pro_update_CREDIT_BALANCE
/**
     会员收支记录修复授信余额历史数据
     liujialong
     2019-03-22 
  **/
 IS
    v_start number:=1;
    v_end number:=500;
    v_count number:=0;--当前循环次数
    v_total_count number;--总条数
    v_cycle_count number;--循环次数
    v_user_name            NUMBER; --用户id(临时变量)
    v_record_channel        varchar2(50);--收付渠道
    v_create_date        date ; --创建时间
    v_max_create_date        date ; --最大创建时间
     v_id        number ; --主键ID
    v_credit_balance number;
BEGIN
            select count(1) into v_total_count from TBL_USER_ACCOUNT_RECORD;
            select ceil(v_total_count/500) into v_cycle_count from dual;
            BEGIN
                WHILE v_count<v_cycle_count LOOP
                            update TBL_USER_ACCOUNT_RECORD   t
                                    set credit_balance=
                                            case when t.record_channel='授信' then
                                                    (select SURPLUS_MONEY from TBL_USER_ACCOUNT_RECORD t2 where t2.id=t.id)
                                            else 
                                                nvl( ( select SURPLUS_MONEY from TBL_USER_ACCOUNT_RECORD where  user_name=t.user_name and  record_channel='授信' and create_date=  (select max(create_date) from TBL_USER_ACCOUNT_RECORD t2 where  record_channel='授信' and user_name=t.user_name and t2.create_date<=t.create_date)),0)
                                             end
                                    where id in (select id from (select t1.*,rownum rn from (select * from TBL_USER_ACCOUNT_RECORD where user_name<>10001259 order by create_date,id) t1 where rownum<=v_end) t2 where rn>=v_start);
                    commit;
                    v_count:=v_count+1;
                     v_start :=v_end +1;
                     v_end :=v_end+500;
                END LOOP;
            END;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END pro_update_CREDIT_BALANCE;
/

