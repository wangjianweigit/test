create trigger TRI_BANK_ACCOUNT
  before insert
  on TBL_BANK_ACCOUNT
  for each row
BEGIN
   IF INSERTING
   THEN
      if :new.BANK_ACCOUNT is null then
         
        :new.BANK_ACCOUNT := :new.id;
      end if;
   END IF;
END;
/

