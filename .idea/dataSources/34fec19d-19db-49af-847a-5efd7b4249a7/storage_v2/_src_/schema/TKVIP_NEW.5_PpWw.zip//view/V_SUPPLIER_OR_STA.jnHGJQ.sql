create view V_SUPPLIER_OR_STA as
  SELECT id,
          code,
          name,
          fullname,
          contacts,
          phone,
          '供应商' TYPE
     FROM TKERP.TBL_SUPPLIER_INFO
   UNION
   SELECT id,
          USER_CODE code,
          COMPANY_NAME name,
          COMPANY_NAME fullname,
          contacts,
          CONTACT_PHONE_NUMBER phone,
          '入驻商' TYPE
     FROM TBL_STATIONED_USER_INFO sui
    WHERE     sui.stationed_user_type = '2'
          AND NOT EXISTS
                 (SELECT 1
                    FROM TKERP.TBL_SUPPLIER_INFO si
                   WHERE sui.id = si.id)
/

