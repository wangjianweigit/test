create FUNCTION           GETSKU_USER_SALEPRICE_O_N
/**
    （新版）通过用户名获取SKU商品的             未来销售价格(精确) 
    wangpeng
    2017-05-12              2018-07-24   update  for wangpeng 
    修改：2018-08-16，特殊折扣支持入驻商会员服务费折扣  for wangpeng
    修改：2018-12-25   update  for wangpeng  支持新老商品不同费率计算
    修改：2019-01-09   update  for wangpeng  支持私有站特殊价格计算
    价格计算规则：特殊价优先 -->  活动价（取所有活动中最低的折扣）、 站点价(按照用户站点折扣计算) 、  会员价（按照会员折扣计算）  取最低
    reid   2018.10.25 预售活动相关修改
    修改：2019-06-15   update by zhenghui 限时折扣、预售、清尾，服务费折扣统一
    修改：2019-06-27   update by reid     特殊价格与活动价格取较低值
    返回值：商品实际销售价格
**/
(
     C_USER_NAME   VARCHAR2,         --用户名
     C_PRODUCT_SKU_ID   NUMBER       --商品SKUID 
) RETURN NUMBER
 IS
     V_PRODUCT_PRIZE NUMBER:=0;             --需要返回的商品价格
     V_USER_ID NUMBER:=0;                   --用户ID
     V_PRODUCT_ITEMNUMBER   VARCHAR2(50);   --商品货号
     V_HD_FLAG NUMBER:=-1;                  --是否参加了活动
     V_HD_DISCOUNT NUMBER:=1;               --活动折扣
     V_HY_DISCOUNT NUMBER:=1;               --会员等级折扣
     V_SITE_DISCOUNT NUMBER:=1;             --站点折扣
     V_TS_DISCOUNT NUMBER:=1;               --特殊价折扣
     V_HYFWF_DISCOUNT NUMBER :=1 ;          --会员服务费折扣率,站点或会员等级折扣
     V_SITE_ID NUMBER:=0;                   --会员站点
     V_HDHY_DISCOUNT NUMBER:=1;             --活动会员折扣
     V_TS_FLAG NUMBER:=-1;                  --是否有特殊价  -1为没有   非-1为有特殊价
     
     V_PRODUCT_PRIZE_COST NUMBER:=0;                 --商品报价
     V_PRODUCT_SALE_PRIZE NUMBER:=0;                 --应售价
     V_MEMBER_SERVICE_RATE NUMBER:=0;                --会员服务费比例-汇总
     V_MEMBER_SERVICE_RATE_RZS NUMBER:=0;            --会员服务费比例-入驻商
     V_MEMBER_SERVICE_RATE_QJ NUMBER:=0;             --会员服务费比例-全局
     V_MEMBER_SERVICE_MONEY_RZS NUMBER:=0;           --会员服务费-入驻商
     V_MEMBER_SERVICE_MONEY_QJ NUMBER:=0;            --会员服务费-全局
     V_PRODUCT_CREATE_DATE DATE;                                             --商品创建时间                          --界线新加配置
     V_SYS_LINE DATE:=TO_DATE('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置
     V_SYS_DEFAULT_HY_DIS NUMBER := 0.7;                                     --新注册会员老商品采用默认费率折扣      --界线新加配置
     
     V_PRODUCT_TYPE NUMBER:=0;                        --商品类型（0：普通商品，1：定制商品，2：菜鸟商品，3：私有平台商品）   --私有平台特殊价格新加配置
     V_STA_USER_SPEC_PR_TEMP_ID NUMBER:=-1;           --用户特殊价格模板                                                     --私有平台特殊价格新加配置
     V_PRODUCT_TYPE_ID NUMBER:=0;                     --商品分类                                                             --私有平台特殊价格新加配置
     V_PRODUCT_SPECS_ID NUMBER :=0;                   --商品规格ID                                                           --私有平台特殊价格新加配置
     V_PRODUCT_SPECS VARCHAR2(500);                   --商品规格名称                                                         --私有平台特殊价格新加配置
     V_OFF_PRICE NUMBER :=0;                          --优惠金额                                                             --私有平台特殊价格新加配置
     
     V_TS_PRODUCT_SALE_PRIZE NUMBER :=0;              --私有站商品 有特殊价情况下的商品售价      
BEGIN

    /*************************商品新老计费费率控制*********begin**********************/
    SELECT A.CREATE_DATE,A.PRODUCT_TYPE,A.PRODUCT_TYPE_ID INTO V_PRODUCT_CREATE_DATE,V_PRODUCT_TYPE,V_PRODUCT_TYPE_ID FROM TBL_PRODUCT_INFO A,TBL_PRODUCT_SKU B WHERE B.ID = C_PRODUCT_SKU_ID AND A.ITEMNUMBER = B.PRODUCT_ITEMNUMBER  AND ROWNUM<2;
    IF V_PRODUCT_CREATE_DATE < V_SYS_LINE THEN
        --查询入驻商会员服务费比例-老费率
        SELECT NVL(MEMBER_SERVICE_RATE,0),NVL(AREA_SERVICE_RATE,0) INTO V_MEMBER_SERVICE_RATE_RZS,V_MEMBER_SERVICE_RATE_QJ FROM TBL_STATIONED_OLD_SERVICE_RATE WHERE STATIONED_USER_ID = (
            SELECT STATIONED_USER_ID FROM TBL_PRODUCT_SKU WHERE ID = C_PRODUCT_SKU_ID AND ROWNUM<2
        );
    END IF;
    /*************************商品新老计费费率控制*********end**********************/
    
   --查询全局会员服务费比例
   --select member_service_rate into v_member_service_rate_qj from TBL_SYS_CONFIG where id = 1;

   IF V_PRODUCT_CREATE_DATE >= V_SYS_LINE THEN
       --查询入驻商会员服务费比例-按当前费率计算
       SELECT NVL(MEMBER_SERVICE_RATE,0),NVL(AREA_SERVICE_RATE,0) INTO V_MEMBER_SERVICE_RATE_RZS,V_MEMBER_SERVICE_RATE_QJ FROM TBL_STATIONED_USER_INFO WHERE ID = (
           SELECT STATIONED_USER_ID FROM TBL_PRODUCT_SKU WHERE ID = C_PRODUCT_SKU_ID
       );
   END IF;
    
   --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
   V_MEMBER_SERVICE_RATE := V_MEMBER_SERVICE_RATE_RZS + V_MEMBER_SERVICE_RATE_QJ;

   --查询SKU基本信息
   SELECT PRODUCT_ITEMNUMBER,PRODUCT_PRIZE_COST,PARENT_ID,PRODUCT_SPECS INTO V_PRODUCT_ITEMNUMBER,V_PRODUCT_PRIZE_COST,V_PRODUCT_SPECS_ID,V_PRODUCT_SPECS FROM TBL_PRODUCT_SKU WHERE PRODUCT_GROUP = '尺码' AND ID = C_PRODUCT_SKU_ID ;

   --计算应销售价
   V_PRODUCT_SALE_PRIZE:=V_PRODUCT_PRIZE_COST/(1-V_MEMBER_SERVICE_RATE);

   --计算入驻商会员服务费 = 应销售价*入驻商会员服务费比例
   V_MEMBER_SERVICE_MONEY_RZS := V_PRODUCT_SALE_PRIZE * V_MEMBER_SERVICE_RATE_RZS;
        
   --计算全局会员服务费 = 应销售价*全局会员服务费比例
   V_MEMBER_SERVICE_MONEY_QJ := V_PRODUCT_SALE_PRIZE * V_MEMBER_SERVICE_RATE_QJ;
   
   --查询会员站点
   SELECT NVL(MIN(SITE_ID),0),NVL(MIN(ID),0),NVL(MIN(DISCOUNT),1),NVL(MIN(STA_USER_SPEC_PR_TEMP_ID),-1) INTO V_SITE_ID,V_USER_ID,V_HY_DISCOUNT,V_STA_USER_SPEC_PR_TEMP_ID FROM TBL_USER_INFO WHERE USER_NAME = C_USER_NAME;
   
   --(按照老的费率计算)
   IF V_PRODUCT_CREATE_DATE < V_SYS_LINE THEN
        SELECT NVL(MIN(DISCOUNT),V_SYS_DEFAULT_HY_DIS) INTO V_HY_DISCOUNT FROM TBL_USER_OLD_DISCOUNT WHERE USER_NAME = C_USER_NAME;
   END IF;
   
   --查询站点折扣
   SELECT NVL(MIN(DISCOUNT),1) INTO V_SITE_DISCOUNT FROM TBL_SITE_INFO  WHERE ID = V_SITE_ID;
   
   --如果没有查询到用户信息，则返回原价
   IF V_USER_ID=0 THEN
        V_PRODUCT_PRIZE:=V_PRODUCT_SALE_PRIZE;
   ELSE
         --特殊价格查询--私有平台商品
       IF V_PRODUCT_TYPE = 3 THEN
           --用户配置了特殊价格模板
           IF V_STA_USER_SPEC_PR_TEMP_ID != -1 THEN 
               --模板详情的类型 1:按照商品规格设置；2:按照全局规格设置；3:按照商品分类设置
               --如果某规格3个维度都符合，则优先级按商品>规格>分类确定特殊价
                SELECT NVL(MIN(OFF_PRICE),0),NVL(MIN(ID),-1) INTO V_OFF_PRICE,V_TS_FLAG 
                FROM (
                    SELECT B.ID,B.OFF_PRICE FROM TBL_STA_USER_SPEC_PR_TEMP A,TBL_STA_USER_SPEC_PR_TEMP_DEL B WHERE A.ID = B.TEMPLATE_ID AND A.IS_DELETE = 1 
                    AND A.BEGIN_DATE <= SYSDATE AND A.END_DATE >=SYSDATE 
                    AND A.ID = V_STA_USER_SPEC_PR_TEMP_ID 
                    AND (
                        (B.TYPE = 1 AND PRODUCT_SPECS_ID = V_PRODUCT_SPECS_ID)
                        OR
                        (B.TYPE = 2 AND PRODUCT_SPECS = V_PRODUCT_SPECS)
                        OR
                        (B.TYPE = 3 AND PRODUCT_TYPE_ID = V_PRODUCT_TYPE_ID)
                    )
                    ORDER BY B.TYPE ASC
                ) WHERE ROWNUM <2;
          END IF;
       ELSE 
           --查询特殊价格折扣
           SELECT NVL(MIN(DISCOUNT),1),NVL(MIN(ID),-1) INTO V_TS_DISCOUNT,V_TS_FLAG FROM
           (
            SELECT A.* FROM TBL_USER_DISCOUNT_PRODUCT A,TBL_PRODUCT_SKU B ,TBL_USER_DISCOUNT C
            WHERE A.USER_NAME = C_USER_NAME 
              AND B.PRODUCT_COLOR = A.PRODUCT_COLOR 
              AND B.PRODUCT_SPECS = A.PRODUCT_SPECS
              AND B.PRODUCT_ITEMNUMBER = A.PRODUCT_ITEMNUMBER
             AND C.STATE = '3' 
             AND C.APPLY_NUMBER = A.APPLY_NUMBER
             AND SYSDATE BETWEEN A.BEGIN_TIME AND A.END_TIME
             AND B.PRODUCT_GROUP = '尺码'
             AND B.ID = C_PRODUCT_SKU_ID
             ORDER BY A.ID DESC
            ) WHERE ROWNUM <2;
        END IF;
       /*********有特殊价格：如果当前商品SKU对于当前用户存在特殊价，则需要先计算出特殊价情况下的售价信息**********/
       IF V_TS_FLAG<>-1 THEN 
       --特殊价格处理-私有站商品
        IF V_PRODUCT_TYPE = 3 THEN
            --私有站特殊价格处理 = 应售价 - 优惠价格
            V_TS_PRODUCT_SALE_PRIZE := V_PRODUCT_SALE_PRIZE - V_OFF_PRICE;
            IF V_TS_PRODUCT_SALE_PRIZE  < 0 THEN
                V_TS_PRODUCT_SALE_PRIZE := 0 ;
            END IF;
        END IF;
       END IF;---特殊价判断结束
        --查询参加的活动----订货会、限时折扣、预售活动、清尾活动
       SELECT NVL(MIN(C.ACTIVITY_DISCOUNT),1),NVL(MIN(C.ID),-1),NVL(MIN(A.ACTIVITY_SERVICE_DISCOUNT),1) INTO V_HD_DISCOUNT,V_HD_FLAG,V_HDHY_DISCOUNT FROM TBL_ACTIVITY_INFO A ,TBL_ACTIVITY_DETAIL A1,TBL_ACTIVITY_PRODUCT C 
       WHERE A.ACTIVITY_STATE = '3' AND A.STATE = '2'  AND A.ACTIVITY_TYPE='2'
       AND SYSDATE <= A.END_DATE 
       AND SYSDATE <= C.ACTIVITY_END_DATE 
       AND A.ID = A1.ACTIVITY_ID
       AND C.ACTIVITY_ID = A.ID 
       AND C.PRODUCT_ITEMNUMBER =V_PRODUCT_ITEMNUMBER
        AND  
        CASE 
           WHEN (A1.USER_GROUP_ID = 0 OR A1.USER_GROUP_ID IS NULL)
               THEN 1
           ELSE
               CASE WHEN EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND A1.USER_GROUP_ID = AA.ID AND  BB.USER_ID = C_USER_NAME)
               THEN 
                   1
               ELSE
                   0
               END
        END  = 1
       AND EXISTS (SELECT 1 FROM TBL_ACTIVITY_SITE TAS WHERE TAS.ACTIVITY_ID = A.ID AND TAS.SITE_ID = V_SITE_ID);
       --获取 会员折扣 或  站点折扣  中最低的
       V_HYFWF_DISCOUNT:= LEAST(V_HY_DISCOUNT,V_SITE_DISCOUNT);
       IF V_HD_FLAG=-1 THEN  
            --比较特殊折扣是否是最低的折扣
            V_HYFWF_DISCOUNT := LEAST(V_HYFWF_DISCOUNT,V_TS_DISCOUNT);
            V_PRODUCT_PRIZE := V_PRODUCT_PRIZE_COST+V_MEMBER_SERVICE_MONEY_RZS+(V_MEMBER_SERVICE_MONEY_QJ*V_HYFWF_DISCOUNT);
            --参加了活动
       ELSE  
            --获取最低折扣   会员折扣与活动会员折扣与活动折扣中最低
            V_HYFWF_DISCOUNT := LEAST(V_HYFWF_DISCOUNT,V_HDHY_DISCOUNT,V_HD_DISCOUNT);
             --比较特殊折扣是否是最低的折扣
            V_HYFWF_DISCOUNT := LEAST(V_HYFWF_DISCOUNT,V_TS_DISCOUNT);
            --按照活动计算  报价*活动折扣 + 入驻商会员服务费*活动折扣 + 全局会员服务费*会员折扣与活动会员折扣与活动折扣中最低
            V_PRODUCT_PRIZE := (V_PRODUCT_PRIZE_COST*V_HD_DISCOUNT) + (V_MEMBER_SERVICE_MONEY_RZS*V_HD_DISCOUNT) + (V_MEMBER_SERVICE_MONEY_QJ*V_HYFWF_DISCOUNT);
       END IF; 
   END IF;
   ---如果私有站的特殊折扣售价不为0，则比较特殊价是否为最低价格
   IF V_TS_PRODUCT_SALE_PRIZE<> 0 THEN
       V_PRODUCT_PRIZE := LEAST(V_PRODUCT_PRIZE,V_TS_PRODUCT_SALE_PRIZE);
   END IF;
   IF CEIL(V_PRODUCT_PRIZE)-V_PRODUCT_PRIZE<0.5 THEN
      V_PRODUCT_PRIZE := CEIL(V_PRODUCT_PRIZE);
   ELSIF CEIL(V_PRODUCT_PRIZE)-V_PRODUCT_PRIZE=0 THEN
      V_PRODUCT_PRIZE := V_PRODUCT_PRIZE;
   ELSE 
      V_PRODUCT_PRIZE := CEIL(V_PRODUCT_PRIZE)-0.5;
   END IF;
   
   RETURN V_PRODUCT_PRIZE;
   
END GETSKU_USER_SALEPRICE_O_N;
/

