create FUNCTION           is_view_display
/**
    查看店铺的专用用户在查看店铺或者装修预览是，根据用户名、货号判断该用户是否可以看到该商品
    规则如下：
    预览用户只能看到自身所在店铺的商品
    songwangwen 2018.08.09
   显示规则
    返回值：1（显示）  0：不显示
**/
(
    c_user_name   varchar2,            --用户名
    c_product_itemnumber   varchar2    --商品货号
) return varchar2
 is
     v_flag number:=1;                              --是否显示   1（显示）  0：不显示 2:订货会商品
     v_u_stationed_user_id          number:=0;      --预览用户所属入驻商ID，不是预览用户则为0
     v_p_stationed_user_id          number:=0;      --商品所属入驻商ID
     v_count number:=0;                             --临时变量

BEGIN
    select count(1) into v_count from tbl_stationed_user_relate where user_id = c_user_name and rownum <=1;
    IF v_count =0 THEN
        RETURN 1;
    END IF;
    select stationed_user_id into v_u_stationed_user_id from tbl_stationed_user_relate where user_id = c_user_name and rownum <=1;
    select stationed_user_id into v_p_stationed_user_id from TBL_PRODUCT_INFO where itemnumber = c_product_itemnumber and rownum <=1;
    /**用户所属入驻商与商品所属入驻商相同**/ 
    IF v_u_stationed_user_id = v_p_stationed_user_id THEN
        RETURN 1;
    END IF;
   RETURN 0;
END is_view_display;
/

