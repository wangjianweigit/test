create PROCEDURE     INSERT_PRODUCT_SKU_APPLY
/**
    新增商品SKU
    当i_product_sku_color_lst传入空时，只新增规格SKU信息
**/
(
   i_product_sku_list       IN  t_product_sku_list,  --商品SKU数组对象
   i_product_id             IN  number,            --商品ID
   i_stationed_user_id      IN  number,       --入驻商ID
   output_status            OUT varchar2, --返回的状态码 0-失败 1-成功
   output_msg               OUT varchar2 --返回的信息
) AS 
   v_color_id number;   --颜色ID
   v_specs_id number;   --规格ID
   v_size_id number;   --尺码ID
   v_product_sku t_product_sku;     --SKU数组中的一个元素
   temp_count int:=0;    --临时变量 计数
   v_product_sku_name varchar2(500); --SKU名称
BEGIN
    output_status:='0';
    -- 判断商品SKU是否为空 --
    IF i_product_sku_list.COUNT = 0  THEN
        output_msg:='商品SKU不能为空';
        RETURN;
    END IF;
    --判断商家用户名是否为空--
    SELECT COUNT(*) INTO temp_count FROM TBL_STATIONED_USER_INFO WHERE id = i_stationed_user_id;
    IF temp_count = 0 THEN
        output_msg:='入驻商ID不存在';
        RETURN;
    END IF;
    --判断商品货号是否为空--
    SELECT COUNT(*) INTO temp_count FROM TBL_PRODUCT_INFO_APPLY WHERE id = i_product_id;
    IF temp_count = 0 THEN
        output_msg:='商品ID不存在';
        RETURN;
    END IF;
    
    --循环所有的尺码，分别新增或者更新颜色，规格数据--
   
        FOR i IN 1..i_product_sku_list.COUNT LOOP
            --取得颜色各列值--
            v_product_sku:=i_product_sku_list(i);
            /***************************判断颜色是否已存在*****************************************************************/
            SELECT nvl(min(id),0) INTO v_color_id FROM TBL_PRODUCT_SKU_APPLY 
            WHERE STATIONED_USER_ID = i_stationed_user_id
            AND PRODUCT_GROUP_MEMBER = v_product_sku.product_color 
            AND PRODUCT_ID = i_product_id;
            --颜色数据不存在，则插入
            IF v_color_id = 0 THEN
                  --取得颜色编号--
                  SELECT SEQ_PRODUCT_SKU.NEXTVAL INTO v_color_id FROM dual;
                   --颜色sku名--
                   v_product_sku_name:= '颜色:' || v_product_sku.product_color;
                  --插入颜色--
                  INSERT INTO TBL_PRODUCT_SKU_APPLY
                    (
                        id,
                        stationed_user_id,
                        product_id,
                        parent_id,
                        product_group,
                        product_group_member,
                        product_color_imgurl,
                        product_sku_name
                    ) VALUES 
                    (
                        v_color_id,
                        i_stationed_user_id,
                        i_product_id,
                        0,
                        '颜色',
                        v_product_sku.product_color,
                        v_product_sku.product_color_imgurl,
                        v_product_sku_name
                    );
            ELSE
                --颜色数据已经存在，则更新
                UPDATE TBL_PRODUCT_SKU_APPLY
                SET product_color_imgurl = v_product_sku.product_color_imgurl
                WHERE id = v_color_id;
            END IF;
            /**********************************判断规格是否已存在**************************************************/
            SELECT nvl(min(id),0) INTO v_specs_id FROM TBL_PRODUCT_SKU_APPLY 
            WHERE STATIONED_USER_ID = i_stationed_user_id
            AND PRODUCT_GROUP_MEMBER = v_product_sku.product_specs 
            AND PRODUCT_ID = i_product_id
            AND PARENT_ID = v_color_id;
            --规格数据不存在，则插入
            IF v_specs_id = 0 THEN
                  --取得规格编号--
                  SELECT SEQ_PRODUCT_SKU.NEXTVAL INTO v_specs_id FROM dual;
                   --规格sku名--
                   v_product_sku_name:= '颜色:' || v_product_sku.product_color||' 规格:'||v_product_sku.product_specs;
                  --插入规格--
                  INSERT INTO TBL_PRODUCT_SKU_APPLY
                    (
                        id,
                        stationed_user_id,
                        product_id,
                        parent_id,
                        product_group,
                        product_group_member,
                        product_sku_name,
                        product_prize_tag,
                        product_prize_cost,
                        product_gbcode
                    ) VALUES 
                    (
                        v_specs_id,
                        i_stationed_user_id,
                        i_product_id,
                        v_color_id,
                        '规格',
                        v_product_sku.product_specs,
                        v_product_sku_name,
                        v_product_sku.product_prize_tag,
                        v_product_sku.product_prize_cost,
                        v_product_sku.product_gbcode
                    );
            ELSE
                --规格已经存在，则更新价格以及国标码数据
                UPDATE TBL_PRODUCT_SKU_APPLY             
                SET PRODUCT_PRIZE_COST = v_product_sku.product_prize_cost,
                PRODUCT_GBCODE = v_product_sku.product_gbcode
                WHERE id = v_specs_id;
            END IF;
            /**********************************判断尺码是否已存在**************************************************/
            SELECT nvl(min(id),0) INTO v_size_id FROM TBL_PRODUCT_SKU_APPLY 
            WHERE STATIONED_USER_ID = i_stationed_user_id
            AND PRODUCT_GROUP_MEMBER = v_product_sku.product_size 
            AND PRODUCT_ID = i_product_id
            AND PARENT_ID = v_specs_id;
            --尺码数据不存在，则插入
            IF v_size_id = 0 THEN
                  --取得尺码编号--
                  SELECT SEQ_PRODUCT_SKU.NEXTVAL INTO v_size_id FROM dual;
                   --尺码sku名--
                   v_product_sku_name:= '颜色:' || v_product_sku.product_color||' 规格:'||v_product_sku.product_specs||' 尺码:'||v_product_sku.product_size;
                  --插入尺码--
                  INSERT INTO TBL_PRODUCT_SKU_APPLY
                    (
                        id,
                        stationed_user_id,
                        product_id,
                        parent_id,
                        product_group,
                        product_group_member,
                        product_sku_name,
                        product_prize_tag,
                        product_prize_cost,
                        product_gbcode,
                        product_inlong,
                        product_color,
                        product_specs,
                        product_color_imgurl
                    ) VALUES 
                    (
                        v_size_id,
                        i_stationed_user_id,
                        i_product_id,
                        v_specs_id,
                        '尺码',
                        v_product_sku.product_size,
                        v_product_sku_name,
                        v_product_sku.product_prize_tag,
                        v_product_sku.product_prize_cost,
                        v_product_sku.product_gbcode,
                        v_product_sku.product_inlong,
                        v_product_sku.product_color,
                        v_product_sku.product_specs,
                        v_product_sku.product_color_imgurl
                    );
            ELSE
                --尺码已经存在，则更新价格以及国标码数据以及内长
                UPDATE TBL_PRODUCT_SKU_APPLY             
                SET 
                PRODUCT_PRIZE_TAG = v_product_sku.product_prize_tag,
                PRODUCT_PRIZE_COST = v_product_sku.product_prize_cost,
                PRODUCT_GBCODE = v_product_sku.product_gbcode,
                PRODUCT_INLONG = v_product_sku.product_inlong,
                PRODUCT_COLOR_IMGURL = v_product_sku.product_color_imgurl
                WHERE id = v_size_id;
            END IF;           
        END LOOP;
    output_status:='1';
    output_msg:='商品SKU新增成功';
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='更新或插入SKU出现未知错误:'||SQLCODE || ':'||SQLERRM||'';
    ROLLBACK;
END INSERT_PRODUCT_SKU_APPLY;
/

