create PROCEDURE           LEAGUE_RECHARGE_FINANCE_AGENT
/**
     业务员代客户进行以下操作
     01、充值，02、充值验款通过、03充值验款驳回
     shif
     20170520
     返回值：成功或失败消息提示信息
  **/
(
  client_operate_type     in varchar2,      --操作类型 01-充值 02-充值验款 03 充值驳回
  client_sale_user_name in varchar2,        --代理业务人员用户名称
  client_xdr_type       in   varchar2,      --下单人用户类型（3：业务员，4：业务经理，5：店长，6：营业员，7：自行下单）
  client_league_user_name in varchar2,      --充值用户名
  client_recharge_number  in number,        --充值金额
  client_recharge_channel in varchar2,      --充值渠道   01-现金 02-pos刷卡 03-现金转账
  client_recharge_remark  in varchar2,      --备注
  client_third_number     in varchar2,      --第三方支付号
  client_voucher_img_url  in varchar2,      --充值凭证图片url
  client_charge_type      in varchar2,      --充值类型：1、正常充值；2、预付充值
  output_status           out varchar2,     --返回的状态码 0-失败 1-成功
  output_msg              out varchar2,      --返回的信息
  output_number           out varchar2      --返回充值单号
 ) is
  v_credit_money                 number:=0;    --数据库中的代理业务员或门店授信额度
  temp_client_sale_real_name     varchar2(50); --代理业务员用户真实名称
  v_credit_money_order number:=0;              --业务员订单已使用-订单
  v_credit_money_wait number:=0;               --业务员待缴款
  v_credit_money_cz number:=0;     --业务员代客户充值，未验款的金额
  v_credit_money_use number:=0;                --业务员总待缴款
  temp_accountants_subject_id    varchar2(50); --会计科目id
  temp_accountants_subject_name  varchar2(50); --会计科目名称
  temp_user_id                   number := 0;  --用户id
  temp_user_manage_name          varchar2(50); --加盟商名称
  temp_record_number             varchar2(50); --收付单号
  temp_remark                    varchar2(500);--摘要
  temp_count                     number := 0;  --临时变量
  temp_turnover_number           varchar2(50); --验款记录关联单号，临时变量
  temp_operate_name              varchar2(30); --临时变量 操作名称
  v_state char(1);                              --业务人员状态[库]
  v_user_type number;                          --业务人员类型[库]
  v_user_id number;                            --业务人员用户id
  v_store_user_type char(1);                   --门店定义用户类型
  v_store_state char(1);                       --门店状态
  v_store_id number :=0;                       --门店id
  v_ywjl_user_name varchar2(50);               --业务经理用户名
  v_ywy_user_name varchar2(50);                --业务员用户名
  v_md_id number:=0;                           --门店id
  v_user_md_id number:=0;                      --用户归属门店id
  temp_user_rel_type  varchar2(50);                      --业务人员类型(中文)
BEGIN
  output_status := '0';
  --1.当为充值时
  output_msg := '充值失败！';
  IF client_operate_type <> '01' THEN
      output_msg := '不支持的操作类型，请检查！';
      RETURN;
  END IF;

  --1.0 增加充值金额的校验处理。
  IF client_recharge_number IS NULL OR client_recharge_number <=0 THEN
      output_msg := '充值金额异常，请检查！';
      RETURN;
  END IF;
  --1.1获取用户信息
  SELECT COUNT(*)
    INTO temp_count
    FROM TBL_USER_INFO
   WHERE USER_NAME = client_league_user_name;
  IF TEMP_COUNT <> 0 THEN
    SELECT USER_MANAGE_NAME, ID,store_id
      INTO temp_user_manage_name, temp_user_id,v_user_md_id
      FROM TBL_USER_INFO
     WHERE USER_NAME = client_league_user_name;
  ELSE
    OUTPUT_MSG := '用户信息不能为空，请检查!';
    RETURN;
  END IF;
  --1.2获取账户信息
  SELECT COUNT(*)
    INTO temp_count
    FROM TBL_BANK_ACCOUNT
   WHERE USER_ID = temp_user_id;
  IF temp_count <= 0 THEN
    output_msg := '用户账户信息不能为空，请检查!';
    RETURN;
  END IF;
    --1.3验证代理业务人员
    IF client_xdr_type='3' OR client_xdr_type='4' THEN  --业务员或业务经理代下单
        --1.31验证业务员信息
        SELECT COUNT(*) INTO temp_count FROM TBL_SYS_USER_INFO WHERE USER_NAME = client_sale_user_name;
        IF temp_count = 1 THEN
            SELECT ID,USER_TYPE,STATE,CREDIT_MONEY,USER_REALNAME
              INTO v_user_id,v_user_type,v_state,v_credit_money,temp_client_sale_real_name
              FROM TBL_SYS_USER_INFO
             WHERE USER_NAME = client_sale_user_name;
            IF v_state = '1' THEN
                output_msg:='当前操作用户已被禁用，无法代客户充值!';
                RETURN;
            ELSE
                IF v_user_type != 3 and v_user_type != 4 THEN
                    output_msg:='当前操作员不是业务员，无法代客户充值!';
                    RETURN;
                END IF;
            END IF;
        ELSE
            output_msg:='业务员或业务经理信息异常!';
            RETURN;
        END IF;
        --1.32验证业务员与客户关系
         IF client_xdr_type = '3' THEN
                SELECT COUNT(1) INTO temp_count FROM TBL_USER_INFO WHERE REFEREE_USER_ID = v_user_id AND USER_NAME = client_league_user_name;
                IF temp_count <= 0 THEN
                    output_msg:='当前业务员与客户关系存疑，无法代客户充值!';
                    RETURN;
                END IF;
         END IF;
          --1.32验证业务经理与客户关系
         IF client_xdr_type = '4' THEN
                SELECT COUNT(1) INTO temp_count FROM TBL_USER_INFO WHERE MARKET_SUPERVISION_USER_ID = v_user_id AND USER_NAME = client_league_user_name;
                IF temp_count <= 0 THEN
                    output_msg:='当前业务经理与客户关系存疑，无法代客户充值!';
                    RETURN;
                END IF;
         END IF;
     ELSIF client_xdr_type='5' OR client_xdr_type='6' THEN  --门店代充值
            --1.31验证业务人员信息
            SELECT COUNT(*) INTO temp_count FROM TBL_SYS_USER_INFO WHERE USER_NAME = client_sale_user_name;
            IF TEMP_COUNT = 1 THEN
                SELECT ID,USER_TYPE,STATE,USER_REALNAME
                  INTO v_user_id,v_user_type,v_state,temp_client_sale_real_name
                  FROM TBL_SYS_USER_INFO WHERE USER_NAME = client_sale_user_name;
                IF v_state = '1' THEN
                    output_msg:='当前操作用户已被禁用，无法代客户充值!';
                    RETURN;
                ELSE
                    IF v_user_type != 5 and v_user_type != 6 THEN
                        output_msg:='当前操作员不是店长或营业员，无法代客户充值!';
                        RETURN;
                    END IF;
                END IF;
            ELSE
                output_msg:='店长或营业员信息异常!';
                RETURN;
            END IF;
            --1.33验证门店与用户关系
            SELECT count(1) into temp_count
              FROM TBL_STORE_INFO C
             WHERE C.ID = v_user_md_id
                   AND C.SHOPKEEPER_USER_ID = v_user_id
                   OR EXISTS(SELECT 1 FROM TBL_STORE_USER_REL A WHERE A.STORE_ID = C.ID AND A.USER_ID = v_user_id AND A.TYPE = '6');
            IF temp_count = 1 THEN
                SELECT CASE WHEN C.SHOPKEEPER_USER_ID = v_user_id THEN '5' ELSE '6' END AS TYPE,C.STATE,C.ID,C.STORE_LIMIT
                  into v_store_user_type,v_store_state,v_store_id,v_credit_money
                  FROM TBL_STORE_INFO C
                 WHERE c.id = v_user_md_id
                       AND C.SHOPKEEPER_USER_ID = v_user_id
                       OR EXISTS(SELECT 1 FROM TBL_STORE_USER_REL A WHERE A.STORE_ID = C.ID AND A.USER_ID = v_user_id AND A.TYPE = '6');
                IF v_store_state ='1' THEN
                    output_msg:='当前门店已停运不能代客户充值!';
                    RETURN;
                END IF;
                IF v_store_user_type <> v_user_type THEN
                    output_msg:='用户类型存疑，不能代客户充值!';
                    RETURN;
                END IF;
                IF v_state = '1' THEN
                    output_msg:='当前用户已禁用，不能继续操作!';
                    RETURN;
                END IF;
            ELSE
                output_msg:='门店信息异常!';
                RETURN;
            END IF;
            SELECT COUNT(1) INTO temp_count FROM TBL_USER_INFO WHERE STORE_ID = v_store_id AND USER_NAME = client_league_user_name;
            IF temp_count <=0 THEN
                output_msg:='当前用户不属于该门店，无法代客户充值!';
                RETURN;
            END IF;
     ELSE
         output_msg:='业务员用户类型不存在!';
         RETURN;
     END IF;

     ---1.4获取当前充值操作业务人员相关信息
     SELECT (SELECT TSUI.USER_NAME FROM TBL_SYS_USER_INFO TSUI WHERE TSUI.ID = TUI.REFEREE_USER_ID) AS REFEREE_USER_NAME,
            (SELECT TSUI.USER_NAME FROM TBL_SYS_USER_INFO TSUI WHERE TSUI.ID = TUI.MARKET_SUPERVISION_USER_ID) AS MARKET_SUPERVISION_USER_NAME,TUI.STORE_ID
       INTO v_ywy_user_name,v_ywjl_user_name,v_md_id
       FROM TBL_USER_INFO TUI
      WHERE TUI.USER_NAME = client_league_user_name;
     ---1.5获取当前操作业务人员相关授信剩余额度
     IF client_xdr_type='3' OR client_xdr_type='4' THEN
       ---0查询业务代客户现金充值待审核使用额度
       SELECT NVL(SUM(MONEY),0) INTO v_credit_money_cz FROM TBL_USER_CHARGE_RECORD TUCR WHERE TUCR.STATE = '1' AND TUCR.AGENCY_USER_ID = v_user_id;
       ---1查询业务员订单现金支付待审核使用额度
       SELECT NVL(SUM(LOGISTICS_MONEY+PRODUCT_MONEY+DF_MONEY),0) INTO v_credit_money_order FROM TBL_ORDER_INFO WHERE PAYMENT_STATE = 3 AND SALE_USER_NAME = client_sale_user_name;
       ---2查询业务员待缴款额度
       SELECT NVL(SUM(CONTRIBUTION_MONEY),0) INTO v_credit_money_wait from TBL_CONTRIBUTION_WAIT WHERE STATE <> 3 AND SALE_USER_NAME = client_sale_user_name;
       ---3查询业务员总待缴款金额
       v_credit_money_use := v_credit_money_cz + v_credit_money_order + v_credit_money_wait;
       ---4计算业务员可用额度
       v_credit_money := v_credit_money - v_credit_money_use;
     END IF;
     ---1.6获取当前操作业务人员相关授信剩余额度
     IF CLIENT_XDR_TYPE='5' OR CLIENT_XDR_TYPE='6' THEN
        ---0查询业务代客户现金充值待审核使用额度
        SELECT NVL(SUM(MONEY),0) INTO v_credit_money_cz FROM TBL_USER_CHARGE_RECORD WHERE STATE = '1' AND (AGENCY_USER_TYPE='5' or AGENCY_USER_TYPE='6') AND MD_ID = v_store_id;
        ---1查询门店订单现金支付待审核使用额度
        SELECT NVL(SUM(LOGISTICS_MONEY+PRODUCT_MONEY+DF_MONEY),0) INTO v_credit_money_order FROM TBL_ORDER_INFO WHERE PAYMENT_STATE = 3 AND (XDR_USER_TYPE='5' or XDR_USER_TYPE='6') AND SALE_MD_ID = v_store_id;
        ---2查询门店待缴款额度
        SELECT NVL(SUM(CONTRIBUTION_MONEY),0) INTO v_credit_money_wait FROM TBL_CONTRIBUTION_WAIT WHERE STATE <> 3 AND (XDR_USER_TYPE='5' or XDR_USER_TYPE='6') AND MD_ID = v_store_id;
        ---3查询门店总待缴款金额
        v_credit_money_use:=v_credit_money_cz+v_credit_money_order+v_credit_money_wait;
        ---4计算门店可用额度
        v_credit_money := v_credit_money - v_credit_money_use;
     END IF;
    --1.7计算业务员的授信额度是否大于充值金额
    IF v_credit_money >= client_recharge_number THEN
        --产生订单号记录
        temp_record_number          := GETAUTONUMBER('CZ');
        temp_turnover_number        := GETAUTONUMBER('CZ');
        temp_accountants_subject_id := '1001CZ';
        temp_operate_name           := '充值';
        temp_accountants_subject_name:='童库';
        
         IF client_xdr_type = '3' THEN
                temp_user_rel_type:='业务员';
         elsif client_xdr_type = '4' then 
                temp_user_rel_type:='业务经理';
         END IF;
        --创建现金充值记录
        TEMP_REMARK := temp_user_rel_type||temp_client_sale_real_name||'代充值:' || to_char(client_recharge_number,'fm999999990.00')||'元，支付方式：'||client_recharge_channel;
        IF client_charge_type = 2 THEN
            TEMP_REMARK := CASE WHEN
             client_recharge_remark IS  NULL
             THEN temp_user_rel_type||temp_client_sale_real_name||'代客户('||temp_user_manage_name||')预付充值:' || to_char(client_recharge_number,'fm999999990.00')||'元，充值方式：'||client_recharge_channel
             ELSE temp_user_rel_type||temp_client_sale_real_name||'代客户('||temp_user_manage_name||')预付充值:' || to_char(client_recharge_number,'fm999999990.00')||'元，充值方式：'||client_recharge_channel||',备注：'||client_recharge_remark
             END;
        ELSE
            TEMP_REMARK := CASE WHEN
             client_recharge_remark IS  NULL
             THEN temp_user_rel_type||temp_client_sale_real_name||'代客户('||temp_user_manage_name||')充值:' || to_char(client_recharge_number,'fm999999990.00')||'元，充值方式：'||client_recharge_channel
             ELSE temp_user_rel_type||temp_client_sale_real_name||'代客户('||temp_user_manage_name||')充值:' || to_char(client_recharge_number,'fm999999990.00')||'元，充值方式：'||client_recharge_channel||',备注：'||client_recharge_remark
             END;
        END IF;
        --用户充值记录
        INSERT INTO TBL_USER_CHARGE_RECORD
          (ID, RECORD_NUMBER, RECORD_ITEM_NUMBER, RECORD_CHANNEL, REMARK, CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME, ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
           PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME, MONEY, STATE,TURNOVER_NUMBER,THIRD_NUMBER,VOUCHER_IMG_URL,
           YWJL_USER_NAME,YWY_USER_NAME,MD_ID,AGENCY_USER_ID,AGENCY_USER_TYPE,CHARGE_TYPE)
        VALUES
          (SEQ_USER_ACCOUNT_RECORD.NEXTVAL,temp_record_number, '1', client_recharge_channel,temp_remark, SYSDATE, client_league_user_name, temp_user_manage_name, temp_accountants_subject_id, temp_accountants_subject_name,
           '1001','现金', client_recharge_number,'1',temp_turnover_number, client_third_number,client_voucher_img_url,
           v_ywjl_user_name,v_ywy_user_name,v_md_id,v_user_id,client_xdr_type,client_charge_type);
        output_msg:='充值支付成功，请耐心等待验款审核！';
        output_status := '1';
        output_number := temp_record_number;
        COMMIT;
        RETURN;
    ELSE
        output_msg:='授信余额不足，无法完成充值！余额【'||to_char(v_credit_money,'fm999999990.00')||'】';
        RETURN;
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    output_msg := '充值或还款操作出现未知错误!';
    ROLLBACK;
    RETURN;
END league_recharge_finance_agent;
/

