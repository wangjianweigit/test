create FUNCTION           getProductSpec_SalePrice
/**
    （新版）通过用户名获取商品规格的销售价格   （精确价格）
    wangpeng
    2017-07-13
    返回值：规格价格
**/
(
    c_user_name   varchar2,   --用户名
    c_spec_id   varchar2      --商品规格ID    
) return varchar2
 is
    v_prize number:=0;
    v_product_prize_str varchar2(50):='0.00';   --需要返回的商品规格价格
BEGIN

        --通过sku获取价格

        select getSku_User_SalePrice(c_user_name,min(id)) into v_prize from tbl_product_sku where parent_id = c_spec_id and product_group ='尺码';

        v_product_prize_str := to_char(nvl(v_prize,0),'fm999999990.00');

   return v_product_prize_str;
   
END getProductSpec_SalePrice;
/

