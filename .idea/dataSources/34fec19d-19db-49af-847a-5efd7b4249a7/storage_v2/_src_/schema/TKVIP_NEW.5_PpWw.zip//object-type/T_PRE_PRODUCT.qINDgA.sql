create TYPE "T_PRE_PRODUCT"                                                                          as object(
product_itemnumber varchar2(100 byte),
product_color varchar2(50 byte),
product_specs varchar2(50 byte)
)
/

