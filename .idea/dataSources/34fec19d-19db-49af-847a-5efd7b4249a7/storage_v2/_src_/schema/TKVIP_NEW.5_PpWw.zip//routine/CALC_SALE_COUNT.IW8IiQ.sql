create PROCEDURE           CALC_SALE_COUNT
/**
     计算商品销量固话
     定时执行，每10分钟执行一次   新版，只统计已支付订单数据
     wangpeng
     2018-11-28
  **/
IS
    D_LAST_UPDATE DATE;--最后一次固化时间
BEGIN

   --查询最后一次固化时间
   select update_date into D_LAST_UPDATE from TBL_PRODUCT_SALE where rownum <2;

   ------------统计实时销量-公式：已支付固化数据+固化时间后支付---begin--------------------
   MERGE INTO TBL_PRODUCT_INFO P
        USING (  
            SELECT 
                (     
                    (
                        SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                        WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER AND PI.ITEMNUMBER = OP.ITEMNUMBER(+)
                        AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                        AND  OI.PAYMENT_STATE = 2 and OI.PAYMENT_DATE >= trunc(D_LAST_UPDATE)
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                        WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE = 1
                        AND POI.PAYMENT_STATE = '2' and POI.PAYMENT_DATE >= trunc(D_LAST_UPDATE)
                    )
                 +  (
                        SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                        FROM TBL_PRE_ORDER_DETAIL POD,TBL_PRE_ORDER_INFO POI,TBL_CUSTOM_PRODUCT_REL CPR
                        WHERE POI.ORDER_NUMBER = POD.ORDER_NUMBER and POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE  and PI.ITEMNUMBER = CPR.ORIGINAL_PRODUCT_ITEMNUMBER(+)
                        AND POI.PRE_ORDER_TYPE IN (2,3) 
                        AND POI.PAYMENT_STATE = '2' and POI.PAYMENT_DATE >= trunc(D_LAST_UPDATE)
                    )
                ) SALE_COUNT_TODAY,
             PI.SALE_ALL,
             PI.SALE_7,
             PI.SALE_15,
             PI.SALE_30,
             PI.SALE_90,
             PI.ITEMNUMBER
            FROM TBL_PRODUCT_SALE PI
        ) NP  
        ON (P.ITEMNUMBER = NP.ITEMNUMBER)
   WHEN MATCHED THEN
      UPDATE SET 
            P.PRODUCT_COUNT = NP.SALE_ALL + NVL(NP.SALE_COUNT_TODAY,0),
            P.PRODUCT_COUNT7 = NP.SALE_7 + NVL(NP.SALE_COUNT_TODAY,0),
            P.PRODUCT_COUNT15 = NP.SALE_15 + NVL(NP.SALE_COUNT_TODAY,0),
            P.PRODUCT_COUNT30 = NP.SALE_30 + NVL(NP.SALE_COUNT_TODAY,0),
            P.PRODUCT_COUNT90 = NP.SALE_90 + NVL(NP.SALE_COUNT_TODAY,0)
      WHERE P.ITEMNUMBER = NP.ITEMNUMBER 
      ;
  ------------统计实时销量-公式：已支付固化数据+固化时间后支付---begin--------------------
  COMMIT;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
END CALC_SALE_COUNT;
/

