create TYPE           T_NEW_ORDER_PRODUCT_SKU                                                                           
FORCE  as object
(
    sku_id number,            --订单商品sku
    count number,          --订单商品数量
    unit_price number          --商品sku单价
);
/

