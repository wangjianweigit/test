create FUNCTION           getProduct_OldHdPrice_Qj
/**
    （新版）获取商品折扣价            价格区间
    wangpeng
    2017-06-06
    2018-12-25   update  for wangpeng  支持新老商品不同费率计算
    2019-09-05   update  for wangpeng  支持新老商品不同费率计算 针对2019-09-15新费率调整
    返回值：格式化后的商品折扣应售原价
**/
(
    c_product_itemnumber   varchar2,--商品货号
    c_hd_discount          number,   --活动优惠
    c_hdhy_discount        number    --活动会员折扣 
) return varchar2
 is
    v_product_prize_str varchar2(50):='0.00-0.00';      --需要返回的商品价格区间
    v_min_prize_hd number:=0;                           --商品最小活动价
    v_max_prize_hd number:=0;                           --商品最大活动价
    v_min_prize_cost number:=0;                         --商品最小报价
    v_max_prize_cost number:=0;                         --商品最大报价
    v_product_sale_prize_min number:=0;                 --应售价-最小价
    v_product_sale_prize_max number:=0;                 --应售价-最大价
 
    v_member_service_rate number:=0;                    --会员服务费比例-汇总
    v_member_service_rate_rzs number:=0;                --会员服务费比例-入驻商
    v_member_service_rate_qj number:=0;                 --会员服务费比例-全局
    v_member_service_money_rzs_min number:=0;           --会员服务费-入驻商-最低
    v_member_service_money_qj_min number:=0;            --会员服务费-全局-最低
    v_member_service_money_rzs_max number:=0;           --会员服务费-入驻商-最高
    v_member_service_money_qj_max number:=0;            --会员服务费-全局-最高
    v_product_create_date date;                                             --商品创建时间                          --界线新加配置
    v_sys_line date:=to_date('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置
    v_sys_line2 date:=to_date('2019-09-15 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置  针对2019-09-15新费率调整
    
BEGIN

    /*************************商品新老计费费率控制*********begin**********************/
    select a.create_date into v_product_create_date from tbl_product_info a where a.ITEMNUMBER=c_product_itemnumber;
    if v_product_create_date < v_sys_line then
        --查询入驻商会员服务费比例-老费率
        select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RATE where STATIONED_USER_ID = (
            select STATIONED_USER_ID from tbl_product_info where ITEMNUMBER=c_product_itemnumber
        );
    end if;
    /*************************商品新老计费费率控制*********end**********************/
        
   --查询全局会员服务费比例
   --select member_service_rate into v_member_service_rate_qj from TBL_SYS_CONFIG where id = 1;
 
    if v_product_create_date >= v_sys_line then
       --查询入驻商会员服务费比例-按当前费率计算
        select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_USER_INFO where id = (
            select STATIONED_USER_ID from tbl_product_info where ITEMNUMBER=c_product_itemnumber
        );
    end if;
    
    /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
    if v_sys_line2 > v_product_create_date and v_product_create_date >= v_sys_line then
        --查询入驻商会员服务费比例-老费率2次调整
        select nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RAT2 where STATIONED_USER_ID = (
            select STATIONED_USER_ID from tbl_product_info where ITEMNUMBER=c_product_itemnumber
        );
    end if;
    /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
    
    --会员服务费比例汇总 = 入驻商会员服务费比例 + 全局会员服务费比例
    v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;

    --查询报价区间
    select nvl(min(f.product_prize_cost),0),nvl(max(f.product_prize_cost),0) into v_min_prize_cost,v_max_prize_cost from tbl_product_sku f where f.product_group='尺码' and f.state='上架' and f.product_itemnumber = c_product_itemnumber;
   
    --应售价-最低
    v_product_sale_prize_min:=v_min_prize_cost/(1-v_member_service_rate);
    --应售价-最高
    v_product_sale_prize_max:=v_max_prize_cost/(1-v_member_service_rate);
   
    --计算入驻商会员服务费-最低 = 应销售价*入驻商会员服务费比例
    v_member_service_money_rzs_min := v_product_sale_prize_min * v_member_service_rate_rzs;
    --计算全局会员服务费-最低 = 应销售价*全局会员服务费比例
    v_member_service_money_qj_min := v_product_sale_prize_min * v_member_service_rate_qj;
    
    --计算入驻商会员服务费-最高 = 应销售价*入驻商会员服务费比例
    v_member_service_money_rzs_max := v_product_sale_prize_max * v_member_service_rate_rzs;
    --计算全局会员服务费-最高 = 应销售价*全局会员服务费比例
    v_member_service_money_qj_max := v_product_sale_prize_max * v_member_service_rate_qj;
    
    
   
   --按照活动计算,当活动折扣小于活动会员折扣时，使用活动折扣计算
    if c_hd_discount < c_hdhy_discount then
        --使用会员折扣计算  报价*活动折扣 + 入驻商会员服务费*活动折扣 + 全局会员服务费*活动折扣
        v_min_prize_hd := (v_min_prize_cost*c_hd_discount) + (v_member_service_money_rzs_min*c_hd_discount) + (v_member_service_money_qj_min*c_hd_discount);
        v_max_prize_hd := (v_max_prize_cost*c_hd_discount) + (v_member_service_money_rzs_max*c_hd_discount) + (v_member_service_money_qj_max*c_hd_discount);
    else
        --使用会员折扣计算  报价*活动折扣 + 入驻商会员服务费*活动折扣 + 全局会员服务费*活动会员服务费折扣
        v_min_prize_hd := (v_min_prize_cost*c_hd_discount) + (v_member_service_money_rzs_min*c_hd_discount) + (v_member_service_money_qj_min*c_hdhy_discount);
        v_max_prize_hd := (v_max_prize_cost*c_hd_discount) + (v_member_service_money_rzs_max*c_hd_discount) + (v_member_service_money_qj_max*c_hdhy_discount);
    end if;
   
   
   
     if ceil(v_min_prize_hd)-v_min_prize_hd<0.5 then
      v_min_prize_hd := ceil(v_min_prize_hd);
   elsif ceil(v_min_prize_hd)-v_min_prize_hd=0 then
      v_min_prize_hd := v_min_prize_hd;
   else 
      v_min_prize_hd := ceil(v_min_prize_hd)-0.5;
   end if;
   
     if ceil(v_max_prize_hd)-v_max_prize_hd<0.5 then
      v_max_prize_hd := ceil(v_max_prize_hd);
   elsif ceil(v_max_prize_hd)-v_max_prize_hd=0 then
      v_max_prize_hd := v_max_prize_hd;
   else 
      v_max_prize_hd := ceil(v_max_prize_hd)-0.5;
   end if;
   
   v_product_prize_str:=to_char(v_min_prize_hd,'fm999999990.00')||'-'||to_char(v_max_prize_hd,'fm999999990.00');
   
   return v_product_prize_str;
   
END getProduct_OldHdPrice_Qj;
/

