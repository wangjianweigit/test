create PROCEDURE           AUTO_MRBCARD_EXPIRE
/**
     没间隔一段时间检测一次所有的会员卡是否过期，过期则将余额设置为0，并记录会员卡日志
     songwangwen
     2018-07-18
  **/
IS
   c_user_type                VARCHAR2(50):='7';   --表示是平台用户获取会员卡额度校验码的key值
   v_user_name                VARCHAR2(50);        --平台会员user_name
   v_user_key                 VARCHAR2 (32);       --用户KEY
   v_create_code              VARCHAR2 (32);       --通过当前余额计算得到的校验码，用于校验余额是否被篡改
   v_card_balance_checkcode   VARCHAR2 (50);       --临时变量，会员卡余额校验码
   v_card_balance             NUMBER;              --临时变量，会员卡余额
BEGIN
   BEGIN
      FOR tb IN ( /***
                  查询已过期的会员卡记录
                  ***/
                 SELECT *
                   FROM TBL_USER_MBR_CARD
                  WHERE CARD_BALANCE > 0 AND EXPIRATION_DATE <= SYSDATE)
      LOOP
         v_user_name := to_char(tb.user_id);
         -------------------------------------验证余额是否被篡改-start--------------------------------------------------
         --获取用户KEY
         SELECT getUserKey (v_user_name, 'old', c_user_type) INTO v_user_key FROM DUAL;
         --查询得到数据库中当前的校验码
         SELECT card_balance_checkcode,card_balance INTO v_card_balance_checkcode,v_card_balance FROM TBL_USER_MBR_CARD WHERE user_id = tb.user_id;
         --获取余额校验码并判断是否被篡改
         v_create_code := getCheck_Code (v_user_name, v_card_balance, v_user_key);

         IF  v_card_balance_checkcode IS NULL OR v_card_balance_checkcode <> v_create_code
         THEN
            RETURN;
         END IF;

        --创建新的账户KEY
        select getUserKey(v_user_name,'new',c_user_type) into v_user_key from dual;
        --产生新的余额校验码（过期会员卡，余额直接修改为0）
        select getcheck_code(v_user_name,0,v_user_key) into v_card_balance_checkcode from dual;
        ---更新会员卡余额,校验码
        UPDATE TBL_USER_MBR_CARD
           SET card_balance = 0,
               card_balance_checkcode = v_card_balance_checkcode,
               update_date = SYSDATE
         WHERE user_id = tb.user_id;
         --更新用户账户KEY
         update TBL_USER_MBR_CARD_CACHE_KEY set cache_key = v_user_key,create_time=sysdate where user_name = v_user_name;
        --记录会员卡收支记录信息
        /***1、记录会员卡使用日志*****/
            INSERT INTO TBL_USER_MBR_CARD_USE_RECORD (id,
                                                      mbr_card_id,
                                                      order_number,
                                                      TYPE,
                                                      used_amount,
                                                      remark,
                                                      create_date)
               SELECT SEQ_USER_MBR_CARD_USE_RECORD.NEXTVAL,
                      umc.id,
                      '',
                      6,
                      v_card_balance,
                      '会员卡过期，余额自动清零' REMARK,
                      umc.expiration_date
                 FROM TBL_USER_MBR_CARD umc
                WHERE umc.user_id = tb.user_id;        
            /****提交数据***/
            COMMIT;
      END LOOP;
   END;
EXCEPTION
   /* Formatted on 2018/07/25 10:10:51 (QP5 v5.227.12220.39754) */
WHEN OTHERS THEN
    ROLLBACK;
END AUTO_MRBCARD_EXPIRE;


/**********JOB，自动清除已过期的会员卡额度JOB*************/
/

