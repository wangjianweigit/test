create PROCEDURE           CALC_SALE_COUNT_bak1128
/**
     计算商品销量固话
     此存储过程 供定时任务调用   老版备份，已停用
     wangpeng
     2017-10-09

     郑晖  2018-10-12  定制订单的销量也计入原有的货号销量中
  **/
IS
   OUTPUT_STATUS   VARCHAR2 (50);                       --返回的状态码 0-取消失败 1-取消成功
   OUTPUT_MSG      VARCHAR2 (300);                                     --返回的信息
BEGIN
   MERGE INTO TBL_PRODUCT_INFO P
        USING (  
            SELECT (SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                         WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER
                               AND (   OI.ORDER_STATE = 1
                                    OR OI.ORDER_STATE = 2
                                    OR OI.ORDER_STATE = 3
                                    OR OI.ORDER_STATE = 5)
                               AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                               AND PI.ITEMNUMBER = OP.ITEMNUMBER(+))
                     + (SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                         WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER
                               AND (   POI.ORDER_STATE = 1
                                    OR POI.ORDER_STATE = 2
                                    OR POI.ORDER_STATE = 3
                                    OR POI.ORDER_STATE = 5)
                               AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+))
                     + (SELECT NVL (SUM (TEMP.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM (
                            SELECT 
                                SUM(POD.PRODUCT_COUNT) AS PRODUCT_COUNT,
                                CPR.ORIGINAL_PRODUCT_ITEMNUMBER AS PRODUCT_ITEMNUMBER
                            FROM TBL_PRE_ORDER_DETAIL POD
                            LEFT JOIN TBL_PRE_ORDER_INFO POI ON POI.ORDER_NUMBER = POD.ORDER_NUMBER
                            LEFT JOIN TBL_CUSTOM_PRODUCT_REL CPR ON POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE
                            WHERE POI.ORDER_STATE IN (1,2,3,5) AND POI.PRE_ORDER_TYPE IN (2,3)
                            GROUP BY CPR.ORIGINAL_PRODUCT_ITEMNUMBER
                          ) TEMP WHERE PI.ITEMNUMBER = TEMP.PRODUCT_ITEMNUMBER(+))
                        SALE_COUNT,
                     PI.ITEMNUMBER
                FROM TBL_PRODUCT_INFO PI
            GROUP BY PI.ITEMNUMBER
        ) NP
           ON (P.ITEMNUMBER = NP.ITEMNUMBER)
   WHEN MATCHED
   THEN
      UPDATE SET P.PRODUCT_COUNT = NVL (NP.SALE_COUNT, 0)
              WHERE P.ITEMNUMBER = NP.ITEMNUMBER
                    AND P.PRODUCT_TYPE = 0;

   COMMIT;
  
   -----------------7天销量统计
   MERGE INTO TBL_PRODUCT_INFO P
        USING (  
            SELECT (SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                         WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER
                               AND OI.CREATE_DATE >= SYSDATE - 7
                               AND (   OI.ORDER_STATE = 1
                                    OR OI.ORDER_STATE = 2
                                    OR OI.ORDER_STATE = 3
                                    OR OI.ORDER_STATE = 5)
                               AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                               AND PI.ITEMNUMBER = OP.ITEMNUMBER(+))
                     + (SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                         WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER
                               AND POI.CREATE_DATE >= SYSDATE - 7
                               AND (   POI.ORDER_STATE = 1
                                    OR POI.ORDER_STATE = 2
                                    OR POI.ORDER_STATE = 3
                                    OR POI.ORDER_STATE = 5)
                               AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+))
                     + (SELECT NVL (SUM (TEMP.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM (
                            SELECT 
                                SUM(POD.PRODUCT_COUNT) AS PRODUCT_COUNT,
                                CPR.ORIGINAL_PRODUCT_ITEMNUMBER AS PRODUCT_ITEMNUMBER
                            FROM TBL_PRE_ORDER_DETAIL POD
                            LEFT JOIN TBL_PRE_ORDER_INFO POI ON POI.ORDER_NUMBER = POD.ORDER_NUMBER
                            LEFT JOIN TBL_CUSTOM_PRODUCT_REL CPR ON POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE
                            WHERE POI.ORDER_STATE IN (1,2,3,5) AND POI.PRE_ORDER_TYPE IN (2,3) AND POI.CREATE_DATE >= SYSDATE - 7
                            GROUP BY CPR.ORIGINAL_PRODUCT_ITEMNUMBER
                          ) TEMP WHERE PI.ITEMNUMBER = TEMP.PRODUCT_ITEMNUMBER(+))
                        SALE_COUNT_MONTH,
                     PI.ITEMNUMBER
                FROM TBL_PRODUCT_INFO PI
            GROUP BY PI.ITEMNUMBER) NP
           ON (P.ITEMNUMBER = NP.ITEMNUMBER)
   WHEN MATCHED
   THEN
      UPDATE SET P.PRODUCT_COUNT7 = NVL (NP.SALE_COUNT_MONTH, 0)
              WHERE P.ITEMNUMBER = NP.ITEMNUMBER
                    AND P.PRODUCT_TYPE = 0;
   COMMIT;
   
   -----------------15天销量统计
   MERGE INTO TBL_PRODUCT_INFO P
        USING (  
            SELECT (SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                         WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER
                               AND OI.CREATE_DATE >= SYSDATE - 15
                               AND (   OI.ORDER_STATE = 1
                                    OR OI.ORDER_STATE = 2
                                    OR OI.ORDER_STATE = 3
                                    OR OI.ORDER_STATE = 5)
                               AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                               AND PI.ITEMNUMBER = OP.ITEMNUMBER(+))
                     + (SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                         WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER
                               AND POI.CREATE_DATE >= SYSDATE - 15
                               AND (   POI.ORDER_STATE = 1
                                    OR POI.ORDER_STATE = 2
                                    OR POI.ORDER_STATE = 3
                                    OR POI.ORDER_STATE = 5)
                               AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+))
                     + (SELECT NVL (SUM (TEMP.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM (
                            SELECT 
                                SUM(POD.PRODUCT_COUNT) AS PRODUCT_COUNT,
                                CPR.ORIGINAL_PRODUCT_ITEMNUMBER AS PRODUCT_ITEMNUMBER
                            FROM TBL_PRE_ORDER_DETAIL POD
                            LEFT JOIN TBL_PRE_ORDER_INFO POI ON POI.ORDER_NUMBER = POD.ORDER_NUMBER
                            LEFT JOIN TBL_CUSTOM_PRODUCT_REL CPR ON POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE
                            WHERE POI.ORDER_STATE IN (1,2,3,5) AND POI.PRE_ORDER_TYPE IN (2,3) AND POI.CREATE_DATE >= SYSDATE - 15
                            GROUP BY CPR.ORIGINAL_PRODUCT_ITEMNUMBER
                          ) TEMP WHERE PI.ITEMNUMBER = TEMP.PRODUCT_ITEMNUMBER(+))
                        SALE_COUNT_MONTH,
                     PI.ITEMNUMBER
                FROM TBL_PRODUCT_INFO PI
            GROUP BY PI.ITEMNUMBER) NP
           ON (P.ITEMNUMBER = NP.ITEMNUMBER)
   WHEN MATCHED
   THEN
      UPDATE SET P.PRODUCT_COUNT15 = NVL (NP.SALE_COUNT_MONTH, 0)
              WHERE P.ITEMNUMBER = NP.ITEMNUMBER
                    AND P.PRODUCT_TYPE = 0;
   COMMIT;
   
   -----------------30天销量统计
   MERGE INTO TBL_PRODUCT_INFO P
        USING (  
            SELECT (SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                         WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER
                               AND OI.CREATE_DATE >= SYSDATE - 30
                               AND (   OI.ORDER_STATE = 1
                                    OR OI.ORDER_STATE = 2
                                    OR OI.ORDER_STATE = 3
                                    OR OI.ORDER_STATE = 5)
                               AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                               AND PI.ITEMNUMBER = OP.ITEMNUMBER(+))
                     + (SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                         WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER
                               AND POI.CREATE_DATE >= SYSDATE - 30
                               AND (   POI.ORDER_STATE = 1
                                    OR POI.ORDER_STATE = 2
                                    OR POI.ORDER_STATE = 3
                                    OR POI.ORDER_STATE = 5)
                               AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+))
                     + (SELECT NVL (SUM (TEMP.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM (
                            SELECT 
                                SUM(POD.PRODUCT_COUNT) AS PRODUCT_COUNT,
                                CPR.ORIGINAL_PRODUCT_ITEMNUMBER AS PRODUCT_ITEMNUMBER
                            FROM TBL_PRE_ORDER_DETAIL POD
                            LEFT JOIN TBL_PRE_ORDER_INFO POI ON POI.ORDER_NUMBER = POD.ORDER_NUMBER
                            LEFT JOIN TBL_CUSTOM_PRODUCT_REL CPR ON POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE
                            WHERE POI.ORDER_STATE IN (1,2,3,5) AND POI.PRE_ORDER_TYPE IN (2,3) AND POI.CREATE_DATE >= SYSDATE - 30
                            GROUP BY CPR.ORIGINAL_PRODUCT_ITEMNUMBER
                          ) TEMP WHERE PI.ITEMNUMBER = TEMP.PRODUCT_ITEMNUMBER(+))
                        SALE_COUNT_MONTH,
                     PI.ITEMNUMBER
                FROM TBL_PRODUCT_INFO PI
            GROUP BY PI.ITEMNUMBER) NP
           ON (P.ITEMNUMBER = NP.ITEMNUMBER)
   WHEN MATCHED
   THEN
      UPDATE SET P.PRODUCT_COUNT30 = NVL (NP.SALE_COUNT_MONTH, 0)
              WHERE P.ITEMNUMBER = NP.ITEMNUMBER
                    AND P.PRODUCT_TYPE = 0;
   COMMIT;
   
   -----------------90天销量统计
   MERGE INTO TBL_PRODUCT_INFO P
        USING (  
            SELECT (SELECT NVL (SUM (OP.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM TBL_ORDER_INFO OI, TBL_ORDER_PRODUCT OP
                         WHERE     OP.ORDER_NUMBER = OI.ORDER_NUMBER
                               AND OI.CREATE_DATE >= SYSDATE - 90
                               AND (   OI.ORDER_STATE = 1
                                    OR OI.ORDER_STATE = 2
                                    OR OI.ORDER_STATE = 3
                                    OR OI.ORDER_STATE = 5)
                               AND NOT EXISTS(SELECT 1 FROM TBL_PRE_ORDER_RELATE TPOR WHERE OI.ORDER_NUMBER = TPOR.ORDER_NUMBER)     
                               AND PI.ITEMNUMBER = OP.ITEMNUMBER(+))
                     + (SELECT NVL (SUM (POD.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM TBL_PRE_ORDER_INFO POI, TBL_PRE_ORDER_DETAIL POD
                         WHERE     POI.ORDER_NUMBER = POD.ORDER_NUMBER
                               AND POI.CREATE_DATE >= SYSDATE - 90
                               AND (   POI.ORDER_STATE = 1
                                    OR POI.ORDER_STATE = 2
                                    OR POI.ORDER_STATE = 3
                                    OR POI.ORDER_STATE = 5)
                               AND PI.ITEMNUMBER = POD.PRODUCT_ITEMNUMBER(+))
                     + (SELECT NVL (SUM (TEMP.PRODUCT_COUNT), 0) SALE_COUNT
                          FROM (
                            SELECT 
                                SUM(POD.PRODUCT_COUNT) AS PRODUCT_COUNT,
                                CPR.ORIGINAL_PRODUCT_ITEMNUMBER AS PRODUCT_ITEMNUMBER
                            FROM TBL_PRE_ORDER_DETAIL POD
                            LEFT JOIN TBL_PRE_ORDER_INFO POI ON POI.ORDER_NUMBER = POD.ORDER_NUMBER
                            LEFT JOIN TBL_CUSTOM_PRODUCT_REL CPR ON POD.PRODUCT_ITEMNUMBER = CPR.CUSTOM_PRODUCT_ITEMNUMBER AND POI.PRE_ORDER_TYPE = CPR.PRE_ORDER_TYPE
                            WHERE POI.ORDER_STATE IN (1,2,3,5) AND POI.PRE_ORDER_TYPE IN (2,3) AND POI.CREATE_DATE >= SYSDATE - 90
                            GROUP BY CPR.ORIGINAL_PRODUCT_ITEMNUMBER
                          ) TEMP WHERE PI.ITEMNUMBER = TEMP.PRODUCT_ITEMNUMBER(+))
                        SALE_COUNT_MONTH,
                     PI.ITEMNUMBER
                FROM TBL_PRODUCT_INFO PI
            GROUP BY PI.ITEMNUMBER) NP
           ON (P.ITEMNUMBER = NP.ITEMNUMBER)
   WHEN MATCHED
   THEN
      UPDATE SET P.PRODUCT_COUNT90 = NVL (NP.SALE_COUNT_MONTH, 0)
              WHERE P.ITEMNUMBER = NP.ITEMNUMBER
                    AND P.PRODUCT_TYPE = 0;
   COMMIT;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
END CALC_SALE_COUNT_bak1128;
/

