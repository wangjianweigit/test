create function           getproductsku_stocks
/**
    修改 reid 2019.04.30
    return  商品sku在在某个仓库的（逻辑）库存量
**/
(
   c_product_sku     number,                                      --商品sku
   c_warehouse_id    number,                                      --仓库
   c_user_name       varchar2                                     --用户user_name
)
   return number
is
   v_product_sku_stock        number := 0;--需要返回的商品sku库存数据
   v_count                    number := 0;--临时变量
   v_book_count               number := 0;--预售数量(当前可卖的数量。订单下单或取消订单或未发退款会进行扣减或加)
   v_total_count              number := 0;--仓库实际库存数量
   v_order_occupy_count       number := 0;--订单占用量
   v_pre_order_occupy_count   number := 0;--预付订单预占用量
   v_locked_stock_amount      number := 0;--活动量
   v_activity_sell_amount     number := 0;--活动已售量
   v_site_id                  number := 0;--会员所在的站点id
   v_activity_flag            number := 0;--是否参加活动标志 0-未参加 1-参加
   v_activity_id              number := 0;--参加的活动id
   v_activity_type            number := 0;--参加的活动类型 1：限时折扣；2：订货会；4：预售
   v_locked_stock             number := 0;--参加的活动是否锁定库存 1.共享库存   2.锁定库存
   v_product_itemnumber       varchar2 (50);--商品货号
   v_main_warehouse_id        number := 2;--默认仓库id，某些情况下，仅考虑该仓库的库存（当前仅仅考虑华东仓）
begin
   --0.0获取用户所在站点
   select tui.site_id into v_site_id from tbl_user_info tui where tui.user_name = c_user_name;
   --0.1判断sku是否已下架
   select count (1) into v_count from tbl_product_sku tps where tps.state = '上架' and tps.id = c_product_sku;
   ---如果sku非上架状态，直接返回0
   if v_count <= 0
   then
      return 0;
   end if;
   select tps.product_itemnumber into v_product_itemnumber from tbl_product_sku tps where tps.state = '上架' and tps.id = c_product_sku;
   --判断该商品是否参与了活动
   select count (1) into v_count from tbl_activity_product ap, tbl_activity_info tai,tbl_activity_detail ad
   where  ap.product_itemnumber = v_product_itemnumber
   and tai.id = ap.activity_id and tai.id = ad.activity_id
   and sysdate between ap.activity_start_date and ap.activity_end_date
   and tai.activity_state = '3' and tai.state = '2'
   and exists (select 1 from tbl_activity_site tas  where tas.site_id = v_site_id and tas.activity_id = tai.id)
   and (case when (ad.user_group_id = 0 or ad.user_group_id is null) then 1 else case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and ad.user_group_id = aa.id and bb.user_id = c_user_name) then 1 else 0 end end) = 1;
   
   if v_count > 0 then
      v_activity_flag := 1;                                             --参加活动
   end if;

   /***********1、当前商品参加了活动，需要继续判断活动类型，是否锁定库存等**********/
   if v_activity_flag = 1 then
      --1.0 查询商品参加的活动类型
        select to_number (tai.activity_type),tai.id,to_number(locked_stock) into v_activity_type, v_activity_id,v_locked_stock
        from tbl_activity_product ap,tbl_activity_info tai,tbl_activity_detail ad
        where  ap.product_itemnumber = v_product_itemnumber
        and tai.id = ap.activity_id and tai.id = ad.activity_id
        and sysdate between ap.activity_start_date and ap.activity_end_date
        and tai.activity_state = '3' and tai.state = '2'
        and exists (select 1 from tbl_activity_site tas  where tas.site_id = v_site_id and tas.activity_id = tai.id)
        and (case when (ad.user_group_id = 0 or ad.user_group_id is null) then 1 else case when exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and ad.user_group_id = aa.id and bb.user_id = c_user_name) then 1 else 0 end end) = 1
        and rownum <= 1;
        
      --1.1 当前商品正在参加限时折扣活动【tbl_sale_activity_info】，需要判断是否锁定库存
      if v_activity_type = 1 then
         /**
         1.1.1 判断活动是否需要锁定库，如果需要则：库存 = 使用锁定库存 - 已售库存
         是否锁定库存  1.共享库存；2.锁定库存 
         **/
         if v_locked_stock = 2 then                                          --锁定库存，则库存 = 锁定量 - 已售库存
            select nvl (tsas.locked_stock_amount, 0),
                   nvl (tsas.activity_sell_amount, 0)
              into v_locked_stock_amount, v_activity_sell_amount
              from tbl_sale_activity_sku tsas
             where     tsas.product_sku = c_product_sku
                   and tsas.activity_id = v_activity_id
                   and tsas.warehouse_id = c_warehouse_id;

            --（活动时间内,活动数量限制的）并且活动实际可买数小于实际库存数，则当前sku可卖库存即为活动数-活动销售量
            v_product_sku_stock :=
               v_locked_stock_amount - v_activity_sell_amount;
         end if;
      end if;
      --1.2 当前商品正在参加订货会活动【tbl_preorder_activity_info】，直接使用实际库存
      if v_activity_type = 2 then
        -- v_activity_flag := 0;
        /*******临时解决方案**begin**wangpeng 2019-03-12******应该使用上面注释的部分****/
         if c_warehouse_id = v_main_warehouse_id then 
            ---订货会活动，华东仓库存直接返回最大值9999
            v_product_sku_stock := 9999;
         else
           ---订货会活动，非华东仓库不销售，库存直接返回0
            v_product_sku_stock := 0;
         end if;
         /*******临时解决方案**end**wangpeng 2019-03-12**********/
      end if;
      --1.3 当前商品正在预售活动【tbl_presell_activity_info】,当前仅华东仓（成品仓 warehouse_id = 2）可以预售，其他仓库则直接返回0
      if v_activity_type = 4 then
          if c_warehouse_id = v_main_warehouse_id then
            select nvl(tsas.presell_stock_amount, 0),nvl(tsas.activity_sell_amount, 0)
            into v_locked_stock_amount, v_activity_sell_amount
            from tbl_presell_activity_sku tsas
            where     
            tsas.product_sku = c_product_sku
            and tsas.activity_id = v_activity_id;
            --预售活动商品库存 = 预售量 - 已经销售量
            v_product_sku_stock := v_locked_stock_amount - v_activity_sell_amount;
          else
            v_product_sku_stock := 0;
          end if;
      end if;
   /***********2、当前商品没有参加活动，则库存直接取逻辑库存***********/
   end if;
   ---如果商品没有参加【定货会】【预售】等活动，获取 参加了【限时折扣】但是未锁定库存；则直接查询库存占用表数据
   if v_activity_type not in (2,4) or (v_activity_type=1 and v_locked_stock != 2) then
      --2.0获取对应sku实际库存
      --2.1 查询是否存储库存信息
      select count (1) into v_count from tbl_product_sku_stock where product_sku = c_product_sku and warehouse_id = c_warehouse_id;
      if v_count <= 0 then
         return 0;
      end if;
      /*2.2查询实际库存、占用库存、预占用库存***********************/
      select nvl(sum(product_total_count),0),nvl(sum(product_order_occupy_count),0),nvl(sum(pre_order_occupy_count),0)
      into v_total_count, v_order_occupy_count, v_pre_order_occupy_count
      from tbl_product_sku_stock
      where product_sku = c_product_sku and warehouse_id = c_warehouse_id;
       --2.3 计算库存信息 = sku实际库存量-订单占用量（多站点多活动） -预占用量
      v_product_sku_stock := v_total_count - v_order_occupy_count - v_pre_order_occupy_count;
   end if;
   /***
   如果当前商品正在参加 【限时折扣】活动，且是锁定库存
   则需要比较以下两者的大小
   1、活动库存 = 活动锁定量 - 活动销售量
   2、逻辑库存 = sku实际库存量-订单占用量（多站点多活动） -预占用量
   
   如果 活动库存 小于  逻辑库存 则返回活动库存作为该sku的可销售库存
   */
   if (v_activity_type = 1
       and v_locked_stock = 2
       and (v_locked_stock_amount - v_activity_sell_amount) <=(v_total_count- v_order_occupy_count- v_pre_order_occupy_count)
       )
   then
      v_product_sku_stock := v_locked_stock_amount - v_activity_sell_amount;
   end if;
   if v_product_sku_stock < 0
   then
      v_product_sku_stock := 0;
   end if;
   --返回值
   return v_product_sku_stock;
exception
   when others  then
   return 0;
end getproductsku_stocks;
/

