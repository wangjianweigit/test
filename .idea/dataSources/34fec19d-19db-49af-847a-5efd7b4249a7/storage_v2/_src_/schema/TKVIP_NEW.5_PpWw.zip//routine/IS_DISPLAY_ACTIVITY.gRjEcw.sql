create FUNCTION           IS_DISPLAY_ACTIVITY
/**
    根据活动ID，用户判断该活动是否对改用户展示
    by zhenghui
    返回值：1（显示）  0：不显示
**/
(
    C_USER_NAME VARCHAR2, --用户名
    C_ACTIVITY_ID NUMBER        --活动ID
) RETURN VARCHAR2
 IS
     V_COUNT NUMBER:=0;
     V_USER_GROUP_ID NUMBER:=0;  --商品ID
     V_FLAG NUMBER:=1; --是否显示 1（显示）  0：不显示
BEGIN

    --查询活动是否存在
    SELECT COUNT(1) INTO V_COUNT FROM TBL_ACTIVITY_INFO AI WHERE AI.ID = C_ACTIVITY_ID;
        
    IF V_COUNT > 0 THEN
        --查询活动是否关联用户组
        SELECT NVL(AD.USER_GROUP_ID,0) INTO V_USER_GROUP_ID FROM TBL_ACTIVITY_INFO AI,TBL_ACTIVITY_DETAIL AD WHERE AI.ID = AD.ACTIVITY_ID AND AI.ID = C_ACTIVITY_ID;
                    
        IF V_USER_GROUP_ID > 0 THEN
            --如果关联用户组则查询该用户是否存在用户组中
            SELECT COUNT(1) INTO V_COUNT FROM TBL_USER_GROUP UG,TBL_USER_GROUP_DETAIL GD WHERE UG.ID = GD.GROUP_ID AND (gd.ACTIVITY_ID = C_ACTIVITY_ID OR gd.ACTIVITY_ID = 0) AND UG.STATE = '2' AND UG.ID = V_USER_GROUP_ID AND GD.USER_ID = C_USER_NAME;
                        
            IF V_COUNT = 0 THEN      
                V_FLAG := 0;      
            END IF;
                    
        END IF;
    END IF;

    RETURN V_FLAG;

END IS_DISPLAY_ACTIVITY;
/

