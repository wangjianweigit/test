create PROCEDURE           AUTO_PRODUCT_COLOR_SORT
/**
    songwangwen 2018-08-15
    根据商品各个颜色的库存情况，进行自动颜色排序，规则如下
    颜色根据库存情况自动排序（定时执行）

    1、按固定（华东仓-成品仓）中的库存进行判断
    2、如果几个颜色都是齐码（按规格），库存多的颜色排在前面
    3、如果几个颜色存在断码（按规格），齐码（按规格）多的颜色排在断码前面
    4、如果几个颜色都是断码（按规格），库存多的颜色排在前面
     
    songwangwen 2018-12-05 商品其他信息一致时，按照原先的排序顺序不做修改
    
    reid 2019.03.18  不存在库存的商品排序错误问题修改
  **/
IS
   v_warehouse_id         number:=2;                      ---仓库ID，默认使用华东仓-成品仓 id = 2
   v_product_itemnumber   VARCHAR2 (50);                 --货号
   v_count                number;                        --临时变量

BEGIN
   BEGIN
      /*** 仅查询普通商品（在批发平台售卖的商品）*********/
      FOR tb IN (SELECT itemnumber FROM TBL_PRODUCT_INFO WHERE PRODUCT_TYPE = 0)
      LOOP
         v_product_itemnumber := TO_CHAR (tb.itemnumber);
           /***
              如果根本无库存，则不需要排序颜色
            **/
            select count(1)  into v_count
            FROM TBL_PRODUCT_SKU_STOCK pss 
            INNER JOIN TBL_PRODUCT_SKU ps  ON ps.id = pss.product_sku
            WHERE ps.product_group = '尺码'
            AND pss.warehouse_id = v_warehouse_id
            AND ps.product_itemnumber = v_product_itemnumber;
         IF v_count > 0 THEN
         -------------------------------------根据以上的规则，重新修改商品颜色的排序-------------------------------------------------
         /***********保留原先的排序数据***********/
         INSERT INTO TBL_PRODUCT_COLOR_SORT_TMP 
         SELECT * FROM TBL_PRODUCT_COLOR_SORT WHERE product_itemnumber = v_product_itemnumber;
         /**删除旧的颜色排序数据***/
         DELETE FROM TBL_PRODUCT_COLOR_SORT WHERE product_itemnumber = v_product_itemnumber;
         /***新插入颜色排序数据***/
         INSERT INTO TBL_PRODUCT_COLOR_SORT
                         select 
                temp4.product_id,
                temp4.product_itemnumber,
                temp4.product_sku_id,
                rownum stot_id
                from 
                (
                      select 
                      temp3.product_id,
                      temp3.product_itemnumber,
                      temp3.product_sku_id
                      FROM (
                             SELECT                      
                              pi.id product_id,
                              temp2.product_itemnumber,
                              temp2.product_color,
                              temp2.stock_num,                          /**该颜色的总库存*/
                              temp2.specs_complete_num,                /**该颜色下属的规格的齐码数*/
                              (CASE
                                  WHEN specs_num = specs_complete_num THEN 1
                                  ELSE 0
                               END) color_complete_flag,        /**颜色齐码标志位  1.齐码   2.断码**/
                              (SELECT id
                                 FROM TBL_PRODUCT_SKU pps
                                WHERE  pps.product_group = '颜色'
                                      AND pps.product_group_member = temp2.product_color
                                      AND pps.product_itemnumber = temp2.product_itemnumber)  product_sku_id
                         FROM (  SELECT product_itemnumber,
                                        product_color,
                                        SUM (stock_num) stock_num,  /**颜色总库存*/
                                        COUNT (1) specs_num,       /**该颜色下属的规格总数*/
                                        SUM (
                                           CASE
                                              WHEN stock_sku_num = sku_num THEN 1
                                              ELSE 0
                                           END)  specs_complete_num /**该颜色下属的规格的齐码数*/
                                   FROM (  SELECT ps.product_itemnumber,
                                                  ps.product_specs,
                                                  ps.product_color,
                                                  SUM (
                                                     NVL (
                                                        CASE
                                                           WHEN ( NVL ( PRODUCT_TOTAL_COUNT, 0) - NVL (PRODUCT_ORDER_OCCUPY_COUNT,0)- NVL (PRE_ORDER_OCCUPY_COUNT,0)) <= 0
                                                           THEN 0 
                                                           ELSE NVL ( PRODUCT_TOTAL_COUNT,0)- NVL (PRODUCT_ORDER_OCCUPY_COUNT,0)- NVL (PRE_ORDER_OCCUPY_COUNT,0)
                                                        END,0))
                                                     stock_num,     /**库存数量**/
                                                  SUM (
                                                     CASE
                                                         WHEN ( NVL ( PRODUCT_TOTAL_COUNT, 0) - NVL (PRODUCT_ORDER_OCCUPY_COUNT,0)- NVL (PRE_ORDER_OCCUPY_COUNT,0)) <= 0
                                                        THEN
                                                           0
                                                        ELSE
                                                           1
                                                     END)
                                                     stock_sku_num, /**有库存的SKU数量**/
                                                  COUNT (ps.ID) sku_num
                                             FROM  TBL_PRODUCT_SKU ps
                                             LEFT JOIN TBL_PRODUCT_SKU_STOCK pss ON ps.id = pss.product_sku   AND pss.warehouse_id = v_warehouse_id
                                             WHERE     ps.product_group = '尺码'
                                                  AND ps.product_itemnumber = v_product_itemnumber
                                         GROUP BY ps.product_itemnumber,
                                                  ps.product_color,
                                                  ps.product_specs) temp1
                               GROUP BY product_itemnumber, product_color) temp2
                               INNER JOIN tbl_product_info pi on temp2.product_itemnumber = pi.itemnumber
                      ) temp3
                    LEFT JOIN TBL_PRODUCT_COLOR_SORT_TMP pcs on temp3.product_sku_id = pcs.product_sku_id
                    ORDER BY 
                    temp3.color_complete_flag DESC,
                    temp3.specs_complete_num DESC,
                    temp3.stock_num DESC,
                    pcs.sort_id asc
                ) temp4;             
         /****提交数据***/
         COMMIT;
      END IF;
      END LOOP;
   END;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
END AUTO_PRODUCT_COLOR_SORT;
/

