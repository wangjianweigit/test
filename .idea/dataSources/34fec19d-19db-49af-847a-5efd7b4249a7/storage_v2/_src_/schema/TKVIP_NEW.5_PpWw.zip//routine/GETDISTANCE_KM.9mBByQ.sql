create FUNCTION           GETDISTANCE_KM
/**
    计算两个地图坐标的直线距离
   shif 2018.06.11
**/
(latA number,                       --起点经度值
 lonA number,                        --起点维度值
 latB number,                        --终点经度值
 lonB number                         --终点维度值
) RETURN NUMBER is     ---返回值，两个坐标点的距离（单位米）
  R number := 6371;--地球半径km
  lon1            number :=0;
  lon2            number :=0;
  lat1            number := 0;
  lat2            number := 0;
  distance        number := 0;
  PI number := 3.141592625;
begin

    lon1 := (PI / 180) * latA;
    lon2 := (PI / 180) * latB;
    lat1 := (PI / 180) * lonA;
    lat2 := (PI / 180) * lonB;
    --两点间距米
    distance := acos(sin(lat1) * sin(lat2) +cos(lat1) * cos(lat2) * cos(lon2 - lon1)) * R;

    return round(distance,5);
    EXCEPTION
WHEN OTHERS THEN
    RETURN 0;
end;
/

