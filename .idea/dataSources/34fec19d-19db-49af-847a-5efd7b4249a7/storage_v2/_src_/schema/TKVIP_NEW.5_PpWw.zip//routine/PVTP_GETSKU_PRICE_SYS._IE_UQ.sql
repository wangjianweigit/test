create FUNCTION PVTP_GETSKU_PRICE_SYS
/**
    计算私有平台导入的童库平台商品的售价（仅考虑入驻商的全局会员折扣）            sku价格
    reid  2019.10.17
    返回值：商品售价
**/
(
    c_stationed_user_id     number,     --当前访问的私有平台ID（即所属私有商家的ID）
    c_sku_id                number      --商品SKUID    
) return varchar2
 is
     v_count number:=0;                                  --临时变量
     v_user_discount  number:=0;                         --私有商家默认会员折扣
     v_product_prize number:=0;                          --需要返回的SKU应销售价格
     v_prize_cost number:=0;                             --SKU报价
     v_product_sale_prize number:=0;                     --应售价
     v_member_service_rate_rzs number:=0;                --会员服务费比例-入驻商
     v_member_service_rate_qj number:=0;                 --会员服务费比例-全局
     v_member_service_money_rzs number:=0;                --会员服务费-入驻商
     v_member_service_money_qj number:=0;                 --会员服务费-全局
     v_product_create_date date;                                             --商品创建时间                          --界线新加配置
     v_sys_line date:=to_date('2019-01-30 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置
     v_sys_line2 date:=to_date('2019-09-13 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置  针对2019-09-13新费率调整
BEGIN
    --查询入驻商会员服务费比例-按当前费率计算
    select nvl(user_discount,1)
    into v_user_discount
    from TBL_PVTP_CONFIG where stationed_user_id = c_stationed_user_id;
    --是否是童库平台分享过来的商品
    SELECT COUNT(1) INTO v_count from TBL_PRODUCT_INFO pi 
    where exists (select 1 from TBL_PRODUCT_SKU ps where ps.product_itemnumber = pi.itemnumber and ps.id = c_sku_id)
    and pi.is_private = 1;
     IF v_count <> 0 THEN
            /*************************商品新老计费费率控制*********begin**********************/
            select a.create_date into v_product_create_date from tbl_product_info a,tbl_product_sku b where b.id = c_sku_id  and a.ITEMNUMBER = b.PRODUCT_ITEMNUMBER and rownum<2;
            if v_product_create_date < v_sys_line then
                --查询入驻商会员服务费比例-老费率
                select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RATE where STATIONED_USER_ID = (
                    select STATIONED_USER_ID from tbl_product_sku where id = c_sku_id and rownum<2
                );
            end if;
            /*************************商品新老计费费率控制*********end**********************/
            
           --查询全局会员服务费比例
           --select member_service_rate into v_member_service_rate_qj from TBL_SYS_CONFIG where id = 1;
           
           if v_product_create_date >= v_sys_line then
               --查询入驻商会员服务费比例-按当前费率计算
                select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_USER_INFO where id = (
                    select STATIONED_USER_ID from tbl_product_sku where id = c_sku_id
                );
           end if;
                   
            /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
            if v_sys_line2 > v_product_create_date and v_product_create_date >= v_sys_line then
                --查询入驻商会员服务费比例-老费率2次调整
                select nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_qj from TBL_STATIONED_OLD_SERVICE_RAT2 where STATIONED_USER_ID = (
                    select STATIONED_USER_ID from tbl_product_sku where id = c_sku_id and rownum<2
                );
            end if;
            /*************************商品新老计费费率控制****针对2019-09-15新费率调整*****begin**********************/
           --查询原价最低价
           select nvl(f.product_prize_cost,0) into v_prize_cost from tbl_product_sku f where id=c_sku_id;
     END IF;
   --计算应销售价
   v_product_sale_prize:=v_prize_cost/(1-(v_member_service_rate_rzs+v_member_service_rate_qj));
   /*********************************计算最终价***********************************/
   --入驻商会员服务费 = 应销售价*入驻商会员服务费比例
   v_member_service_money_rzs := v_product_sale_prize * v_member_service_rate_rzs;
   --全局会员服务费 = 应销售价*全局会员服务费比例
   v_member_service_money_qj := v_product_sale_prize * v_member_service_rate_qj;
   ---应售价  = 报价 + 入驻商会员服务费 + 全局会员服务费*私有商家默认会员折扣
   v_product_prize := v_prize_cost+v_member_service_money_rzs+(v_member_service_money_qj*v_user_discount);
   /****
   dbms_output.put_line('入驻商会员服务费比例==='||v_member_service_rate_rzs);
   dbms_output.put_line('入驻商会员服务费==='||v_member_service_money_rzs);
   dbms_output.put_line('全局会员服务费比例==='||v_member_service_rate_qj);
   dbms_output.put_line('全局会员服务费==='||v_member_service_money_qj);
   dbms_output.put_line('应售价==='||v_product_sale_prize);
   dbms_output.put_line('最终售价==='||v_product_prize);
***/
     if ceil(v_product_prize)-v_product_prize<0.5 then
      v_product_prize := ceil(v_product_prize);
   elsif ceil(v_product_prize)-v_product_prize=0 then
      v_product_prize := v_product_prize;
   else 
      v_product_prize := ceil(v_product_prize)-0.5;
   end if;
   return v_product_prize;
END PVTP_GETSKU_PRICE_SYS;
/

