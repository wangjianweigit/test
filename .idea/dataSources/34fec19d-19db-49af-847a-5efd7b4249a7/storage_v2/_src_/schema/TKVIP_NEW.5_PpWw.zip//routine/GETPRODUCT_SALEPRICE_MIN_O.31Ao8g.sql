create FUNCTION           getProduct_SalePrice_Min_O
/**
    (新版)通过用户名获取商品货号最低价格（未来价格，可以用户活动预告价查询）  （列表专用）已优化
    wangpeng
    2017-05-13   
    返回值：商品价格   （未考虑特殊价格）
**/
(
    c_user_name   varchar2,   --用户名
    c_product_itemnumber   varchar2--商品货号    
) return varchar2
 is
 v_product_prize_str varchar2(50):='0.00';   --需要返回的商品价格
 v_id number:=0;                              --最低报价SKUID
BEGIN

    --查询最低报价的SKUID
    select id into v_id from (select id from tbl_product_sku where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架' order by product_prize_cost asc ) where rownum<2;

    --查找SKU对应的实际销售价
    v_product_prize_str:=nvl(to_char(getSku_User_SalePrice_O(c_user_name,v_id),'fm999999990.00'),'0.00');

    return v_product_prize_str;
   
   
   
   
END getProduct_SalePrice_Min_O;
/

