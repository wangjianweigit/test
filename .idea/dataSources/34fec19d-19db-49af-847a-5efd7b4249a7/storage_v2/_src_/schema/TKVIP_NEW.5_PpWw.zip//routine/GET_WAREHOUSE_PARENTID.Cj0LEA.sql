create FUNCTION           GET_WAREHOUSE_PARENTID
/**
    根据仓库ID查询该仓库的祖父节点，
    songwangwen
    2017-04-26
    
    zhengfy 2019-06-24 改为根据仓库ID查询该仓库的直接父节点
**/
(
    v_warehouse_id   NUMBER   --仓库ID 
) return NUMBER
 is
 v_warehouse_parent_id NUMBER;
BEGIN
    select decode(wi.parent_id, 0, wi.id, wi.parent_id) into v_warehouse_parent_id
    from tbl_warehouse_info wi
    where wi.id = v_warehouse_id;
      
   return v_warehouse_parent_id;
END GET_WAREHOUSE_PARENTID;
/

