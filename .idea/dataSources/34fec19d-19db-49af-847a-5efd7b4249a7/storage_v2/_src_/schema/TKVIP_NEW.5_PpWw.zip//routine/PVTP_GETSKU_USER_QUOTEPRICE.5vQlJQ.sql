create FUNCTION PVTP_GETSKU_USER_QUOTEPRICE
/** 
    私有平台专用：计算商品SKU的报价信息  ---create by reid 2019.09.06
    返回值：商品报价信息，用于清分计算
**/
(
     c_stationed_user_id    number,      --当前访问的私有平台ID（即所属私有商家的ID）
     c_user_name            varchar2,    --用户名
     c_product_sku_id        number       --商品SKUID
) return number
is
     v_temp_count               number :=0;     --临时变量
     v_site_id                  number:=0;      --会员站点
     v_product_type             number:=0;      --商品类型（0：普通商品，3：私有平台商品）   --私有平台特殊价格新加配置
     v_product_itemnumber       varchar2(50);   --商品货号
     v_activity_id              number:=0;      --商品参加的活动ID
     /**
        0：未参加活动
        1：限时折扣（数据表：tbl_sale_activity_info）;
        3: 私有站活动
     **/
     v_activity_type            number:=0;      --商品参加的活动类型 
     v_activity_product_id      number:=0;      --商品参加的活动管理的活动商品表的ID
     v_quote_price              number :=0;     --最终返回的报价信息
     v_activity_quote_price     number :=0;     --活动情况下的报价信息
BEGIN  
   --获取会员信息
   select nvl(min(site_id),0)
   into v_site_id 
   from tbl_user_info where user_name = c_user_name;
   IF v_site_id=0 THEN 
        RETURN 0;
   END IF;
    ----判断商品是私有商品还是童库分享得商品
    select count(1) into v_temp_count from TBL_PVTP_PRODUCT_INFO ppi where ppi.stationed_user_id = c_stationed_user_id
    and exists (select 1 from TBL_PVTP_PRODUCT_SKU pps where pps.product_id = ppi.id and pps.id = c_product_sku_id);
   IF v_temp_count<>0 THEN
         --查询商品基本信息
       select ps.product_itemnumber,ps.product_prize_cost,3
       into v_product_itemnumber,v_quote_price,v_product_type
       from tbl_pvtp_product_sku ps,
       tbl_pvtp_product_info pi
       where ps.product_itemnumber = pi.itemnumber
       and ps.product_group = '尺码' and ps.id = c_product_sku_id;
   ELSE
       --查询商品基本信息
       select ps.product_itemnumber,ps.product_prize_cost,pi.product_type 
       into v_product_itemnumber,v_quote_price,v_product_type
       from tbl_product_sku ps,
       tbl_product_info pi,
       tbl_pvtp_product_info_ref pir
       where ps.product_itemnumber = pi.itemnumber
       and pir.platform_id = c_stationed_user_id
       and pi.id = pir.product_id
       and pi.is_private = 1
       and pir.enabled_flag = 1
       and ps.product_group = '尺码' 
       and ps.id = c_product_sku_id;
   END IF;
   ---1、******************查询商品参加了那个活动
    SELECT
    (case when activity_state='going' then temp2.activity_id else 0 end),
    (case when activity_state='going' then temp2.activity_type else 0 end),
    (case when activity_state='going' then temp2.activity_product_id else 0 end) 
    into v_activity_id,v_activity_type,v_activity_product_id
    from
    (
        select 
        (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,0,instr(activity_tag,'#-#',1,1)-1)) else 0 end) activity_id,
        (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,instr(activity_tag,'#-#',1,1)+3,1)) else 0 end) activity_type,
        (case when length(temp.activity_tag)>0 then substr(temp.activity_tag,instr(activity_tag,'#-#',1,2)+3,5) else '' end) activity_state,
        (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,instr(activity_tag,'#-#',1,4)+3)) else 0 end) activity_product_id
        from (
            select NVL(PVTP_GET_ACTIVITY_TAG(c_stationed_user_id,c_user_name,v_product_itemnumber),'') activity_tag from dual
        ) temp
    ) temp2;
   /*2、******************查询商品在特殊价格、活动情况下的【活动报价】*********************************/
   ------2.1 查询是否参加了平台活动
   IF v_activity_type = 1 THEN
           select count(1) into v_temp_count from TBL_ACTIVITY_PRODUCT ap where id = v_activity_product_id;
           IF v_activity_type<>0 AND v_activity_type<>3 AND v_temp_count<>0 then
               SELECT (v_quote_price*activity_discount) into v_activity_quote_price FROM TBL_ACTIVITY_PRODUCT ap where id = v_activity_product_id;
           END IF;
   END IF;
   IF v_activity_type = 3 THEN
             select count(1) into v_temp_count from tbl_sta_sale_activity_product where id = v_activity_product_id;
             IF v_temp_count<>0 THEN
                    select (v_quote_price*activity_discount) into v_activity_quote_price from tbl_sta_sale_activity_product where id = v_activity_product_id;
             END IF;
   END IF;
   --如果商品的活动报价存在，判断原始报价与活动报价的大小，取较小值
   IF v_activity_quote_price<>0 THEN
          v_quote_price:= least(v_quote_price,v_activity_quote_price);
   END IF;
   return v_quote_price;
END PVTP_GETSKU_USER_QUOTEPRICE;
/

