create view V_ORDER_STATION_MONEY as
SELECT a.order_number,
            a.PRODUCT_ITEMNUMBER itemnumber,
            SUM (round(a.DIVIDE_MONEY * b.COUNT,2)) product_total_money,
            SUM (b.COUNT) product_count
       FROM TBL_ORDER_DIVIDE_RECORD a, tbl_order_product_sku b
      WHERE     a.order_number = b.order_number
            AND a.product_sku = b.product_sku
            AND DIVIDE_TYPE = 1
   GROUP BY a.order_number, a.PRODUCT_ITEMNUMBER
/

