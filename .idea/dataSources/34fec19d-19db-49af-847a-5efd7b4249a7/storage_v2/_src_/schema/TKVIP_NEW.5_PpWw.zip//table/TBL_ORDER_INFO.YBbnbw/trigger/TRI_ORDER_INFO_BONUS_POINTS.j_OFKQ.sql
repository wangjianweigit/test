create trigger TRI_ORDER_INFO_BONUS_POINTS
  before update
  on TBL_ORDER_INFO
  for each row
BEGIN
   --更新订单支付状态，如果被改为付款成功，则执行以下操作
   IF UPDATING('PAYMENT_STATE') OR  UPDATING('REFUND_STATE')
   THEN
         IF :OLD.PAYMENT_STATE!=2 and :NEW.PAYMENT_STATE=2 THEN
            /**插入数据**/
            INSERT INTO TBL_MEMBER_BONUS_POINTS (ID, USER_NAME, ORDER_SOURCE, ORDER_NUMBER, TYPE,
                    PRODUCT_TOTAL_MONEY, SCORE, CREATE_DATE)
                    select
                    SEQ_MEMBER_BONUS_POINTS.nextval,
                    USER_NAME,
                    '订单支付',
                    :NEW.ORDER_NUMBER,
                    1,
                    PRODUCT_TOTAL_MONEY,
                    (PRODUCT_TOTAL_MONEY*sale) SCORE,
                    sysdate
                     from (
                    select USER_NAME,ORDER_NUMBER,sum((PRODUCT_COUNT-history_num)*(PRODUCT_TOTAL_MONEY/PRODUCT_COUNT)) PRODUCT_TOTAL_MONEY,
                    (select  SCALE from TBL_BONUS_POINTS_CONF  WHERE ORDER_SOURCE='订单支付' and rownum<=1 ) sale
                     from (select p1.*,
                            case (select count(1) from tbl_order_product p2 where  p2.ORDER_NUMBER !=:NEW.ORDER_NUMBER and
                             p1.ITEMNUMBER = P2.ITEMNUMBER and P1.ITEMNUMBER = P2.ITEMNUMBER
                            and p1.PRODUCT_COLOR = p2.PRODUCT_COLOR and p1.PRODUCT_SPECS = p2.PRODUCT_SPECS
                            ) when 0 then 1 else 0 end history_num
                            from tbl_order_product p1 where ORDER_NUMBER = :NEW.ORDER_NUMBER
                        ) temp1 group by USER_NAME,ORDER_NUMBER
                    ) temp2;
         END IF;
     IF :OLD.REFUND_STATE!=2 AND :NEW.REFUND_STATE=2 THEN        /**客户申请取消订单*/
            /**插入数据**/
            INSERT INTO TBL_MEMBER_BONUS_POINTS (ID, USER_NAME, ORDER_SOURCE, ORDER_NUMBER, TYPE,
                    PRODUCT_TOTAL_MONEY, SCORE, CREATE_DATE)
                    select
                    SEQ_MEMBER_BONUS_POINTS.nextval,
                    USER_NAME,
                    '取消订单',
                    :NEW.ORDER_NUMBER,
                    2,
                    PRODUCT_TOTAL_MONEY,
                    -1*(PRODUCT_TOTAL_MONEY*sale) SCORE,
                    sysdate
                    from
                      (SELECT USER_NAME,
                             ORDER_NUMBER,
                             SUM (PRODUCT_TOTAL_MONEY) PRODUCT_TOTAL_MONEY,
                             (SELECT SCALE
                                FROM TBL_BONUS_POINTS_CONF WHERE ORDER_SOURCE = '取消订单' AND ROWNUM <= 1) sale
                        FROM tbl_order_product p1
                       WHERE ORDER_NUMBER = :NEW.ORDER_NUMBER
                    GROUP BY USER_NAME, ORDER_NUMBER) temp1;
     END IF;
   END IF;
END;
/

