create procedure submit_pre_order
/**
    提交预付订单
    wanghai
    2017-09-26
    增加对会员卡的支持  shif 20180717
    
    reid 2018.10.23 增加商品单价不允许为0的校验
    zhengfy 20190716 记录活动id、活动商品id、商品报价、订单自动取消时间
    reid 2019.10.14 预订下单完成后，删除下单规格下的所有SKU数据，防止出现该规格下某个SKU失效未下单、未删除问题
*/
(
    c_user_name            in  number,       --下单用户名
    c_order_product        in  T_ORDER_PRODUCT_LST,
    c_order_source         in  varchar2,     --下单来源
    c_activity_id          in  number,       --活动ID
    c_product_money        in  number,       --商品总价
    c_mbr_card             in  number,       --预定订单是否使用了会员卡优化   1.未使用  2.已经使用
    output_status          out number,       --返回码：0、失败；1、成功
    output_msg             out varchar2,     --返回信息
    output_earnest_money   out number        --返回预付定金金额
) as
    t_result_count     number := 0;         --数量零时结果
    t_sku_count        number := 0;         --下单SKU数量
    t_index            number := 1;
    v_order_product    T_ORDER_PRODUCT;

    v_user_manage_name varchar2(50);        --下单用户姓名
    v_ywjl_user_name   varchar2(50);        --业务经理用户名
    v_ywy_user_name    varchar2(50);        --业务员用户名
    v_store_id         number;              --门店ID


    v_product_count    number := 0;         --下单商品总数
    v_product_money    number := 0;         --下单商品总价
    v_order_number     varchar2(50);        --预付订单单号
    v_earnest_money    number := 0;         --预付定金金额
    v_deposit_percent  number := 0;         --预付比例
    v_mbr_card_reduce  number := 0;         --订单在使用会员卡优惠后，减少的金额，没有使用会员卡优化，则为0
    v_temp_activity_product_count number := 0;
    v_product_type     number := 1;             --商品分类类型 1.表示鞋类（商品规格固定）  2.表示其他类型（商品规格自定义）
begin
    output_status := 0;

    --校验活动是否有效
    select count(1) into t_result_count from TBL_ACTIVITY_INFO where ACTIVITY_STATE = '3' and STATE = '2' and sysdate between BEGIN_DATE and END_DATE and id = c_activity_id;
    if t_result_count = 0 then
        output_msg := '活动未开始或已过期，请检查！';
        return;
    end if;

    --校验用户是否可参加活动
    select count(1) into t_result_count from TBL_ACTIVITY_DETAIL a1
    where a1.ACTIVITY_ID = c_activity_id
    and
    case
       when a1.user_group_id = 0
           then 1
       else
           case when 
           exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb where aa.id = bb.group_id and aa.state = '2' and a1.user_group_id = aa.id and  bb.user_id = c_user_name
           AND (bb.ACTIVITY_ID = a1.activity_id OR bb.ACTIVITY_ID = 0)
           )
           then
               1
           else
               0
           end
     end  = 1;

    if t_result_count = 0 then
        output_msg := '用户未参加该活动，请检查！';
        return;
    end if;

    --获取用户信息
    select count(1) into t_result_count from tbl_user_info where id = c_user_name;
    if t_result_count <> 0 then
        select user_manage_name,(select user_name from tbl_sys_user_info where id = i.market_supervision_user_id) as ywjl_user_name,
            (select user_name from tbl_sys_user_info where id = i.referee_user_id) as ywy_user_name,store_id
        into v_user_manage_name,v_ywjl_user_name,v_ywy_user_name,v_store_id from tbl_user_info i where id = c_user_name;
    else
        output_msg := '未找到用户信息，请检查！';
        return;
    end if;

    --集合数据插入临时表
    if c_order_product.count = 0 then
        output_msg := '未选择需要购买的商品，请检查！';
        return;
    end if;

    for i in c_order_product.first..c_order_product.last loop
        v_order_product := c_order_product(i);
        insert into TMP_ORDER_PRODUCT_SKU(product_sku,count,ACTIVITY_PRODUCT_ID) 
        select v_order_product.product_sku, v_order_product.count, ap.id
        from TBL_ACTIVITY_PRODUCT ap
        where activity_id = c_activity_id
            and exists(
                select 1
                from tbl_product_sku ps
                where id = v_order_product.product_sku
                and ps.product_itemnumber = ap.product_itemnumber
            );
    end loop;

    t_sku_count := c_order_product.count;

    --校验SKU合法性
    SELECT t_sku_count - COUNT(1) INTO t_result_count FROM TBL_PRODUCT_SKU a,TMP_ORDER_PRODUCT_SKU b,TBL_ACTIVITY_PRODUCT c WHERE a.ID = b.product_sku AND a.PRODUCT_ITEMNUMBER = c.PRODUCT_ITEMNUMBER AND a.STATE='上架' and c.ACTIVITY_ID = c_activity_id;
    IF t_result_count <> 0 THEN
        output_msg:='SKU错误或已下架请检查SKU的有效性！';
        RETURN;
    END IF;

    --获取订单号
    v_order_number := '2'||getAutoNumber('D');

    --插入预付订单主表
    INSERT INTO TBL_PRE_ORDER_INFO(
        ID,ORDER_NUMBER,USER_ID,USER_MANAGE_NAME,ORDER_SOURCE,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,ACTIVITY_ID,ACTIVITY_NAME,MBR_CARD,MBR_CARD_REDUCE
    )
    VALUES(
        SEQ_PRE_ORDER_INFO.NEXTVAL,v_order_number,c_user_name,v_user_manage_name,c_order_source,
        v_ywjl_user_name,v_ywy_user_name,v_store_id,c_activity_id,
        (select ACTIVITY_NAME from TBL_ACTIVITY_INFO where id = c_activity_id),
        c_mbr_card,0
    );

    --生成阶梯价临时表
    insert into TMP_TIERED_PRICE(PRODUCT_ITEMNUMBER,product_color,PRODUCT_SPECS,PRICE)
    select PRODUCT_ITEMNUMBER,product_color,PRODUCT_SPECS,min(prize) prize
    from (
        select bb.*,aa.PRIZE,aa.min_count from TBL_ACTIVITY_PRODUCT_SPECPRIZE aa,(
            select a.PRODUCT_ITEMNUMBER,a.product_color,a.PRODUCT_SPECS,sum(b.count) sum_count from tbl_product_sku a,TMP_ORDER_PRODUCT_SKU b where a.id = b.product_sku
        group by a.PARENT_ID,a.PRODUCT_ITEMNUMBER,a.product_color,a.PRODUCT_SPECS
        ) bb where aa.PRODUCT_SPEC =bb.PRODUCT_SPECS and aa.PRODUCT_ITEMNUMBER  = bb.PRODUCT_ITEMNUMBER
            and aa.ACTIVITY_ID = c_activity_id
        and SUM_COUNT >= min_count
    ) group by PRODUCT_ITEMNUMBER,product_color,PRODUCT_SPECS;

    --插入预付订单详细表
    INSERT INTO TBL_PRE_ORDER_DETAIL
    (
        ID,ORDER_NUMBER,USER_ID,PRODUCT_SKU,PRODUCT_ITEMNUMBER,PRODUCT_COLOR,PRODUCT_SPECS,PRODUCT_SIZE,PRODUCT_COUNT,PRODUCT_UNIT_PRICE,PRODUCT_MONEY,MBR_CARD_REDUCE,
        ACTIVITY_PRODUCT_ID,ACTIVITY_PRODUCT_PRIZE_COST
    )
    SELECT
        SEQ_PRE_ORDER_DETAIL.NEXTVAL,v_order_number,c_user_name,ID,PRODUCT_ITEMNUMBER,PRODUCT_COLOR,PRODUCT_SPECS,PRODUCT_GROUP_MEMBER,b.count,
        decode(c_mbr_card,2,GETSKU_USER_VIPPRICE_PRE(c_user_name,ID),GETSKU_USER_SALEPRICE_PRE(c_user_name,ID)),
        decode(c_mbr_card,2,GETSKU_USER_VIPPRICE_PRE(c_user_name,ID),GETSKU_USER_SALEPRICE_PRE(c_user_name,ID)) * b.count,
        decode(c_mbr_card,2,GETSKU_USER_SALEPRICE_PRE(c_user_name,ID) - GETSKU_USER_VIPPRICE_PRE(c_user_name,ID),0),
        b.ACTIVITY_PRODUCT_ID,  getSku_User_QuotePrice(c_user_name, A.ID, 1, b.count, c_mbr_card)
     FROM TBL_PRODUCT_SKU a,TMP_ORDER_PRODUCT_SKU b
    WHERE a.ID = b.product_sku;

    --获取商品总数
    SELECT SUM(PRODUCT_COUNT) into v_product_count FROM TBL_PRE_ORDER_DETAIL WHERE ORDER_NUMBER = v_order_number;

    --获取商品总价
    SELECT SUM(PRODUCT_MONEY) INTO v_product_money FROM TBL_PRE_ORDER_DETAIL WHERE ORDER_NUMBER = v_order_number;
    
    --获取 订单在使用会员卡优惠后，减少的金额
    SELECT SUM(MBR_CARD_REDUCE * PRODUCT_COUNT) INTO v_mbr_card_reduce FROM TBL_PRE_ORDER_DETAIL WHERE ORDER_NUMBER = v_order_number;

    --校验是否存在单价为0的商品，存在则不允许提交
    select count(1) into t_result_count from TBL_PRE_ORDER_DETAIL WHERE ORDER_NUMBER = v_order_number AND PRODUCT_UNIT_PRICE = 0;
    if t_result_count > 0 then
        output_msg:='订单中商品价格异常(部分商品单价为)，请重新下单！';
        ROLLBACK;
        RETURN;
    end if;
    --校验商品总价是否被篡改
    IF v_product_money <> c_product_money THEN
        output_msg:='商品价格被篡改或商品价格发生变化,订单总价（'||v_product_money||'），请重新下单！';
        ROLLBACK;
        RETURN;
    END IF;
    

    --获取预付定金比例
    select deposit_percent into v_deposit_percent from TBL_ACTIVITY_DETAIL where activity_id = c_activity_id;

    --计算预付定金金额
    v_earnest_money := round(v_product_money * v_deposit_percent, 2);
    
     --校验订单中是否包含活动商品
    select count(1) into v_temp_activity_product_count
    from tbl_pre_order_info oi
    where oi.activity_id > 0
    and exists(
        select 1
        from tbl_pre_order_detail op
        where oi.order_number = op.order_number
        and op.activity_product_id > 0
    );
    --更新预付订单主表信息
    UPDATE TBL_PRE_ORDER_INFO SET PRODUCT_MONEY = v_product_money,PRODUCT_COUNT = v_product_count,earnest_money = v_earnest_money,mbr_card_reduce = v_mbr_card_reduce,
        LAST_CANCEL_DATE = (
          CASE WHEN v_temp_activity_product_count > 0 then GETORDERLASTCANCELDATE(v_order_number, 2)
          else create_date + 1
          end
        )  
    WHERE ORDER_NUMBER = v_order_number;
     /*************
        2019.10.14 reid
        判断下单商品是鞋类还是非鞋类，
        如果是鞋类,则需要删除规格下的所有SKU
        如果是非鞋类，则需要删除该颜色下的所有SKU
     *************/
     BEGIN
         FOR tb IN(
                select product_itemnumber from TBL_PRE_ORDER_DETAIL
                where order_number =  v_order_number
                group by product_itemnumber
         ) LOOP
                 select to_number(type) into v_product_type from tbl_dic_product_type dpt
                 where exists (
                    select 1 from TBL_PRODUCT_INFO pi
                    inner join TBL_PRODUCT_SKU ps on pi.itemnumber = ps.product_itemnumber
                    inner join TBL_PRE_ORDER_DETAIL pod on pod.product_sku = ps.id
                    WHERE pod.order_number = v_order_number
                    and dpt.id = pi.product_type_id
                    and pi.itemnumber = tb.product_itemnumber
                 );
                 IF v_product_type = 1 THEN
                    --鞋类（删除规格下的所有尺码）
                    delete from TBL_PRE_USER_CART puc
                    where puc.product_sku in (
                        select id from TBL_PRODUCT_SKU tps where tps.parent_id in (
                            select 
                            ps.parent_id
                            from TBL_PRE_ORDER_DETAIL pod 
                            inner join TBL_PRODUCT_SKU ps on pod.product_sku = ps.id
                            where pod.order_number =  v_order_number
                            and ps.product_group = '尺码'
                            and ps.product_itemnumber = tb.product_itemnumber
                        ) and tps.product_group = '尺码'
                    )
                    and puc.activity_id = c_activity_id
                    and puc.user_id = c_user_name;
                 ELSE
                    ---非鞋类（删除颜色下的所有尺码）
                     delete from TBL_PRE_USER_CART puc where puc.product_sku in (
                         select id from TBL_PRODUCT_SKU nod
                         start with nod.id in (
                           select parent_id from TBL_PRODUCT_SKU tps where tps.id in (
                                select 
                                ps.parent_id
                                from TBL_PRE_ORDER_DETAIL pod 
                                inner join TBL_PRODUCT_SKU ps on pod.product_sku = ps.id
                                where pod.order_number = v_order_number
                                and ps.product_group = '尺码'
                                and ps.product_itemnumber = tb.product_itemnumber
                            ) 
                            and tps.product_group = '规格'
                         )
                         connect by PRIOR nod.id = nod.parent_id
                     )
                     and puc.activity_id = c_activity_id
                     and puc.user_id = c_user_name;
                 END IF;
         END LOOP;
     END;
    --记录预付订单商品清分规则
    --入驻商货款
    insert into TBL_PRE_ORDER_DIVIDE(ID,ORDER_NUMBER,PRODUCT_SKU,DIVIDE_TYPE,STATIONED_USER_ID,DIVIDE_MONEY,PRODUCT_PRICE)
    select SEQ_PRE_ORDER_DIVIDE.nextval,
        v_order_number,
        PRODUCT_SKU,
        '1',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        GETSKU_USER_LIQUIDATIONPRICE(1,c_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,c_mbr_card),
        PRODUCT_UNIT_PRICE
    from TBL_PRE_ORDER_DETAIL where ORDER_NUMBER = v_order_number;

    --平台服务费
    insert into TBL_PRE_ORDER_DIVIDE(ID,ORDER_NUMBER,PRODUCT_SKU,DIVIDE_TYPE,STATIONED_USER_ID,DIVIDE_MONEY,PRODUCT_PRICE)
    select SEQ_PRE_ORDER_DIVIDE.nextval,
        v_order_number,
        PRODUCT_SKU,
        '2',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        GETSKU_USER_LIQUIDATIONPRICE(2,c_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,c_mbr_card),
        PRODUCT_UNIT_PRICE
    from TBL_PRE_ORDER_DETAIL where ORDER_NUMBER = v_order_number;

    --仓储费
    insert into TBL_PRE_ORDER_DIVIDE(ID,ORDER_NUMBER,PRODUCT_SKU,DIVIDE_TYPE,STATIONED_USER_ID,DIVIDE_MONEY,PRODUCT_PRICE)
    select SEQ_PRE_ORDER_DIVIDE.nextval,
        v_order_number,
        PRODUCT_SKU,
        '3',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        GETSKU_USER_LIQUIDATIONPRICE(3,c_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,c_mbr_card),
        PRODUCT_UNIT_PRICE
    from TBL_PRE_ORDER_DETAIL where ORDER_NUMBER = v_order_number;

    --入驻商服务费
    insert into TBL_PRE_ORDER_DIVIDE(ID,ORDER_NUMBER,PRODUCT_SKU,DIVIDE_TYPE,STATIONED_USER_ID,DIVIDE_MONEY,PRODUCT_PRICE)
    select SEQ_PRE_ORDER_DIVIDE.nextval,
        v_order_number,
        PRODUCT_SKU,
        '4',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        GETSKU_USER_LIQUIDATIONPRICE(4,c_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,c_mbr_card),
        PRODUCT_UNIT_PRICE
    from TBL_PRE_ORDER_DETAIL where ORDER_NUMBER = v_order_number;
    
    --入驻商支付服务费
    insert into TBL_PRE_ORDER_DIVIDE(ID,ORDER_NUMBER,PRODUCT_SKU,DIVIDE_TYPE,STATIONED_USER_ID,DIVIDE_MONEY,PRODUCT_PRICE)
    select SEQ_PRE_ORDER_DIVIDE.nextval,
        v_order_number,
        PRODUCT_SKU,
        '5',
        (select STATIONED_USER_ID from tbl_product_info where itemnumber = product_itemnumber),
        GETSKU_USER_LIQUIDATIONPRICE(5,c_user_name,PRODUCT_SKU,PRODUCT_UNIT_PRICE,c_mbr_card),
        PRODUCT_UNIT_PRICE
    from TBL_PRE_ORDER_DETAIL where ORDER_NUMBER = v_order_number;

    output_status := '1';
    output_msg := v_order_number;
    output_earnest_money := v_earnest_money;
exception when others then
    output_status := 0;
    output_msg:='提交订单出现未知错误::'||SQLCODE || '::'||SQLERRM||'----';
end submit_pre_order;
/

