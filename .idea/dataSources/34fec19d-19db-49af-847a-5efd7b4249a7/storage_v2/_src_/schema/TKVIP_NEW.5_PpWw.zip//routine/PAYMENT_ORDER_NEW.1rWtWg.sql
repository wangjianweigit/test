create PROCEDURE           payment_order_NEW
/**
   订单付款
    wangpeng
    2016-03-21
    2016-11-02 增加收支记录业务归属记录处理 shif
    20170309   增加多仓下单合并付款的处理。
    返回值：付款结果消息
**/
(

        client_user_name in varchar2,               --用户名
        client_pay_trade_number in varchar2,            --付款交易号
        client_balance_money in number,             --余额支付金额
        client_credit_money in number,              --授信支付金额
        client_third_money in number,               --第三方支付金额
        client_third_type in varchar2,              --第三方信息体  支付宝 微信 银联
        client_third_number in varchar2,            --第三方支付号码
        output_status  out varchar2,                --返回的状态码 0-失败 1-成功 2-充值成功，但无法完成订单支付
        output_msg out varchar2                     --返回的信息
) AS
    v_record_number varchar2(50);          --收付单号
    v_remark varchar2(300);                 --摘要
    v_total_count number:=0;                   --总商品数量
    v_temp_count number:=0;                     --临时变量
    v_user_manage_name varchar2(50);            --客户姓名
    v_account_balance_begin number:=0;                --客户充值前余额
    v_account_balance number:=0;                --客户余额
    v_credit_money_balance number:=0;           --授信余额
    v_account_balance_checkcode varchar2(32);  --余额校验码
    v_credit_checkcode varchar2(32);       --授信余额校验码
    v_create_code varchar2(32);             --计算的校验码
    v_user_key varchar2(32);               --用户KEY
    v_credit_money_use number:=0;           --授信已使用
    v_user_id number:=0;                        --用户ID
    v_payment_state varchar2(50);               --付款状态
    v_order_state varchar2(50);            --订单流程状态
    v_logistics_money number:=0;                --数据库中的物流费用
    v_product_money number:=0;                  --数据库中的商品总价
    v_all_record_type varchar(30);              --付款渠道组合信息
    v_ORDER_TYPE varchar(50);                   --订单类型
    v_df_money number:=0;                        --代发费用
    V_YWY_USERNAME VARCHAR2(100);--业务员用户名-【收支记录】
    V_YWJL_USERNAME VARCHAR2(100);--业务经理用户名-【收支记录】
    V_MDID NUMBER;--门店ID-【收支记录】
    v_order_numbers varchar2(1000);--合并付款的订单号列表
    v_temp_order_numbers varchar2(1000) :='1001';--已付款的订单号列表
    v_frozen_balance number := 0;                --冻结余额
    v_frozen_checkcode varchar2(32);            --冻结余额校验码
    v_frozen_balance_use number := 0;           --冻结余额使用金额
    v_earnest_money number := 0;                --定金扣减金额
    v_pre_order_number varchar2(50);            --预付订单号
    v_order_count number := 0;                  --商品数量
    v_pre_order_count number := 0;              --预付商品数量
    v_pre_payment_type number := 0;             --预付订单支付类型
BEGIN
    output_status:='0';
    --获取用户信息
    select count(*) into v_temp_count from tbl_user_info where user_name = client_user_name;
    if v_temp_count<>0 then
        select user_manage_name,id into v_user_manage_name,v_user_id from tbl_user_info where user_name = client_user_name;
    else
        output_msg:='用户信息不能为空，请检查!';
        return;
    end if;

    --获取账户信息
    select count(*) into v_temp_count from TBL_BANK_ACCOUNT where USER_ID = v_user_id;
    if v_temp_count<>0 then
        select account_balance,credit_money_balance,credit_money_use,account_balance_checkcode,credit_checkcode,frozen_balance,frozen_checkcode 
        into v_account_balance_begin,v_credit_money_balance,v_credit_money_use,v_account_balance_checkcode,v_credit_checkcode,v_frozen_balance,v_frozen_checkcode 
        from TBL_BANK_ACCOUNT where USER_ID = v_user_id;
    else
        output_msg:='用户账户信息不能为空，请检查!';
        return;
    end if;

    --获取商品总数量
    /*select nvl(sum(PRODUCT_COUNT),0) into v_total_count from tbl_order_product where ORDER_NUMBER=client_order_number and USER_NAME=client_user_name;*/
    select nvl(sum(t1.product_count), 0)
      into v_total_count
      from tbl_order_info t1
     where user_name = client_user_name
           and exists(select 1
                        from tbl_order_union_pay_detail t2
                       where t2.pay_trade_number = client_pay_trade_number
                             and t2.order_number = t1.order_number);
    --获取收付单号
    v_record_number:=getAutoNumber('XD');

    --验证余额是否被篡改-----------------------------------------------------------------------------------------------------------------------------------------
    --获取用户KEY
    select getUserKey(client_user_name,'old','1') into v_user_key from dual;
    --获取余额校验码并判断是否被篡改
    v_create_code:=getCheck_Code(client_user_name,v_account_balance_begin,v_user_key);
    --DBMS_OUTPUT.put_line('比对余额校验码========='||v_account_balance_checkcode||'-------'||v_create_code);
    if v_account_balance_checkcode is null or v_account_balance_checkcode<>v_create_code then
        output_msg:='余额发生篡改，无法完成当前操作!';
        return;
    end if;
    --验证授信是否被篡改---------------------------------------------------------------------------------------------------------------------------------------------
    --获取授信校验码并判断是否被篡改
    v_create_code:=getCheck_Code(client_user_name,v_credit_money_balance,v_user_key);
    --DBMS_OUTPUT.put_line('比对授信校验码========='||v_credit_checkcode||'-------'||v_create_code);
    if v_credit_checkcode is null or v_credit_checkcode<>v_create_code then
        output_msg:='授信余额发生篡改，无法完成当前操作!';
        return;
    end if;
    --验证冻结余额是否被篡改---------------------------------------------------------------------------------------------------------------------------------------------
    --获取冻结余额校验码并判断是否被篡改
    v_create_code:=getCheck_Code(client_user_name,v_frozen_balance,v_user_key);
    --DBMS_OUTPUT.put_line('比对授信校验码========='||v_credit_checkcode||'-------'||v_create_code);
    if v_frozen_checkcode is null or v_frozen_checkcode<>v_create_code then
        output_msg:='冻结余额发生篡改，无法完成当前操作!';
        return;
    end if;

    --验证订单号码是否存在
     --select count(*) into v_temp_count from TBL_ORDER_INFO where PARENT_ORDER_NUMBER=client_order_number and USER_NAME=client_user_name;
      select  count(1)
      into v_temp_count
      from tbl_order_info t1
     where user_name = client_user_name
           and exists(select 1
                        from tbl_order_union_pay_detail t2
                       where t2.pay_trade_number = client_pay_trade_number
                             and t2.order_number = t1.order_number);
    if v_temp_count<>0 then
        select wm_concat(t2.order_number) into v_order_numbers
          from tbl_order_union_pay_detail t2
         where t2.pay_trade_number = client_pay_trade_number;

        v_remark:='付订单货款时，生成充值记录,商品明细请见订单号码:'||v_order_numbers;
       SELECT t1.MD_ID AS MDID,t1.YWY_USER_NAME AS YWY_USER_NAME,t1.YWJL_USER_NAME AS YWJL_USERNAME Into V_MDID,V_YWY_USERNAME,V_YWJL_USERNAME
         FROM tbl_order_info t1
        WHERE user_name = client_user_name
           and exists(select 1
                        from tbl_order_union_pay_detail t2
                       where t2.pay_trade_number = client_pay_trade_number
                             and t2.order_number = t1.order_number)
           and rownum <=1;
    else
        v_remark:='付订单货款时，但由于订单号码错误，无法完成订单，生成充值记录,钱款已转入您的余额';
    end if;
        --业务归属处理--
    IF V_YWY_USERNAME IS NULL AND V_YWJL_USERNAME IS NULL AND V_MDID IS NULL THEN
      SELECT T.REFEREE_USER_ID AS YWY_USER_NAME,T.MARKET_SUPERVISION_USER_ID AS YWJL_USER_NAME,T.STORE_ID AS MD_ID
        INTO V_YWY_USERNAME,V_YWJL_USERNAME,V_MDID
        FROM TBL_USER_INFO T
       WHERE T.USER_NAME = client_user_name;
    END IF;

    if v_temp_count<>0 then
        --获取流程状态，支付状态
        select wm_concat(t1.order_number)
          into v_temp_order_numbers
          from tbl_order_info t1
         where t1.USER_NAME=client_user_name
               and (t1.order_state <> 1 or t1.payment_state <> 1)
               and exists(select 1
                        from tbl_order_union_pay_detail t2
                       where t2.pay_trade_number = client_pay_trade_number
                             and t2.order_number = t1.order_number);
    else
        output_msg:='订单号码有误，无法完成该订单，请检查!';
        if client_third_money>0 then
            output_msg:='付订单货款时，但由于订单号码错误，无法完成订单，钱款已转入您的余额!';
        end if;
        output_status:='2';
        return;
    end if;

    --验证订单状态和支付状态是否为 未支付, 【已支付的订单】
    if v_temp_order_numbers is not null and v_temp_order_numbers <> '1001' then
        output_msg:=v_temp_order_numbers||'订单已付款，无需重复付款!';
        if client_third_money>0 then
            output_msg:=v_temp_order_numbers||'订单已付款，无需重复付款，钱款已转入您的余额!';
        end if;
        output_status:='2';
        return;
    end if;
    --获取订单需支付的金额
    select sum(t1.logistics_money),sum(t1.product_money),sum(case when t1.order_type='代发' then df_money else  0 end) as df_money,
        sum(nvl((select earnest_money from TBL_PRE_ORDER_RELATE where ORDER_NUMBER = t1.order_number),0)) as earnest_money,
        min(nvl((select pre_order_number from TBL_PRE_ORDER_RELATE where ORDER_NUMBER = t1.order_number),'0')) as pre_order_number
          into v_logistics_money,v_product_money,v_df_money,v_earnest_money,v_pre_order_number
    from tbl_order_info t1
         where t1.USER_NAME=client_user_name
               and exists(select 1
                        from tbl_order_union_pay_detail t2
                       where t2.pay_trade_number = client_pay_trade_number
                             and t2.order_number = t1.order_number);
    /*if v_ORDER_TYPE='批发' then
        --验证支付总额是否等于 余额支付金额+授信支付金额+第三方支付金额
        if (client_balance_money+client_credit_money+client_third_money)<>(v_logistics_money+v_product_money) then
            output_msg:='您支付的金额与（商品总价+物流费用）不符!';
            if client_third_money>0 then
                output_msg:='您支付的金额与（商品总价+物流费用）不符，钱款已转入您的余额!';
                --更新用户账户校验码
                update_user_account_code(client_user_name);
                commit;
                output_status:='2';
            end if;
            return;
        end if;
    end if;

    if v_ORDER_TYPE='代发' then
        --验证支付总额是否等于 余额支付金额+授信支付金额+第三方支付金额
        if (client_balance_money+client_credit_money+client_third_money)<>(v_logistics_money+v_product_money+v_df_money) then
            output_msg:='您支付的金额与（商品总价+物流费用+代发费用）不符!';
            if client_third_money>0 then
                output_msg:='您支付的金额与（商品总价+物流费用+代发费用）不符，钱款已转入您的余额!';
                --更新用户账户校验码
                update_user_account_code(client_user_name);
                commit;
                output_status:='2';
            end if;
            return;
        end if;
    end if;*/
    --验证支付总额是否等于 余额支付金额+授信支付金额+第三方支付金额+定金扣除金额
    if (client_balance_money+client_credit_money+client_third_money)<>(v_logistics_money+v_product_money + v_df_money - v_earnest_money) then
            output_msg:='您支付的金额与（商品总价+物流费用+代发费用）不符!';
            if client_third_money>0 then
                output_msg:='您支付的金额与（商品总价+物流费用+代发费用）不符，钱款已转入您的余额!';
            end if;
            output_status:='2';
            return;
     end if;
     
     select nvl(max(case when t.payment_type = '授信' then 1 else 0 end),0) into v_pre_payment_type from TBL_PRE_ORDER_INFO t,TBL_PRE_ORDER_RELATE t1,tbl_order_union_pay_detail t2 
     where t.order_number = t1.pre_order_number and t2.order_number = t1.order_number and t2.pay_trade_number = client_pay_trade_number;


    --当预定订单支付方式非授信支付时，验证余额是否大于等于需支付金额
    if v_pre_payment_type = 0 and v_account_balance_begin>=(v_logistics_money+v_product_money+v_df_money-v_earnest_money) then
        --如果授信不等于0
        if client_credit_money>0 then
           output_msg:='您的余额可以足额支付货款，请勿选择授信支付!';
            if client_third_money>0 then
                output_msg:='您的余额可以足额支付货款，请勿选择授信支付，钱款已转入您的余额!';
            end if;
            output_status:='2';
           return;
        end if;
    end if;
    

   --如果第三方支付不为0，则生成消费记录，并扣减余额为 用户余额-第三方支付金额      收付渠道为：支付宝、微信、银联
    if client_third_money<>0 then
        v_all_record_type:=v_all_record_type||client_third_type;
        v_remark:='付订单货款';
        --当订金金额大于0时，增加订金抵扣备注
        if v_earnest_money > 0 then
            v_remark := v_remark||'（订金抵扣'||v_earnest_money||'元）';
        end if;
        v_remark := v_remark||'，商品明细请见订单号码:'||v_order_numbers;
        insert into TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
                         CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
                         ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
                         PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
                         MONEY, COUNT, SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,
                         CHECK_DATE,TURNOVER_NUMBER,third_number,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,CREDIT_BALANCE)
        values(SEQ_USER_ACCOUNT_RECORD.NEXTVAL,v_record_number||'2',1,client_third_type,'付款', v_remark,
               sysdate,client_user_name,v_user_manage_name,
               '2121TK','童库',
               '2121','应付账款',
                client_third_money,v_total_count,v_account_balance_begin-client_third_money,'已审核',client_pay_trade_number,client_user_name,client_user_name,
                sysdate,v_record_number,client_third_number,V_YWJL_USERNAME,V_YWY_USERNAME,V_MDID,v_credit_money_balance);

    end if;

    --如果余额支付不为0
     if client_balance_money<>0 then
        if v_all_record_type !='' then
            v_all_record_type:=v_all_record_type||'+';
        end if;
        v_all_record_type:=v_all_record_type||'余额';
        --验证余额是否大于支付金额
        if client_balance_money>v_account_balance_begin then
            output_msg:='账户余额不足!无法完成该订单!';
            if client_third_money>0 then
                output_msg:='账户余额不足!无法完成该订单，钱款已转入您的余额!';
            end if;
            output_status:='2';
            return;
        else
            --生成消费记录，并扣减余额为 用户余额=用户余额-第三方支付金额-余额支付金额  收付渠道为：余额
            v_remark:='付订单货款';
            --当未使用第三方支付，并且订金金额大于0时，增加订金抵扣备注
            if client_third_money = 0 and v_earnest_money > 0 then
                v_remark := v_remark||'（订金抵扣'||v_earnest_money||'元）';
            end if;
            v_account_balance:=v_account_balance_begin-client_third_money-client_balance_money;
            if v_frozen_balance > client_balance_money then
                v_frozen_balance := v_frozen_balance - client_balance_money;
                v_frozen_balance_use := client_balance_money;
                v_remark := v_remark||'，其中冻结余额支付'||v_frozen_balance_use||'元';
            else
                if v_frozen_balance > 0 then
                    v_frozen_balance_use := v_frozen_balance;
                    v_frozen_balance := 0;
                    v_remark := v_remark||'，其中冻结余额支付'||v_frozen_balance_use||'元';
                end if;
            end if;
            
            v_remark := v_remark||'，商品明细请见订单号码:'||v_order_numbers;
            insert into TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
                             CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
                             ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
                             PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
                             MONEY, COUNT, SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,
                             CHECK_DATE,TURNOVER_NUMBER,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,CREDIT_BALANCE)
            values(SEQ_USER_ACCOUNT_RECORD.NEXTVAL,v_record_number||'3',1,'余额','付款', v_remark,
                   sysdate,client_user_name,v_user_manage_name,
                   '2121TK','童库',
                   '2121','应付账款',
                    client_balance_money,v_total_count,v_account_balance,'已审核',client_pay_trade_number,client_user_name,client_user_name,
                    sysdate,v_record_number,V_YWJL_USERNAME,V_YWY_USERNAME,V_MDID,v_credit_money_balance);
        end if;
    end if;

    --如果授信支付不为0
     if client_credit_money<>0 then
         if v_all_record_type!='' then
            v_all_record_type:=v_all_record_type||'+';
        end if;
        v_all_record_type:=v_all_record_type||'授信';
        --验证授信是否大于授信支付金额
        if client_credit_money>v_credit_money_balance then
            output_msg:='授信余额不足!无法完成该订单!';
            if client_third_money>0 then
                output_msg:='授信余额不足!无法完成该订单，钱款已转入您的余额!';
            end if;
            output_status:='2';
            return;
        else
            --生成消费记录，并扣减用户授信为  用户授信余额=用户授信余额-授信支付金额   收付渠道为：授信
            v_remark:='付订单货款,商品明细请见订单号码:'||v_order_numbers;
            v_credit_money_use:=v_credit_money_use+client_credit_money;
            v_credit_money_balance := v_credit_money_balance - client_credit_money;
            insert into TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
                             CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
                             ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
                             PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
                             MONEY, COUNT, SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,
                             CHECK_DATE,TURNOVER_NUMBER,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,CREDIT_BALANCE)
            values(SEQ_USER_ACCOUNT_RECORD.NEXTVAL,v_record_number||'4',1,'授信','付款', v_remark,
                   sysdate,client_user_name,v_user_manage_name,
                   '2121TK','童库',
                   '2121','应付账款',
                    client_credit_money,v_total_count,v_account_balance_begin,'已审核',client_pay_trade_number,client_user_name,client_user_name,
                    sysdate,v_record_number,V_YWJL_USERNAME,V_YWY_USERNAME,V_MDID,v_credit_money_balance);
            
        end if;
    end if;

    --更新订单支付状态、配货状态
    update tbl_order_info t1
       set t1.payment_number=v_record_number,t1.order_state=2,t1.payment_state=2,t1.check_state=1,
           t1.payment_date=sysdate,t1.payment_money=(t1.product_money + t1.logistics_money + case when t1.order_type='代发' then df_money else  0 end),t1.payment_type=v_all_record_type
     where t1.user_name=client_user_name
           and exists(select 1
                        from tbl_order_union_pay_detail t2
                       where t2.pay_trade_number = client_pay_trade_number
                             and t2.order_number = t1.order_number);

    --更新账户余额、授信
    update TBL_BANK_ACCOUNT set account_balance=(account_balance-client_balance_money-client_third_money),
        credit_money_balance=(credit_money_balance-client_credit_money),credit_money_use=(credit_money_use+client_credit_money),frozen_balance=v_frozen_balance where user_id = v_user_id;

    --更新用户账户校验码
    PRO_UPDATE_USER_ACCOUNT_CODE(client_user_name);
    
    --增加冻结余额使用记录
    insert into TBL_FROZEN_BALANCE_USE(id,order_number,user_id,use_money) values(SEQ_FROZEN_BALANCE_USE.nextval,client_pay_trade_number,v_user_id,v_frozen_balance_use);

    --更新合并支付记录状态
    update tbl_order_union_pay set state =1,pay_date = sysdate where pay_trade_number = client_pay_trade_number;
    
    --循环处理预付订单
    declare cursor c_pre_order_relate is select t1.pre_order_number,t1.order_number,t1.earnest_money from TBL_PRE_ORDER_RELATE t1,tbl_order_union_pay_detail t2 where t2.pay_trade_number = client_pay_trade_number and t2.order_number = t1.order_number;
    
    begin
        for r_relate in c_pre_order_relate loop
            --获取所有已支付尾款订单的商品数量
            select sum(t1.product_count) into v_order_count
            from tbl_order_info t1
            where exists(select 1 from TBL_PRE_ORDER_RELATE t2
                           where t2.PRE_ORDER_NUMBER = r_relate.pre_order_number
                                 and t2.order_number = t1.order_number)
                and PAYMENT_STATE = 2;
                                 
            --获取预付订单商品数量
            select PRODUCT_COUNT into v_pre_order_count from TBL_PRE_ORDER_INFO where order_number = r_relate.pre_order_number;
            
            --判断预付订单是否全部完结
            if v_pre_order_count <= v_order_count then
                update TBL_PRE_ORDER_INFO set PAYMENT_USE_MONEY = nvl(PAYMENT_USE_MONEY, 0) + r_relate.earnest_money,ORDER_STATE = '5',FINISH_DATE = sysdate where order_number = r_relate.pre_order_number;
            else
                update TBL_PRE_ORDER_INFO set PAYMENT_USE_MONEY = nvl(PAYMENT_USE_MONEY, 0) + r_relate.earnest_money,ORDER_STATE = '3' where order_number = r_relate.pre_order_number;
            end if;
            
            update TBL_PRE_ORDER_DETAIL set PLACE_STATE = '2' where order_number = r_relate.pre_order_number
                and product_sku in (select product_sku from TBL_ORDER_PRODUCT_SKU a where order_number = r_relate.order_number);
        end loop;
    end;

    output_status:='1';
    output_msg:='订单支付成功';
EXCEPTION WHEN OTHERS THEN
    output_msg:='订单支付出现未知错误';
    ROLLBACK;
END payment_order_NEW;
/

