create TYPE           "T_ORDER_PRODUCT_PDA" FORCE  as object
(
    product_sku int,  --订单商品sku
    count int,  --订单sku数量
    edit_state int,--调价状态 1.未调价    2.已调价
    new_product_price number,
    product_gbcode VARCHAR2 (500 Byte) --sku国标码
);
/

