create FUNCTION PVTP_GETPRODUCT_TAGS_LIST
/**
   获取私有平台商品列表商品的活动标签信息 
   create by reid 2019.09.05
**/
(
    c_stationed_user_id     number,      --当前访问的私有平台ID（即所属私有商家的ID）
    c_user_name             varchar2,    --用户名
    c_product_itemnumber    varchar2     --商品货号  
) return varchar2
 is
     v_count number:=0;                     --通用临时参数
     v_user_id number:=0;                   --用户id
     v_hd_flag number:=-1;                  --是否参加了活动
     v_site_id number:=0;                   --会员站点
     v_tag_color varchar2(20);              --活动标签颜色
     v_tag_name varchar2(100);              --活动标签名称
     v_tag_img_wx varchar2(500);            --移动端标签图片
     v_tag_img_pc varchar2(500);            --pc端标签图片
     v_tag_level number:=2;                 --列表页标签等级
     v_return_tags varchar2(500);           --需要返回的标签
begin

   --查询会员站点
   select nvl(min(site_id),0),nvl(min(id),0)
   into v_site_id,v_user_id
   from tbl_user_info where user_name = c_user_name;
   ---会员不存在，直接返回空
   IF v_user_id=0 THEN 
        RETURN v_return_tags;
   END IF;
   --判断商品是私有商品还是童库分享得商品
   select count(1) into v_count from TBL_PVTP_PRODUCT_INFO where itemnumber = c_product_itemnumber and stationed_user_id = c_stationed_user_id;
   IF v_count<>0 THEN
       --判断商品是否参加了私有平台本身的商城活动
       select 
       nvl(min(ssap.id),-1),nvl(min(ssa.tag_name),'1')
       into v_hd_flag,v_tag_name
       from TBL_STA_SALE_ACTIVITY_PRODUCT ssap
       INNER JOIN TBL_STA_SALE_ACTIVITY ssa on ssa.id = ssap.activity_id
       where sysdate between ssa.begin_date and ssa.end_date
       and ssa.activity_state = 1
       and ssa.is_delete = 1
       and ssa.stationed_user_id = c_stationed_user_id
       and ssap.is_delete = 1
       and ssap.product_itemnumber = c_product_itemnumber;
   ELSE
       ---查询是否是童库平台分享至私有平台的商品
       SELECT COUNT(1) INTO v_count from TBL_PRODUCT_INFO pi 
       where pi.itemnumber = c_product_itemnumber 
       and pi.is_private = 1
       AND EXISTS(
            select 1 from TBL_PVTP_PRODUCT_INFO_REF ppir
            WHERE ppir.product_id = pi.id and ppir.platform_id = c_stationed_user_id
            AND ppir.enabled_flag = 1
       );
       IF v_count= 0 THEN
          RETURN v_return_tags;
       END IF;
       ---判断商品是否参加了平台活动  ----限时折扣
        select nvl(min(c.id),-1),nvl(min(a1.tag_color),'1'),nvl(min(a1.tag_name),'1'),nvl(min(a1.tag_img_wx),'1'),nvl(min(a1.tag_img_pc),'1'),nvl(min(a1.tag_level),2) 
        into v_hd_flag,v_tag_color,v_tag_name,v_tag_img_wx,v_tag_img_pc,v_tag_level 
        from tbl_activity_info a ,tbl_activity_detail a1,tbl_activity_product c 
        where a.activity_state = '3' and a.state = '2' 
        and a.activity_type = '1'
        and sysdate between a.begin_date and a.end_date 
        and sysdate between c.activity_start_date and c.activity_end_date 
        and a.id = a1.activity_id
        and c.activity_id = a.id 
        and c.product_itemnumber =c_product_itemnumber
        and(case when (a1.user_group_id = 0 or a1.user_group_id is null) then 1 else case when 
            exists (select 1 from tbl_user_group aa,tbl_user_group_detail bb 
            where aa.id = bb.group_id and aa.state = '2' and a1.user_group_id = aa.id and bb.user_id = c_user_name AND (bb.ACTIVITY_ID = a1.activity_id OR bb.ACTIVITY_ID = 0)
            
            )then 1 else 0 end end
        ) = 1
        and exists (select 1 from tbl_activity_site tas where tas.activity_id = a.id and tas.site_id = v_site_id);
   END IF;
    --参加了活动
   IF v_hd_flag!=-1 THEN
        if v_tag_level = 1 then
            --附加活动标签
            v_return_tags := v_tag_level||'#-#'||v_tag_img_wx||'#-#'||v_tag_img_pc;
        else
            --附加活动标签
            v_return_tags := v_tag_level||'#-#'||v_tag_name||'#-#'||v_tag_color;
        end if;
   END IF;  
   return v_return_tags;
end PVTP_GETPRODUCT_TAGS_LIST;
/

