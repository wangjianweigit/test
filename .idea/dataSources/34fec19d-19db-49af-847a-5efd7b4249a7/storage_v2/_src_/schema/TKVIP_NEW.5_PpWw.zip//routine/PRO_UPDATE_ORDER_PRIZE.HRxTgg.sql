create PROCEDURE           pro_update_order_prize 
/**
   订单调价
    shif
    2017-05-02
    返回值：订单提交结果消息
**/ 
(
        client_order_number in varchar2,            --订单编号
        client_order_sku_ids in varchar2,           --商品SKU集合  使用逗号分隔
        client_order_old_prize in varchar2,         --商品原单价集合  使用逗号分隔
        client_order_new_prize in varchar2,         --商品折后单价集合  使用逗号分隔
        client_logistics_company_code in varchar2,  --物流公司代码
        client_logistics_money number:=0,           --物流费用
        client_update_reason in varchar2,            --调价原因,
        client_df_money in number:=0,               --代发费用
        output_status  out varchar2,                --返回的状态码 0-失败 1-成功
        output_msg out varchar2                     --返回的信息
) AS
    v_logistics_company_name varchar2(50);      --物流公司名称
    v_sku_count int:=0;                         --商品SKU数组个数
    v_sku_old_prize_count int:=0;               --商品原单价集合个数
    v_sku_new_prize_count int:=0;               --商品折后单价集合个数
    v_temp_count int:=0;                    --临时变量 计数
    temp_sku_id number:=0;          --临时变量  SKUID
    temp_sku_new_prize number:=0;   --临时变量  原单价
    temp_sku_old_prize number:=0;   --临时变量  折后单价
    v_order_state int:=0;            --订单总状态
    v_payment_state int:=0;            --订单付款状态
    v_order_type varchar2(50);            --订单类型
    v_df_money number:=0;   --临时变量  代发费用
BEGIN
    output_status:='0';
    --数据有效性校验
    v_sku_count:=length(replace(client_order_sku_ids,',',',-'))-length(client_order_sku_ids)+1;
    v_sku_old_prize_count:=length(replace(client_order_old_prize,',',',-'))-length(client_order_old_prize)+1;
    v_sku_new_prize_count:=length(replace(client_order_new_prize,',',',-'))-length(client_order_new_prize)+1;
    
    if v_sku_count<>v_sku_old_prize_count or v_sku_count<>v_sku_new_prize_count then
        output_msg:='商品个数与价格组个数不符!';
        return;
    end if;
    
    --校验SKU的有效性
    select v_sku_count-count(*) into v_temp_count from tbl_product_sku a,(
        select substr(t,1,instr(t,',',1)-1) skuid_str  from (
            select substr(s,instr(s,',',1,rownum)+1) as t,rownum as d ,instr(s,',',1,rownum)+1 from (
                select ','||client_order_sku_ids||','  as s from dual
            )connect by instr(s,',','1',rownum)>1
        ) where t is not null
    ) b where a.id = b.skuid_str;
    --DBMS_OUTPUT.PUT_LINE('-------：'||v_temp_count);
    if v_temp_count<>0 then
        output_msg:='SKU错误或已下架请检查SKU的有效性!';
        return;
    end if;
 
    --查询物流公司名称
    select count(*) into v_temp_count from TBL_LOGISTICS_COMPANY where code = client_logistics_company_code;
    if v_temp_count<>0 then 
        select name into v_logistics_company_name from TBL_LOGISTICS_COMPANY where code = client_logistics_company_code;
    else
        output_msg:='物流信息不能为空，请检查!';
        return;
    end if;
    
    --校验订单是否存在以及订单状态
    select count(*) into v_temp_count from tbl_order_info where ORDER_NUMBER=client_order_number;
    if v_temp_count<>0 then 
        --获取流程状态，支付状态
        select order_state,payment_state,order_type into v_order_state,v_payment_state,v_order_type from tbl_order_info where ORDER_NUMBER=client_order_number;
        --验证订单状态和支付状态是否为 未支付
        if v_order_state <> 1 OR v_payment_state <> 1 then
            output_msg:='当前订单状态为【'||v_order_state||'】，不支持调价!';
            return;
        end if;
    else
        output_msg:='订单号码有误，无法调价，请检查!';
        return;
    end if; 
    
    v_temp_count:=1;
    --修改订单详细表的价格
    while v_temp_count<=v_sku_count loop
        temp_sku_id:=getStrforArrid(','||client_order_sku_ids||',',',',v_temp_count);
        temp_sku_old_prize:=getStrforArrid(','||client_order_old_prize||',',',',v_temp_count);
        temp_sku_new_prize:=getStrforArrid(','||client_order_new_prize||',',',',v_temp_count);
        
        update tbl_order_product_sku 
            set product_unit_price = round(temp_sku_new_prize,2),
                product_old_unit_price = temp_sku_old_prize,
                product_total_discount_money = round((temp_sku_old_prize-temp_sku_new_prize)*count,2),
                product_total_money = round(temp_sku_new_prize*count,2)
        where ORDER_NUMBER = client_order_number and product_sku = temp_sku_id;
          
        v_temp_count:=v_temp_count+1;
    end loop;
    
    --修改订单规格表的单价
    update tbl_order_product ecl set ecl.product_unit_price=  
       (select ecd.product_unit_price From tbl_order_product_sku ECD 
            where ecl.user_name=ecd.user_name and  
                  ecl.order_number=ecd.order_number and 
                  ecl.itemnumber=ecd.product_itemnumber and ecl.product_specs=ecd.product_specs and ecl.product_color=ecd.product_color and
                  ecd.order_number=ecl.order_number and rownum<2)
       where ecl.order_number = client_order_number;           
    
    --计算商品优惠价格和商品总价
    update tbl_order_product ecl 
        set product_total_discount_money=(select round(sum(ecd.product_total_discount_money),2) from tbl_order_product_sku ecd where ecd.order_number=ECL.order_number and ecd.order_item_number=ecl.order_item_number),
            product_total_money=(select sum(ecd.product_total_money) from tbl_order_product_sku ecd where ecd.order_number=ECL.order_number and ecd.order_item_number=ecl.order_item_number)  
        where ecl.order_number=client_order_number;
     if v_order_type='代发' then
        v_df_money:=client_df_money;
     else 
        v_df_money:=0;   
     end if;   
     update tbl_order_info ech 
        set product_money=(select sum(ecl.product_total_money) from tbl_order_product ecl where ecl.order_number=ech.order_number), 
            discount_money=(select round(sum(ecl.product_total_discount_money),2) from tbl_order_product ecl where ecl.order_number=ech.order_number),
            logistics_company_code = client_logistics_company_code,
            logistics_company_name = v_logistics_company_name,
            logistics_money = client_logistics_money,
            update_reason = client_update_reason,
            df_money=v_df_money
        where ech.order_number=client_order_number;   
     output_status:='1';
     output_msg:='订单调价执行成功';
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='订单调价出现未知错误';
    ROLLBACK;
END pro_update_order_prize;
/

