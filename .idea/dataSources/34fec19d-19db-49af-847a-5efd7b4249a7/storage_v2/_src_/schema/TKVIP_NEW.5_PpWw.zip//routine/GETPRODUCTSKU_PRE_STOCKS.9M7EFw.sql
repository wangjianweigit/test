create FUNCTION           getProductSku_pre_stocks
/**
      获取商品sku预付订单付尾款可下单库存
      shif
      2017-10-08
      返回值：商品sku库存
  **/
(c_product_sku  NUMBER, --商品sku
 c_pre_order_number VARCHAR2 --预付订单号
 ) RETURN NUMBER IS
  v_product_sku_stock    NUMBER := 0; --需要返回的商品sku库存数据
  v_count                NUMBER := 0; --临时变量
  v_warehouse_id         NUMBER :=2;--预付订单固定仓库 华东仓
  v_logic_total_count    NUMBER := 0; --仓库可下逻辑库存数量
  v_pre_total_count      NUMBER := 0; --预付订单手工占用库存数量（在当前预付订单占用之前的）
  v_warehouse_date       DATE;     --预付订单手工占用时间
BEGIN
  --0.1判断预付单号是否存在
  SELECT COUNT(1)
    INTO v_count
    FROM TBL_PRE_ORDER_INFO TPOI
   WHERE TPOI.ORDER_NUMBER = c_pre_order_number;
  IF v_count <= 0 THEN
    RETURN 0;
  END IF;
  --0.2判断预付单号是否已手工占用
  SELECT COUNT(1)
    INTO v_count
    FROM TBL_PRE_ORDER_INFO TPOI
   WHERE TPOI.ORDER_NUMBER = c_pre_order_number
         AND TPOI.WAREHOUSE_STATE = '2'
         AND TPOI.WAREHOUSE_ID IS NOT NULL;
  --0.21未手工占用
  IF v_count <= 0 THEN
    SELECT NVL((SELECT NVL(PRODUCT_TOTAL_COUNT,0) -NVL(PRODUCT_ORDER_OCCUPY_COUNT,0)-NVL(PRE_ORDER_OCCUPY_COUNT,0)
              FROM TBL_PRODUCT_SKU_STOCK TPSS
             WHERE TPSS.PRODUCT_SKU = c_product_sku AND TPSS.WAREHOUSE_ID = v_warehouse_id),0) INTO v_product_sku_stock
      FROM DUAL;
    IF v_product_sku_stock <=0 THEN
       RETURN 0;
    ELSE
       RETURN v_product_sku_stock;
    END IF;
  END IF;
  --0.22 手工占用了
  SELECT TPOI.WAREHOUSE_ID,TPOI.WAREHOUSE_DATE
    INTO v_warehouse_id,v_warehouse_date
    FROM TBL_PRE_ORDER_INFO TPOI
   WHERE TPOI.ORDER_NUMBER = c_pre_order_number
         AND TPOI.WAREHOUSE_STATE = '2'
         AND TPOI.WAREHOUSE_ID IS NOT NULL;
  --0.23获取当前逻辑库存（未扣减预占用）
  SELECT NVL((SELECT NVL(PRODUCT_TOTAL_COUNT,0) -NVL(PRODUCT_ORDER_OCCUPY_COUNT,0)
              FROM TBL_PRODUCT_SKU_STOCK TPSS
             WHERE TPSS.PRODUCT_SKU = c_product_sku AND TPSS.WAREHOUSE_ID = v_warehouse_id),0) INTO v_logic_total_count
      FROM DUAL;
  IF v_logic_total_count <=0 THEN --逻辑库存不足
     RETURN 0;
  END IF;
  --0.24 获取在当前预付订单之前其他手工占用的总数
  SELECT NVL((SELECT SUM(TPOD.PRODUCT_COUNT)
            FROM TBL_PRE_ORDER_DETAIL TPOD,TBL_PRE_ORDER_INFO TPOI
           WHERE TPOD.ORDER_NUMBER = TPOI.ORDER_NUMBER
                 AND TPOI.ORDER_STATE IN('2','3','4')
                 AND TPOI.WAREHOUSE_DATE < v_warehouse_date
                 AND TPOD.PRODUCT_SKU = c_product_sku
                 AND TPOD.ORDER_NUMBER <> c_pre_order_number),0)
    INTO  v_pre_total_count
    FROM DUAL;
  v_product_sku_stock:= v_logic_total_count - v_pre_total_count;
  IF v_product_sku_stock <=0 THEN
     RETURN 0;
  END IF;
  --返回值
  RETURN v_product_sku_stock;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END getProductSku_pre_stocks;
/

