create FUNCTION           GET_PRODUCT_QUOTE_RANGE_BY_SKU
/**
    根据商品的ID以及其SKU_ID 查询该SKU的价格或价格区间
    获取一个商品的报价区间
    songwangwen
    2017.04.18
    返回值：商品价格价格区间 格式 最低价-最高价  示例  57.5-65.3
**/
(
    c_sku_id   number,--商品货号
    c_type number      --商品状态    1:待审核的商品 2:出售中的商品
        
) return varchar2
 is
 v_product_prize_str varchar2(50):='0.00-0.00';   --需要返回的商品价格
 v_prize_min number:=0;                           --最低报价
 v_prize_max number:=0;                           --最高报价
BEGIN
 /**************************查询待审批商品SKU表********************************/
   IF c_type = 1
   THEN
       --获取最低价
       select MIN(PRODUCT_PRIZE_COST) INTO v_prize_min from TBL_PRODUCT_SKU_APPLY ps start with ps.id = c_sku_id connect by PRIOR ps.id = ps.PARENT_ID;
       --获取高低价  
       select MAx(PRODUCT_PRIZE_COST) INTO v_prize_max from TBL_PRODUCT_SKU_APPLY ps start with ps.id = c_sku_id connect by PRIOR ps.id = ps.PARENT_ID;
   END IF;
 /**************************查询待审批通过商品SKU表********************************/
  IF c_type = 2
   THEN
        --获取最低价
       select MIN(PRODUCT_PRIZE_COST) INTO v_prize_min from TBL_PRODUCT_SKU ps start with ps.id = c_sku_id connect by PRIOR ps.id = ps.PARENT_ID;
       --获取高低价  
       select MAx(PRODUCT_PRIZE_COST) INTO v_prize_max from TBL_PRODUCT_SKU ps start with ps.id = c_sku_id connect by PRIOR ps.id = ps.PARENT_ID;
   END IF;
   --计算价格
   IF v_prize_min != v_prize_max
   THEN
         v_product_prize_str:= to_char(v_prize_min,'fm999999990.00') ||' - '||to_char(v_prize_max,'fm999999990.00');
   END IF;
   IF v_prize_min = v_prize_max
   THEN
         v_product_prize_str:= to_char(v_prize_min,'fm999999990.00');
   END IF;
   return v_product_prize_str;
END GET_PRODUCT_QUOTE_RANGE_BY_SKU;
/

