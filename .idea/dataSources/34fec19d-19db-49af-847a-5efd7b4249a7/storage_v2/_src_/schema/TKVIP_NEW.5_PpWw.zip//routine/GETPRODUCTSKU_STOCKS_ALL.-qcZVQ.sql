create FUNCTION           getProductSku_stocks_ALL
/**
    yejingquan 2019.05.08
    return  商品SKU全仓的逻辑库存(暂不考虑活动库存问题)
**/
(
   c_product_sku     NUMBER,                                      --商品sku
   c_warehouse_id    NUMBER                                       --仓库
)
   RETURN NUMBER
IS
   v_product_sku_stock        NUMBER := 0;--需要返回的商品sku库存数据
   v_count                    NUMBER := 0;--临时变量
   v_total_count              NUMBER := 0;--实际库存数量
   v_order_occupy_count       NUMBER := 0;--订单占用量
   v_pre_order_occupy_count   NUMBER := 0;--预付订单预占用量
   v_product_itemnumber       VARCHAR2 (50);--商品货号
BEGIN
   --0.0判断sku是否已下架
   select count (1) into v_count FROM TBL_PRODUCT_SKU tps where tps.state = '上架' and tps.id = c_product_sku;
   ---如果SKU非上架状态，直接返回0
   IF v_count <= 0
   THEN
      RETURN 0;
   END IF;

   --如果传入的仓库ID为0 则表示查询全仓,否则按仓查询
   IF c_warehouse_id = 0 THEN
       --1.0获取对应sku实际库存
       --1.1 查询是否存储库存信息
       SELECT COUNT (1) INTO v_count FROM TBL_PRODUCT_SKU_STOCK WHERE PRODUCT_SKU = c_product_sku;
       IF v_count <= 0
       THEN
          RETURN 0;
       END IF;
       /*1.2查询实际库存、占用库存、预占用库存***********************/
       SELECT nvl(sum(product_total_count),0),nvl(sum(product_order_occupy_count),0),nvl(sum(pre_order_occupy_count),0)
       INTO v_total_count, v_order_occupy_count, v_pre_order_occupy_count
       FROM TBL_PRODUCT_SKU_STOCK
       WHERE PRODUCT_SKU = c_product_sku;
       --1.3 计算库存信息 = sku实际库存量-订单占用量（多站点多活动） -预占用量
       v_product_sku_stock := v_total_count - v_order_occupy_count - v_pre_order_occupy_count;
   ELSE
       --1.0获取对应sku实际库存
       --1.1 查询是否存储库存信息
       SELECT COUNT (1) INTO v_count FROM TBL_PRODUCT_SKU_STOCK WHERE PRODUCT_SKU = c_product_sku AND WAREHOUSE_ID = c_warehouse_id;
       IF v_count <= 0
       THEN
          RETURN 0;
       END IF;
       /*1.2查询实际库存、占用库存、预占用库存***********************/
       SELECT nvl(sum(product_total_count),0),nvl(sum(product_order_occupy_count),0),nvl(sum(pre_order_occupy_count),0)
       INTO v_total_count, v_order_occupy_count, v_pre_order_occupy_count
       FROM TBL_PRODUCT_SKU_STOCK
       WHERE PRODUCT_SKU = c_product_sku AND WAREHOUSE_ID = c_warehouse_id;
       --1.3 计算库存信息 = sku实际库存量-订单占用量（多站点多活动） -预占用量
       v_product_sku_stock := v_total_count - v_order_occupy_count - v_pre_order_occupy_count;
   END IF;
   IF v_product_sku_stock < 0
   THEN
      v_product_sku_stock := 0;
   END IF;
   --返回值
   RETURN v_product_sku_stock;
EXCEPTION
   WHEN OTHERS
   THEN
      RETURN 0;
END getProductSku_stocks_All;
/

