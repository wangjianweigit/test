create FUNCTION PVTP_GETPRODUCT_STOCKS
/**
    查询整个商品货号在私有站展示的商品的逻辑库存 reid 2019.09.24
    return  商品sku在在某个仓库的（逻辑）库存量
**/
(
   c_stationed_user_id     number,                                --当前访问的私有平台ID（即平台所属私有商家的ID）
   c_product_itemnumber     varchar2,                             --商品货号
   c_warehouse_id    number,                                      --仓库
   c_user_name       varchar2                                     --用户user_name
)
   return number
is
   v_product_sku_stock        number := 0;--需要返回的商品sku库存数据
   v_count                    number := 0;--临时变量
   v_book_count               number := 0;--预售数量(当前可卖的数量。订单下单或取消订单或未发退款会进行扣减或加)
   v_total_count              number := 0;--仓库实际库存数量
   v_order_occupy_count       number := 0;--订单占用量
   v_pre_order_occupy_count   number := 0;--预付订单预占用量
   v_locked_stock_amount      number := 0;--活动量
   v_activity_sell_amount     number := 0;--活动已售量
   v_site_id                  number := 0;--会员所在的站点id
   v_activity_flag            number := 0;--是否参加活动标志 0-未参加 1-参加
   v_activity_id              number := 0;--参加的活动id
   v_activity_type            number := 0;--参加的活动类型 1：限时折扣；2：订货会；4：预售
   v_locked_stock             number := 0;--参加的活动是否锁定库存 1.共享库存   2.锁定库存
   v_product_itemnumber       varchar2 (50);--商品货号
   v_main_warehouse_id        number := 2;--默认仓库id，某些情况下，仅考虑该仓库的库存（当前仅仅考虑华东仓）
begin
   --0.0获取用户所在站点
   select tui.site_id into v_site_id from tbl_user_info tui where tui.user_name = c_user_name;
    --判断商品是私有商品还是童库分享的商品
    select count(1) into v_count from TBL_PVTP_PRODUCT_INFO ppi where ppi.stationed_user_id = c_stationed_user_id
    and ppi.itemnumber = c_product_itemnumber;
    IF v_count <> 0 THEN
         ---私有商品  
         select SUM(NVL(PVTP_GETPRODUCTSKU_STOCKS(c_stationed_user_id,ps.id,c_warehouse_id,c_user_name),0))
         into v_product_sku_stock
         from tbl_pvtp_product_sku ps
         where ps.product_itemnumber = c_product_itemnumber
         and ps.product_group = '尺码'
         and ps.state = '上架';
    ELSE
         --童库商品 
         select SUM(NVL(PVTP_GETPRODUCTSKU_STOCKS(c_stationed_user_id,ps.id,c_warehouse_id,c_user_name),0))
         into v_product_sku_stock
         from tbl_product_sku ps
         where ps.product_itemnumber = c_product_itemnumber
         and ps.product_group = '尺码'
         and ps.state = '上架'
         and ps.start_stop_state = 1;
    END IF;
   
   --返回值
   return v_product_sku_stock;
exception
   when others  then
   return 0;
end PVTP_GETPRODUCT_STOCKS;
/

