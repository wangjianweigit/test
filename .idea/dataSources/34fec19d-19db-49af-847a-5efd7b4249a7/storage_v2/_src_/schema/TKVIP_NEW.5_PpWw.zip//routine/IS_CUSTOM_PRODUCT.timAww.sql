create FUNCTION is_custom_product
/**
    （新版）通过用户、货号判断商品可支持定制状态( 0:不可定制 1:可定制)
    shif
    20180105
   显示规则
    返回值：0:不可定制 1:可定制
    
    songwanwgen  2018.09.25 修改   --  商品定制类型分为普通定制、品牌定制
**/
(
    c_user_name   varchar2,            --用户名
    c_product_itemnumber   varchar2    --商品货号
) return varchar2
 is
     v_flag number:=0;                              --商品类型   1（普通商品） 2:订货会商品
     v_count number:=0;                       --临时变量
BEGIN

    --判断商品是否支持定制
    select count(1) into v_count from tbl_product_info where itemnumber = c_product_itemnumber 
    and (IS_BRAND_CUSTOM = 1 or IS_COMMON_CUSTOM=1);
    if v_count <1 then
        return 0;
    end if;
    
    --查询当前商品品牌用户否为可定制
    select count(1) into v_count from TBL_REVIEW_GROUP_BRAND trgb  WHERE EXISTS
              (SELECT 1 FROM TBL_REVIEW_USER_GROUP_DETAIL TRUGD
                      LEFT JOIN TBL_REVIEW_USER_GROUP TRUG ON TRUGD.USER_GROUP_ID = TRUG.ID
                    WHERE TRGB.USER_GROUP_ID = TRUGD.USER_GROUP_ID
                      AND TRUG.STATE = 2 AND TRUG.TYPE = 2 AND USER_ID = c_user_name)
               AND TRGB.brand_id = (select brand_id from tbl_product_info tpi where tpi.itemnumber=c_product_itemnumber);
    
    if v_count>0 then 
        v_flag :=1;
    end if;   
   return v_flag;

END is_custom_product;
/

