create PROCEDURE           import_order_match /**
                                                              导入订单匹配
                                                              wanghai
                                                              2017-08-31
                                                           **/
                                                         (
   in_user_id      IN     NUMBER,                                        --用户名
   in_task_id      IN     NUMBER,                                     --导入任务ID
   in_model_id     IN     NUMBER,
   output_status      OUT VARCHAR2,                         --返回的状态码 0-失败 1-成功
   output_msg         OUT VARCHAR2                                     --返回的信息
                                  )
IS
   TYPE ref_cursor_type IS REF CURSOR;                              --定义一个动态游标

   c_import_order          ref_cursor_type;                           --定义游标类型
   t_order_state_match     VARCHAR2 (200);                         --订单状态匹配关键词
   t_order_table_name      VARCHAR2 (50);                             --导入订单表名
   t_product_table_name    VARCHAR2 (50);                           --导入订单宝贝表名
   t_execute_sql           VARCHAR2 (4000);                            --动态sql
   t_out_order_number      VARCHAR2 (50);                              --电商订单号
   t_order_product_count   NUMBER;                                    --订单商品数量
   t_model_type            CHAR (1);                                --导入订单模版类型
   t_result_count          NUMBER;                                      --结果数量
   t_warehouse_id          NUMBER;                                      --仓库ID
   t_insert_field_name     VARCHAR2(2000);                               --插入字段名称
   t_select_field_name     VARCHAR2(2000);                               --查询字段名称

   v_match_error_msg       VARCHAR2 (2000);                           --匹配错误信息
BEGIN
   output_status := '0';
   --获取平台仓库ID（取第一条）
   select warehouse_id INTO t_warehouse_id from tbl_platform_warehouse where rownum =1;
   --获取导入订单表名
   SELECT 'TMP_IMPORT_ORDER_' || MODEL_CODE,
          'TMP_IMPORT_PRODUCT_' || MODEL_CODE,
          MODEL_TYPE
     INTO t_order_table_name, t_product_table_name, t_model_type
     FROM TBL_ORDER_IMPORT_MODEL
    WHERE id = in_model_id;

   --获取导入订单状态匹配关键词
   SELECT '%' || MATCH_FORMAT || '%'
     INTO t_order_state_match
     FROM TBL_ORDER_IMPORT_MODEL_CONFIG
    WHERE MODEL_ID = in_model_id AND FIELD_NAME = 'order_state';

   v_match_error_msg := '订单状态异常';
   --更新导入订单状态不匹配的订单
   t_execute_sql :=
         'update '
      || t_order_table_name
      || ' set ERROR_MSG = :error_msg where ORDER_STATE not like :order_state and user_id = :user_id and TASK_ID = :task_id';

   EXECUTE IMMEDIATE t_execute_sql
      USING v_match_error_msg,
            t_order_state_match,
            in_user_id,
            in_task_id;

   --更新导入订单状态不匹配的宝贝
   t_execute_sql :=
         'update '
      || t_product_table_name
      || ' set ERROR_MSG = :error_msg where user_id = :user_id and TASK_ID = :task_id and OUT_ORDER_NUMBER in (
            select OUT_ORDER_NUMBER from '
      || t_order_table_name
      || ' where ORDER_STATE not like :order_state and user_id = :user_id and TASK_ID = :task_id
        )';

   EXECUTE IMMEDIATE t_execute_sql
      USING v_match_error_msg,
            in_user_id,
            in_task_id,
            t_order_state_match,
            in_user_id,
            in_task_id;

   --查询导入订单状态匹配的订单
   IF t_model_type = '2'
   THEN
      t_execute_sql :=
            'select OUT_ORDER_NUMBER,PRODUCT_COUNT from '
         || t_order_table_name
         || ' where ORDER_STATE like :order_state and user_id = :user_id and TASK_ID = :task_id';

      OPEN c_import_order FOR t_execute_sql
         USING t_order_state_match, in_user_id, in_task_id;

      --循环订单
      LOOP
         FETCH c_import_order
            INTO t_out_order_number, t_order_product_count;

         EXIT WHEN c_import_order%NOTFOUND;

         --校验订单是否已导入
         SELECT COUNT (1)
           INTO t_result_count
           FROM TBL_IMPORT_ORDER
          WHERE OUT_ORDER_NUMBER = t_out_order_number;

         IF t_result_count > 0
         THEN
            v_match_error_msg :=
               '重复数据，导入数据包含了已提交的电商订单号';

            --更新导入订单错误信息
            t_execute_sql :=
                  'update '
               || t_order_table_name
               || ' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';

            EXECUTE IMMEDIATE t_execute_sql
               USING v_match_error_msg,
                     t_out_order_number,
                     in_user_id,
                     in_task_id;

            --更新导入订单宝贝错误信息
            t_execute_sql :=
                  'update '
               || t_product_table_name
               || ' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';

            EXECUTE IMMEDIATE t_execute_sql
               USING v_match_error_msg,
                     t_out_order_number,
                     in_user_id,
                     in_task_id;

            CONTINUE;
         END IF;

         --校验订单是否存在宝贝信息
         t_execute_sql :=
               'select count(1) from '
            || t_product_table_name
            || ' where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';

         EXECUTE IMMEDIATE t_execute_sql
            INTO t_result_count
            USING t_out_order_number, in_user_id, in_task_id;

         IF t_result_count = 0
         THEN
            v_match_error_msg :=
               '订单报表和宝贝报表无法匹配，未找到宝贝信息';

            --更新导入订单错误信息
            t_execute_sql :=
                  'update '
               || t_order_table_name
               || ' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';

            EXECUTE IMMEDIATE t_execute_sql
               USING v_match_error_msg,
                     t_out_order_number,
                     in_user_id,
                     in_task_id;

            CONTINUE;
         END IF;

         --校验订单商品数量和宝贝商品数量和是否相同
         t_execute_sql :=
               'select sum(PRODUCT_COUNT) from '
            || t_product_table_name
            || ' where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';

         EXECUTE IMMEDIATE t_execute_sql
            INTO t_result_count
            USING t_out_order_number, in_user_id, in_task_id;

         IF t_result_count != t_order_product_count
         THEN
            v_match_error_msg :=
               '订单报表和宝贝报表无法匹配，订单报表商品数量和宝贝报表实际商品数量不一致';

            --更新导入订单错误信息
            t_execute_sql :=
                  'update '
               || t_order_table_name
               || ' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';

            EXECUTE IMMEDIATE t_execute_sql
               USING v_match_error_msg,
                     t_out_order_number,
                     in_user_id,
                     in_task_id;

            --更新导入订单宝贝错误信息
            t_execute_sql :=
                  'update '
               || t_product_table_name
               || ' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';

            EXECUTE IMMEDIATE t_execute_sql
               USING v_match_error_msg,
                     t_out_order_number,
                     in_user_id,
                     in_task_id;

            CONTINUE;
         END IF;

         --校验宝贝商家编码是否匹配
         t_execute_sql :=
               'select count(1) from '
            || t_product_table_name
            || ' a where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id and not exists (SELECT 1 FROM tbl_product_sku ps WHERE product_itemnumber = SUBSTR (a.product_code, 0, LENGTH (a.product_code) - 5)
                                                                                                                                                               AND product_group_member = SUBSTR (a.product_code, -2)
                                                                                                                                                               AND EXISTS (SELECT 1 FROM tbl_dic_product_colors pc WHERE  color_number = SUBSTR (SUBSTR (a.product_code, -5), 0, 3) AND ps.product_color = pc.color_name)
                                                                                                                                                               AND PRODUCT_GROUP = ''尺码'')';
         EXECUTE IMMEDIATE t_execute_sql
            INTO t_result_count
            USING t_out_order_number, in_user_id, in_task_id;

         IF t_result_count > 0
         THEN
            v_match_error_msg :=
               '宝贝报表商家编码字段为空或者数据错误，无法匹配平台sku编号';

            --更新导入订单错误信息
            t_execute_sql :=
                  'update '
               || t_order_table_name
               || ' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';

            EXECUTE IMMEDIATE t_execute_sql
               USING v_match_error_msg,
                     t_out_order_number,
                     in_user_id,
                     in_task_id;

            --更新导入订单宝贝错误信息
            t_execute_sql :=
                  'update '
               || t_product_table_name
               || ' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';

            EXECUTE IMMEDIATE t_execute_sql
               USING v_match_error_msg,
                     t_out_order_number,
                     in_user_id,
                     in_task_id;
         END IF;
      END LOOP;
      
      
       --动态拼接订单 查询字段  
        SELECT wm_concat (field_name) into t_select_field_name
          FROM (SELECT CASE
                          WHEN t2.field_type = '2'
                          THEN
                             'TO_NUMBER (' || t2.field_name || ')'
                          WHEN t2.field_type = '3'
                          THEN
                                'TO_DATE ('
                             || t2.field_name
                             || ', ''yyyy-mm-dd hh24:mi:ss'')'
                          ELSE
                             t2.field_name
                       END
                          AS field_name
                  FROM TBL_ORDER_IMPORT_TASK t1, TBL_ORDER_IMPORT_MODEL_CONFIG t2
                 WHERE t1.model_id = t2.model_id AND t2.TYPE = 1 AND t1.id = in_task_id AND t2.field_name not in (lower('order_state'), Upper('order_state')) );
        --动态拼接订单 插入字段         
        SELECT wm_concat (field_name) into t_insert_field_name FROM (SELECT field_name FROM TBL_ORDER_IMPORT_TASK t1, TBL_ORDER_IMPORT_MODEL_CONFIG t2 WHERE t1.model_id = t2.model_id AND t2.TYPE = 1 AND  t2.field_name not in (lower('order_state'), Upper('order_state')) AND t1.id = in_task_id);

      --校验完成，保存匹配数据到结果表中
      t_execute_sql :=
         'insert into TBL_IMPORT_ORDER(id,'||t_insert_field_name||',user_id,task_id,warehouse_id)
        select SEQ_IMPORT_ORDER.nextval,'||t_select_field_name||',user_id,task_id,'||t_warehouse_id||' warehouse_id  from '||t_order_table_name||' where ERROR_MSG is null and user_id = :user_id and task_id = :task_id';
        EXECUTE IMMEDIATE t_execute_sql USING in_user_id, in_task_id;

    else
        t_execute_sql := 'select OUT_ORDER_NUMBER from '||t_order_table_name||' where ORDER_STATE like :order_state and user_id = :user_id and TASK_ID = :task_id';
        open c_import_order for t_execute_sql using t_order_state_match, in_user_id, in_task_id;

        --循环订单
        loop
            fetch c_import_order into t_out_order_number;
            exit when c_import_order%notfound;

            --校验订单是否已导入
            select count(1) into t_result_count from TBL_IMPORT_ORDER where OUT_ORDER_NUMBER = t_out_order_number;
            if t_result_count > 0 then
                v_match_error_msg := '重复数据，导入数据包含了已提交的电商订单号';

                --更新导入订单错误信息
                t_execute_sql := 'update '||t_order_table_name||' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';
                EXECUTE IMMEDIATE t_execute_sql USING v_match_error_msg, t_out_order_number, in_user_id, in_task_id;

                --更新导入订单宝贝错误信息
                t_execute_sql := 'update '||t_product_table_name||' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';
                EXECUTE IMMEDIATE t_execute_sql USING v_match_error_msg, t_out_order_number, in_user_id, in_task_id;

                continue;
            end if;

            --校验宝贝商家编码是否匹配
            t_execute_sql := 'select count(1) from '||t_product_table_name||' a where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id and not exists (SELECT 1 FROM tbl_product_sku ps WHERE product_itemnumber = SUBSTR (a.product_code, 0, LENGTH (a.product_code) - 5)
                                                                                                                                                                                                                           AND product_group_member = SUBSTR (a.product_code, -2)
                                                                                                                                                                                                                           AND EXISTS (SELECT 1 FROM tbl_dic_product_colors pc WHERE  color_number = SUBSTR (SUBSTR (a.product_code, -5), 0, 3) AND ps.product_color = pc.color_name)
                                                                                                                                                                                                                           AND PRODUCT_GROUP = ''尺码'')';
            EXECUTE IMMEDIATE t_execute_sql into t_result_count USING t_out_order_number, in_user_id, in_task_id;
            if t_result_count > 0 then
                v_match_error_msg := '宝贝报表商家编码字段为空或者数据错误，无法匹配平台sku编号';

                --更新导入订单错误信息
                t_execute_sql := 'update '||t_order_table_name||' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';
                EXECUTE IMMEDIATE t_execute_sql USING v_match_error_msg, t_out_order_number, in_user_id, in_task_id;

                --更新导入订单宝贝错误信息
                t_execute_sql := 'update '||t_product_table_name||' set ERROR_MSG = :error_msg where OUT_ORDER_NUMBER = :out_order_number and user_id = :user_id and TASK_ID = :task_id';
                EXECUTE IMMEDIATE t_execute_sql USING v_match_error_msg, t_out_order_number, in_user_id, in_task_id;
            end if;
        end loop;
       
        
        --动态拼接订单 查询字段  
        SELECT wm_concat (field_name) into t_select_field_name
          FROM (SELECT CASE
                          WHEN t2.field_type = '2'
                          THEN
                             'TO_NUMBER (' || t2.field_name || ')'
                          WHEN t2.field_type = '3'
                          THEN
                                'TO_DATE ('
                             || t2.field_name
                             || ', ''yyyy-mm-dd hh24:mi:ss'')'
                          ELSE
                             t2.field_name
                       END
                          AS field_name
                  FROM TBL_ORDER_IMPORT_TASK t1, TBL_ORDER_IMPORT_MODEL_CONFIG t2
                 WHERE t1.model_id = t2.model_id AND t2.field_name not in (lower('product_count'), Upper('product_count'),lower('order_state'), Upper('order_state')) AND t2.TYPE = 1 AND t1.id =in_task_id);
        --动态拼接订单 插入字段         
        SELECT wm_concat (field_name) into t_insert_field_name FROM (SELECT field_name FROM TBL_ORDER_IMPORT_TASK t1, TBL_ORDER_IMPORT_MODEL_CONFIG t2 WHERE t1.model_id = t2.model_id AND t2.TYPE = 1 AND t2.field_name not in (lower('order_state'), Upper('order_state'))  AND t1.id = in_task_id);      
        
        --校验完成，保存匹配数据到结果表中
        t_execute_sql := 'insert into TBL_IMPORT_ORDER(id,'||t_insert_field_name||',product_count,task_id,user_id,warehouse_id)
        select SEQ_IMPORT_ORDER.nextval,'||t_select_field_name||',(select sum(PRODUCT_COUNT) from '||t_product_table_name||' where OUT_ORDER_NUMBER = a.out_order_number and user_id = :user_id and TASK_ID = :task_id) product_count,task_id,user_id,'||t_warehouse_id|| ' warehouse_id from '||t_order_table_name||' a where ERROR_MSG is null and user_id = :user_id and task_id = :task_id';
        EXECUTE IMMEDIATE t_execute_sql USING in_user_id, in_task_id, in_user_id, in_task_id;

    end if;
    
    
    --动态拼接宝贝 查询字段  
    SELECT wm_concat (field_name) into t_select_field_name
      FROM (SELECT CASE
                      WHEN t2.field_type = '2'
                      THEN
                         'TO_NUMBER (' || t2.field_name || ')'
                      WHEN t2.field_type = '3'
                      THEN
                            'TO_DATE ('
                         || t2.field_name
                         || ', ''yyyy-mm-dd hh24:mi:ss'')'
                      ELSE
                         t2.field_name
                   END
                      AS field_name
              FROM TBL_ORDER_IMPORT_TASK t1, TBL_ORDER_IMPORT_MODEL_CONFIG t2
             WHERE t1.model_id = t2.model_id AND t2.field_name not in (lower('product_code'), Upper('product_code')) AND t2.TYPE = 2 AND t2.TYPE = 2 AND t1.id = in_task_id);
                 
    --动态拼接宝贝 插入字段         
    SELECT wm_concat (field_name) into t_insert_field_name FROM (SELECT field_name FROM TBL_ORDER_IMPORT_TASK t1, TBL_ORDER_IMPORT_MODEL_CONFIG t2 WHERE t1.model_id = t2.model_id AND t2.field_name not in (lower('product_code'), Upper('product_code')) AND t2.TYPE = 2  AND t1.id = in_task_id);      
    
    --保存匹配数据到结果表中 -- 宝贝信息
    t_execute_sql := 'insert into TBL_IMPORT_ORDER_PRODUCT(id,'||t_insert_field_name||',IMPORT_PRODUCT_COUNT,product_sku,user_id,task_id) 
    select SEQ_IMPORT_ORDER_PRODUCT.nextval,'||t_select_field_name||',product_count,
           (SELECT id FROM tbl_product_sku ps WHERE  product_itemnumber = SUBSTR (product_code, 0, LENGTH (product_code) - 5) AND product_group_member = SUBSTR (product_code, -2) AND  EXISTS (SELECT 1 FROM tbl_dic_product_colors pc WHERE  color_number = SUBSTR (SUBSTR (product_code, -5), 0, 3) AND ps.product_color = pc.color_name) and PRODUCT_GROUP = ''尺码'') product_sku,
           user_id,task_id from '||t_product_table_name||' where ERROR_MSG is null and user_id = :user_id and task_id = :task_id and out_order_number in (select OUT_ORDER_NUMBER from '||t_order_table_name||' where ERROR_MSG is null and user_id = :user_id and TASK_ID = :task_id)';
    EXECUTE IMMEDIATE t_execute_sql USING in_user_id, in_task_id, in_user_id, in_task_id;

    --保存匹配结果数据
    t_execute_sql := 'select count(1) from '||t_order_table_name||' a where ERROR_MSG is null and user_id = :user_id and TASK_ID = :task_id';
    EXECUTE IMMEDIATE t_execute_sql into t_result_count USING in_user_id, in_task_id;

    update TBL_ORDER_IMPORT_TASK set IMPORT_SUCCESS_COUNT = t_result_count,ORDER_COUNT = t_result_count,state ='2',WAIT_DISPOSE_COUNT = t_result_count where id = in_task_id;

    t_execute_sql := 'select count(1) from '||t_order_table_name||' a where ERROR_MSG is not null and user_id = :user_id and TASK_ID = :task_id';
    EXECUTE IMMEDIATE t_execute_sql into t_result_count USING in_user_id, in_task_id;

    update TBL_ORDER_IMPORT_TASK set IMPORT_FAIL_ORDER_COUNT = t_result_count where id = in_task_id;

    t_execute_sql := 'select count(1) from '||t_product_table_name||' a where ERROR_MSG is not null and user_id = :user_id and TASK_ID = :task_id';
    EXECUTE IMMEDIATE t_execute_sql into t_result_count USING in_user_id, in_task_id;

    update TBL_ORDER_IMPORT_TASK set IMPORT_FAIL_PRODUCT_COUNT = t_result_count where id = in_task_id;


    output_msg := '匹配导入订单完成';
EXCEPTION WHEN OTHERS THEN
    output_status := '1';
    output_msg := '匹配导入订单数据异常';
    --output_msg := 'errorCode='||sqlcode||chr(10)||sqlerrm||chr(10)||t_execute_sql;

    ROLLBACK;
END import_order_match;
/

