create PROCEDURE CANCEL_ORDER_AUTO
/**
     订单超过24小时未付款自动取消 含转账汇款  
     此存储过程 供定时任务调用
     shif
     2017-05-29 

     增加支付状态条件 -- by wanghai 20190416
     修改订单自动取消规则 zhengfy 20190718
  **/
 IS
 output_status         varchar2(50); --返回的状态码 0-取消失败 1-取消成功
 output_msg            varchar2(300); --返回的信息
BEGIN
  --定义游标查询超过时间未付款的订单(不包括定制预付订单产生的尾款订单)
   declare cursor out_time_orders is  
        select user_name,order_number from TBL_ORDER_INFO toi 
        where ORDER_STATE = 1 and payment_state = 1
        and NOT EXISTS (
            SELECT 1
            FROM tbl_pre_order_info tpoi, TBL_PRE_ORDER_RELATE tpor
            WHERE     tpoi.order_number = tpor.pre_order_number
            AND tpoi.pre_order_type = 2
            AND toi.order_number = tpor.order_number
        )
        and decode(last_cancel_date, null, create_date + 1 - sysdate, last_cancel_date - sysdate) < 0
        ;
   begin
        for c_row in out_time_orders loop
           CANCEL_ORDER(c_row.user_name,c_row.order_number,'订单超过付款截止时间未付款，系统自动取消',output_status,output_msg);
        end loop;
    end;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END CANCEL_ORDER_AUTO;
/

