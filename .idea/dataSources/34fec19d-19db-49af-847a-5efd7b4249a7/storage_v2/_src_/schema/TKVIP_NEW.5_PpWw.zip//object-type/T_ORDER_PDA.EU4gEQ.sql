create TYPE           T_ORDER_PDA                                                                                                                                                                                                                                                                                                                              as object
(
    order_remark VARCHAR2 (1000 Byte),    --订单备注
    order_product_list   T_ORDER_PRODUCT_LST_PDA,--订单商品列表
    logistics_company_code VARCHAR2(50 Byte),  --物流公司代码
    product_money NUMBER,  --订单商品金额
    logistics_money NUMBER,  --订单物流费用
    df_money NUMBER,   --订单代发费用
    edit_state NUMBER,  --调价状态 1.未调价 2.已调价
    freight_edit_state NUMBER, --运费调价状态 1.未调价 2.已调价
    warehouse_id NUMBER,   --下单仓库id
    freight_payment_type NUMBER --运费是否到付  1.先支付运费   ；2：到付运费
)
/

