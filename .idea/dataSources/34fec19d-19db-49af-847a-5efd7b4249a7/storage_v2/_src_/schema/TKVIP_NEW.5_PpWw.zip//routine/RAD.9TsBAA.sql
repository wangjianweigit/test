create FUNCTION RAD
/**
    计算圆弧函数，通过经纬度坐标，计算弧度值，用于计算坐标点的距离
*/
(d number) RETURN NUMBER   --坐标值
is
PI number :=3.141592625;
 
begin
return  d* PI/180.0;
end ;
/

