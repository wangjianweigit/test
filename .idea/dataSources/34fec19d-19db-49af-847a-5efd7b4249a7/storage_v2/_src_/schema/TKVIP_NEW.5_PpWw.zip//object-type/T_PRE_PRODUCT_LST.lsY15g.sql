create TYPE "T_PRE_PRODUCT_LST"                                                                          as table of t_pre_product
/

