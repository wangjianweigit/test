create PROCEDURE PVTP_INS_OR_UPD_SKU_APPLY
/**
    私有站专用，创建商品SKU信息
    2019.09.23 reid
**/
(
   i_product_sku_list       IN  t_product_sku_list,     --商品SKU数组对象
   i_product_id             IN  number,                 --商品ID
   i_stationed_user_id      IN  number,                 --入驻商ID
   output_status            OUT varchar2,               --返回的状态码 0-失败 1-成功
   output_msg               OUT varchar2                --返回的信息
) AS 
   v_color_id number;   --颜色ID
   v_specs_id number;   --规格ID
   v_size_id number;   --尺码ID
   v_product_sku t_product_sku;     --SKU数组中的一个元素
   temp_count int:=0;    --临时变量 计数
   v_product_sku_name varchar2(500);   --SKU名称
   v_product_itemnumber varchar2(50);      --商品货号
   v_product_sku_code varchar2(50);   --SKU编码
   v_product_type_type number:=0;     --当前生产SKU的商品类型   1.鞋类商品   2.非鞋类商品
   v_product_color_number varchar2(3):=null;--商品颜色编码，用于生产SKU编码
   v_product_color_specs_index number:=0;     --一个颜色下的规格数量，用作生成商品的SKU编码
   v_product_color varchar2(50);       --当前轮询的颜色信息，用于判断是否需要重置v_product_color_specs_index
BEGIN
    output_status:='0';
    -- 判断商品SKU是否为空 --
    IF i_product_sku_list.COUNT = 0  THEN
        output_msg:='商品SKU不能为空';
        RETURN;
    END IF;
    --判断商家用户名是否为空--
    SELECT COUNT(*) INTO temp_count FROM TBL_STATIONED_USER_INFO WHERE id = i_stationed_user_id;
    IF temp_count = 0 THEN
        output_msg:='入驻商ID不存在';
        RETURN;
    END IF;
    --判断商品货号是否为空--
    SELECT COUNT(*) INTO temp_count FROM TBL_PVTP_PRODUCT_INFO_APPLY WHERE id = i_product_id;
    IF temp_count = 0 THEN
        output_msg:='商品ID不存在';
        RETURN;
    END IF;
    --判断当前商品的类型是否是鞋类
    select
    (select type from TBL_DIC_PRODUCT_TYPE where id = pia.PRODUCT_TYPE_ID),pia.itemnumber
    into v_product_type_type,v_product_itemnumber
    from TBL_PVTP_PRODUCT_INFO_APPLY pia
    WHERE id = i_product_id;
        --循环所有的尺码，分别新增或者更新颜色，规格数据--
        FOR i IN 1..i_product_sku_list.COUNT LOOP
            --取得颜色各列值--
            v_product_sku:=i_product_sku_list(i);
            IF v_product_color is null or v_product_color!=v_product_sku.product_color THEN
                v_product_color_specs_index := 0;--一个颜色下的规格数量，重置为0
            END IF;
            v_product_color:=v_product_sku.product_color;
             /********查询得到当前的颜色编码数据是否存在**********/  
            SELECT COUNT(*) INTO temp_count FROM TBL_DIC_PRODUCT_COLORS WHERE COLOR_NAME = v_product_sku.product_color;
            IF temp_count = 0 THEN
                output_msg:='颜色【'||v_product_sku.product_color||'】未配置颜色编码信息！';
                RETURN;
            END IF;
            /********查询得到当前的颜色编码数据**********/  
            SELECT COLOR_NUMBER into v_product_color_number FROM TBL_DIC_PRODUCT_COLORS WHERE COLOR_NAME = v_product_sku.product_color;
            /***************************判断颜色是否已存在*****************************************************************/    
            SELECT nvl(min(id),0) INTO v_color_id FROM TBL_PVTP_PRODUCT_SKU_APPLY 
            WHERE STATIONED_USER_ID = i_stationed_user_id
            AND PRODUCT_GROUP_MEMBER = v_product_sku.product_color 
            AND PRODUCT_ID = i_product_id;
            --颜色数据不存在，则插入
            IF v_color_id = 0 THEN
                  --取得颜色编号--
                  SELECT SEQ_PRODUCT_SKU.NEXTVAL INTO v_color_id FROM dual;
                   --颜色sku名--
                   v_product_sku_name:= '颜色:' || v_product_sku.product_color;
                  --插入颜色--
                  INSERT INTO TBL_PVTP_PRODUCT_SKU_APPLY
                    (
                        id,
                        stationed_user_id,
                        product_itemnumber,
                        product_id,
                        parent_id,
                        product_group,
                        product_group_member,
                        product_color_imgurl,
                        product_sku_name
                    ) VALUES 
                    (
                        v_color_id,
                        i_stationed_user_id,
                        v_product_itemnumber,
                        i_product_id,
                        0,
                        '颜色',
                        v_product_sku.product_color,
                        v_product_sku.product_color_imgurl,
                        v_product_sku_name
                    );
            ELSE
                --颜色数据已经存在，则更新
                UPDATE TBL_PVTP_PRODUCT_SKU_APPLY
                SET product_color_imgurl = v_product_sku.product_color_imgurl
                WHERE id = v_color_id;
            END IF;
            /**********************************判断规格是否已存在**************************************************/
            v_specs_id:= v_product_sku.product_specs_id;
            IF v_specs_id = 0 THEN
                SELECT nvl(min(id),0) INTO v_specs_id FROM TBL_PVTP_PRODUCT_SKU_APPLY 
                WHERE STATIONED_USER_ID = i_stationed_user_id
                AND PRODUCT_GROUP_MEMBER = v_product_sku.product_specs 
                AND PRODUCT_ID = i_product_id
                AND PARENT_ID = v_color_id;
            END IF;
            v_product_color_specs_index :=v_product_color_specs_index + 1;--一个颜色下的规格数量，每个不同规格自增1
            --规格数据不存在，则插入
            IF v_specs_id = 0 THEN
                  --取得规格编号--
                  SELECT SEQ_PRODUCT_SKU.NEXTVAL INTO v_specs_id FROM dual;
                   --规格sku名--
                   v_product_sku_name:= '颜色:' || v_product_sku.product_color||' 规格:'||v_product_sku.product_specs;
                  --插入规格--
                  INSERT INTO TBL_PVTP_PRODUCT_SKU_APPLY
                    (
                        id,
                        stationed_user_id,
                        product_itemnumber,
                        product_id,
                        parent_id,
                        product_group,
                        product_group_member,
                        product_sku_name,
                        product_prize_tag,
                        product_prize_cost,
                        product_gbcode
                    ) VALUES 
                    (
                        v_specs_id,
                        i_stationed_user_id,
                        v_product_itemnumber,
                        i_product_id,
                        v_color_id,
                        '规格',
                        v_product_sku.product_specs,
                        v_product_sku_name,
                        v_product_sku.product_prize_tag,
                        v_product_sku.product_prize_cost,
                        v_product_sku.product_gbcode
                    );
            ELSE
                --规格sku名--
                v_product_sku_name:= '颜色:' || v_product_sku.product_color||' 规格:'||v_product_sku.product_specs;
                --规格已经存在，则更新价格以及国标码数据
                UPDATE TBL_PVTP_PRODUCT_SKU_APPLY             
                SET PRODUCT_PRIZE_COST = v_product_sku.product_prize_cost,
                PRODUCT_GBCODE = v_product_sku.product_gbcode,
                product_sku_name = v_product_sku_name,
                product_group_member = v_product_sku.product_specs
                WHERE id = v_specs_id;
            END IF;
            /**********************************判断尺码是否已存在**************************************************/
            v_size_id:= v_product_sku.product_sku_id;
            IF v_size_id = 0 THEN
                SELECT nvl(min(id),0) INTO v_size_id FROM TBL_PVTP_PRODUCT_SKU_APPLY 
                WHERE STATIONED_USER_ID = i_stationed_user_id
                AND PRODUCT_GROUP_MEMBER = v_product_sku.product_size 
                AND PRODUCT_ID = i_product_id
                AND PARENT_ID = v_specs_id;
            END IF;
            --尺码数据不存在，则插入
            IF v_size_id = 0 THEN
                  --取得尺码编号--
                  SELECT SEQ_PRODUCT_SKU.NEXTVAL INTO v_size_id FROM dual;
                   --尺码sku名--
                   v_product_sku_name:= '颜色:' || v_product_sku.product_color||' 规格:'||v_product_sku.product_specs||' 尺码:'||v_product_sku.product_size;
                  --如果当前商品是鞋类
                  IF v_product_type_type = 1 THEN
                    v_product_sku_code:= v_product_itemnumber||v_product_color_number||v_product_sku.product_size;
                  ELSE
                    --如果当前商品是鞋类,则增加颜色在的规格序号
                    v_product_sku_code:= v_product_itemnumber||v_product_color_number||lpad(v_product_color_specs_index,2,'0');
                  END IF;
                  --插入尺码--
                  INSERT INTO TBL_PVTP_PRODUCT_SKU_APPLY
                    (
                        id,
                        stationed_user_id,
                        product_itemnumber,
                        product_id,
                        parent_id,
                        product_group,
                        product_group_member,
                        product_sku_name,
                        product_prize_tag,
                        product_prize_cost,
                        product_gbcode,
                        product_inlong,
                        product_weight,
                        product_color,
                        product_specs,
                        product_color_imgurl,
                        product_sku_code
                    ) VALUES 
                    (
                        v_size_id,
                        i_stationed_user_id,
                        v_product_itemnumber,
                        i_product_id,
                        v_specs_id,
                        '尺码',
                        v_product_sku.product_size,
                        v_product_sku_name,
                        v_product_sku.product_prize_tag,
                        v_product_sku.product_prize_cost,
                        v_product_sku.product_gbcode,
                        v_product_sku.product_inlong,
                        v_product_sku.product_weight,
                        v_product_sku.product_color,
                        v_product_sku.product_specs,
                        v_product_sku.product_color_imgurl,
                        v_product_sku_code
                    );
            ELSE
                --尺码sku名--
                v_product_sku_name:= '颜色:' || v_product_sku.product_color||' 规格:'||v_product_sku.product_specs||' 尺码:'||v_product_sku.product_size;
                --尺码已经存在，则更新价格以及国标码数据以及内长
                UPDATE TBL_PVTP_PRODUCT_SKU_APPLY             
                SET 
                PRODUCT_PRIZE_TAG = v_product_sku.product_prize_tag,
                PRODUCT_PRIZE_COST = v_product_sku.product_prize_cost,
                PRODUCT_GBCODE = v_product_sku.product_gbcode,
                PRODUCT_INLONG = v_product_sku.product_inlong,
                PRODUCT_WEIGHT = v_product_sku.product_weight,
                PRODUCT_COLOR_IMGURL = v_product_sku.product_color_imgurl,
                PRODUCT_SKU_NAME = v_product_sku_name,
                PRODUCT_GROUP_MEMBER = v_product_sku.product_size,
                product_specs = v_product_sku.product_specs
                WHERE id = v_size_id;
            END IF;           
        END LOOP;
    output_status:='1';
    output_msg:='商品SKU编辑成功';
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='更新或插入SKU出现未知错误:'||SQLCODE || ':'||SQLERRM||''||dbms_utility.format_error_backtrace();
    ROLLBACK;
END PVTP_INS_OR_UPD_SKU_APPLY;
/

