create PROCEDURE           PAYMENT_STATISTICS_HISTORY 
IS
   T_STATISTICS_DATE DATE;
   T_STATIONED_USER_ID NUMBER;
   T_DATE DATE;
   T_COUNT NUMBER;
BEGIN
  --定义游标查询超过24小时未付款的订单
    DECLARE CURSOR STATISTICS_DATES IS SELECT STATISTICS_DATE FROM TBL_PAYMENTS_SETTLEMENT GROUP BY STATISTICS_DATE ORDER BY STATISTICS_DATE;
    BEGIN
        FOR C_ROW IN STATISTICS_DATES LOOP
            
            T_STATISTICS_DATE := C_ROW.STATISTICS_DATE;
            --查询前一天未发生资金流水的入驻游标
            DECLARE CURSOR STATIONED_USERS IS SELECT T_MAIN.ID,
                NVL(T1.NUM,0) NUM 
            FROM TBL_STATIONED_USER_INFO T_MAIN,(
                SELECT STATIONED_USER_ID,
                    COUNT(1) NUM 
                FROM TBL_STATIONED_CAPITAL_LOGS SCL 
                WHERE TO_CHAR(CREATE_DATE,'yyyy-mm-dd') = TO_CHAR(T_STATISTICS_DATE,'yyyy-mm-dd') 
                GROUP BY SCL.STATIONED_USER_ID
            ) T1 WHERE T_MAIN.ID = T1.STATIONED_USER_ID(+) AND NVL(T1.NUM,0) = 0 ORDER BY T_MAIN.ID;
            BEGIN
                FOR C_USER_ROW IN STATIONED_USERS LOOP
                
                    T_STATIONED_USER_ID := C_USER_ROW.ID;
                    
                    ----查询当前入驻商最近一条资金流水记录
                    SELECT CREATE_DATE into T_DATE FROM (
                        SELECT CREATE_DATE FROM TBL_STATIONED_CAPITAL_LOGS SCL 
                        WHERE SCL.STATIONED_USER_ID = T_STATIONED_USER_ID AND TO_CHAR(CREATE_DATE,'yyyy-mm-dd') < TO_CHAR(T_STATISTICS_DATE,'yyyy-mm-dd')
                        ORDER BY CREATE_DATE DESC
                    ) WHERE ROWNUM = 1;
                    DBMS_OUTPUT.put_line('T_DATE：======================='||T_DATE);

                    MERGE INTO TBL_PAYMENTS_SETTLEMENT T USING (
                        SELECT * FROM (
                            SELECT ACCOUNT_BALANCE,
                                CAN_WITHDRAWAL_BALANCE,
                                WAIT_SETTLEMENT_BALANCE,
                                ENSURE_AMOUNT,
                                PS.STATIONED_USER_ID,
                                PS.STATISTICS_DATE
                            FROM TBL_PAYMENTS_SETTLEMENT PS
                            WHERE PS.STATIONED_USER_ID = T_STATIONED_USER_ID
                            AND PS.STATISTICS_DATE = TRUNC(T_DATE)
                            ORDER BY STATISTICS_DATE DESC
                        ) WHERE ROWNUM = 1
                    ) T1 ON (T.STATIONED_USER_ID = T1.STATIONED_USER_ID AND TRUNC(T.STATISTICS_DATE) = TRUNC(T_STATISTICS_DATE))
                    WHEN MATCHED THEN
                    UPDATE SET T.ACCOUNT_BALANCE = T1.ACCOUNT_BALANCE,
                        T.CAN_WITHDRAWAL_BALANCE = T1.CAN_WITHDRAWAL_BALANCE,
                        T.WAIT_SETTLEMENT_BALANCE = T1.WAIT_SETTLEMENT_BALANCE,
                        T.ENSURE_AMOUNT = T1.ENSURE_AMOUNT;
                END LOOP; 
            END;
                  
        END LOOP;
    END;     
   COMMIT;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
END PAYMENT_STATISTICS_HISTORY;
/

