create procedure           pvpt_readjust_order_pda
/***
    订货PDA调价
    create by wanghai 2019-09-11
***/
(
    c_order_number varchar2           --支付单号
)
AS

v_new_product_unit_price number := 0;   --调价后单价
v_sku_discount_money number := 0;       --调价单价
v_platform_money number := 0;           --会员服务费
v_product_type_id number := 0;          --商品类型ID
v_product_type_type char(1 byte);       --商品类型的类别
v_storage_charges number := 0;          --SKU仓储费
v_service_pay_charges number := 0;      --支付服务费比例
v_service_charges number := 0;          --入驻商服务费比例
v_stationed_money number := 0;          --入驻商货款
v_temp_count number := 0;               --临时变量，数量

v_new_product_total_money number := 0;   --计算后SKU总价

begin

    --查询待修改商品数量
     select count(*) into v_temp_count
        from tbl_order_product_sku where PRODUCT_UNIT_PRICE <> PRODUCT_OLD_UNIT_PRICE 
        and order_number = c_order_number;

    --删除剩余金额数据
    delete from TBL_PVTP_DIVIDE_ODD where order_number = c_order_number;

    if v_temp_count > 0 then
        --查询订单商品列表
        declare cursor order_sku is 
            select order_number,product_sku,PRODUCT_UNIT_PRICE,PRODUCT_TOTAL_MONEY,PRODUCT_OLD_UNIT_PRICE,COUNT 
            from tbl_order_product_sku where PRODUCT_UNIT_PRICE <> PRODUCT_OLD_UNIT_PRICE 
            and order_number = c_order_number;

        --循环处理调价商品的清分规则
        begin
            for c_row in order_sku
            loop 
            
                --调价后单价
                v_new_product_unit_price := trunc(c_row.PRODUCT_TOTAL_MONEY / c_row.COUNT, 2);
                
                --单价计算的总价
                v_new_product_total_money := round(v_new_product_unit_price * c_row.COUNT, 2);
                
                --调价单价
                v_sku_discount_money := c_row.PRODUCT_OLD_UNIT_PRICE - v_new_product_unit_price;
                --获取会员服务费
                SELECT divide_money INTO v_platform_money FROM TBL_ORDER_DIVIDE_RECORD WHERE divide_type = 2 and order_number = c_row.order_number and product_sku = c_row.product_sku;
                
                --获取商品类型ID
                select PRODUCT_TYPE_ID into v_product_type_id from TBL_PVTP_PRODUCT_INFO where ITEMNUMBER = (select PRODUCT_ITEMNUMBER from TBL_PVTP_PRODUCT_SKU where id = c_row.product_sku);
                   
                --获取商品类型的类别
                select type into v_product_type_type from TBL_DIC_PRODUCT_TYPE where id = v_product_type_id;
                   
                --查询SKU仓储费
                if v_product_type_type = '1' then
                   select nvl(max(storage_charges),0) into v_storage_charges from TBL_PVTP_STAT_STORAGE_CHARGES ssc,TBL_PVTP_PRODUCT_SKU ps 
                   where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size(+) = ps.product_group_member and ps.id = c_row.product_sku and type = v_product_type_type;
                else
                   select nvl(max(storage_charges),0) into v_storage_charges from TBL_PVTP_STAT_STORAGE_CHARGES ssc,TBL_PVTP_PRODUCT_SKU ps 
                   where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size = v_product_type_id and ps.id = c_row.product_sku and type = v_product_type_type;
                end if;
                
                --查询支付服务费比例,入驻商服务费比例
                select nvl(pay_service_rate,0),nvl(service_charges,0) into v_service_pay_charges,v_service_charges from TBL_PVTP_CONFIG where STATIONED_USER_ID = (
                    select STATIONED_USER_ID from TBL_PVTP_PRODUCT_SKU where id = c_row.product_sku
                );
                
                if v_sku_discount_money < 0 then
                    v_stationed_money := v_new_product_unit_price - v_platform_money;
                elsif v_sku_discount_money >= v_platform_money then
                    v_stationed_money := v_new_product_unit_price;
                    v_platform_money := 0;
                else
                    v_stationed_money := v_new_product_unit_price - (v_platform_money - v_sku_discount_money);
                    v_platform_money := v_platform_money - v_sku_discount_money;
                end if;
                
                if v_storage_charges >= v_stationed_money then
                    v_storage_charges := 0;
                end if;
                
                --更新入驻商货款
                update TBL_ORDER_DIVIDE_RECORD set divide_money = v_stationed_money - trunc(v_stationed_money*v_service_charges,2) - trunc(v_stationed_money*v_service_pay_charges,2) - v_storage_charges WHERE divide_type = 1 and order_number = c_row.order_number and product_sku = c_row.product_sku;
                --更新会员服务费
                update TBL_ORDER_DIVIDE_RECORD set divide_money = v_platform_money WHERE divide_type = 2 and order_number = c_row.order_number and product_sku = c_row.product_sku;
                --更新仓储费
                update TBL_ORDER_DIVIDE_RECORD set divide_money = v_storage_charges WHERE divide_type = 3 and order_number = c_row.order_number and product_sku = c_row.product_sku;
                --更新入驻商服务费
                update TBL_ORDER_DIVIDE_RECORD set divide_money = trunc(v_stationed_money*v_service_charges,2) WHERE divide_type = 4 and order_number = c_row.order_number and product_sku = c_row.product_sku;
                --更新支付服务费
                update TBL_ORDER_DIVIDE_RECORD set divide_money = trunc(v_stationed_money*v_service_pay_charges,2) WHERE divide_type = 5 and order_number = c_row.order_number and product_sku = c_row.product_sku;
            
                if v_new_product_total_money <> c_row.PRODUCT_TOTAL_MONEY then
                    insert into TBL_PVTP_DIVIDE_ODD(
                        order_number,
                        product_sku,
                        odd_amount
                    )
                    values (
                        c_row.order_number,
                        c_row.product_sku,
                        c_row.PRODUCT_TOTAL_MONEY - v_new_product_total_money
                    );
                end if;
            end loop;
        end;
    end if;

end pvpt_readjust_order_pda;
/

