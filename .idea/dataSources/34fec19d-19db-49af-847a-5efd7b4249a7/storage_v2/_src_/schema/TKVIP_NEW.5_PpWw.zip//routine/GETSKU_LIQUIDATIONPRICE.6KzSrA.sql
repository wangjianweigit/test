create FUNCTION           getSku_LiquidationPrice
/**
    通过用户名获取SKU商品的最终清分价格
    wanghai
    创建：2019-05-30 create by wanghai 重构GETSKU_USER_LIQUIDATIONPRICE函数，直接使用传入报价进行计算 
    修改：2019-09-05 update by wanghai  支持新老商品不同仓储费计算 针对2019-09-15新仓储费调整  
    
    返回值：商品清分价格
**/
(
    c_type  number,                     --清分类型  1、入驻商收入；2、平台服务费；3、仓储服务费；4、入驻商服务费；5、支付服务费
    c_user_name   varchar2,             --用户名
    c_product_sku_id   number,          --商品SKUID
    c_product_price    number,          --商品单价
    c_vip   number,                     --会员价标识
    c_original_cost number,             --原报价
    c_new_cost  number,                 --折扣后报价
    c_activity_id   number              --活动ID
) return number
 is
     v_service_pay_charges  number:=0;           --入驻商支付服务费率
     v_service_charges      number:=0;           --入驻商服务费率
     v_storage_charges      number:=0;           --仓储服务费
     v_product_itemnumber   varchar2(50);        --商品货号
     v_product_prize_cost   number:=0;           --商品报价
     v_product_specs_id     number :=0;          --商品规格ID                   --私有平台特殊价格新加配置
     v_product_specs        varchar2(500);       --商品规格名称                 --私有平台特殊价格新加配置
     v_product_type_id      number := 0;         --商品类型ID
     v_product_type_type    char := '1';         --商品类型类别
     v_discount             number := 1;         --折扣
     v_now_prize_cost       number;              --当前清分报价
     v_liquidation_prize    number;              --清分金额
     
     v_product_create_date date;                                               --商品创建时间  
     v_sys_line2 date:=to_date('2019-09-15 00:00:00','yyyy-mm-dd hh24:mi:ss'); --系统界线时间                          --界线新加配置  针对2019-09-15新费率调整
BEGIN
    
    v_now_prize_cost := c_new_cost;

    --查询入驻商支付服务费比例,入驻商服务费比例
    select nvl(pay_service_rate,0), nvl(service_charges,0) into v_service_pay_charges,v_service_charges  from TBL_STATIONED_USER_INFO where id = (
        select STATIONED_USER_ID from tbl_product_sku where id = c_product_sku_id
    );

    --查询SKU基本信息
    select a.create_date,a.product_type_id,b.product_itemnumber,b.product_prize_cost,b.parent_id,b.product_specs into v_product_create_date,v_product_type_id,v_product_itemnumber,v_product_prize_cost,v_product_specs_id,v_product_specs from tbl_product_info a,tbl_product_sku b where a.itemnumber = b.product_itemnumber and b.product_group = '尺码' and b.id = c_product_sku_id and rownum < 2;
       
    --获取商品类型的类别
    select type into v_product_type_type from TBL_DIC_PRODUCT_TYPE where id = v_product_type_id;
       
   /*************************商品新老计费费率控制*********begin**********************/
    --查询SKU仓储费
    --老仓储费查询
    if v_product_create_date < v_sys_line2 then
        if v_product_type_type = '1' then
           select nvl(max(storage_charges),0) into v_storage_charges from TBL_STATIONED_STORAGE_CHARGES2 ssc,tbl_product_sku ps 
           where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size(+) = ps.product_group_member and ps.id = c_product_sku_id and type = v_product_type_type;
        else
           select nvl(max(storage_charges),0) into v_storage_charges from TBL_STATIONED_STORAGE_CHARGES2 ssc,tbl_product_sku ps 
           where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size = v_product_type_id and ps.id = c_product_sku_id and type = v_product_type_type;
        end if;
    end if;
    
    --新仓储费查询
    if v_product_create_date >= v_sys_line2 then
        if v_product_type_type = '1' then
           select nvl(max(storage_charges),0) into v_storage_charges from tbl_stationed_storage_charges ssc,tbl_product_sku ps 
           where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size(+) = ps.product_group_member and ps.id = c_product_sku_id and type = v_product_type_type;
        else
           select nvl(max(storage_charges),0) into v_storage_charges from tbl_stationed_storage_charges ssc,tbl_product_sku ps 
           where ssc.stationed_user_id(+) = ps.stationed_user_id and ssc.product_size = v_product_type_id and ps.id = c_product_sku_id and type = v_product_type_type;
        end if;
    end if;
    /*************************商品新老计费费率控制*********end**********************/
    
    --报价大于售价，按照售价计算入驻商货款
    if v_now_prize_cost > c_product_price then
        v_now_prize_cost := c_product_price;
    end if;
    
    --如果报价小于仓储费，则不收取仓储费
    if v_now_prize_cost <= v_storage_charges then
        v_storage_charges := 0;
    end if;
    
    --计算清分规则
    if c_type = 1 then
        --入驻商收入 报价*折扣-报价*活动折扣*入驻商服务费-仓储费
        v_liquidation_prize := trunc(v_now_prize_cost,2) - trunc(v_now_prize_cost*v_service_charges,2) - trunc(v_now_prize_cost*v_service_pay_charges,2) - v_storage_charges;
    elsif c_type = 2 then
        --会员服务费 活动价-报价*活动折扣
        v_liquidation_prize := c_product_price - trunc(v_now_prize_cost,2);
    elsif c_type = 3 then
        v_liquidation_prize := v_storage_charges;
    elsif c_type = 4 then
        v_liquidation_prize := trunc(v_now_prize_cost*v_service_charges,2);
    elsif c_type = 5 then
        --入驻商支付服务费
        v_liquidation_prize := trunc(v_now_prize_cost*v_service_pay_charges,2);
    end if;
   
    return v_liquidation_prize;
   
END getSku_LiquidationPrice;
/

