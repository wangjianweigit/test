create PROCEDURE           SUBMIT_RETAIL_ORDER_ARR
/**
    新版本新零售提交订单存储过程
    
    2019.07.11 reid 创建
    
    返回值 
        output_status 0-失败 1-成功
        output_msg  成功：返回支付单号；失败：返回错误原因
     
**/
(
        client_user_name in varchar2,              --下单人user_name
        client_receiving_name in varchar2,         --收货人姓名
        client_receiving_phone in varchar2,        --收货电话
        client_user_province_id in number,         --收货地省ID
        client_receiving_address in varchar2,      --收货地址
        client_order_source  in varchar2,          --订单来源
        client_order_remark in varchar2,           --订单备注
        client_logistics_company_code in varchar2, --物流公司代码
        product_sku_list IN  T_ORDER_PRODUCT_LST,  --订单中包含的SKU信息集合
        output_status  out varchar2,               --返回的状态码 0-失败 1-成功
        output_msg out varchar2                    --返回的信息
) AS
       v_temp_count    number :=0;                                 --临时变量
BEGIN
    output_status:='0';
    --先调用新零售订单确认存储过程；进行订单提交前的校验。
    CONFIRM_RETAIL_ORDER(client_user_name,client_logistics_company_code,product_sku_list,output_status,output_msg);
    --校验未能通过，直接返回
    IF output_status<>'1' THEN
        RETURN;
    END IF;
    output_status:='1';
    output_msg:='允许下单';
  EXCEPTION
    WHEN OTHERS THEN
        output_status := '0';
        output_msg:='提交订单出现未知错误::'||SQLCODE || '::'||SQLERRM||'----';
END SUBMIT_RETAIL_ORDER_ARR;
------------------------------------------------
/

