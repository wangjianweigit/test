create FUNCTION pvtp_getProduct_TagPrice_Qj
/**
    （私有站专用）通过用户名获取商品吊牌价格区间 
    reid 2019-09-26
    返回值：商品价格
**/
(
    c_stationed_user_id     number,   --当前访问的私有平台ID（即所属私有商家的ID）
    c_product_itemnumber   varchar2     --商品货号    
) return varchar2
 is
    v_count number:=0;                               --临时变量
    v_product_prize_str varchar2(50):='0.00-0.00';   --需要返回的商品价格
BEGIN
    --判断商品是私有商品还是童库分享的商品
    select count(1) into v_count from TBL_PVTP_PRODUCT_INFO ppi where ppi.stationed_user_id = c_stationed_user_id
    and ppi.itemnumber = c_product_itemnumber;
    IF v_count <> 0 THEN
            --通过sku获取最低价
            select nvl(to_char(min(product_prize_tag),'fm999999990.00'),'0.00')||'-'||nvl(to_char(max(product_prize_tag),'fm999999990.00'),'0.00') 
            into v_product_prize_str  
            from tbl_pvtp_product_sku 
            where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架';
    ELSE
            --通过sku获取最低价
            select nvl(to_char(min(product_prize_tag),'fm999999990.00'),'0.00')||'-'||nvl(to_char(max(product_prize_tag),'fm999999990.00'),'0.00') 
            into v_product_prize_str  
            from tbl_product_sku 
            where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架';
    END IF;
    return v_product_prize_str;
END pvtp_getProduct_TagPrice_Qj;
/

