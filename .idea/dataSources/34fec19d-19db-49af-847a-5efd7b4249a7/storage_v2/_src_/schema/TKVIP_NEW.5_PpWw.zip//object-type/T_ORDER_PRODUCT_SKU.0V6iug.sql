create TYPE  "T_ORDER_PRODUCT_SKU" FORCE  as object
(
    sku_id int,  --订单商品sku
    order_old_prize number,  --订单sku旧价格
    order_new_prize number,  --订单sku新价格
    order_discount_money number --订单sku优惠价格
);
/

