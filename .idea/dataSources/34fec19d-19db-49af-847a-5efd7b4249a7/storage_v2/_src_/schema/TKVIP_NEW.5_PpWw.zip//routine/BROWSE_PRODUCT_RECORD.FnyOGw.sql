create PROCEDURE           browse_product_record
/**
     (新版)添加浏览商品记录
     shifan
     2017-05-16
     返回值：添加成功或添加失败消息
  **/
(
    client_user_name  IN VARCHAR2,  --用户名
    client_itemnumber IN VARCHAR2, --商品货号
    output_status     OUT VARCHAR2, --返回的状态码 0-添加失败 1-添加成功
    output_msg        OUT VARCHAR2 --返回的信息
 ) IS
      temp_count                   INT := 0; --临时变量
      temp_user_id                 NUMBER := 0; --用户id
      temp_look_product_price      VARCHAR2(50); --浏览商品价格
      temp_look_product_name       VARCHAR2(300); --浏览商品名字
      temp_look_product_img_url    VARCHAR2(200); --浏览商品图片路径
      temp_product_type_id         number; --浏览商品类型ID
BEGIN
      output_status := '0';
      output_msg    := '添加失败！';
      SELECT nvl(min(id),0) INTO temp_user_id FROM tbl_user_info WHERE user_name = client_user_name;
      IF temp_user_id = 0 THEN
        output_msg := '用户信息不能为空，请检查！';
        RETURN;
      END IF;
      
      SELECT COUNT(*)
        INTO temp_count
        FROM tbl_product_info
       WHERE itemnumber = client_itemnumber;
      IF temp_count = 0 THEN
        output_msg := '商品信息不存在，请检查！';
        RETURN;
      END IF;

      --通过用户名获取商品货号最低价格
      temp_look_product_price:=getProduct_SalePrice_Min(client_user_name, client_itemnumber);  
        
      --获取商品名称，主图片路径
      SELECT product_name, product_img_url, PRODUCT_TYPE_ID
        INTO temp_look_product_name, temp_look_product_img_url, temp_product_type_id
        FROM tbl_product_info
       WHERE itemnumber = client_itemnumber;
      --先删除原有记录，再新增
      DELETE FROM tbl_user_see_product_log
       WHERE user_id = temp_user_id
             AND product_itemnumber = client_itemnumber;
      INSERT INTO tbl_user_see_product_log
        (id, user_id, product_name, product_price, product_img_url, product_itemnumber, create_date, product_type_id)
      VALUES
        (seq_user_see_product_log.NEXTVAL, temp_user_id, temp_look_product_name, temp_look_product_price, temp_look_product_img_url, client_itemnumber, SYSDATE, temp_product_type_id);
      output_status := '1';
      output_msg    := '浏览成功！';
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        output_msg := '浏览商品记录时出现未知错误！';
        ROLLBACK;
END browse_product_record;
/

