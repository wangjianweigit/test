create FUNCTION           is_display_search
/**
    （新版）通过用户、货号判断商品是否显示(上架、暂下架状态商品)----------商品列表页表专用
    考虑以下信息：
    1、商品显示区域
    2、站点延后显示时间
    3、区域控货
    songwangwen
    2017-07-18
   显示规则
   
   reid 2018.12.26 私有平台商品也需要展示
   如果商品不是启用状态，直接返回，不显示 zhengfangyuan 2019.02.27
   返回值：1（显示）  0：不显示
   
**/
(
    c_user_name   varchar2,            --用户名
    c_product_itemnumber   varchar2    --商品货号
) return varchar2
 is
     v_id number:=0;                                --商品ID
     v_sell_state_date date;                        --商品最后上架时间
     v_district_templet_id number:=0;               --商品显示区域模板ID
     v_user_company_address_prov number:=0;         --用户经营地 省代码
     v_user_company_address_city number:=0;         --用户经营地 市代码
     v_site_id number:=0;                           --客户站点ID
     v_flag number:=1;                              --是否显示   1（显示）  0：不显示 2:订货会商品
     v_stationed_user_id number:=0;                 --入驻商ID
     v_month_statement number:=2;                   --入驻商是否支持月结  1、不支持月结   2、支持月结
     v_credit_money number:=0;                       --会员月结额度
     v_count number:=0;                       --临时变量
     
     v_user_type number:=0;                         --用户类型 1 用户会员 2 店铺会员 3店铺查看用户 4：游客 5：私有平台用户
BEGIN

    --如果不是普通商品，直接返回，不显示   songwanwgen    2018.09.06
      --如果商品不是启用状态，直接返回，不显示 zhengfangyuan 2019.02.27
    SELECT COUNT(1) INTO v_count  FROM TBL_PRODUCT_INFO TPI WHERE TPI.PRODUCT_TYPE in (0,3) AND TPI.ITEMNUMBER = c_product_itemnumber and tpi.start_stop_state = 1
     and exists(
        select 1
        from tbl_product_sku
        where product_itemnumber = TPI.itemnumber
        and start_stop_state = 1
        and product_group = '尺码'
    );
    IF v_count =0 THEN
        RETURN 0;
    END IF;
    
    --查询用户城市代码和站点
    select user_company_address_province,user_company_address_city,site_id,user_type into v_user_company_address_prov,v_user_company_address_city,v_site_id,v_user_type from tbl_user_info where user_name = c_user_name;      

    --查询商品ID和上架时间,区域模板
    select id,sell_state_date,district_templet_id,stationed_user_id into v_id,v_sell_state_date,v_district_templet_id,v_stationed_user_id from tbl_product_info where ITEMNUMBER = c_product_itemnumber and (STATE = '上架' or STATE = '暂下架');
    
    --查询入驻商是否支持月结
    select month_statement into v_month_statement from TBL_STATIONED_USER_INFO where id = v_stationed_user_id;

    --查询会员月结额度
    select credit_money into v_credit_money from TBL_BANK_ACCOUNT where user_id = c_user_name;

    --有月结额度  并且  不支持 授信支付  则不显示商品
    if v_credit_money!=0 and  v_month_statement=1 then
        v_flag:=0;
    end if;
   
    if v_flag !=0 then
        --查询商品是否在站点显示
        select count(1) into v_flag from TBL_SITE_PRODUCT_DELAY where site_id = v_site_id and product_id = v_id and v_sell_state_date+delay_days<=sysdate;
    end if;

    if v_user_type in (1,2,5) then 
        if v_flag !=0 then
            --填写了省市信息
            if v_user_company_address_prov is not null and v_user_company_address_prov != 0 and v_user_company_address_city is not null and v_user_company_address_city != 0  then 
                --查询商品是否在用户区域显示
                select count(1) into v_flag from TBL_DISTRICT_TEMPLET_REL where template_id = v_district_templet_id and (region_id = v_user_company_address_prov or region_id = v_user_company_address_city);
            end if;
        end if;
    end if;

    if v_flag !=0 then
        v_flag := 1;
    end if;
    
    if v_user_type in (1,2) then 
        /**********************进行区域控货的判断********************************/
       --全部控货的过滤处理
       SELECT COUNT(1) INTO v_count
         FROM TBL_PRODUCT_INFO TPI,MV_USER_PRODUCT_CONTROL_DETAIL vupc
        WHERE TPI.ITEMNUMBER = c_product_itemnumber
          and VUPC.USER_ID = c_user_name
          AND VUPC.PRODUCT_CONTROL_MODE = '1'
          AND VUPC.PRODUCT_CONTROL_BRAND = TPI.BRAND_ID
                          ;
       --当前商品在控货范围内
       if v_count > 0 then
          v_flag := 0;
       else
         --下单控货的过滤处理
         SELECT COUNT(1) INTO v_count
           FROM TBL_PRODUCT_INFO TPI,MV_USER_PRODUCT_CONTROL_DETAIL VUPC,MV_USER_ORDER_PRODUCT TOPS,
           (SELECT A.ITEMNUMBER FROM (SELECT ITEMNUMBER,ORDER_DATE FROM MV_ORDER_PRODUCT_CONTROL WHERE CONTROL_USER_ID = c_user_name) A,
                (SELECT ITEMNUMBER,ORDER_DATE FROM MV_ORDER_PRODUCT_CONTROL WHERE USER_ID = c_user_name) B
                WHERE A.ITEMNUMBER = B.ITEMNUMBER
                  AND A.ORDER_DATE < B.ORDER_DATE) t
          WHERE TPI.ITEMNUMBER = c_product_itemnumber
                AND VUPC.PRODUCT_CONTROL_MODE = '2'
                AND VUPC.USER_ID = c_user_name
                AND VUPC.PRODUCT_CONTROL_BRAND = TPI.BRAND_ID
                AND TOPS.USER_ID = VUPC.CONTROL_USER_ID
                AND TOPS.ITEMNUMBER = TPI.ITEMNUMBER
                --过滤被控货人可以看的商品 yejingquan 2019.05.31
                AND TPI.ITEMNUMBER != t.ITEMNUMBER;
         if v_count > 0 then
          v_flag := 0;
         end if;
       end if;
   end if;
   return v_flag;

END is_display_search;
/

