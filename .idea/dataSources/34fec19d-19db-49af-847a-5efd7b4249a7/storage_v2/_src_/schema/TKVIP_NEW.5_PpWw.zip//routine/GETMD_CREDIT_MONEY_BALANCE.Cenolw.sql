create FUNCTION getMd_CREDIT_MONEY_BALANCE
/**
    获取门店授信余额
    wangpeng
    2016-09-30
**/
(
    c_md_id   number       --门店ID
) return number
 is
     v_credit_money_use number:=0;       --门店总欠款
     v_credit_money number:=0;         --门店授信余额
     v_credit_money_cz number:=0;      --充值占用
     v_credit_money_order number:=0;   --订单占用
     v_credit_money_wait  number:=0;    --待缴款
BEGIN
    --查询门店授信额度
    select a.STORE_LIMIT into v_credit_money from TBL_STORE_INFO a where a.id =c_md_id;
   ---0查询业务代客户现金充值待审核使用额度
        select nvl(sum(MONEY),0) into v_credit_money_cz from TBL_USER_CHARGE_RECORD where STATE = '待验款' and MD_ID = c_md_id;
        ---1查询门店订单现金支付待审核使用额度
        select nvl(sum(LOGISTICS_MONEY+PRODUCT_MONEY+df_money),0) into v_credit_money_order from TBL_ORDER_INFO where PAYMENT_STATE = 3 and (XDR_USER_TYPE='5' or XDR_USER_TYPE='6') and MD_ID = c_md_id;
        ---2查询门店待缴款额度
        select nvl(sum(CONTRIBUTION_MONEY),0) into v_credit_money_wait from TBL_CONTRIBUTION_WAIT where STATE!=3 and (XDR_USER_TYPE='5' or XDR_USER_TYPE='6') and MD_ID = c_md_id;
        --查询门店总待缴款金额
        v_credit_money_use:=v_credit_money_cz+v_credit_money_order+v_credit_money_wait;
        --计算门店可用额度
        v_credit_money:=v_credit_money-v_credit_money_use;

   return v_credit_money;
END getMd_CREDIT_MONEY_BALANCE;
/

