create PROCEDURE           CANCEL_PRE_ORDER_AUTO
/**
     预付订单超过24小时未付款自动取消
     此存储过程 供定时任务调用
     wangpeng
     2017-10-27 

     songwangwen 20180727 增加会员卡相关修改
     修改订单自动取消规则 zhengfy 20190718
  **/
IS
   c_user_type                VARCHAR2(50):='7';   --表示是平台用户获取会员卡额度校验码的key值
   v_login_name               varchar2(50);             --用户登录名
   v_user_name                VARCHAR2(50);        --平台会员user_name
   v_mbr_card number := 0;                         --订单是否使用会员卡  1-.没有使用 2-有使用
   v_product_money number := 0;                    --订单商品金额
   v_card_id number := 0;                          --会员卡ID
   v_expiration_date DATE;                         --会员卡过期时间
   v_user_key                 VARCHAR2 (32);       --用户KEY
   v_create_code              VARCHAR2 (32);       --通过当前余额计算得到的校验码，用于校验余额是否被篡改
   v_card_balance_checkcode   VARCHAR2 (50);       --临时变量，会员卡余额校验码
   v_card_balance             NUMBER;              --临时变量，会员卡余额
BEGIN
  --定义游标查询超过24小时未付款的订单
   declare cursor out_time_orders is  
        select USER_ID,USER_MANAGE_NAME,order_number from TBL_PRE_ORDER_INFO 
        where decode(last_cancel_date, null, create_date + 1 - sysdate, last_cancel_date - sysdate)<0 and ORDER_STATE = 1;

   begin
        for c_row in out_time_orders loop
           select login_name,user_name into v_login_name,v_user_name from tbl_user_info where id = c_row.USER_ID;
           update TBL_PRE_ORDER_INFO SET CANCEL_REASON = '订单超过付款截止时间未付款，系统自动取消', CANCEL_DATE = sysdate, ORDER_STATE = 6, CANCEL_USER_NAME = v_login_name, CANCEL_USER_REALNAME = c_row.USER_MANAGE_NAME
           WHERE ORDER_NUMBER = c_row.order_number AND USER_ID = c_row.USER_ID;

            ------------------------------------会员卡额度返还相关-start-------------------------------------------------
            SELECT MBR_CARD,PRODUCT_MONEY INTO v_mbr_card, v_product_money FROM TBL_PRE_ORDER_INFO WHERE ORDER_NUMBER = c_row.order_number AND USER_ID = c_row.USER_ID;
            --会员卡余额回退 1.未使用会员卡 2.使用会员卡
            IF v_mbr_card = 2 THEN
               --会员卡信息
               SELECT ID,CARD_BALANCE,EXPIRATION_DATE INTO v_card_id,v_card_balance,v_expiration_date FROM TBL_USER_MBR_CARD WHERE USER_ID = c_row.USER_ID;
               IF v_expiration_date > SYSDATE THEN /****会员卡未过期，额度返还****/
                     -------------------------------------验证余额是否被篡改-start--------------------------------------------------
                     --获取用户KEY
                     SELECT getUserKey (v_user_name, 'old', c_user_type) INTO v_user_key FROM DUAL;
                     --查询得到数据库中当前的校验码
                     SELECT card_balance_checkcode,card_balance INTO v_card_balance_checkcode,v_card_balance FROM TBL_USER_MBR_CARD WHERE user_id = c_row.USER_ID;
                     --获取余额校验码并判断是否被篡改
                     v_create_code := getCheck_Code (v_user_name, v_card_balance, v_user_key);

                     IF  v_card_balance_checkcode IS NULL OR v_card_balance_checkcode <> v_create_code
                     THEN
                        RETURN;
                     END IF;
                    --创建新的账户KEY
                    select getUserKey(v_user_name,'new',c_user_type) into v_user_key from dual;
                    --产生新的余额校验码（过期会员卡，余额直接修改为0）
                    select getcheck_code(v_user_name,v_card_balance+v_product_money,v_user_key) into v_card_balance_checkcode from dual;
                    ---更新会员卡余额,校验码
                    UPDATE TBL_USER_MBR_CARD
                       SET card_balance = v_card_balance+v_product_money,
                           card_balance_checkcode = v_card_balance_checkcode,
                           update_date = SYSDATE
                     WHERE user_id = c_row.USER_ID;
                     --更新用户账户KEY
                     update TBL_USER_MBR_CARD_CACHE_KEY set cache_key = v_user_key,create_time=sysdate where user_name = v_user_name;
                  ---增加会员卡使用记录
                  INSERT INTO TBL_USER_MBR_CARD_USE_RECORD (
                     ID, MBR_CARD_ID, ORDER_NUMBER, TYPE, USED_AMOUNT, REMARK, CREATE_DATE
                  ) VALUES (
                      SEQ_USER_MBR_CARD_USE_RECORD.NEXTVAL, v_card_id, c_row.order_number, 4, v_product_money, '预定订单付款超时，会员卡额度返还。订单号：' || c_row.order_number, SYSDATE
                  );
               END IF;
            END IF;
            ------------------------------------会员卡额度返还相关-end------------------------------------------------------
        end loop;
    end;
   commit;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END CANCEL_PRE_ORDER_AUTO;
/

