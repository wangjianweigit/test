create FUNCTION           GET_PRODUCT_QUOTE_RANGE_BY_ID
/**
    根据货号获取一个商品的报价区间
    songwangwen
    2017.04.18
    返回值：商品价格价格区间 格式 最低价-最高价  示例  57.5-65.3
**/
(
    c_product_id   number--商品货号    
) return varchar2
 is
 v_product_prize_str varchar2(50):='0.00-0.00';   --需要返回的商品价格
 v_prize_min number:=0;                           --最低报价
 v_prize_max number:=0;                           --最高报价
BEGIN

   --获取最低价
   select MIN(PRODUCT_PRIZE_COST) INTO v_prize_min from TBL_PRODUCT_SKU_APPLY WHERE PRODUCT_GROUP='尺码' and PRODUCT_ID = c_product_id;
   --获取高低价  
   select MAx(PRODUCT_PRIZE_COST) INTO v_prize_max from TBL_PRODUCT_SKU_APPLY WHERE PRODUCT_GROUP='尺码' and PRODUCT_ID = c_product_id;
   --计算价格
   IF v_prize_min != v_prize_max
   THEN
         v_product_prize_str:= to_char(v_prize_min,'fm999999990.00') ||' - '||to_char(v_prize_max,'fm999999990.00');
   END IF;
   IF v_prize_min = v_prize_max
   THEN
         v_product_prize_str:= to_char(v_prize_min,'fm999999990.00');
   END IF;
   return v_product_prize_str;
END GET_PRODUCT_QUOTE_RANGE_BY_ID;
/

