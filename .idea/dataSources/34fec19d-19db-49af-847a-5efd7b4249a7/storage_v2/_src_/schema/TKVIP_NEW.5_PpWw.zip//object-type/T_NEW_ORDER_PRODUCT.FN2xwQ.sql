create TYPE           T_NEW_ORDER_PRODUCT               
FORCE  as object
(
    product_itemnumber VARCHAR2 (50 Byte),                --商品货号
    product_sku_list    T_NEW_ORDER_PRODUCT_SKU_LIST      --商品SKU集合
);
/

