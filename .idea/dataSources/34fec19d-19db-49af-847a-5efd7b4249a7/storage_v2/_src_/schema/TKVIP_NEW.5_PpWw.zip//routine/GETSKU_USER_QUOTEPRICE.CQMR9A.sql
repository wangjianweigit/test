create FUNCTION           getSku_User_QuotePrice
/** 
    计算商品SKU的报价信息
    -------------------------reid  2019-05-30-------------------------          
    计算规则如下1、2、3种方式计算出的报价取最低值
    1、商品参加了【清尾活动】、且设置了阶梯价格
        1）、直接使用阶梯报价作为报价
    2、商品没有参加【清尾活动】、或者参加【清尾活动】但是没有设置阶梯价格
        1）、如果当前用户对应当前商品有特殊折扣，则直接使用SKU报价作为最终报价A
        2）、如果商品参加了活动（无特殊折扣），则报价等于原报价*活动折扣
        3）、如果商品未参加任何活动，则报价等于原SKU报价
    3、如果使用了VIP卡
        1）、直接使用阶梯报价作为报价
    -------------------------reid  2019-06-27 规则改造如下------------
    1、根据当前用户以及商品，需要查询出以下值
        1)、是否参加了活动
        2)、如果参加了清尾活动，是否有设置阶梯价
        3)、活动售价(即考虑商品活动折扣计算出来的商品售价)
        4)、清尾阶梯售价(即考虑清尾活动的阶梯价格计算出来的商品售价)
    2、当商品没有参加任何活动。报价信息 = SKU原始报价
    3、商品参加了活动（非清尾）。报价信息 = SKU原始报价*活动折扣
    4、商品参加了活动（清尾活动）
        1）、清尾阶梯售价 < 活动售价：报价信息 = 阶梯价
        2）、清尾阶梯售价 >= 活动售价：报价信息 = SKU原始报价*活动折扣
    返回值：商品报价信息，用于清分计算
**/
(
     c_user_name        varchar2,     --用户名
     c_product_sku_id   number,       --商品SKUID 
     c_buy_out_flag     number:=1,    --是否买断该商品  1：非买断   2：买断(仅当商品参加清尾活动时，该参数有意义)
     c_product_count    number:=1,    --商品购买量，一次下单中，当前货号的总购买量(仅当商品参加清尾活动时，该参数有意义)
     c_mbr_card         number:=1     --是否使用了会员卡  1 没有使用   2.有使用
) return number
is
     v_temp_count               number :=0;     --临时变量
     v_site_id                  number:=0;      --会员站点
     v_product_type             number:=0;      --商品类型（0：普通商品，1：定制商品，2：菜鸟商品，3：私有平台商品）   --私有平台特殊价格新加配置
     v_product_itemnumber       varchar2(50);   --商品货号
     v_activity_id              number:=0;      --商品参加的活动ID
     /**
        0：未参加活动
        1：限时折扣（数据表：tbl_sale_activity_info）;
        2：订货会（表tbl_preorder_activity_info）
        3:店铺活动
        4：预售（表tbl_presell_activity_info）
        5：清尾活动（表tbl_clear_activity_info）
     **/
     v_activity_type            number:=0;      --商品参加的活动类型 
     v_activity_product_id      number:=0;      --商品参加的活动管理的活动商品表的ID
     v_product_specs            varchar2(50);   --商品规格名称    
     v_quote_price              number :=0;     --最终返回的报价信息
     v_activity_quote_price     number :=0;     --活动情况下的报价信息
     v_latter_quote_price       number :=0;     --参加了【清尾】活动且存在阶梯价情况下的报价信息
BEGIN  
   --获取会员信息
   select nvl(min(site_id),0)
   into v_site_id
   from tbl_user_info where user_name = c_user_name;  
   --查询商品基本信息
   select ps.product_itemnumber,ps.product_specs,ps.product_prize_cost,pi.product_type 
   into v_product_itemnumber,v_product_specs,v_quote_price,v_product_type
   from tbl_product_sku ps,tbl_product_info pi
   where ps.product_itemnumber = pi.itemnumber
   and ps.product_group = '尺码' and ps.id = c_product_sku_id;
   ---查询商品参加了那个活动
    SELECT
    (case when activity_state='going' then temp2.activity_id else 0 end),
    (case when activity_state='going' then temp2.activity_type else 0 end),
    (case when activity_state='going' then temp2.activity_product_id else 0 end) 
    into v_activity_id,v_activity_type,v_activity_product_id
    from
    (
        select 
        (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,0,instr(activity_tag,'#-#',1,1)-1)) else 0 end) activity_id,
        (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,instr(activity_tag,'#-#',1,1)+3,1)) else 0 end) activity_type,
        (case when length(temp.activity_tag)>0 then substr(temp.activity_tag,instr(activity_tag,'#-#',1,2)+3,5) else '' end) activity_state,
        (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,instr(activity_tag,'#-#',1,4)+3)) else 0 end) activity_product_id
        from (
            select NVL(GET_ACTIVITY_TAG(c_user_name,v_product_itemnumber),'') activity_tag from dual
        ) temp
    ) temp2;
   /*1、***********************商品参加了清尾活动，且设置了阶梯价格***********************************************/
   IF v_activity_type = 5 THEN
       IF c_buy_out_flag = 1 THEN
               ---查询是否存在阶梯价格
               select count(1) into v_temp_count from 
               TBL_ACTIVITY_PRODUCT_SPECPRIZE  aps
               where aps.activity_product_id = v_activity_product_id
               and activity_id = v_activity_id
               and product_itemnumber = v_product_itemnumber
               and PRODUCT_SPEC = v_product_specs
               and min_count >0
               and min_count <= c_product_count;
                --已设置阶梯价，则需要按照阶梯价进行计算价格
                   IF v_temp_count > 0 THEN
                       --查询当前阶梯的报价信息
                       select prize into v_latter_quote_price
                       FROM TBL_ACTIVITY_PRODUCT_SPECPRIZE aps
                       where aps.activity_product_id = v_activity_product_id
                       and activity_id = v_activity_id
                       and product_itemnumber = v_product_itemnumber
                       and PRODUCT_SPEC = v_product_specs
                       and min_count = (
                             select max(min_count) from 
                             TBL_ACTIVITY_PRODUCT_SPECPRIZE 
                             where aps.activity_product_id = v_activity_product_id
                             and activity_id = v_activity_id
                             and product_itemnumber = v_product_itemnumber
                             and PRODUCT_SPEC = v_product_specs
                             and min_count >0
                             and min_count <= c_product_count
                       );
                   END IF;
       END IF;
       --如果是买断，则获取买断的报价信息
       IF c_buy_out_flag = 2 THEN
             ---查询是否存在买断价格
               select count(1) into v_temp_count from 
               TBL_ACTIVITY_PRODUCT_SPECPRIZE  aps
               where aps.activity_product_id = v_activity_product_id
               and activity_id = v_activity_id
               and product_itemnumber = v_product_itemnumber
               and PRODUCT_SPEC = v_product_specs
               and min_count =-1;
                --已设置阶梯价，则需要按照阶梯价进行计算价格
                   IF v_temp_count > 0 THEN
                       --查询当前阶梯的报价信息
                       select prize into v_latter_quote_price
                       FROM TBL_ACTIVITY_PRODUCT_SPECPRIZE aps
                       where aps.activity_product_id = v_activity_product_id
                       and activity_id = v_activity_id
                       and product_itemnumber = v_product_itemnumber
                       and PRODUCT_SPEC = v_product_specs
                       and min_count = -1;
                   END IF;
       END IF;
   END IF;
   /*2、******************查询商品在特殊价格、活动情况下的【活动报价】*********************************/
   ------2.1 查询是否参加了平台活动
   select count(1) into v_temp_count from TBL_ACTIVITY_PRODUCT ap where id = v_activity_product_id;
   IF v_activity_type<>0 AND v_activity_type<>3 AND v_temp_count<>0 then
       SELECT (v_quote_price*activity_discount) into v_activity_quote_price FROM TBL_ACTIVITY_PRODUCT ap where id = v_activity_product_id;
   END IF;
   ------2.2 查询是否参加了店铺活动
   IF v_activity_type = 3 THEN
             select count(1) into v_temp_count from tbl_sta_sale_activity_product where id = v_activity_product_id;
             IF v_temp_count<>0 THEN
                    select (v_quote_price*activity_discount) into v_activity_quote_price from tbl_sta_sale_activity_product where id = v_activity_product_id;
             END IF;
   END IF;
   --如果商品的活动报价存在，判断原始报价与活动报价的大小，取较小值
   IF v_activity_quote_price<>0 THEN
          v_quote_price:= least(v_quote_price,v_activity_quote_price);
   END IF;
   --如果商品的活动阶梯报价存在，判断原始报价与活动阶梯报价的大小，取较小值
   IF v_latter_quote_price<>0 THEN
      v_quote_price:= least(v_quote_price,v_latter_quote_price);
   END IF;
   return v_quote_price;
END getSku_User_QuotePrice;
/

