create PROCEDURE           new_confirm_order_entry
/**
     确认订单口[多仓下单] 
     reid  2019.04.23 创建
     
  **/
(
 client_user_name in varchar2,             --用户名
 client_order_lst IN  T_NEW_ORDER_LIST,         --订单数组对象
 client_mbr_card number,                   --是否使用了会员卡优化（1：未使用，2：使用）
 output_status  out varchar2,              --返回的状态码 0-失败 1-成功
 output_msg out varchar2                   --返回的信息
) AS
v_order                     T_NEW_ORDER;                            --订单对象
v_order_product             T_NEW_ORDER_PRODUCT;                    --订单商品对象
v_order_product_list        T_NEW_ORDER_PRODUCT_LIST;               --订单商品对象集合
v_order_product_sku         T_NEW_ORDER_PRODUCT_SKU;                --订单商品SKU对象
v_order_product_sku_list    T_NEW_ORDER_PRODUCT_SKU_LIST;          --订单商品SKU对象集合
v_temp_count                number :=0;--临时变量
v_order_product_money       number :=0;--订单金额（页面汇总）
v_sku_product_money         number :=0;--商品SKU金额（后台汇总）

BEGIN
  output_status:='0';
   /**临时代码，清空表数据**/
  delete from TMP_NEW_ORDER;
  delete from TMP_NEW_ORDER_PRODUCT;
  delete from TMP_NEW_ORDER_PRODUCT_SKU;
  --循环处理订单
  IF client_order_lst.count > 0 THEN
     FOR i IN 1..client_order_lst.COUNT LOOP
        v_order:=client_order_lst(i);--获取订单对象
        /**
        1.0 判断仓库是否存在，不存在则直接返回错误，不存在包括ID错误或者ID对当前用户不可见
        **/
         select count (1) into v_temp_count
         from tbl_site_warehouse sw
         where sw.warehouse_id = v_order.warehouse_id
              and exists (select 1 from tbl_user_info ui
                         where ui.user_name = client_user_name and sw.site_id = ui.site_id);
         IF v_temp_count = 0
         THEN
            OUTPUT_MSG := '下单仓库不存在';
            RETURN;
         END IF;
        --插入订单临时表信息
        INSERT INTO TMP_NEW_ORDER (ORDER_ID,WAREHOUSE_ID,PRODUCT_MONEY) VALUES (i,v_order.warehouse_id,v_order.product_money);
        /****************************循环处理订单对象中的商品信息*********************************/
        v_order_product_list:= v_order.product_list;
          IF v_order_product_list.count > 0 THEN
                 FOR j IN 1..v_order_product_list.COUNT LOOP
                        v_order_product:=v_order_product_list(j);--获取订单商品对象ORDER_ID            NUMBER,
                        INSERT INTO TMP_NEW_ORDER_PRODUCT (ORDER_ID,ORDER_PRODUCT_ID,PRODUCT_ITEMNUMBER,BUY_OUT_FLAG,ACTIVITY_ID,ACTIVITY_TYPE)
                        SELECT
                        i ORDER_ID,
                        to_number(i||''||j) ORDER_PRODUCT_ID,
                        v_order_product.product_itemnumber,
                        v_order_product.buy_out_flag,
                        (case when activity_state='going' then temp2.activity_id else 0 end) activity_id,
                        (case when activity_state='going' then temp2.activity_type else 0 end) activity_type
                        from
                        (
                            select 
                            (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,0,instr(activity_tag,'#-#',1,1)-1)) else 0 end) activity_id,
                            (case when length(temp.activity_tag)>0 then to_number(substr(temp.activity_tag,instr(activity_tag,'#-#',1,1)+3,1)) else 0 end) activity_type,
                            (case when length(temp.activity_tag)>0 then substr(temp.activity_tag,instr(activity_tag,'#-#',1,2)+3,5) else '' end) activity_state
                            from (
                                select NVL(GET_ACTIVITY_TAG(client_user_name,v_order_product.product_itemnumber),'') activity_tag from dual
                            ) temp
                        ) temp2;
                       /****************************循环处理订单对象中的商品SKU信息*********************************/
                       v_order_product_sku_list:=v_order_product.product_sku_list;
                       IF v_order_product_sku_list.count > 0 THEN
                            FOR k IN 1..v_order_product_sku_list.COUNT LOOP
                                v_order_product_sku:=v_order_product_sku_list(k);--获取订单商品SKU对象
                                INSERT INTO TMP_NEW_ORDER_PRODUCT_SKU (ORDER_ID,ORDER_PRODUCT_ID,SKU_ID,COUNT) VALUES (i,to_number(i||''||j),v_order_product_sku.sku_id,v_order_product_sku.count);
                            END LOOP;/**end v_order_product_list**/
                       ELSE
                         output_status:='0';
                         output_msg:='订单商品SKU列表参数错误';
                         RETURN;      
                       END IF;  
                 END LOOP;/**end v_order_product_list**/
         ELSE
            output_status:='0';
            output_msg:='订单商品列表参数错误';
            RETURN;      
         END IF;
     END LOOP;/**end client_order_lst**/
     ----2 完成下单数据的记录后，进行下单库存的相关校验
     ----2.1 校验SKU的有效性，如果SKU已下架则不允许下单
     select count(1) into v_temp_count from  TMP_NEW_ORDER_PRODUCT_SKU;--查询下单的商品SKU数量
     SELECT   v_temp_count
          - (SELECT COUNT (1)
               FROM TBL_PRODUCT_SKU ps
                    inner join TMP_NEW_ORDER_PRODUCT_SKU ops on ps.id = ops.sku_id
                    inner join TBL_PRODUCT_INFO pi on ps.product_itemnumber = pi.itemnumber
                    WHERE (pi.state = '上架' or pi.state = '暂下架')
                    AND pi.STATE = '上架')
     INTO v_temp_count
     FROM DUAL;
     IF v_temp_count <> 0
     THEN
        output_msg := '部分商品SKU不存在或已下架，请检查SKU的有效性!';
     RETURN;
     END IF;
     ---2.2 校验商品库存是否充足
     begin
      for tb in(
        SELECT 
        ops.sku_id,
        getproductsku_stocks(ops.sku_id,tno.warehouse_id,client_user_name) stock_count,
        ops.count order_count
        from TMP_NEW_ORDER_PRODUCT_SKU ops
        inner join TMP_NEW_ORDER_PRODUCT po on ops.order_product_id = po.order_product_id
        inner join TMP_NEW_ORDER tno on tno.order_id = po.order_id
    ) loop
         IF tb.stock_count < tb.order_count
         THEN
            SELECT    'SKU('
                   || tb.sku_id
                   || '),货号:'
                   || product_itemnumber
                   || ' '
                   || product_sku_name
                   || ',可下单数：'
                   || tb.stock_count
                   || '，您实际下单数：'
                   || tb.order_count
              INTO output_msg
              FROM TBL_PRODUCT_SKU
             WHERE ID = tb.sku_id;
         RETURN;
         END IF;
    end loop;
    end;
    ---2.3 循环商品表，判断所有货号（无论是否是同一个仓库），买断标志位必须一致
    select 
    sum(case when count(1) >1 then 1 else 0 end) into v_temp_count
    from
    (
        select 
        product_itemnumber,
        buy_out_flag
        from tmp_new_order_product
        group by product_itemnumber,buy_out_flag
    ) group by product_itemnumber;
    
    IF v_temp_count <> 0
     THEN
        output_msg := '所有订单中的相同货号的买断标志位必须一致';
     RETURN;
     END IF;
     /***
     循环商品SKU表，将计算出商品SKU的售价信息，用于校验商品的金额
     ***/
    merge into TMP_NEW_ORDER_PRODUCT_SKU t1
    using (
            SELECT ops.order_id,
               ops.order_product_id,
               ops.sku_id,
               get_ByOut_SalePrice (10000329,op.activity_id,ops.sku_id,op.buy_out_flag,get_ByOut_SaleProductCount (ops.sku_id)) sku_unit_price
          FROM TMP_NEW_ORDER_PRODUCT_SKU ops,TMP_NEW_ORDER_PRODUCT op where ops.order_product_id = op.order_product_id
    ) t2
       on (t1.order_id = t2.order_id and t1.order_product_id = t2.order_product_id and t1.sku_id = t2.sku_id)
       when matched then 
       update set T1.sku_unit_price = t2.sku_unit_price;
       ----3 库存校验完成，校验商品价格信息
       select sum(PRODUCT_MONEY) into v_order_product_money from TMP_NEW_ORDER;
       select sum(COUNT*NVL(SKU_UNIT_PRICE,0)) into v_sku_product_money from TMP_NEW_ORDER_PRODUCT_SKU ops;
       IF v_order_product_money<>v_sku_product_money THEN
             output_msg := '商品价格被篡改或商品价格发生变化,应收货款（'|| v_sku_product_money|| '），请重新下单!';
            RETURN;
       END IF;
  ELSE
         output_status:='0';
         output_msg:='订单列表参数错误';
         RETURN;
  END IF;
  output_status:='1';
  output_msg := '订单信息校验成功';
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END new_confirm_order_entry;
------------------------------------------------
/

