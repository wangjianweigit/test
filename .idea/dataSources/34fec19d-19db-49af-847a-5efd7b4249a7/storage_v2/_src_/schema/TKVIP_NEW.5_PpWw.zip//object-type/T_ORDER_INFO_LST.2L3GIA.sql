create TYPE           T_ORDER_INFO_LST                  
AS TABLE OF T_ORDER_INFO;
------------------------------------------------
/

