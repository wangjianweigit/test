create PROCEDURE           update_account_record_balance
/**
     处理会员收支记录余额
     shif
     2017-05-29 
  **/
 IS
v_account_balance     number;         --当前余额
BEGIN
  --定义游标查询超过24小时未付款的订单
   declare cursor account_record is  
        SELECT ROW_NUMBER() OVER(PARTITION BY collect_user_name ORDER BY create_date desc,id DESC) rn,        
       a.* FROM (select * from TBL_USER_ACCOUNT_RECORD where create_date > to_date('20170602','yyyymmdd') and USER_NAME in (10003296,10006451,10002326,10006068,10000754,10006227,10005335,10000486,10001416,10005077)) a;
        
   begin
        for c_row in account_record loop
           if c_row.rn = 1 then
                select account_balance into v_account_balance from tbl_bank_account where user_id = c_row.COLLECT_USER_NAME;
           end if;
           
           DBMS_OUTPUT.PUT_LINE('修改记录编号：【'||c_row.id||'】修改前金额：【'||c_row.SURPLUS_MONEY||'】修改后金额：【'||v_account_balance||'】');
           update TBL_USER_ACCOUNT_RECORD set SURPLUS_MONEY = v_account_balance where id = c_row.id;
           
           if c_row.RECORD_CHANNEL!='授信' then
               if c_row.ACCOUNTANTS_SUBJECT_ID = '1001CZ' then
                    v_account_balance := v_account_balance - c_row.money;
               else
                    v_account_balance := v_account_balance + c_row.money;
               end if;
           end if;
           
           
        end loop;
    end;
    
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END update_account_record_balance;
/

