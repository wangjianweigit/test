create FUNCTION           getFreightMoney_Order_Return
/**
    计算运费--(退货时，计算选择退的商品的运费)
    shif
    20170823
    返回值：订单退款商品运费
**/
(
 c_order_number in varchar2                          --订单编号
) return number
 is
 v_total_money                      number:=0;       --运费
 v_order_logistics_money            number:=0;       --订单运费
 v_temp_count                       number:=0;       --临时变量
 v_order_deliver_logis_money    number:=0;       --订单已发运费
 v_order_return_logis_money     number:=0;       --订单已退运费
BEGIN
    --获取订单的运费
    select logistics_money into v_order_logistics_money from tbl_order_info where order_number = c_order_number;
    --订单免运费时
    if v_order_logistics_money<=0 then
       return 0;
    end if;
    --计算已退运费
    select nvl((select sum(t.logistics_money) from TBL_ORDER_RETURN_INFO t where t.order_number = c_order_number and t.state in('1','2')),0)
      into v_order_return_logis_money
      from dual;
    --当订单即将退的部分+已发+已申请退=订单数量（订单完成）
    select count(1)
      into  v_temp_count
      from TBL_ORDER_PRODUCT_SKU t1,
           (select a.order_number,a.product_sku,sum(a.count) returned_count
              from TBL_ORDER_RETURN_PRODUCT a
             where a.order_number = c_order_number
                   and exists(select 1 from TBL_ORDER_RETURN_INFO b where b.return_number = a.return_number and b.state in('1','2'))
             group by a.order_number,a.product_sku
            ) t2,
            TMP_ORDER_PRODUCT_SKU_RETURN t3
     where t1.order_number = c_order_number
           and t1.order_number = t2.order_number(+)
           and t1.order_number = t3.order_number(+)
           and t1.product_sku = t2.product_sku(+)
           and t1.product_sku = t3.product_sku(+)
           and t1.count - nvl(t1.total_send_count,0) > nvl(t2.returned_count,0) + nvl(t3.return_count,0);
    if v_temp_count = 0 then
       select getFreightMoney_Order_Deliver(c_order_number,'0') into v_order_deliver_logis_money from dual;
       v_total_money := v_order_logistics_money - v_order_deliver_logis_money - v_order_return_logis_money;
    else
       --订单未完成
       select getFreightMoney_Order_Deliver(c_order_number,'1') into v_order_deliver_logis_money from dual;
       v_total_money := v_order_logistics_money - v_order_deliver_logis_money;
       select getFreightMoney_Order_Deliver(c_order_number,'0') into v_order_deliver_logis_money from dual;
       if v_total_money > v_order_logistics_money - v_order_deliver_logis_money - v_order_return_logis_money then
          v_total_money := v_order_logistics_money - v_order_deliver_logis_money - v_order_return_logis_money;
       end if;
    end if;
    if v_total_money<=0 then
       v_total_money :=0;
    end if;
   --返回运费
   return nvl(v_total_money,0);
exception
 when others then
    return 0;
END getFreightMoney_Order_Return;
/

