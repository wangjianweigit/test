create FUNCTION           getSaasProductItemNumber
    /**
    生成云仓商品货号
    songwangwen
    2018.09.05
  **/
  (
      c_stationed_user_id  IN NUMBER     --入驻商ID
  ) RETURN VARCHAR2 IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  returnstr             VARCHAR2(50);   --返回货号
  v_count               NUMBER;         --临时变量
  v_itemnumber          VARCHAR2(50);   --货号
  v_owner_id            NUMBER:=0;      --临时变量,表TBL_WMS_CUSTOMER_INFO主键
  v_customer_code       NUMBER;         --临时变量,表TBL_WMS_CUSTOMER_INFO 客户编码
  v_seq_number          NUMBER;         --临时变量,货主的最大货号序列，
BEGIN
  --初始化货号为空
  returnstr := '';
  --根据入驻商信息查询入驻商对应的货主信息
        SELECT 
        wci.id,wci.customer_code,(NVL(wci.max_itemnumber,0)+1) max_itemnumber
        INTO v_owner_id,v_customer_code,v_seq_number
        from tkerp.TBL_WMS_CUSTOMER_INFO wci,
        TBL_SAAS_ERP_CONFIG sec 
        where wci.OWNER_USER_ID = sec.owner_user_id
        and sec.STATIONED_USER_ID = c_stationed_user_id
        and wci.is_delete = '0'
        AND rownum <=1;
  --未能查询到数据，货号创建失败，直接返回空
  if v_customer_code is null or v_customer_code='' then
     return returnstr;
  end if;
  /***********货号规则如下（商家编码+5位序列数字）***********/
   select  v_customer_code||REPLACE(lpad(v_seq_number,5,'0'), '4', '5') into v_itemnumber from dual;    
        returnstr:=v_itemnumber; 
   /****验证货号是否已经被占用,如果被占用，则序列化需要加1后更新**/
   SELECT COUNT(1) INTO v_count FROM TBL_PRODUCT_INFO WHERE ITEMNUMBER = v_itemnumber;
   IF v_count>0 THEN
         v_seq_number:=v_seq_number+1;
         update tkerp.TBL_WMS_CUSTOMER_INFO SET max_itemnumber = v_seq_number WHERE id = v_owner_id;
   ELSE  
        returnstr:=v_itemnumber;
   END IF;
  COMMIT;
  RETURN returnstr;
EXCEPTION
 WHEN OTHERS THEN
  rollback;
  return '';
END getSaasProductItemNumber;
/

