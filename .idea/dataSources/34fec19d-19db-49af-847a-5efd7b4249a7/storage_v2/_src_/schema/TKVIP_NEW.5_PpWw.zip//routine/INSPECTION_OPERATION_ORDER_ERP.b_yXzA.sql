create PROCEDURE           inspection_operation_order_erp
/**
  批量处理订单审核，更新订单状态--(erp专用)
  shifan
  20170520
  返回订单审核、订单审核驳回成功或失败消息
  **/
( client_check_money_user_name  IN VARCHAR2,     --审核人用户名
  client_check_money_user_rname IN VARCHAR2,     --审核人用户姓名
  client_order_numbers          IN VARCHAR2,     --审核订单号数组，以','分割字符串
  client_check_money_creason    IN VARCHAR2,     --审核驳回原因
  client_check_money_type       IN VARCHAR2,     --审核类型 1-审核通过 2-审核驳回 3-手工配货时订单状态更新
  output_status                 OUT VARCHAR2,    --返回的状态码 0-失败 1-成功
  output_msg                    OUT VARCHAR2     --返回的信息
 ) IS
  temp_unchecked_number   INT := 0;              --临时变量 -收款金额不等于订单金额的订单数量
  temp_pre_checked_number INT := 0;              --临时变量 -待进行订单审核或审核驳回的订单数量
  temp_checked_number     INT := 0;              --临时变量 -检查数量
BEGIN
  output_status := '0';
  output_msg    := '操作失败！';

  --1.0待进行订单审核或审核驳回的订单数量
  SELECT COUNT(1) INTO temp_pre_checked_number FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ',')));
  SELECT COUNT(1)
      INTO temp_checked_number
      FROM TBL_ORDER_INFO T
     WHERE T.ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))));
  IF temp_checked_number <=0 THEN
     output_msg    := '订单不存在！';
     RETURN;
  END IF;

  --2.0审核通过
  IF client_check_money_type = '1' THEN
    output_msg := '订单审核失败！';
    --2.1当前订单中存在会员待审核状态下的订单数量
     SELECT COUNT(1)
      INTO temp_checked_number
      FROM TBL_ORDER_INFO T
     WHERE T.ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))))
           AND EXISTS(SELECT 1 FROM TBL_USER_INFO F WHERE  F.USER_NAME = T.USER_NAME AND F.USER_STATE = 4);
     IF temp_checked_number>0 THEN
         output_msg := '订单所属会员审核状态为待审核！';
         RETURN;
     END IF;

    --2.2当前订单列表中待审核流程状态的订单数量
    SELECT COUNT(1)
      INTO temp_checked_number
      FROM TBL_ORDER_INFO
     WHERE ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))))
           AND ORDER_STATE = 2 AND  CHECK_STATE=1 AND PAYMENT_STATE=2;

    --2.3存在非待审核流程状态的订单审核处理
    IF temp_pre_checked_number - temp_checked_number <> 0 THEN
      output_msg := '订单状态异常！';
      IF temp_pre_checked_number > 1 THEN
        output_msg := '订单审核列表中存在异常状态订单！';
      END IF;
      RETURN;
    END IF;
    SELECT COUNT(1)
      INTO temp_unchecked_number
      FROM TBL_ORDER_INFO A, (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ',')))) b
     WHERE A.ORDER_NUMBER = B.ORDER_NUMBER
           AND ROUND(PAYMENT_MONEY, 2) != ROUND(PRODUCT_MONEY + NVL(LOGISTICS_MONEY, 0) + NVL(DF_MONEY, 0), 2);
    IF temp_unchecked_number <> 0 THEN
      output_msg := '收款金额不等于订单金额不允许审核通过！';
      RETURN;
    END IF;
    --2.4订单审核
    UPDATE TBL_ORDER_INFO
       SET CHECK_STATE=2,CHECK_USER_NAME = CLIENT_CHECK_MONEY_USER_NAME, CHECK_USER_REALNAME = CLIENT_CHECK_MONEY_USER_RNAME, CHECK_DATE = SYSDATE
     WHERE ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))));
    output_status := '1';
    output_msg    := '订单审核成功！';
  ELSE
    --3.0审核驳回
    IF client_check_money_type = '2' THEN
      output_msg := '订单审核驳回失败！';
      --3.1当前订单中存在会员待审核状态下的订单数量
       SELECT COUNT(1)
        INTO temp_checked_number
        FROM TBL_ORDER_INFO T
       WHERE T.ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))))
             AND EXISTS(SELECT 1 FROM TBL_USER_INFO F WHERE  F.USER_NAME=T.USER_NAME AND F.USER_STATE = 4);
       IF temp_checked_number >0 THEN
           output_msg := '订单所属会员审核状态为待审核！';
           RETURN;
       END IF;
      --3.2当前订单列表中待审核流程状态的订单数量
      SELECT COUNT(1)
        INTO temp_checked_number
        FROM TBL_ORDER_INFO
       WHERE ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))))
             AND ORDER_STATE = 2 AND  CHECK_STATE=1 AND PAYMENT_STATE=2;
      --3.3存在非待审核流程状态的订单审核驳回处理
      IF temp_pre_checked_number - temp_checked_number <> 0 THEN
        output_msg := '订单状态异常！';
        IF temp_pre_checked_number > 1 THEN
        output_msg := '订单审核列表中存在异常状态订单！';
        END IF;
        RETURN;
      END IF;
      --3.4更新订单相应状态
      UPDATE TBL_ORDER_INFO
         SET ORDER_STATE= 4,CHECK_STATE=3,REFUND_STATE=1, CHECK_USER_NAME = client_check_money_user_name, CHECK_USER_REALNAME = client_check_money_user_rname, check_date = SYSDATE, check_cancle_reason = client_check_money_creason
      WHERE ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))));
      output_status := '1';
      output_msg    := '订单审核驳回成功！';
    ELSE
      --4.0手工配货时更新订单状态
       IF client_check_money_type = '3' THEN
         output_msg := '订单状态更新失败！';
         --4.1增加配货时，订单是否已取消的判断处理
         SELECT COUNT(1)
          INTO temp_checked_number
          FROM TBL_ORDER_INFO
         WHERE ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))))
               AND ORDER_STATE IN (4,6) AND CANCEL_USER_NAME IS NOT NULL AND CANCEL_DATE IS NOT NULL;
         IF temp_checked_number <> 0 THEN
            output_msg    := '订单已被用户取消，无法配货！';
            IF temp_pre_checked_number > 1 THEN
              output_msg := '订单列表中存在已取消状态订单！';
            END IF;
            RETURN;
         End If;
         --4.2增加配货时，订单是否申请退货退款的判断处理
         SELECT COUNT(1)
          INTO temp_checked_number
          FROM TBL_ORDER_RETURN_INFO
         WHERE ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))))
               AND STATE='1';
         IF temp_checked_number <> 0 THEN
             output_msg    := '订单已申请部分退货！';
             IF temp_pre_checked_number > 1 THEN
               output_msg := '订单列表中存在已申请部分退货状态订单！';
             END IF;
             RETURN;
         END IF;
         --4.3首次配货时，更新订单状态
         SELECT COUNT(1)
          INTO temp_checked_number
          FROM TBL_ORDER_INFO
         WHERE ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))))
               AND ORDER_STATE = 2 AND  CHECK_STATE=2 AND PAYMENT_STATE=2;
         IF temp_checked_number >0 THEN
            --4.4存在非待审核流程状态的订单审核处理
            IF temp_pre_checked_number - temp_checked_number <> 0 THEN
               output_msg := '订单状态异常！';
               IF temp_pre_checked_number > 1 THEN
                  output_msg := '订单列表中存在异常状态订单！';
               END IF;
               RETURN;
            END IF;
            --更新订单相应状态
            UPDATE TBL_ORDER_INFO
               SET ORDER_STATE= 3
            WHERE ORDER_NUMBER IN (SELECT COLUMN_VALUE AS ORDER_NUMBER FROM (SELECT * FROM TABLE(splitstr(client_order_numbers, ','))));
         END IF;
         output_status := '1';
         output_msg    := '订单状态更新成功！';
      ELSE
         output_msg := '不支持的操作类型！';
         RETURN;
      END IF;
    END IF;
  END IF;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    output_msg := '订单审核操作出现未知错误！';
    ROLLBACK;
END inspection_operation_order_erp;
/

