create FUNCTION           getFreightMoney_Order_Deliver
/**
    计算运费--(退货时，计算订单已发商品运费)
    shif
    20170823
    返回值：订单已发商品运费
**/
(
 c_order_number in varchar2,                          --订单编号
 c_type         in char:='0'                          --计算类型【0-计算订单发货已发运费 1-计算订单扣除退款部分运费】
) return number
 is
 v_user_province_id                 number;          --收货地址所在省ID
 v_total_money                      number:=0;       --运费
 v_det_id                           number:=0;       --快递运费模板
 v_temp_receiving_address           varchar2(500);   --临时变量 收货地址
 v_logistics_company_id             number:=0;       --物流公司ID
 v_logistics_company_code           varchar2(50):=0; --物流公司code
 v_temp_first_count                 number:=0;       --临时变量 首件数量
 v_temp_first_money                 number:=0;       --临时变量 首件价格
 v_temp_continue_count              number:=0;       --临时变量 续件数量
 v_temp_continue_money              number:=0;       --临时变量 续件价格
 v_temp_default_id                  number:=999999;  --全局默认运费
 v_type                             char:='0';       --物流公司类型
 v_warehouse_id                     number:=0;       --仓库id
 v_parent_warehouse_id              number :=0;      --大仓id
BEGIN
    --获取订单的收货地址
    select receiving_address,logistics_company_code,warehouse_id into v_temp_receiving_address,v_logistics_company_code,v_warehouse_id from tbl_order_info where order_number = c_order_number;
    select PARENT_ID into v_parent_warehouse_id from TBL_WAREHOUSE_INFO  where id = v_warehouse_id;
    --获取收货地址省份ID
    select min(id) into v_user_province_id from TBL_DIC_REGION where name =GETSTRFORARRID_str(','||v_temp_receiving_address||',',',',1);
    --查询物流公司类型
    select Type,Id into v_type,v_logistics_company_id from TBL_LOGISTICS_COMPANY where code = v_logistics_company_code;
    --普通物流公司
    if v_type = '0' then
        v_temp_default_id:=999999;
    end if;
    --代发物流公司
    if v_type = '1' then
        v_temp_default_id:=999998;
    end if;
    --定义游标查询使用统一运费模板的商品数量
    declare cursor product_skus_counts is
        SELECT c.freight_template_id, SUM(d.a_count) total_count
          FROM TBL_PRODUCT_INFO C,
               (SELECT t1.product_itemnumber,SUM(CASE WHEN c_type = '1' THEN t1.count - nvl(t2.return_count, 0) ELSE nvl(total_send_count, 0)END) a_count
                  FROM TBL_ORDER_PRODUCT_SKU t1, TMP_ORDER_PRODUCT_SKU_RETURN t2
                 WHERE t1.order_number = c_order_number
                       AND t1.order_number = t2.order_number(+)
                       AND t1.product_sku = t2.product_sku(+)
                 GROUP BY t1.product_itemnumber) d
         WHERE d.product_itemnumber = c.itemnumber
               AND d.a_count > 0
         GROUP BY c.freight_template_id;
       myrec product_skus_counts%rowtype;
    begin
        for c_row in product_skus_counts loop
            --获取本商品的运费模板---当查询不到模板的时候，则使用全局通用模板，模板ID固定为99999
            select nvl(min(id),v_temp_default_id) into v_det_id from
            (
                select id from TBL_FREIGHT_TEMPLATE_DETAIL
                    where
                     template_id = c_row.freight_template_id
                    and LOGISTICS_COMPANY_ID = v_logistics_company_id
                    and (range like '%'||v_user_province_id||'%' or range ='0')
                    and warehouse_id = v_parent_warehouse_id
                order by range desc
            ) where rownum<2;
            --获取模板详情
            select first_count,first_money,continue_count,continue_money into v_temp_first_count,v_temp_first_money,v_temp_continue_count,v_temp_continue_money from TBL_FREIGHT_TEMPLATE_DETAIL where id = v_det_id;
            --计算首件价格
            if v_total_money=0 then
                v_total_money:=v_total_money+v_temp_first_money;
                --DBMS_OUTPUT.PUT_LINE('---1----：'||v_total_money);
                if c_row.total_count>v_temp_first_count then
                    v_total_money:=v_total_money+ceil((c_row.total_count-v_temp_first_count)/v_temp_continue_count)*v_temp_continue_money;
                    --DBMS_OUTPUT.PUT_LINE('----2---：'||v_total_money);
                end if;
            else
                v_total_money:=v_total_money+ceil(c_row.total_count/v_temp_continue_count)*v_temp_continue_money;
                --DBMS_OUTPUT.PUT_LINE('---3----：'||v_total_money);
            end if;
            --计算续件金额
         end loop;
     end;
   --返回运费
   return nvl(v_total_money,0);
exception
 when others then
    return 0;
END getFreightMoney_Order_Deliver;
/

