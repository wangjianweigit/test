create FUNCTION           PVTP_GET_SHOP_ACTIVITY_TAG
/**
  获取店铺活动标签
**/
(
    c_product_itemnumber    varchar2    --商品货号
) return varchar2
 is
     v_return_tag varchar2(500):='';                --需要返回的标签
BEGIN
   
    /***************查询参加的店铺活动的标签*****************************/
   select min(TAG_NAME) into v_return_tag
   from TBL_STA_SALE_ACTIVITY ssa where exists (
        select 1 from TBL_STA_SALE_ACTIVITY_PRODUCT ssap where
        ssap.activity_id = ssa.id
        AND ssap.is_delete = 1
        AND ssap.PRODUCT_ITEMNUMBER = c_product_itemnumber
   )
   AND ssa.activity_state = 1
   AND ssa.END_DATE >=sysdate
   AND ssa.BEGIN_DATE <=sysdate
   AND ssa.is_delete = 1
   and rownum <=1;

    RETURN v_return_tag;
END PVTP_GET_SHOP_ACTIVITY_TAG;
/

