create FUNCTION           getSku_min_pre
/**
    （新版）获取订货会活动阶梯价最低可设置价格
    wangpeng
     创建：2018-07-24
    返回值：最低可设置阶梯价格
**/
(
    c_product_sku   number,     --SKUID
    c_hd_discount   number      --折扣
) return varchar2
 is
    v_product_prize number:=0;             --最低可设置阶梯价格
    v_product_prize_cost number:=0;        --报价
    v_product_sale_prize number:=0;        --最低销售价
    
    v_member_service_rate number:=0;       --会员服务费比例-汇总
    v_member_service_rate_rzs number:=0;   --会员服务费比例-入驻商
    v_member_service_rate_qj number:=0;    --会员服务费比例-全局
    v_member_service_money_rzs number:=0;  --会员服务费-入驻商
    v_product_vip_prize number:=0;         --应售会员价
    
BEGIN
     
   --查询全局会员服务费比例
   --select member_service_rate into v_member_service_rate_qj from TBL_SYS_CONFIG where id = 1;
   
   --查询入驻商会员服务费比例
    select nvl(member_service_rate,0),nvl(AREA_SERVICE_RATE,0) into v_member_service_rate_rzs,v_member_service_rate_qj from TBL_STATIONED_USER_INFO where id = (
        select STATIONED_USER_ID from tbl_product_sku where id = c_product_sku
    );
    
    --会员服务费比例 = 入驻商会员服务费比例 + 全局会员服务费比例
    v_member_service_rate := v_member_service_rate_rzs + v_member_service_rate_qj;

   --查询SKU基本信息
   select product_prize_cost into v_product_prize_cost from tbl_product_sku where product_group in('规格') and id = c_product_sku ;

   --计算应销售价
   v_product_sale_prize:=v_product_prize_cost/(1-v_member_service_rate);
   
   --计算入驻商会员服务费 = 应销售价*入驻商会员服务费比例
   v_member_service_money_rzs := v_product_sale_prize * v_member_service_rate_rzs;
   
   --应售会员价 = 报价 + 入驻商会员服务费
   v_product_vip_prize := v_product_prize_cost + v_member_service_money_rzs;
   

   --按照活动计算  会员价 = 应售会员价 * 活动折扣
   v_product_prize := v_product_vip_prize*c_hd_discount;
    
     if ceil(v_product_prize)-v_product_prize<0.5 then
      v_product_prize := ceil(v_product_prize);
   elsif ceil(v_product_prize)-v_product_prize=0 then
      v_product_prize := v_product_prize;
   else 
      v_product_prize := ceil(v_product_prize)-0.5;
   end if;


   return v_product_prize;
   
END getSku_min_pre;
/

