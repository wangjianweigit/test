create FUNCTION           UPDATE_PRODUCT_ITEMNUMBER_NEW
    /**
    更新货号规则表的序列（seq_number）信息
    返回：1 表示成功  其他表示失败
    songwangwen
    2017.05.31
  **/
  (
   brand_id  IN NUMBER, --商品品牌ID
   year      IN NUMBER, --年份
   season_id IN NUMBER --季节ID
  ) RETURN VARCHAR2 IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  returnstr     VARCHAR2(50); --返回货号
  v_count       NUMBER; --临时变量
  v_temp_count  NUMBER; --临时变量
  v_brand_code  VARCHAR2(10); --商品品牌code
  v_year_code   VARCHAR2(10); --商品年份code
  v_season_code VARCHAR2(10); --商品季节code
  v_year_length number;--年份的长度
  v_seq_number  number;--货号生成序号
  v_itemnumber  VARCHAR2(50); --货号
BEGIN
  --初始化货号为空
  returnstr := '';
  --参数校验
  SELECT CODE INTO v_brand_code FROM TBL_DIC_PRODUCT_BRAND WHERE ID = brand_id;
  if v_brand_code is null or v_brand_code ='' then
     return returnstr;
  end if;

  SELECT CODE INTO v_season_code FROM TBL_DIC_PRODUCT_SEASON WHERE ID = season_id;
  if v_season_code is null or v_season_code ='' then
     return returnstr;
  end if;

  select nvl(length(to_char(year)),0 ) into v_year_length from dual;
  if v_year_length <> 4 then
     return returnstr;
  end if;
  SELECT TO_NUMBER(SUBSTR(TO_CHAR(year),LENGTH(TO_CHAR(year)),1)) INTO v_year_code FROM DUAL;
  select count(1) into v_count from TBL_PRODUCT_ITEMNUMBER_NEW where  brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
  if v_count = 1 then
        select SEQ_NUMBER into v_seq_number from TBL_PRODUCT_ITEMNUMBER_NEW where  brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
     --更新序列
     update TBL_PRODUCT_ITEMNUMBER_NEW set seq_number = to_number(REPLACE(lpad(v_seq_number+1,3,'0'), '4', '5')) where brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;         
  end if;
  COMMIT;
  return '1';
EXCEPTION
 WHEN OTHERS THEN
  rollback;
  return '';
END UPDATE_PRODUCT_ITEMNUMBER_NEW;
/

