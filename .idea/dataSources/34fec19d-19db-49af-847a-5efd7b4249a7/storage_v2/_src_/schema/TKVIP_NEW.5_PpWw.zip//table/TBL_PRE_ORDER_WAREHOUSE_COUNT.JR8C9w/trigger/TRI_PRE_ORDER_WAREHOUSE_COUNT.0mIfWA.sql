create trigger TRI_PRE_ORDER_WAREHOUSE_COUNT
  after insert or update or delete
  on TBL_PRE_ORDER_WAREHOUSE_COUNT
  for each row
DECLARE
  v_temp_count        INT := 0;
  v_temp_accupy_count INT := 0;
BEGIN
  --新预付订单占用量插入【手工占用】
  IF INSERTING THEN
    
    v_temp_accupy_count := :NEW.OCCUPY_COUNT;
    
    --查询当前SKU是否在库存及占用表是否有记录
    SELECT COUNT(1) INTO v_temp_count  FROM TBL_PRODUCT_SKU_STOCK  WHERE PRODUCT_SKU = :NEW.PRODUCT_SKU AND WAREHOUSE_ID = :NEW.WAREHOUSE_ID;
    
    --无库存占用数据时插入
    IF v_temp_count = 0 THEN 
      INSERT INTO TBL_PRODUCT_SKU_STOCK
        (ID, PRODUCT_SKU, WAREHOUSE_ID, PRODUCT_TOTAL_COUNT, PRODUCT_ORDER_OCCUPY_COUNT,PRE_ORDER_OCCUPY_COUNT)
      VALUES
        (SEQ_PRODUCT_SKU_STOCK.NEXTVAL, :NEW.PRODUCT_SKU, :NEW.WAREHOUSE_ID, 0,0, v_temp_accupy_count);
    else
        --更新占用量
        UPDATE TBL_PRODUCT_SKU_STOCK
         SET PRE_ORDER_OCCUPY_COUNT = PRE_ORDER_OCCUPY_COUNT + v_temp_accupy_count
       WHERE PRODUCT_SKU = :NEW.PRODUCT_SKU
         AND WAREHOUSE_ID = :NEW.WAREHOUSE_ID;
    END IF;
  END IF;

  --占用量删除【预付订单产生普通订单】
  IF DELETING THEN
    IF :OLD.OCCUPY_COUNT = 0 THEN
      RETURN;
    END IF;
    v_temp_accupy_count := 0 - :OLD.OCCUPY_COUNT;
    UPDATE TBL_PRODUCT_SKU_STOCK
     SET PRE_ORDER_OCCUPY_COUNT= PRE_ORDER_OCCUPY_COUNT + v_temp_accupy_count
   WHERE PRODUCT_SKU = :OLD.PRODUCT_SKU
         AND WAREHOUSE_ID = :OLD.WAREHOUSE_ID;
  END IF;
END;
/

