create FUNCTION getProduct_SalePrice_Min
/**
    （新版）通过用户名获取商品货号最低价格             (精确计算) 
    wangpeng
    2017-05-12
    价格计算规则：查询所有SKU实际销售价，然后取最低           调用函数getSku_User_SalePrice
    返回值：商品最低销售价格    （计算了特殊价格）
**/
(
    c_user_name   varchar2,             --用户名
    c_product_itemnumber   varchar2     --商品货号    
) return varchar2
 is
 v_product_prize_str varchar2(50):='0.00';   --需要返回的商品价格
 v_source_type varchar2(10):='1';
BEGIN

   --通过sku获取最低价
   select nvl(to_char(min(price),'fm999999990.00'),'0.00') into v_product_prize_str  from (
        select getSku_User_SalePrice(c_user_name,id) price from tbl_product_sku where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架'
   );
   return v_product_prize_str;
   
END getProduct_SalePrice_Min;
/

