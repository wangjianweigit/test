create FUNCTION PVTP_IS_OUTSTOCK_PRODUCT
/**
    reid 2019.09.12 
    判断私有平台销售的商品是否可以缺货订购
    返回值：0非缺货订购商品 ；1:是缺货订购商品
**/
(
    c_stationed_user_id     number,              --当前下单私有平台ID（即所属私有商家的ID）
    c_user_name             varchar2,            --用户名
    c_product_itemnumber    varchar2,            --商品货号
    c_warehouse_id          number:=0            --仓库ID 如果使用默认值0，则表示所有仓库中，只有有一个仓库可以缺货订购即可
) return varchar2
 is
     v_count number:=0;                                    --临时变量
     v_site_id number:=0;                                  --客户站点ID
     v_is_outstock number:=0;                              --商品类型  0非缺货订购商品 ；1:是缺货订购商品
     v_activity_type number:=0;                            --活动类型 1.限时折扣;2.订货会;4.预售;5.一口清;6.团批（TBL_GROUP_ACTIVITY_INFO） 
BEGIN
    --查询用户城市代码和站点
    select site_id into v_site_id from tbl_user_info where user_name = c_user_name;
    --判断商品是私有商品还是童库分享得商品
    select count(1) into v_count from TBL_PVTP_PRODUCT_INFO ppi where ppi.stationed_user_id = c_stationed_user_id
    and ppi.itemnumber = c_product_itemnumber;
    IF v_count <> 0 THEN
            /**************查询当前用户对于该商品是否存在可以缺货订购的仓*******************/
            IF c_warehouse_id = 0 THEN
                 SELECT 
                    (case when sum(
                        case when (
                            select default_outstock_warehouse 
                            from tbl_stationed_user_info sui,
                            tbl_pvtp_product_info pi 
                            where pi.stationed_user_id = sui.id
                            and pi.itemnumber =  c_product_itemnumber
                            and pi.stationed_user_id = c_stationed_user_id
                        ) = sw.warehouse_id 
                        and (select is_outstock from tbl_pvtp_product_info where itemnumber = c_product_itemnumber)=1 then
                        1 else 0 end
                    )>0 then 1 else 0 end) is_outstock into v_is_outstock
                 FROM TBL_SITE_WAREHOUSE sw
                 WHERE sw.site_id = v_site_id;
            ELSE
                SELECT
                (case when (
                        case when (
                            select default_outstock_warehouse 
                            from tbl_stationed_user_info sui,
                            tbl_pvtp_product_info pi 
                            where pi.stationed_user_id = sui.id
                            and pi.itemnumber =  c_product_itemnumber
                            and pi.stationed_user_id = c_stationed_user_id
                        ) = c_warehouse_id
                        and (select is_outstock from tbl_pvtp_product_info where itemnumber = c_product_itemnumber)=1 then
                        1 else 0 end
                    )>0 then 1 else 0 end) into v_is_outstock
                FROM DUAL;
            END IF;
    ELSE
            select IS_ACTIVITY(c_user_name,c_product_itemnumber) into v_activity_type from dual;
            IF v_activity_type = 2 OR v_activity_type = 4 OR v_activity_type = 5 THEN
                RETURN v_is_outstock;
            END IF;
            /**************查询当前用户对于该商品是否存在可以缺货订购的仓*******************/
            IF c_warehouse_id = 0 THEN
                 SELECT 
                    (case when sum(
                        case when (
                            select default_outstock_warehouse 
                            from tbl_stationed_user_info sui,
                            tbl_product_info pi 
                            where pi.stationed_user_id = sui.id
                            and pi.itemnumber =  c_product_itemnumber
                        ) = sw.warehouse_id 
                        and (select is_outstock from tbl_product_info where itemnumber = c_product_itemnumber)=1 then
                        1 else 0 end
                    )>0 then 1 else 0 end) is_outstock into v_is_outstock
                 FROM TBL_SITE_WAREHOUSE sw
                 WHERE sw.site_id = v_site_id;
            ELSE
                SELECT
                (case when (
                        case when (
                            select default_outstock_warehouse 
                            from tbl_stationed_user_info sui,
                            tbl_product_info pi 
                            where pi.stationed_user_id = sui.id
                            and pi.itemnumber =  c_product_itemnumber
                        ) = c_warehouse_id
                        and (select is_outstock from tbl_product_info where itemnumber = c_product_itemnumber)=1 then
                        1 else 0 end
                    )>0 then 1 else 0 end) into v_is_outstock
                FROM DUAL;
            END IF;
    END IF;
    return v_is_outstock;
END PVTP_IS_OUTSTOCK_PRODUCT;
/

