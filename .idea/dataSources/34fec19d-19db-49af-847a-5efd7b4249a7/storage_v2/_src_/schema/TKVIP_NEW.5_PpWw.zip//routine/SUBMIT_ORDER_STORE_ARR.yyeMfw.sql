create PROCEDURE           SUBMIT_ORDER_STORE_ARR 
/**
   提交订单【支持大量商品提交】
   shif
   2017-10-23
   增加记录订单是否是缺货商品订单   shif 2017-11-23
   返回值：订单提交结果消息
   
    songwangwen 2018.10.16 预售活动相关修改

    songwangwen 2018.11.29  发货方式调整相关修改(默认代发)
     liujialong  2019.1.8  订单主表增加用户是否支持送货入户
    yejingquan  20190311 下单用户是否存在快递配置
**/
(
   client_user_name                IN     VARCHAR2,                      --用户名
   client_receiving_name           IN     VARCHAR2,                    --收货人姓名
   client_receiving_phone          IN     VARCHAR2,                     --收货电话
   client_user_province_id         IN     NUMBER,                     --收货地省ID
   client_receiving_address        IN     VARCHAR2,                     --收货地址
   client_order_remark             IN     VARCHAR2,                     --订单备注
   client_order_product_list       IN     T_ORDER_PRODUCT_LST,        --订单商品列表
   client_logistics_company_code   IN     VARCHAR2,                   --物流公司代码
   client_product_money            IN     NUMBER,                  --前台传递 商品总价
   client_logistics_money          IN     NUMBER,                  --前台传递 物流总价
   client_df_money                 IN     NUMBER,                  --前台传递 代发费用
   client_order_source             IN     VARCHAR2,                     --订单来源
   client_submode                         CHAR,      --下单模式   0:正常下单   1：代客户下单
   client_xdr_user_name            IN     VARCHAR2,                   --下单人用户名
   client_xdr_type                        CHAR, --下单人用户类型（3：业务员，4：业务经理，5：店长，6：营业员，7：自行下单）
   client_warehouse_id                    NUMBER,                     --下单仓库id
   output_status                      OUT VARCHAR2,         --返回的状态码 0-失败 1-成功
   output_msg                         OUT VARCHAR2                     --返回的信息
                                                  )
AS
   v_user_manage_name              VARCHAR2 (50);                       --客户姓名
   v_logistics_company_id          NUMBER := 0;                       --物流公司ID
   v_logistics_company_name        VARCHAR2 (50);                     --物流公司名称
   v_product_money                 NUMBER := 0;                    --后台计算 商品总价
   v_logistics_money               NUMBER := 0;                    --后台计算 物流总价
   v_order_product                 T_ORDER_PRODUCT;                   --订单商品对象
   temp_count                      INT := 1;                         --临时变量 计数
   temp_sku_id                     NUMBER := 0;                   --临时变量 SKUID
   temp_sku_count                  NUMBER := 0;                    --临时变量 订购数量
   temp_ok_count_ck                NUMBER := 0;                      --仓库实际库存数
   v_order_number                  VARCHAR2 (21);                        --订单号
   v_product_store_total_money     NUMBER := 0;                --店铺零售总价 系统计算得出
   v_product_total_money           NUMBER := 0;                  --商品总价 系统计算得出
   v_ysyf                          NUMBER := 0;                  --应收运费 系统计算得出
   v_temp_count                    INT := 0;                            --临时变量
   v_is_outstock                   INT := 0;                          --缺货预售标记
   v_flag                          INT := 0;                     --业务员客户关系验证标志
   v_user_type                     NUMBER := 0;                  --数据库中的系统用户类型
   v_state                         CHAR (1);                     --数据库中的系统用户状态
   v_order_type                    VARCHAR2 (50);               --订单类型  批发  代发
   v_issuing_grade_id              NUMBER := 1;                     --用户代发等级ID
   v_piece_cost                    NUMBER := 0;                     --代发等级单价费用
   v_product_total_count           NUMBER := 0;                       --购买商品总数
   v_store_user_type               CHAR (1);                        --门店人员用户类型
   v_store_state                   CHAR (1);                            --门店状态
   v_user_state                    CHAR (1);                            --用户状态
   v_store_id                      NUMBER := 0;                         --门店ID
   v_df_money                      NUMBER := 0;                         --代发费用
   v_ywjl_user_name                VARCHAR2 (50);               --业务经理username
   v_ywy_user_name                 VARCHAR2 (50);                --业务员username
   v_partner_user_name             VARCHAR2 (50);                --合作商username
   v_supervisor_user_name          VARCHAR2 (50);                 --督导username
   v_md_id                         NUMBER := 0;                         --门店ID
   v_site_id                       NUMBER := 0;                       --用户所属站点
   v_outstock_flag                 NUMBER := 0;                   --是否缺货订购订单标识
   v_store_goods_deposit_balance   NUMBER := 0;                     --店铺会员押金金额
   v_product_store_money           NUMBER := 0;
   v_product_itemnuber             VARCHAR2 (50);                    --临时变量 货号
   v_region_id                     NUMBER :=0;                      --所属区域
   v_shipping_method_id NUMBER;                        --标准配送方式ID,关联表TBL_SHIPPING_METHOD的ID字段
   v_freight_payment_type NUMBER:=1;                    --运费是否到付  1.先支付运费   ；2：到付运费    
   v_is_delivery_home NUMBER:=2;          --用户是否支持送货入户
   v_user_logistics_count     NUMBER :=0;                          --用户是否存在快递配置

BEGIN
   output_status := '0';
   --20180517 yejingquan 订单类型写死
   v_order_type := '批发';

   --校验物流费用和代发费用是否等于0
   IF client_logistics_money > 0 AND client_df_money > 0
   THEN
      output_msg := '运费和代发费用应为0，请重新下单!';
      RETURN;
   END IF;
   --获取所属区域
   select partner_user_id
     into v_region_id
     from tbl_user_info 
    where id = client_user_name;
   --押金余额校验
   SELECT nvl(sum(store_goods_deposit_balance),0)
     INTO v_store_goods_deposit_balance
     FROM tbl_store_bank_account
    WHERE user_id in (select id from tbl_user_info where partner_user_id = v_region_id and user_state = 1);

   --获取待付款的订单金额
   SELECT NVL (SUM (product_store_money), 0)
     INTO v_product_store_money
     FROM tbl_order_info
    WHERE order_state = 1 AND user_name in (select id from tbl_user_info where partner_user_id = v_region_id and user_state = 1);

   IF (v_product_store_money + client_product_money) >
         v_store_goods_deposit_balance
   THEN
      output_msg := '押金余额不足，提交失败!';
      RETURN;
   END IF;

   --校验商品零售价是否为空
   FOR i IN 1 .. client_order_product_list.COUNT
   LOOP
      v_order_product := client_order_product_list (i);

      SELECT COUNT (1)
        INTO v_temp_count
        FROM tbl_product_store_detail t
       WHERE     product_sku = v_order_product.product_sku
             AND RETAIL_PRICE > 0
             AND EXISTS
                    (SELECT 1
                       FROM tbl_product_store
                      WHERE     id = t.product_store_id
                            AND user_id = client_user_name);

      SELECT PRODUCT_ITEMNUMBER
        INTO v_product_itemnuber
        FROM tbl_product_sku
       WHERE id = v_order_product.product_sku;

      IF v_temp_count = 0
      THEN
         output_msg :=
               '商品【'
            || v_product_itemnuber
            || '】联营价未配置或为0，暂时无法下单，请联系管理员!';
         RETURN;
      END IF;
   END LOOP;

   --1.校验下单仓库是否有效
   SELECT COUNT (1)
     INTO v_temp_count
     FROM TBL_SITE_WAREHOUSE T
    WHERE     T.WAREHOUSE_ID = client_warehouse_id
          AND EXISTS
                 (SELECT 1
                    FROM TBL_USER_INFO T1
                   WHERE     T1.USER_NAME = client_user_name
                         AND T1.SITE_ID = T.SITE_ID);

   IF v_temp_count = 0
   THEN
      OUTPUT_MSG := '下单仓库不存在';
      RETURN;
   END IF;

   v_temp_count := 0;

   --2.数据有效性校验
   IF client_order_product_list.COUNT > 0
   THEN
      FOR i IN 1 .. client_order_product_list.COUNT
      LOOP
         v_order_product := client_order_product_list (i);

         INSERT INTO TMP_ORDER_PRODUCT_SKU (WAREHOUSE_ID, PRODUCT_SKU, COUNT)
                 VALUES (
                           client_warehouse_id,
                           v_order_product.PRODUCT_SKU,
                           v_order_product.COUNT);
      END LOOP;

      SELECT COUNT (1)
        INTO v_temp_count
        FROM TMP_ORDER_PRODUCT_SKU T
       WHERE     T.WAREHOUSE_ID = client_warehouse_id
             AND (T.PRODUCT_SKU IS NULL OR T.COUNT IS NULL);

      IF v_temp_count > 0
      THEN
         output_msg := '商品参数部分为空，请检查';
         RETURN;
      END IF;
   ELSE
      OUTPUT_MSG := '订单商品参数为空，请检查';
      RETURN;
   END IF;

   --3.校验SKU的有效性
   temp_count := client_order_product_list.COUNT;

   SELECT   temp_count
          - (SELECT COUNT (1)
               FROM TBL_PRODUCT_SKU       a,
                    TMP_ORDER_PRODUCT_SKU b,
                    TBL_PRODUCT_INFO      c
              WHERE     a.ID = b.PRODUCT_SKU
                    AND B.WAREHOUSE_ID = client_warehouse_id
                    AND a.PRODUCT_ITEMNUMBER = c.ITEMNUMBER
                    AND (c.STATE = '上架' OR c.STATE = '暂下架')
                    AND a.STATE = '上架')
     INTO v_temp_count
     FROM DUAL;

   IF v_temp_count <> 0
   THEN
      output_msg := 'SKU错误或已下架请检查SKU的有效性!';
      RETURN;
   END IF;

   --4.查询物流公司名称
   SELECT COUNT (*)
     INTO v_temp_count
     FROM TBL_LOGISTICS_COMPANY
    WHERE CODE = client_logistics_company_code;

   IF v_temp_count <> 0
   THEN
       SELECT ID,NAME,shipping_method_id
    INTO v_logistics_company_id,v_logistics_company_name,v_shipping_method_id
        FROM TBL_LOGISTICS_COMPANY
       WHERE CODE = client_logistics_company_code;
   ELSE
      output_msg := '物流信息不能为空，请检查!';
      RETURN;
   END IF;

   --5.查询客户姓名
   SELECT COUNT (*)
     INTO v_temp_count
     FROM TBL_USER_INFO
    WHERE USER_NAME = client_user_name;

   IF v_temp_count <> 0
   THEN
      SELECT (SELECT TSUI.USER_NAME
                FROM TBL_SYS_USER_INFO TSUI
               WHERE TSUI.ID = TUI.MARKET_SUPERVISION_USER_ID)
                AS MARKET_SUPERVISION_USER_NAME,
             (SELECT TSUI.USER_NAME
                FROM TBL_SYS_USER_INFO TSUI
               WHERE TSUI.ID = TUI.REFEREE_USER_ID)
                AS REFEREE_USER_NAME,
             (SELECT TSUI.USER_NAME
                FROM TBL_SYS_USER_INFO TSUI
               WHERE TSUI.ID = TUI.PARTNER_USER_ID)
                AS PARTNER_USER_NAME,
             (SELECT TSUI.USER_NAME
                FROM TBL_SYS_USER_INFO TSUI
               WHERE TSUI.ID = TUI.SUPERVISOR_USER_ID)
                AS SUPERVISOR_USER_NAME,
             TUI.STORE_ID,
             TUI.SITE_ID,
             TUI.USER_MANAGE_NAME,
             TUI.ISSUING_GRADE_ID,
             TUI.USER_STATE,
             TUI.USER_TYPE
        INTO v_ywjl_user_name,
             v_ywy_user_name,
             v_partner_user_name,
             v_supervisor_user_name,
             v_md_id,
             v_site_id,
             v_user_manage_name,
             v_issuing_grade_id,
             v_user_state,
             v_user_type
        FROM TBL_USER_INFO TUI
       WHERE USER_NAME = client_user_name;

      IF v_user_state = 2
      THEN
         output_msg := '当前店铺会员被禁用，无法生成订单!';
         RETURN;
      END IF;

      --检查当前用户是否店铺会员
      IF v_user_type = 0
      THEN
         output_msg := '当前用户不是店铺会员，无法生成订单!';
         RETURN;
      END IF;
   ELSE
      output_msg := '用户信息不能为空，请检查!';
      RETURN;
   END IF;

   --6.0校验下单数量是否大于库存数
   FOR i IN 1 .. client_order_product_list.COUNT
   LOOP
      v_order_product := client_order_product_list (i);
      --DBMS_OUTPUT.PUT_LINE('当前SKU：'||getStrforArrid(','||client_order_sku_ids||',',',',temp_count));
      temp_sku_id := v_order_product.PRODUCT_SKU;
      temp_sku_count := v_order_product.COUNT;

      --6.1判断该SKU是否为可缺货订购
      SELECT A.is_outstock
        INTO v_is_outstock
        FROM TBL_PRODUCT_SKU A
       WHERE A.ID = temp_sku_id;

      --6.11非缺货订单的商品，判断下单数是否大于库存可用数
      IF v_is_outstock = 0
      THEN
         --查询可下单库存数
         SELECT GETPRODUCTSKU_STOCKS (temp_sku_id,
                                      client_warehouse_id,
                                      client_user_name)
           INTO temp_ok_count_ck
           FROM DUAL;

         IF temp_ok_count_ck < temp_sku_count
         THEN
            SELECT    'SKU('
                   || temp_sku_id
                   || '),货号:'
                   || product_itemnumber
                   || ' '
                   || product_sku_name
                   || ',可下单数：'
                   || temp_ok_count_ck
                   || '，您实际下单数：'
                   || temp_sku_count
              INTO output_msg
              FROM TBL_PRODUCT_SKU
             WHERE ID = temp_sku_id;

            RETURN;
         END IF;
         --商品参加了预售活动，则会对预售活动的SKU表进行SKU销售数量的更新
         UPDATE TBL_SALE_ACTIVITY_SKU TSAS SET ACTIVITY_SELL_AMOUNT = ACTIVITY_SELL_AMOUNT + temp_sku_count
                WHERE EXISTS (
                         SELECT 1
                           FROM TBL_ACTIVITY_INFO TAI,TBL_ACTIVITY_DETAIL TSAI,
                           TBL_ACTIVITY_PRODUCT AP
                          WHERE TAI.ID = TSAS.ACTIVITY_ID and TAI.ID = TSAI.ACTIVITY_ID
                                AND TAI.ID = AP.ACTIVITY_ID
                                AND AP.PRODUCT_ITEMNUMBER = TSAS.PRODUCT_ITEMNUMBER
                                AND EXISTS (SELECT 1
                                    FROM TBL_ACTIVITY_SITE tas
                                   WHERE tas.site_id = v_site_id AND tas.ACTIVITY_ID = TAI.ID)
                                AND AP.ACTIVITY_START_DATE <= SYSDATE
                                AND AP.ACTIVITY_END_DATE >= SYSDATE
                                AND TAI.ACTIVITY_STATE = '3'
                                AND TAI.STATE = '2'
                                AND TAI.ACTIVITY_TYPE = '4'
                                AND (CASE WHEN (TSAI.USER_GROUP_ID = 0 OR TSAI.USER_GROUP_ID IS NULL) THEN 1 ELSE CASE WHEN 
                                EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB 
                                WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND TSAI.USER_GROUP_ID = AA.ID AND  BB.USER_ID = client_user_name
                                AND (bb.ACTIVITY_ID = tsai.activity_id OR bb.ACTIVITY_ID = 0)
                                ) THEN 1 ELSE 0 END END) = 1 
        )
                      AND TSAS.PRODUCT_SKU = temp_sku_id;
         --商品参加了非预售活动，则会对非预售活动的SKU表进行SKU销售数量的更新
         UPDATE TBL_SALE_ACTIVITY_SKU TSAS
                  SET ACTIVITY_SELL_AMOUNT =
                         ACTIVITY_SELL_AMOUNT + temp_sku_count
                WHERE  EXISTS (
                         SELECT 1
                           FROM TBL_ACTIVITY_INFO TAI, 
               TBL_ACTIVITY_DETAIL TSAI,
                           TBL_ACTIVITY_PRODUCT AP
                          WHERE TAI.ID = TSAS.ACTIVITY_ID
                AND TAI.ID = AP.ACTIVITY_ID
                                AND AP.PRODUCT_ITEMNUMBER = TSAS.PRODUCT_ITEMNUMBER
                                AND TAI.ID = TSAI.ACTIVITY_ID
                                AND EXISTS (SELECT 1
                                    FROM TBL_ACTIVITY_SITE tas
                                   WHERE tas.site_id = v_site_id AND tas.ACTIVITY_ID = TAI.ID)
                                AND AP.ACTIVITY_START_DATE <= SYSDATE
                                AND AP.ACTIVITY_END_DATE >= SYSDATE
                                AND TAI.ACTIVITY_STATE = '3'
                                AND TAI.STATE = '2'
                                AND TAI.ACTIVITY_TYPE != '4'
                                AND TSAI.LOCKED_STOCK = '2'
                                AND (CASE WHEN (TSAI.USER_GROUP_ID = 0 OR TSAI.USER_GROUP_ID IS NULL) THEN 1 ELSE CASE WHEN 
                                EXISTS (SELECT 1 FROM TBL_USER_GROUP AA,TBL_USER_GROUP_DETAIL BB 
                                WHERE AA.ID = BB.GROUP_ID AND AA.STATE = '2' AND TSAI.USER_GROUP_ID = AA.ID AND  BB.USER_ID = client_user_name
                                AND (bb.ACTIVITY_ID = tsai.activity_id OR bb.ACTIVITY_ID = 0)
                                ) THEN 1 ELSE 0 END END) = 1
                 )
                      AND TSAS.PRODUCT_SKU = temp_sku_id
                      AND TSAS.WAREHOUSE_ID = client_warehouse_id;
      END IF;
   END LOOP;

   --7.0计算购买商品总数
   SELECT SUM (COUNT)
     INTO v_product_total_count
     FROM TMP_ORDER_PRODUCT_SKU
    WHERE WAREHOUSE_ID = client_warehouse_id;
    
      --判断当前下单用户是否支持送货入户
    select count(1) into v_temp_count  from TBL_MEMBER_DELIVERY_HOME where user_id=client_user_name and IS_SUPPORT=1 and effect_begin_date<=sysdate and  effect_end_date>=sysdate;
    if v_temp_count>0 then
        v_is_delivery_home:= 1;
    end if;

   --获取订单号
   v_order_number := getAutoNumber ('D');

   --8.0插入订单主表
   INSERT INTO TBL_ORDER_INFO (ID,
                               ORDER_NUMBER,
                               CREATE_DATE,
                               USER_NAME,
                               USER_MANAGE_NAME,
                               ORDER_TYPE,
                               ORDER_STATE,
                               ORDER_REMARK,
                               RECEIVING_NAME,
                               RECEIVING_ADDRESS,
                               RECEIVING_PHONE,
                               LOGISTICS_COMPANY_CODE,
                               LOGISTICS_COMPANY_NAME,
                               LOGISTICS_MONEY,
                               DF_MONEY,
                               PAYMENT_STATE,
                               ORDER_SOURCE,
                               YWJL_USER_NAME,
                               YWY_USER_NAME,
                               MD_ID,
                               XDR_USER_TYPE,
                               XDR_USER_NAME,
                               WAREHOUSE_ID,
                               OLD_LOGISTICS_MONEY,
                               OLD_DF_MONEY,
                               PARTNER_USER_NAME,
                               SUPERVISOR_USER_NAME,
                               IS_STORE_ORDER,
                   DELIVERY_TYPE,
                   FREIGHT_PAYMENT_TYPE,
                   IS_DELIVERY_HOME
                   )
        VALUES (SEQ_ORDER_INFO.NEXTVAL,
                v_order_number,
                SYSDATE,
                client_user_name,
                v_user_manage_name,
                v_order_type,
                1,
                client_order_remark,
                client_receiving_name,
                client_receiving_address,
                client_receiving_phone,
                client_logistics_company_code,
                v_logistics_company_name,
                client_logistics_money,
                v_df_money,
                1,
                client_order_source,
                v_ywjl_user_name,
                v_ywy_user_name,
                v_md_id,
                client_xdr_type,
                client_xdr_user_name,
                client_warehouse_id,
                client_logistics_money,
                v_df_money,
                v_partner_user_name,
                v_supervisor_user_name,
                1,
        v_shipping_method_id,
        v_freight_payment_type,
        v_is_delivery_home);
    --用户是否存在快递配置
   --select count(1) into v_user_logistics_count
  --   from tbl_user_logistics_config
   -- where user_id = client_user_name
   --   and state = 2;
   select (select count(1)
           from table (splitstr (t.enable_logistics, ',')) a,
                tbl_standard_logistics b
          where a.column_value = b.logistics_code
                and b.shipping_method_id = v_shipping_method_id)
          +(select count(1)
              from table (splitstr (t.enable_logistics, ',')) a,
                   tbl_standard_logistics b
             where a.column_value = b.logistics_code
                   and b.shipping_method_id = v_shipping_method_id) 
          into v_user_logistics_count
     from tbl_user_logistics_config t
    where t.user_id = client_user_name
      and t.state = 2;
    if v_user_logistics_count > 0 then
        insert into tbl_order_remark
            (
                id,
                order_number,
                disabled_logistics,
                enable_logistics,
                disabled_logistics_name,
                enabled_logistics_name,
                create_user_id,
                create_user_realname,
                create_date,
                state
            ) 
            select seq_order_remark.nextVal,
                   v_order_number,
                   disabled_logistics,
                   (select to_char (wm_concat (a.column_value))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics,
                   disabled_logistics_name,
                   (select to_char (wm_concat (b.logistics_name))
                      from table (splitstr (t.enable_logistics, ',')) a,
                           tbl_standard_logistics b
                     where     a.column_value = b.logistics_code
                           and b.shipping_method_id = v_shipping_method_id) as enable_logistics_name,
                   create_user_id,
                   '客户设置' create_user_realname,
                   sysdate,
                   state
              from tbl_user_logistics_config t
             where user_id = client_user_name
               and state = 2;
    else
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 start
        SELECT 
        count(1) into v_temp_count
        FROM 
        TBL_LOGISTICS_COMPANY tlc
        INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
        INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
        where tlc.code = client_logistics_company_code;
        --需要新增备注数据
        IF v_temp_count<>0 THEN
            Insert into TBL_ORDER_REMARK
            (ID, ORDER_NUMBER,STATE,ENABLE_LOGISTICS,ENABLED_LOGISTICS_NAME,CREATE_DATE,CREATE_USER_ID,CREATE_USER_REALNAME)
            select
            seq_order_remark.nextval,temp.*
            from 
            (
            SELECT 
            v_order_number ORDER_NUMBER,
            2 STATE,
            to_char(wm_concat(lc.LOGISTICS_CODE)) ENABLE_LOGISTICS, 
            (wm_concat(lc.LOGISTICS_NAME)) ENABLED_LOGISTICS_NAME,
        sysdate,
        0 CREATE_USER_ID,
        '系统设置' CREATE_USER_REALNAME
            FROM 
            TBL_LOGISTICS_COMPANY tlc
            INNER JOIN TBL_STANDARD_LOGISTICS_COM_REF slcr ON tlc.id = slcr.logistics_company_id
            INNER JOIN TBL_STANDARD_LOGISTICS lc ON slcr.standard_logistics_id = lc.id
            where tlc.code = client_logistics_company_code
            ) temp;
        END IF;
        ---插入订单备注表数据，记录当前订单的配送方式管理的标准物流公司信息  reid  2018.12.20 end
    end if;
   --9.0插入订单规格表
   INSERT INTO TBL_ORDER_PRODUCT (ID,
                                  ORDER_NUMBER,
                                  ORDER_ITEM_NUMBER,
                                  USER_NAME,
                                  USER_MANAGE_NAME,
                                  ITEMNUMBER,
                                  PRODUCT_NAME,
                                  PRODUCT_COLOR,
                                  PRODUCT_UNIT_PRICE,
                                  PRODUCT_UNIT_PRICE_TAG,
                                  PRODUCT_OLD_UNIT_PRICE,
                                  ORDER_DATE,
                                  ORDER_TYPE,
                                  PRODUCT_SPECS,
                                  PRODUCT_LACK_COUNT,
                                  WAREHOUSE_ID,
                                  PRODUCT_STORE_PRICE)
      SELECT SEQ_ORDER_PRODUCT.NEXTVAL,
             C.ORDER_NUMBER,
             C.ORDER_ITEM_NUMBER,
             C.USER_NAME,
             C.USER_MANAGE_NAME,
             C.PRODUCT_ITEMNUMBER,
             C.PRODUCT_NAME,
             C.PRODUCT_COLOR,
             C.PRODUCT_UNIT_PRICE,
             C.PRODUCT_PRIZE_TAG,
             C.PRODUCT_OLD_UNIT_PRICE,
             C.ORDER_DATE,
             C.ORDER_TYPE,
             C.PRODUCT_SPECS,
             C.PRODUCT_LACK_COUNT,
             C.WAREHOUSE_ID,
             C.PRODUCT_STORE_PRICE
        FROM (SELECT DISTINCT
                     v_order_number      AS ORDER_NUMBER,
                     DENSE_RANK () OVER (ORDER BY A.PARENT_ID)
                        AS ORDER_ITEM_NUMBER,
                     client_user_name    AS USER_NAME,
                     v_user_manage_name  AS USER_MANAGE_NAME,
                     A.PRODUCT_ITEMNUMBER,
                     (SELECT F.PRODUCT_NAME
                        FROM TBL_PRODUCT_INFO F
                       WHERE     F.ITEMNUMBER = A.PRODUCT_ITEMNUMBER
                             AND ROWNUM = 1)
                        AS PRODUCT_NAME,
                     A.PRODUCT_COLOR,
                     getSku_User_SalePrice (client_user_name, A.ID)
                        AS PRODUCT_UNIT_PRICE,
                     A.PRODUCT_PRIZE_TAG,
                     getSku_User_SalePrice (client_user_name, A.ID)
                        AS PRODUCT_OLD_UNIT_PRICE,
                     SYSDATE             AS ORDER_DATE,
                     V_ORDER_TYPE        AS ORDER_TYPE,
                     A.PRODUCT_SPECS,
                     0                   AS PRODUCT_LACK_COUNT,
                     CLIENT_WAREHOUSE_ID AS WAREHOUSE_ID,
                     (SELECT retail_price
                        FROM tbl_product_store_detail t
                       WHERE     product_sku = A.ID
                             AND EXISTS
                                    (SELECT 1
                                       FROM tbl_product_store
                                      WHERE     id = t.product_store_id
                                            AND user_id = client_user_name))
                        product_store_price
                FROM TBL_PRODUCT_SKU A, TMP_ORDER_PRODUCT_SKU B
               WHERE     A.ID = B.PRODUCT_SKU
                     AND B.WAREHOUSE_ID = client_warehouse_id) C;

   --10.0插入订单详细表
   INSERT INTO TBL_ORDER_PRODUCT_SKU (ID,
                                      ORDER_NUMBER,
                                      ORDER_ITEM_NUMBER,
                                      USER_NAME,
                                      CODENUMBER,
                                      COUNT,
                                      PRODUCT_UNIT_PRICE,
                                      PRODUCT_TOTAL_MONEY,
                                      PRODUCT_OLD_UNIT_PRICE,
                                      ORDER_DATE,
                                      PRODUCT_SKU,
                                      PRODUCT_SKU_NAME,
                                      PRODUCT_ITEMNUMBER,
                                      PRODUCT_COLOR,
                                      PRODUCT_SPECS,
                                      PRODUCT_LACK_COUNT,
                                      PRODUCT_OLDSALE_PRIZE,
                                      WAREHOUSE_ID,
                                      PRODUCT_STORE_PRICE,
                                      PRODUCT_STORE_TOTAL_MONEY)
      SELECT SEQ_ORDER_PRODUCT_SKU.NEXTVAL,
             v_order_number,
             B.ORDER_ITEM_NUMBER,
             client_user_name,
             A.PRODUCT_GROUP_MEMBER,
             C.COUNT,
             getSku_User_SalePrice (client_user_name, A.ID),
             getSku_User_SalePrice (client_user_name, A.ID) * C.COUNT,
             getSku_User_SalePrice (client_user_name, A.ID),
             SYSDATE,
             A.ID,
             A.PRODUCT_SKU_NAME,
             A.PRODUCT_ITEMNUMBER,
             A.PRODUCT_COLOR,
             A.PRODUCT_SPECS,
             0,
             getSku_OldPrice (A.ID),
             client_warehouse_id,
             (SELECT retail_price
                FROM tbl_product_store_detail t
               WHERE     product_sku = A.ID
                     AND EXISTS
                            (SELECT 1
                               FROM tbl_product_store
                              WHERE     id = t.product_store_id
                                    AND user_id = client_user_name)),
               (SELECT retail_price
                  FROM tbl_product_store_detail t
                 WHERE     product_sku = A.ID
                       AND EXISTS
                              (SELECT 1
                                 FROM tbl_product_store
                                WHERE     id = t.product_store_id
                                      AND user_id = client_user_name))
             * C.COUNT
        FROM TBL_PRODUCT_SKU A, TBL_ORDER_PRODUCT B, TMP_ORDER_PRODUCT_SKU C
       WHERE     B.ORDER_NUMBER = v_order_number
             AND B.USER_NAME = client_user_name
             AND B.ITEMNUMBER = A.PRODUCT_ITEMNUMBER
             AND B.PRODUCT_COLOR = A.PRODUCT_COLOR
             AND B.PRODUCT_SPECS = A.PRODUCT_SPECS
             AND A.ID = C.PRODUCT_SKU
             AND C.WAREHOUSE_ID = client_warehouse_id;

   --10.11查询逻辑库存量,根据逻辑库存量与下单量比较，如果不足，则为缺货订购商品订单 --批发5双以上
   IF v_product_total_count >= 5
   THEN
      SELECT COUNT (1)
        INTO v_temp_count
        FROM (SELECT T1.PRODUCT_SKU,
                     T1.COUNT AS PRODUT_COUNT,
                     NVL (
                        (SELECT   NVL (PRODUCT_TOTAL_COUNT, 0)
                                - NVL (PRODUCT_ORDER_OCCUPY_COUNT, 0)
                                - NVL (PRE_ORDER_OCCUPY_COUNT, 0)
                           FROM TBL_PRODUCT_SKU_STOCK
                          WHERE     PRODUCT_SKU = T1.PRODUCT_SKU
                                AND WAREHOUSE_ID = T1.WAREHOUSE_ID),
                        0)
                        AS WAREHOUSE_PRODUCT_COUNT
                FROM TBL_ORDER_PRODUCT_SKU T1
               WHERE T1.ORDER_NUMBER = v_order_number)
       WHERE WAREHOUSE_PRODUCT_COUNT < PRODUT_COUNT;

      IF v_temp_count > 0
      THEN
         v_outstock_flag := 1;
      END IF;
   END IF;

   --11.0修改各表的统计性数据
   UPDATE TBL_ORDER_PRODUCT TOP
      SET PRODUCT_COUNT =
             (SELECT SUM (TOPS.COUNT)
                FROM TBL_ORDER_PRODUCT_SKU TOPS
               WHERE     TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER
                     AND TOPS.ORDER_ITEM_NUMBER = TOP.ORDER_ITEM_NUMBER),
          PRODUCT_TOTAL_MONEY =
             (SELECT SUM (TOPS.PRODUCT_TOTAL_MONEY)
                FROM TBL_ORDER_PRODUCT_SKU TOPS
               WHERE     TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER
                     AND TOPS.ORDER_ITEM_NUMBER = TOP.ORDER_ITEM_NUMBER),
          PRODUCT_STORE_TOTAL_MONEY =
             (SELECT SUM (TOPS.PRODUCT_STORE_TOTAL_MONEY)
                FROM TBL_ORDER_PRODUCT_SKU TOPS
               WHERE     TOPS.ORDER_NUMBER = TOP.ORDER_NUMBER
                     AND TOPS.ORDER_ITEM_NUMBER = TOP.ORDER_ITEM_NUMBER)
    WHERE TOP.ORDER_NUMBER = v_order_number;

   --处理一下,防止总价没有计算
   UPDATE TBL_ORDER_PRODUCT TOP
      SET PRODUCT_TOTAL_MONEY =
             ROUND (TOP.PRODUCT_COUNT * TOP.PRODUCT_UNIT_PRICE, 2),
          PRODUCT_STORE_TOTAL_MONEY =
             ROUND (TOP.PRODUCT_COUNT * TOP.PRODUCT_STORE_PRICE, 2)
    WHERE     TOP.ORDER_NUMBER = v_order_number
          AND (   NVL (PRODUCT_TOTAL_MONEY, 0) = 0
               OR NVL (PRODUCT_STORE_TOTAL_MONEY, 0) = 0);

   --12.0计算店铺零售总价
   SELECT SUM (TOP.PRODUCT_STORE_TOTAL_MONEY), SUM (TOP.PRODUCT_TOTAL_MONEY)
     INTO v_product_store_total_money, v_product_total_money
     FROM TBL_ORDER_PRODUCT TOP
    WHERE TOP.ORDER_NUMBER = v_order_number;

   --校验店铺零售总价是否被篡改
   IF v_product_store_total_money <> client_product_money
   THEN
      output_msg :=
            '商品价格被篡改或商品价格发生变化,应收货款（'
         || v_product_store_total_money
         || '），请重新下单!';
      ROLLBACK;
      RETURN;
   END IF;

   UPDATE TBL_ORDER_INFO TOI
      SET PRODUCT_MONEY = v_product_total_money,
          PRODUCT_STORE_MONEY = v_product_store_total_money,
          PRODUCT_COUNT =
             (SELECT SUM (TOP.PRODUCT_COUNT)
                FROM TBL_ORDER_PRODUCT TOP
               WHERE TOP.ORDER_NUMBER = TOI.ORDER_NUMBER),
          IS_OUTSTOCK_ORDER = v_outstock_flag
    WHERE TOI.ORDER_NUMBER = v_order_number;

   --13.0更新订单占用量
   INSERT INTO TBL_ORDER_WAREHOUSE_COUNT (ID,
                                          ORDER_NUMBER,
                                          WAREHOUSE_ID,
                                          PRODUCT_SKU,
                                          OCCUPY_COUNT,
                                          CREATE_DATE)
      SELECT SEQ_ORDER_WAREHOUSE_COUNT.NEXTVAL,
             ORDER_NUMBER,
             client_warehouse_id,
             PRODUCT_SKU,
             COUNT,
             SYSDATE
        FROM TBL_ORDER_PRODUCT_SKU
       WHERE ORDER_NUMBER = v_order_number;

   output_status := '1';
   output_msg := v_order_number;
EXCEPTION
   WHEN OTHERS
   THEN
      output_status := '0';
      output_msg :=
            '提交订单出现未知错误::'
         || SQLCODE
         || '::'
         || SQLERRM
         || '----';
END SUBMIT_ORDER_STORE_ARR;
------------------------------------------------
/

