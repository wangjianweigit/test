create FUNCTION           getProductItemNumber
    /**
    生成商品货号
    shifan
    2017-04-12
  **/
  (type_id   IN NUMBER, --商品类别ID
   brand_id  IN NUMBER, --商品品牌ID
   year      IN NUMBER, --年份
   season_id IN NUMBER --季节ID
  ) RETURN VARCHAR2 IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  returnstr     VARCHAR2(50); --返回货号
  v_count       NUMBER; --临时变量
  v_temp_count  NUMBER; --临时变量
  v_type_code   VARCHAR2(10); --商品类别code
  v_brand_code  VARCHAR2(10); --商品品牌code
  v_year_code   VARCHAR2(10); --商品年份code
  v_season_code VARCHAR2(10); --商品季节code
  v_year_length number;--年份的长度
  v_seq_number  number;--货号生成序号
  v_itemnumber  VARCHAR2(50); --货号
BEGIN
  --初始化货号为空
  returnstr := '';
  --参数校验
  SELECT CODE INTO v_brand_code FROM TBL_DIC_PRODUCT_BRAND WHERE ID = brand_id;
  if v_brand_code is null or v_brand_code ='' then
     return returnstr;
  end if;

  SELECT CODE INTO v_season_code FROM TBL_DIC_PRODUCT_SEASON WHERE ID = season_id;
  if v_season_code is null or v_season_code ='' then
     return returnstr;
  end if;

  select nvl(length(to_char(year)),0 ) into v_year_length from dual;
  if v_year_length <> 4 then
     return returnstr;
  end if;
  SELECT TO_NUMBER(SUBSTR(TO_CHAR(year),LENGTH(TO_CHAR(year)),1)) INTO v_year_code FROM DUAL;

  SELECT A.CODE INTO v_type_code
  FROM ( SELECT T.ID,T.TYPE_NAME,T.PARENT_ID,T.CODE, LEVEL AS LEV
              FROM TBL_DIC_PRODUCT_TYPE T
        START WITH T.ID = type_id
        CONNECT BY PRIOR T.PARENT_ID = T.ID) A
 WHERE A.LEV IN (SELECT MAX (B.LEV)
                   FROM (SELECT T.*, LEVEL AS LEV
                           FROM TBL_DIC_PRODUCT_TYPE T
                         START WITH T.ID = type_id
                         CONNECT BY PRIOR T.PARENT_ID = T.ID ) B);
  if v_type_code is null or v_type_code ='' then
     return returnstr;
  end if;
  select count(1) into v_count from TBL_PRODUCT_ITEMNUMBER where type_code=v_type_code and brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
  if v_count = 1 then
     --获取上次货号生成
     select seq_number into v_seq_number from TBL_PRODUCT_ITEMNUMBER where type_code=v_type_code and brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
     if v_seq_number = 999 then
        --启用备用季节code
        SELECT CODE_BAK INTO v_season_code FROM TBL_DIC_PRODUCT_SEASON WHERE ID = season_id;
        if v_season_code is null or v_season_code ='' then
           return returnstr;
        end if;
        --验证备用季节是否已有生成货号记录
        select count(1) into v_count from TBL_PRODUCT_ITEMNUMBER where type_code=v_type_code and brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
        if v_count = 1 then
           select seq_number into v_seq_number from TBL_PRODUCT_ITEMNUMBER where type_code=v_type_code and brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
           if v_seq_number = 999 then
              return returnstr;
           end if;
           --判断上次生成的货号是否已被使用
           select  v_type_code||v_year_code||v_season_code||v_brand_code||REPLACE(lpad(v_seq_number,3,'0'), '4', '5') into v_itemnumber from dual;
           select count(1) into v_temp_count from TBL_PRODUCT_INFO where ITEMNUMBER = v_itemnumber;
           if v_temp_count <= 0 then
              rollback;
              return v_itemnumber;
           end if;
           --生成新的货号
           select  v_type_code||v_year_code||v_season_code||v_brand_code||REPLACE(lpad(v_seq_number+1,3,'0'), '4', '5') into returnstr from dual;
           update TBL_PRODUCT_ITEMNUMBER set seq_number = to_number(REPLACE(lpad(v_seq_number+1,3,'0'), '4', '5')) where type_code=v_type_code and brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
        else
           select  v_type_code||v_year_code||v_season_code||v_brand_code||'001' into returnstr from dual;
           insert into TBL_PRODUCT_ITEMNUMBER (TYPE_CODE,BRAND_CODE,YEAR_CODE,SEASON_CODE,SEQ_NUMBER) values(v_type_code,v_brand_code,v_year_code,v_season_code,1);
        end if;
     else
        --不启用备用季节code
        --判断上次生成的货号是否已被使用
        select  v_type_code||v_year_code||v_season_code||v_brand_code||REPLACE(lpad(v_seq_number,3,'0'), '4', '5') into v_itemnumber from dual;
        select count(1) into v_temp_count from TBL_PRODUCT_INFO_APPLY where ITEMNUMBER = v_itemnumber;
        if v_temp_count <= 0 then
           rollback;
           return v_itemnumber;
        end if;
        --生成新的货号
        select  v_type_code||v_year_code||v_season_code||v_brand_code||REPLACE(lpad(v_seq_number+1,3,'0'), '4', '5') into returnstr from dual;
        update TBL_PRODUCT_ITEMNUMBER set seq_number = to_number(REPLACE(lpad(v_seq_number+1,3,'0'), '4', '5')) where type_code=v_type_code and brand_code=v_brand_code and year_code=v_year_code and season_code=v_season_code;
     end if;
  else
     --第一次生成货号
     select  v_type_code||v_year_code||v_season_code||v_brand_code||'001' into returnstr from dual;
     insert into TBL_PRODUCT_ITEMNUMBER (TYPE_CODE,BRAND_CODE,YEAR_CODE,SEASON_CODE,SEQ_NUMBER) values(v_type_code,v_brand_code,v_year_code,v_season_code,1);
  end if;
  COMMIT;
  RETURN returnstr;
EXCEPTION
 WHEN OTHERS THEN
  rollback;
  return '';
END getProductItemNumber;
/

