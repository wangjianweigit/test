create PROCEDURE           pro_payment_transfer
/**
     转账支付(转账汇款)
    yejingquan
    2017-06-06  订单付款确认
    返回值：支付结果消息
**/
(
        client_user_name in varchar2,               --用户名
        client_order_number in varchar2,            --订单号码
        client_transfer_voucher_url in varchar2,    --订单付款凭证
        output_status  out varchar2,                --返回的状态码 0-失败 1-成功
        output_msg out varchar2                     --返回的信息
) AS
    TEMP_CHECKED_NUMBER           INT := 0;                           --临时变量 -检查数量
    v_user_realname   VARCHAR2 (50);                                  --审核人用户姓名
    TEMP_USER_ID                  INT := 0;                           --审核人用户ID
    TMP_SALE_USER_NAME            VARCHAR2 (100);                     --业务员用户名
    TMP_USER_NAME                 VARCHAR2 (100);                     --订单所属用户名
    TMP_USER_MANAGE_NAME          VARCHAR2 (100);                     --订单所属用户姓名
    TMP_CONTRIBUTION_MONEY        NUMBER;                             --待缴款金额
    TMP_PAYMENT_TYPE              VARCHAR2 (50);                      --付款渠道
    V_RECORD_NUMBER               VARCHAR2(50);                       --收付单号
    V_REMARK VARCHAR2(300);                 --摘要
    V_TOTAL_COUNT INT := 0; --商品数量
    V_SURPLUS_MONEY        NUMBER;                             --当前个人账户余额
    V_CREDIT_BALANCE        NUMBER;                            --当前个人账户授信余额
    V_VOUCHER_PATH VARCHAR2(300);----订单支付凭证
    V_XDR_USER_TYPE VARCHAR2(50);----订单下单人用户类型
    V_MD_ID NUMBER;----订单下单时门店ID
    V_YWY_USERNAME VARCHAR2(100);--业务员用户名-【收支记录】
    V_YWJL_USERNAME VARCHAR2(100);--业务经理用户名-【收支记录】
    V_MDID NUMBER;--门店ID-【收支记录】
    v_order_state INTEGER:=0;--订单总状态
BEGIN
    output_status:='0';
    --获取用户信息
   SELECT COUNT (1)
     INTO TEMP_CHECKED_NUMBER
     FROM TBL_SYS_USER_INFO
    WHERE USER_NAME = client_user_name;

   IF TEMP_CHECKED_NUMBER <> 0 THEN
      SELECT USER_REALNAME, ID
        INTO v_user_realname, TEMP_USER_ID
        FROM TBL_SYS_USER_INFO
       WHERE USER_NAME = client_user_name;
   ELSE
      OUTPUT_MSG := '当前操作用户信息不存在，请检查!';
      RETURN;
   END IF;

    --订单号校验
   SELECT COUNT (1)
     INTO TEMP_CHECKED_NUMBER
     FROM TBL_ORDER_INFO
    WHERE ORDER_NUMBER = CLIENT_ORDER_NUMBER AND PAYMENT_STATE = 1 AND PAYMENT_METHOD='转账汇款';

   IF TEMP_CHECKED_NUMBER <> 0 THEN
      SELECT SALE_USER_NAME, (product_money+logistics_money+df_money), '转账汇款',USER_NAME,USER_MANAGE_NAME,PRODUCT_COUNT,XDR_USER_TYPE,MD_ID,MD_ID As MDID,YWY_USER_NAME,YWJL_USER_NAME,order_state 
        INTO TMP_SALE_USER_NAME, TMP_CONTRIBUTION_MONEY, TMP_PAYMENT_TYPE,TMP_USER_NAME,TMP_USER_MANAGE_NAME,V_TOTAL_COUNT,V_XDR_USER_TYPE,V_MD_ID,V_MDID,V_YWY_USERNAME,V_YWJL_USERNAME,v_order_state
        FROM TBL_ORDER_INFO
       WHERE ORDER_NUMBER = CLIENT_ORDER_NUMBER AND PAYMENT_STATE = 1 AND PAYMENT_METHOD='转账汇款';
       if v_order_state!='1' then
            OUTPUT_MSG := '当前订单为非待付款状态，不能完成当前操作，请刷新后重试!';
            RETURN;
       end if;
   ELSE
      OUTPUT_MSG := '当前操作订单信息不存在，请检查!';
      RETURN;
   END IF;
   --1.00计算个人账户余额，记入个人收支记录表中。
      SELECT COUNT(1) INTO TEMP_CHECKED_NUMBER
          FROM TBL_BANK_ACCOUNT T1
         WHERE EXISTS (SELECT 1
                         FROM TBL_USER_INFO T2
                        WHERE USER_NAME = TMP_USER_NAME
                              AND T2.ID = T1.USER_ID);
         IF temp_checked_number <> 0 THEN
           SELECT NVL(T1.ACCOUNT_BALANCE,0),NVL(T1.CREDIT_MONEY_BALANCE,0) INTO v_surplus_money,v_credit_balance
             FROM TBL_BANK_ACCOUNT T1
            WHERE EXISTS (SELECT 1
                            FROM TBL_USER_INFO T2
                           WHERE USER_NAME = tmp_user_name
                                 AND T2.ID = T1.USER_ID);
         ELSE
             OUTPUT_MSG := '订单所属用户帐户异常，请检查！';
             RETURN;
         END IF;
    --1.3生成个人收支记录
        V_RECORD_NUMBER:=GETAUTONUMBER('XD');
        V_REMARK:='付订单货款时，生成充值记录,商品明细请见订单号码:'||CLIENT_ORDER_NUMBER;
        --先产生充值记录
        INSERT INTO TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
                         CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
                         ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
                         PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
                         MONEY, COUNT,SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,CHECK_USER_NAME,CHECK_USER_BUSINESS_NAME,
                         CHECK_DATE,TURNOVER_NUMBER,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,CREDIT_BALANCE)
        VALUES(SEQ_USER_ACCOUNT_RECORD.NEXTVAL,V_RECORD_NUMBER||'1',1,TMP_PAYMENT_TYPE,'收款', V_REMARK,
               SYSDATE,TMP_USER_NAME,TMP_USER_MANAGE_NAME,
               '1001CZ','充值',
               '1001','转账汇款',
                TMP_CONTRIBUTION_MONEY,V_TOTAL_COUNT,V_SURPLUS_MONEY+TMP_CONTRIBUTION_MONEY,'已审核',CLIENT_ORDER_NUMBER,client_user_name,TMP_USER_NAME,client_user_name,
                v_user_realname,
                SYSDATE,V_RECORD_NUMBER,V_YWJL_USERNAME,V_YWY_USERNAME,V_MDID,V_CREDIT_BALANCE);
        V_REMARK:='付订单货款,商品明细请见订单号码:'||CLIENT_ORDER_NUMBER;
        --产生付款记录
        INSERT INTO TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
                         CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
                         ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
                         PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
                         MONEY, COUNT,SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,CHECK_USER_NAME,CHECK_USER_BUSINESS_NAME,
                         CHECK_DATE,TURNOVER_NUMBER,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,CREDIT_BALANCE)
        VALUES(SEQ_USER_ACCOUNT_RECORD.NEXTVAL,V_RECORD_NUMBER||'2',1,TMP_PAYMENT_TYPE,'付款', V_REMARK,
               SYSDATE,TMP_USER_NAME,TMP_USER_MANAGE_NAME,
               '2121TK','童库',
               '2121','应付账款',
                TMP_CONTRIBUTION_MONEY,V_TOTAL_COUNT,V_SURPLUS_MONEY,'已审核',CLIENT_ORDER_NUMBER,client_user_name,TMP_USER_NAME,client_user_name,
                v_user_realname,
                SYSDATE,V_RECORD_NUMBER,V_YWJL_USERNAME,V_YWY_USERNAME,V_MDID,V_CREDIT_BALANCE);
    
      --1.4 更新订单状态
      UPDATE TBL_ORDER_INFO
         SET PAYMENT_STATE = 2,
             order_state = 2,
             transfer_voucher_url = client_transfer_voucher_url,
             payment_transfer_date = sysdate,
             payment_date = sysdate,
             payment_type = '转账汇款',
             payment_money = (product_money+logistics_money+df_money),
             check_state = 1,
             payment_transfer_user_name = client_user_name,
             payment_transfer_user_realname = v_user_realname
       WHERE ORDER_NUMBER = CLIENT_ORDER_NUMBER;

     output_status:='1';
     output_msg:='订单付款确认成功';
  EXCEPTION
    WHEN OTHERS THEN
        output_msg:='订单付款确认出现未知错误';
    ROLLBACK;
END pro_payment_transfer;
/

