create FUNCTION           getProductItemNumber_check
    /**
    用于校验生成的货号是否符合规则，该方法仅返回货号的前几位
     商品品牌code + 商品年份code + 商品季节code
    songwangwen
    2019.04.02
  **/
  (
   brand_id  IN NUMBER, --商品品牌ID
   year      IN NUMBER, --年份
   season_id IN NUMBER --季节ID
  ) RETURN VARCHAR2 IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  returnstr     VARCHAR2(50); --返回货号
  v_count       NUMBER; --临时变量
  v_temp_count  NUMBER; --临时变量
  v_brand_code  VARCHAR2(10); --商品品牌code
  v_year_code   VARCHAR2(10); --商品年份code
  v_season_code VARCHAR2(10); --商品季节code
  v_year_length number;--年份的长度
  v_seq_number  number;--货号生成序号
  v_itemnumber  VARCHAR2(50); --货号
BEGIN
  --初始化货号为空
  returnstr := '';
  --参数校验
  SELECT CODE INTO v_brand_code FROM TBL_DIC_PRODUCT_BRAND WHERE ID = brand_id;
  if v_brand_code is null or v_brand_code ='' then
     return returnstr;
  end if;

  SELECT CODE INTO v_season_code FROM TBL_DIC_PRODUCT_SEASON WHERE ID = season_id;
  if v_season_code is null or v_season_code ='' then
     return returnstr;
  end if;

  select nvl(length(to_char(year)),0 ) into v_year_length from dual;
  if v_year_length <> 4 then
     return returnstr;
  end if;
  SELECT TO_NUMBER(SUBSTR(TO_CHAR(year),LENGTH(TO_CHAR(year)),1)) INTO v_year_code FROM DUAL;
  --组装数据
  select  v_brand_code||v_year_code||v_season_code into returnstr from dual;
  COMMIT;
  RETURN returnstr;
EXCEPTION
 WHEN OTHERS THEN
  rollback;
  return '';
END getProductItemNumber_check;
/

