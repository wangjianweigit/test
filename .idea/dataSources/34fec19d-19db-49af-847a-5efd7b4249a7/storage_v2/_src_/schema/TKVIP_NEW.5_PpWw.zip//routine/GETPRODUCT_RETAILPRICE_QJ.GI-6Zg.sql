create FUNCTION           getProduct_RetailPrice_Qj
/**
    获取商品货号零售价格价格区间   （精确价格）
    yejingquan
    2017-05-13
    返回值：商品价格
**/
(
    c_user_name            varchar2,--用户
    c_product_itemnumber   varchar2--商品货号
) return varchar2
 is
    min_retail_price varchar2(50) :='0.00';
    max_retail_price varchar2(50) :='0.00';
    v_product_price_str varchar2(50) :='0.00-0.00';   --需要返回的商品价格区间
BEGIN

   --获取最小零售价格
   select nvl(to_char(min(retail_price),'fm999999990.00'),'0.00') into min_retail_price
    from tbl_product_store_detail t
   where product_itemnumber = c_product_itemnumber
     and exists (select 1 from tbl_product_store where id = t.product_store_id and user_id = c_user_name);
   --获取最大零售价格
   select nvl(to_char(max(retail_price),'fm999999990.00'),'0.00') into max_retail_price
     from tbl_product_store_detail t
    where product_itemnumber = c_product_itemnumber
      and exists (select 1 from tbl_product_store where id = t.product_store_id and user_id = c_user_name);

   v_product_price_str := min_retail_price||'-'||max_retail_price;

   return v_product_price_str;

END getProduct_RetailPrice_Qj;
/

