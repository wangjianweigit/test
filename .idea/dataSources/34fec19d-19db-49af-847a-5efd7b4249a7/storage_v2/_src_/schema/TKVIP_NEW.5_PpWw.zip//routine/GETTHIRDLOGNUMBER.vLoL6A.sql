create FUNCTION           getThirdLogNumber
/**
    根据时间生成20位编号    
    wanghai
    2017-10-17
**/
(
begin_str   varchar2   --开头字母     
) return varchar2
 is
 returnstr varchar2(50);
 t_count number := 0;
BEGIN
   returnstr:=replace(to_char(systimestamp,'yyyyMMddHH24missxff3'),'.','')||lpad(SEQ_THIRD_LOGNO.nextval,3,'0');
   
   return returnstr;
END getThirdLogNumber;
/

