create TYPE           T_ORDER_LST                                                                                                           
AS TABLE OF T_ORDER;
------------------------------------------------
/

