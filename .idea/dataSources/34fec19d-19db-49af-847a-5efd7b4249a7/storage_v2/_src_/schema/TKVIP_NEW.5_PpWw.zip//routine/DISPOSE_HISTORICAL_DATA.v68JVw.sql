create PROCEDURE           DISPOSE_HISTORICAL_DATA
/**
     运费模板和会员配送模板历史数据处理
     zhenghui
     2019-04-29
  **/
IS
   v_user_id            number;             --私有商家ID
   v_user_name          number := 0;        --私有商家用户名
   v_issuing_grade_id   number := 0;        --代发费用ID
BEGIN
  --定义游标查询所有私有商家
   declare cursor user_list is  
        select ID,USER_NAME from TBL_STATIONED_USER_INFO ui where exists(select 1 from TBL_MERCHANTS_TYPE mt where mt.STATIONED_USER_ID = ui.id and mt.MERCHANTS_TYPE = 4) and ui.STATIONED_USER_TYPE = 2;
        
   begin
        for c_row in user_list loop
        
            v_user_id := c_row.ID;
            v_user_name := c_row.USER_NAME;
            
            --新增默认代发费用等级
            INSERT INTO TBL_ISSUING_GRADE 
            SELECT 
                SEQ_ISSUING_GRADE.NEXTVAL,
                GRADE_NAME,
                PIECE_COST,
                '私有会员默认代发等级-'||v_user_name AS REMARK,
                CREATE_USER_ID,
                SYSDATE,
                IS_DEFAULT,
                SORT_ID,
                2 AS PLATFORM_TYPE,
                v_user_id
            FROM TBL_ISSUING_GRADE WHERE ID = 1;
           
        end loop;
    end;
   commit;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END DISPOSE_HISTORICAL_DATA;
/

