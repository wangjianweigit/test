create FUNCTION           getAutoNumber
/**
    根据时间生成20位编号    
    yejingquan
    2017-04-19
**/
(
begin_str   varchar2   --开头字母     
) return varchar2
 is
 returnstr varchar2(50);
BEGIN
   returnstr:=replace(to_char(systimestamp,'yyyyMMddHH24missxff3'),'.','')||trunc(dbms_random.value(100,999));
   return returnstr;
END getAutoNumber;
/

