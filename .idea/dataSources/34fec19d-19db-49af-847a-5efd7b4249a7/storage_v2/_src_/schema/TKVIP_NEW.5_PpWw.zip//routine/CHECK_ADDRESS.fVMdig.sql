create FUNCTION           check_address
/**
    校验地址信息中的省市县ID是否存在且十分符合规则 songwangwen 2018.12.29
    return 0:不符合规则需要修改    1：符合规则不需要修改
**/
(province_id number,                 --省份ID
 city_id    number,                     --城市ID
 county_id number                   --区县ID
) RETURN NUMBER is     ---返回值，两个坐标点的距离（单位米）
  is_exist number := 0;--地址是否有效  0：有效  1:失效，需要更新
  temp_count      number :=0;--临时变量
begin
    --查询省份是否存在
    SELECT count(1) into temp_count FROM TBL_DIC_REGION where id = province_id and is_display = 1;
    IF temp_count=0 THEN
        is_exist:=1;
        RETURN is_exist;
    END IF; 
    --查询城市是否存在
    SELECT count(1) into temp_count FROM TBL_DIC_REGION where id = city_id and is_display = 1 and parent_id = province_id;
     IF temp_count=0 THEN
        is_exist:=1;
        RETURN is_exist;
    END IF; 
     --查询区县是否存在
    SELECT count(1) into temp_count FROM TBL_DIC_REGION where id = county_id and is_display = 1 and parent_id = city_id;
     IF temp_count=0 THEN
        is_exist:=1;
        RETURN is_exist;
    END IF; 
    return is_exist; 
    EXCEPTION
WHEN OTHERS THEN
    RETURN 0;
END check_address;
/

