create FUNCTION           getProduct_SalePrice_Qj
/**
    （新版）通过用户名获取商品货号价格价格区间   （精确价格）
    wangpeng
    2017-05-13
    返回值：商品价格
**/
(
    c_user_name   varchar2,   --用户名
    c_product_itemnumber   varchar2--商品货号    
) return varchar2
 is
    v_product_prize_str varchar2(50):='0.00-0.00';   --需要返回的商品价格区间
BEGIN

   --通过sku获取最低价
   select nvl(to_char(min(price),'fm999999990.00'),'0.00')||'-'||nvl(to_char(max(price),'fm999999990.00'),'0.00') into v_product_prize_str  from (
        select getSku_User_SalePrice(c_user_name,id) price from tbl_product_sku where product_itemnumber = c_product_itemnumber and product_group ='尺码' and state='上架'
   );
   return v_product_prize_str;
   
END getProduct_SalePrice_Qj;
/

