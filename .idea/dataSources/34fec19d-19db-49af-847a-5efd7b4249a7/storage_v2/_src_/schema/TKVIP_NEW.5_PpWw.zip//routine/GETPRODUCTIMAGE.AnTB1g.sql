create FUNCTION           GETPRODUCTIMAGE
/**
    根据标志位获取商品图片信息
    zhenghui
    2018.11.27
    
    2018.01.18 reid 修改获取第几张图片的方式
**/
(
    C_PRODUCT_ITEMNUMBER    VARCHAR2,                --商品货号
    C_INDEX                 NUMBER                   --标志位  0.主图 
) RETURN VARCHAR2
 IS
    V_IMAGE_URL           VARCHAR2(200);           --活动结束时间
    TEMP_COUNT            NUMBER;
BEGIN
   /***************获取商品第几张图，图片不存在则返回商品主图********************/
   SELECT count(1) into TEMP_COUNT FROM (SELECT A.*, ROWNUM num FROM (SELECT PI.id FROM TBL_PRODUCT_IMAGES PI WHERE PI.PRODUCT_ITEMNUMBER = C_PRODUCT_ITEMNUMBER AND PI.TYPE = 1) A) temp where temp.num = C_INDEX;
   IF TEMP_COUNT = 0 THEN
        SELECT PRODUCT_IMG_URL INTO V_IMAGE_URL FROM TBL_PRODUCT_INFO WHERE ITEMNUMBER = C_PRODUCT_ITEMNUMBER;
   ELSE
        SELECT IMAGE_URL INTO V_IMAGE_URL FROM (SELECT A.*, ROWNUM num FROM (
            select
            pim.image_url
            from tbl_product_images pim
            where pim.product_itemnumber = C_PRODUCT_ITEMNUMBER and pim.type = '1'
            order by pim.type desc, pim.is_primary desc, pim.sortid desc
        ) A) temp where temp.num = C_INDEX;
   END IF;
   RETURN V_IMAGE_URL;
END GETPRODUCTIMAGE;
/

