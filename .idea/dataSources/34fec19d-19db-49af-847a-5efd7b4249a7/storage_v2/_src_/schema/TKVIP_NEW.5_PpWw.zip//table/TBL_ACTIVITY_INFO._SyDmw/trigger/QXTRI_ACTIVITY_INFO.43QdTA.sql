create trigger QXTRI_ACTIVITY_INFO
  before update
  on TBL_ACTIVITY_INFO
  for each row
BEGIN
    IF  UPDATING ('IS_DELETE') or  UPDATING ('STATE')
    THEN
        INSERT INTO QXTMP_PRODUCT(ID,LOG_ID,OPERATION_TYPE,CREATE_DATE) 
        select QXSEQ_PRODUCT.NEXTVAL,b.id,2,sysdate 
        from TBL_ACTIVITY_PRODUCT a,TBL_PRODUCT_INFO b where a.PRODUCT_ITEMNUMBER = b.ITEMNUMBER and a.activity_id = :old.id and b.PRODUCT_TYPE in (0,3);
    END IF;
END;
/

