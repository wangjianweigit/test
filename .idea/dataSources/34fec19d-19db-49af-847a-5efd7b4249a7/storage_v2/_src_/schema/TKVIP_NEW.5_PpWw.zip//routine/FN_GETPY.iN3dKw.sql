create FUNCTION fn_getpy 
(
    p_str    VARCHAR2,  
    p_flag   NUMBER :=0

) RETURN VARCHAR2  
IS  
    v_compare   varchar2(4); /

