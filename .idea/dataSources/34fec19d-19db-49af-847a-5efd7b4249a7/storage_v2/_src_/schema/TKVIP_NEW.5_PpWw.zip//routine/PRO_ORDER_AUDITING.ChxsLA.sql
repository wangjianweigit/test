create PROCEDURE           PRO_ORDER_AUDITING
/**
  订单审核操作
  yejingquan 2017-04-25
  shif 20170518调整优化
  yejingquan 20170523 增加审核驳回原因
  返回值：成功或失败消息提示信息
 **/
(
   CLIENT_CHECK_MONEY_USER_NAME   IN     VARCHAR2,                    --审核人用户名
   CLIENT_PAY_TRADE_NUMBER        IN     VARCHAR2,                    --付款交易号
   CLIENT_ORDER_NUMBER            IN     VARCHAR2,                    --审核订单号
   CLIENT_CHECK_MONEY_TYPE        IN     VARCHAR2,                    --审核类型 1-审核通过 2-审核驳回
   CLIENT_REJECTED_REASON         IN     VARCHAR2,                    --审核驳回原因
   OUTPUT_STATUS                     OUT VARCHAR2,                    --返回的状态码 0-失败 1-成功
   OUTPUT_MSG                        OUT VARCHAR2                     --返回的信息
                                                 )
IS
   temp_checked_number           int := 0;                            --临时变量 -检查数量
   temp_check_money_user_rname   varchar2 (50);                       --审核人用户姓名
   temp_user_id                  int := 0;                            --审核人用户id
   tmp_sale_user_name            varchar2 (100);                      --业务员用户名
   tmp_user_name                 varchar2 (100);                      --订单所属用户名
   tmp_user_manage_name          varchar2 (100);                      --订单所属用户姓名
   tmp_contribution_money        number;                              --待缴款金额
   tmp_payment_type              varchar2 (50);                       --付款渠道
   v_record_number               varchar2(50);                        --收付单号
   v_remark varchar2(3000);                                           --摘要
   v_total_count int := 0;                                            --商品数量
   v_surplus_money        number;                                     --当前个人账户余额
   v_credit_balance        number;                                    --当前个人账户授信余额
   v_contribution_number         varchar2(20);                        --缴款单号
   v_contribution_wait_id number;                                     ----待缴款记录id
   v_voucher_path varchar2(2000);                                     ----订单支付凭证
   v_xdr_user_type varchar2(50);                                      ----订单下单人用户类型
   v_md_id number;                                                    ----订单下单时门店id
   v_ywy_username varchar2(100);                                      --业务员用户名-【收支记录】
   v_ywjl_username varchar2(100);                                     --业务经理用户名-【收支记录】
   v_mdid number;                                                     --门店id-【收支记录】,
   v_order_numbers varchar2(1000);                                    --临时变量，检查是否有状态不符的订单号
   temp_check_order_number   varchar2 (50);                           --循环临时变量
   tmp_total_money        number;                                     --订单付款总额
   v_pay_trade_number     varchar2(50);                               --付款交易号
   temp_voucher_path varchar2(2000);                                  ----订单支付凭证临时变量【合并付款】
   v_contribution_number_flag int:=0;                                 ----是否生成缴款单标志
BEGIN
   output_status := '0';
   output_msg := '操作失败！';
   --1.0校验操作用户
   SELECT COUNT (1)
     INTO TEMP_CHECKED_NUMBER
     FROM TBL_SYS_USER_INFO
    WHERE USER_NAME = client_check_money_user_name;

   IF temp_checked_number <> 0 THEN
      SELECT USER_REALNAME, ID
        INTO temp_check_money_user_rname, temp_user_id
        FROM TBL_SYS_USER_INFO
       WHERE USER_NAME = client_check_money_user_name;
   ELSE
      OUTPUT_MSG := '当前操作用户信息不存在，请检查!';
      RETURN;
   END IF;
   --兼容之前的订单审核增加的校验。原审核时，只需传订单号，新审核时，只需传付款交易号
   IF client_pay_trade_number IS NOT NULL AND client_order_number IS NOT NULL THEN
      OUTPUT_MSG := '参数有误，请检查!';
      RETURN;
   END IF;
   v_pay_trade_number := client_pay_trade_number;

   IF client_pay_trade_number IS NULL THEN
      v_pay_trade_number := client_order_number;
   ELSE
      --获取缴款支付凭证
      SELECT VOUCHER_PATH into temp_voucher_path FROM TBL_ORDER_UNION_PAY T WHERE T.PAY_TRADE_NUMBER = client_pay_trade_number;
      --生成缴款单号
      SELECT GETAUTONUMBER('C') INTO v_contribution_number FROM DUAL;
   END IF;
   --订单号状态校验【校验】
   SELECT COUNT (1),WM_CONCAT(T.ORDER_NUMBER)
     INTO temp_checked_number,v_order_numbers
     FROM TBL_ORDER_INFO t
    WHERE ( EXISTS(SELECT 1 FROM TBL_ORDER_UNION_PAY_DETAIL T1 WHERE T1.PAY_TRADE_NUMBER = v_pay_trade_number AND T1.ORDER_NUMBER = T.ORDER_NUMBER ) ) AND PAYMENT_STATE <> 3;
   IF TEMP_CHECKED_NUMBER <> 0 THEN
      output_msg := v_order_numbers||'订单付款状态异常，请检查!';
      RETURN;
   END IF;
   SELECT COUNT (1)
     INTO temp_checked_number
     FROM TBL_ORDER_INFO T
    WHERE ( EXISTS(SELECT 1 FROM TBL_ORDER_UNION_PAY_DETAIL T1 WHERE T1.PAY_TRADE_NUMBER = v_pay_trade_number AND T1.ORDER_NUMBER = T.ORDER_NUMBER ) ) AND PAYMENT_STATE = 3;
   --循环处理待审核的订单列表，并生成对应缴款单，待缴款单
   IF TEMP_CHECKED_NUMBER >0 THEN
      --生成收支记录对应单号
      v_record_number:=GETAUTONUMBER('XD');
      DECLARE CURSOR to_check_orders IS
        SELECT T.ORDER_NUMBER,T.XDR_USER_NAME, T.PAYMENT_MONEY, T.PAYMENT_TYPE,T.USER_NAME,T.USER_MANAGE_NAME,T.PRODUCT_COUNT,T.SALE_USER_NAME,T.SALE_USER_TYPE,T.SALE_MD_ID,T.MD_ID,T.YWY_USER_NAME,T.YWJL_USER_NAME
          FROM TBL_ORDER_INFO T
         WHERE (EXISTS(SELECT 1 FROM TBL_ORDER_UNION_PAY_DETAIL T1 WHERE T1.PAY_TRADE_NUMBER =v_pay_trade_number AND T1.ORDER_NUMBER = T.ORDER_NUMBER ) ) AND PAYMENT_STATE = 3;
      BEGIN
        FOR c_row IN to_check_orders LOOP
             temp_check_order_number := c_row.ORDER_NUMBER;
             tmp_sale_user_name := c_row.SALE_USER_NAME;
             tmp_contribution_money := c_row.PAYMENT_MONEY;
             tmp_payment_type := c_row.PAYMENT_TYPE;
             tmp_user_name := c_row.USER_NAME;
             tmp_user_manage_name := c_row.USER_MANAGE_NAME;
             v_xdr_user_type := c_row.SALE_USER_TYPE;
             v_md_id := c_row.SALE_MD_ID;
             v_mdid := c_row.MD_ID;
             v_ywy_username := c_row.YWY_USER_NAME;
             v_ywjl_username := c_row.YWJL_USER_NAME;
             --合并付款时支付凭证处理
             IF client_pay_trade_number IS NOT NULL THEN
                v_voucher_path := temp_voucher_path;
             END IF;
             --1-审核通过
             IF CLIENT_CHECK_MONEY_TYPE = '1' THEN
                OUTPUT_MSG := '订单审核失败！';
                 --POS刷卡和转账自动缴款
                 IF TMP_PAYMENT_TYPE = 'POS刷卡' OR TMP_PAYMENT_TYPE = '现金转账' THEN
                    v_contribution_number_flag :=1;
                    v_contribution_wait_id:=SEQ_CONTRIBUTION_WAIT.NEXTVAL;
                    --1.1生成待缴款记录表
                    INSERT INTO TBL_CONTRIBUTION_WAIT (ID,
                                                   SALE_USER_NAME,
                                                   CONTRIBUTION_TYPE,
                                                   ORDER_NUMBER,
                                                   CONTRIBUTION_MONEY,
                                                   CREATE_DATE,
                                                   CREATE_USER_ID,
                                                   CREATE_USER_NAME,
                                                   STATE,
                                                   CONTRIBUTION_NUMBER,
                                                   CONTRIBUTION_DATE,
                                                   RECEIPT_TYPE,
                                                   XDR_USER_TYPE,
                                                   MD_ID)
                     VALUES (v_contribution_wait_id,
                             tmp_sale_user_name,
                             1,
                             temp_check_order_number,
                             tmp_contribution_money,
                             SYSDATE,
                             temp_user_id,
                             temp_check_money_user_rname,
                             2,
                             v_contribution_number,
                             SYSDATE,
                             tmp_payment_type,
                             v_xdr_user_type,
                             v_md_id);
                    --1.2 创建缴款单明细
                     INSERT INTO TBL_CONTRIBUTION_ORDER_DETAIL(
                          CONTRIBUTION_NUMBER,
                          CONTRIBUTION_WAIT_ID
                     )
                     VALUES
                     (
                          V_CONTRIBUTION_NUMBER,
                          V_CONTRIBUTION_WAIT_ID
                      );

                 ELSE
                    --1.3生成待缴款记录表
                    INSERT INTO TBL_CONTRIBUTION_WAIT (ID,
                                                       SALE_USER_NAME,
                                                       CONTRIBUTION_TYPE,
                                                       ORDER_NUMBER,
                                                       CONTRIBUTION_MONEY,
                                                       CREATE_DATE,
                                                       CREATE_USER_ID,
                                                       CREATE_USER_NAME,
                                                       STATE,
                                                       RECEIPT_TYPE,
                                                       XDR_USER_TYPE,
                                                       MD_ID)
                         VALUES (SEQ_CONTRIBUTION_WAIT.NEXTVAL,
                                 tmp_sale_user_name,
                                 1,
                                 temp_check_order_number,
                                 tmp_contribution_money,
                                 SYSDATE,
                                 temp_user_id,
                                 temp_check_money_user_rname,
                                 1,
                                 tmp_payment_type,
                                 v_xdr_user_type,
                                 v_md_id);
                  END IF;
                --1.4 更新订单状态
                UPDATE TBL_ORDER_INFO
                   SET PAYMENT_STATE = 2,CHECK_STATE=1,PAYMENT_NUMBER = v_record_number||'2',PAYMENT_DATE = SYSDATE
                 WHERE ORDER_NUMBER = temp_check_order_number;
             ELSE
                --2-审核驳回
                IF client_check_money_type = '2'
                THEN
                   OUTPUT_MSG := '订单审核驳回失败!';
                   UPDATE TBL_ORDER_INFO
                      SET ORDER_STATE = 1, PAYMENT_STATE = 1
                    WHERE ORDER_NUMBER = temp_check_order_number;
                ELSE
                   OUTPUT_MSG := '不支持的审核类型！';
                   return;
                END IF;
             END IF;
        end loop;
    end;
    IF CLIENT_CHECK_MONEY_TYPE = '1' then
        --1.0计算个人账户余额，记入个人收支记录表中。
        SELECT COUNT(1) INTO TEMP_CHECKED_NUMBER
          FROM TBL_BANK_ACCOUNT T1
         WHERE EXISTS (SELECT 1
                         FROM TBL_USER_INFO T2
                        WHERE USER_NAME = TMP_USER_NAME
                              AND T2.ID = T1.USER_ID);
         IF temp_checked_number <> 0 THEN
           SELECT NVL(T1.ACCOUNT_BALANCE,0),NVL(T1.CREDIT_MONEY_BALANCE,0) INTO v_surplus_money,v_credit_balance
             FROM TBL_BANK_ACCOUNT T1
            WHERE EXISTS (SELECT 1
                            FROM TBL_USER_INFO T2
                           WHERE USER_NAME = tmp_user_name
                                 AND T2.ID = T1.USER_ID);
         ELSE
             OUTPUT_MSG := '订单所属用户帐户异常，请检查！';
             RETURN;
         END IF;
         SELECT WM_CONCAT(T.ORDER_NUMBER),SUM(T.PAYMENT_MONEY),SUM(T.PRODUCT_COUNT)
           INTO v_order_numbers,tmp_total_money,v_total_count
           FROM TBL_ORDER_INFO T
          WHERE (EXISTS(SELECT 1 FROM TBL_ORDER_UNION_PAY_DETAIL T1 WHERE T1.PAY_TRADE_NUMBER = v_pay_trade_number AND T1.ORDER_NUMBER = T.ORDER_NUMBER ));
        --1.1补充生成缴款记录表【现金转账、pos刷卡上面已生成待缴款、缴款明细】
        IF v_contribution_number_flag = 1 THEN
                     INSERT INTO TBL_CONTRIBUTION_ORDER
                      (
                          ID,
                          CONTRIBUTION_NUMBER,
                          SALE_USER_NAME,
                          TOTAL_MONEY,
                          CREATE_DATE,
                          STATE,
                          RECEIPT_TYPE,
                          VOUCHER_PATH,
                          XDR_USER_TYPE,
                          MD_ID
                      )
                      VALUES
                      (
                          SEQ_CONTRIBUTION_ORDER.NEXTVAL,
                          v_contribution_number,
                          tmp_sale_user_name,
                          tmp_total_money,--TMP_CONTRIBUTION_MONEY,
                          SYSDATE,
                          1,
                          tmp_payment_type,
                          v_voucher_path,
                          v_xdr_user_type,
                          v_md_id
                      );
        END IF;
        --1.2生成个人收支记录
        V_REMARK:='付订单货款时，生成充值记录,商品明细请见订单号码:'||v_order_numbers;
        --先产生充值记录
        INSERT INTO TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
                         CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
                         ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
                         PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
                         MONEY, COUNT,SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,CHECK_USER_NAME,CHECK_USER_BUSINESS_NAME,
                         CHECK_DATE,TURNOVER_NUMBER,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,CREDIT_BALANCE)
        VALUES(SEQ_USER_ACCOUNT_RECORD.nextval,v_record_number||'1',1,tmp_payment_type,'收款', v_remark,
               SYSDATE,tmp_user_name,tmp_user_manage_name,'1001CZ','充值','1001','现金',
               tmp_total_money,v_total_count,v_surplus_money + tmp_total_money,'已审核',v_pay_trade_number,client_check_money_user_name,
               tmp_user_name,client_check_money_user_name,temp_check_money_user_rname,SYSDATE,v_record_number,v_ywjl_username,v_ywy_username,v_mdid,v_credit_balance);
        v_remark:='付订单货款,商品明细请见订单号码:'||v_order_numbers;
        --产生付款记录
        INSERT INTO TBL_USER_ACCOUNT_RECORD(ID,RECORD_NUMBER, RECORD_ITEM_NUMBER,RECORD_CHANNEL,RECORD_TYPE,REMARK,
                         CREATE_DATE, COLLECT_USER_NAME, COLLECT_USER_MANAGER_NAME,
                         ACCOUNTANTS_SUBJECT_ID, ACCOUNTANTS_SUBJECT_NAME,
                         PARENT_ACC_SUBJECT_ID, PARENT_ACC_SUBJECT_NAME,
                         MONEY, COUNT,SURPLUS_MONEY, STATE, DOCKET_NUMBER, CREATE_USER, USER_NAME,CHECK_USER_NAME,CHECK_USER_BUSINESS_NAME,
                         CHECK_DATE,TURNOVER_NUMBER,YWJL_USER_NAME,YWY_USER_NAME,MD_ID,CREDIT_BALANCE)
        VALUES(SEQ_USER_ACCOUNT_RECORD.NEXTVAL,v_record_number||'2',1,tmp_payment_type,'付款', v_remark,
               SYSDATE,tmp_user_name,tmp_user_manage_name,'2121TK','童库','2121','应付账款',
               tmp_total_money,v_total_count,v_surplus_money,'已审核',v_pay_trade_number,client_check_money_user_name,tmp_user_name,
               client_check_money_user_name,temp_check_money_user_rname,sysdate,v_record_number,v_ywjl_username,v_ywy_username,v_mdid,v_credit_balance);
       output_status := '1';
       output_msg := '订单审核成功!';
       UPDATE TBL_ORDER_UNION_PAY
          SET AUDIT_STATE = '1',AUDIT_USER_NAME=client_check_money_user_name,AUDIT_USER_REALNAME=temp_check_money_user_rname,AUDIT_DATE=SYSDATE
        WHERE PAY_TRADE_NUMBER = v_pay_trade_number;
    END IF;
    IF CLIENT_CHECK_MONEY_TYPE = '2' then
       OUTPUT_STATUS := '1';
       OUTPUT_MSG := '订单审核驳回成功!';
       UPDATE TBL_ORDER_UNION_PAY
          SET STATE = '0',AUDIT_STATE = '2',AUDIT_USER_NAME = client_check_money_user_name,AUDIT_USER_REALNAME = temp_check_money_user_rname,AUDIT_DATE=SYSDATE,REJECTED_REASON=CLIENT_REJECTED_REASON
        WHERE PAY_TRADE_NUMBER = v_pay_trade_number;
    END IF;
   ELSE
     output_msg := '操作订单不存在，请检查!';
     RETURN;
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      OUTPUT_MSG := '订单审核操作出现未知错误！';
      ROLLBACK;
END PRO_ORDER_AUDITING;
/

